﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using OneClick.KM.API.Middleware;
using OneClick.KM.Core.Utility;
using OneClick.KM.Logger;
using OneClick.KM.Model.ClientManagement;
using System;
using System.Net;
using System.Net.Http;
using System.Text.Json;

namespace OneClick.KM.API.ApiFilters
{
    public class ApiException : ExceptionFilterAttribute
    {

        /// <summary>
        /// override exception filter
        /// </summary>            
        public override async void OnException(ExceptionContext context)
        {

            string exceptiondetails = string.Empty;
            var requestBodyContent = await RequestResponseService.ReadRequestBody(context.HttpContext.Request);
            var clientId = "";// JsonSerializer.Deserialize<ClientMaster>(requestBodyContent.Result).ClientId;

            string CustomErrorCode = string.Empty; // Need to implement

            if (context == null)
                return;

            string exceptionMessage = string.Empty;
            int linenumber = 0;
            var errorCode = string.Empty;
            if (context.Exception != null)
            {
                linenumber = context.Exception.LineNumber();
                errorCode = "ERR-" + linenumber;

                var controllerName = context.RouteData.Values["controller"];
                var actionName = context.RouteData.Values["action"];
                var ex = context.Exception ?? new Exception("Unkown Error");
                string errorDet = "Controller Name: " + controllerName + " || Action Name: " + actionName;
                errorDet += "\n\r Error code : " + errorCode + "\n\r";
                if (context.Exception.InnerException == null)
                {
                    exceptionMessage = context.Exception.Message;
                    LogHelper.Debug(AppSettings.LogFormatter(ex, errorDet), clientId);
                    LogHelper.Error(exceptionMessage, clientId);
                }
                else
                {
                    exceptionMessage = context.Exception.InnerException.Message;

                    LogHelper.Debug(AppSettings.LogFormatter(ex, errorDet), clientId);
                    LogHelper.Error(exceptionMessage, clientId);

                }
                //  exceptiondetails = AppSettings.LogFormResponse(ex);
            }

            context.Result = new JsonResult(Model.CommonMethods.GetGenericMessage(errorCode));
            context.HttpContext.Response.StatusCode = 335;

            base.OnException(context);


        }
    }

    public static class MyExtensions
    {
        public static int LineNumber(this Exception ex)
        {
            var st = new System.Diagnostics.StackTrace(ex, true);
            // Get the top stack frame
            var frame = st.GetFrame(0);
            // Get the line number from the stack frame
            var line = frame.GetFileLineNumber();

            return line;
        }
    }
}
