﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
namespace OneClick.KM.API.ApiFilters
{
    public class ApiLogging : ActionFilterAttribute
    {
        public override void OnActionExecuted(ActionExecutedContext actionExecutedContext)
        {

           
         
             base.OnActionExecuted(actionExecutedContext);
             if (actionExecutedContext.Exception != null)
             {
                 //_log.Error("System Error", new Exception(actionExecutedContext.Exception.Message));
             }
             else
             {
                 //var serializer = new JavaScriptSerializer();
                 //// we need to do this.
                 //serializer.MaxJsonLength = Int32.MaxValue;
                 //_log.Info("API Response=" + serializer.Serialize(((System.Net.Http.ObjectContent)actionExecutedContext.Response.Content).Value));
                 ActionResult actionResult = (ActionResult)actionExecutedContext.Result;
                // LogHelper.Info("API Response=" + actionResult.ToString(),);

             }

             
        }

        /// <summary>
        /// OnActionExecuting filter implementation.
        /// </summary>
        /// <param name="actionContext"></param>
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            base.OnActionExecuting(context);
            GetRequestHeaders(context);
            var apiType = context.HttpContext.Request.Method;
            var apiName = context.HttpContext.Request.Path;
            var argumentList = context.ActionArguments;
            if (context.ActionArguments.Count > 0)
            {
                if (context.ActionArguments.Values.FirstOrDefault() == null)
                {
                   // LogHelper.Info("ApiType: " + apiType + " ,Api=" + apiName + " ,API Request=Null");
                    //_log.Info("ApiType: " + apiType + " ,Api=" + apiName + " ,API Request=Null");
                }
                else
                {
                     //LogHelper.Info("ApiType: " + apiType + " ,Api=" + apiName + " ,API Request=" + JsonConvert.SerializeObject(argumentList.Values.FirstOrDefault()));
                    //_log.Info("ApiType: " + apiType + " ,Api=" + apiName + " ,API Request=" + new JavaScriptSerializer().Serialize(argumentList.Values.FirstOrDefault()));
                   // Log Header Information
                    string headerValues = GetRequestHeaders(context);
                    //LogHelper.Info(headerValues);

                }
            }
            else
            {
                //LogHelper.Info("ApiType" + apiType + " ,Api=" + apiName + " ,API Request=Null");
                //_log.Info("ApiType" + apiType + " ,Api=" + apiName + " ,API Request=Null");
            }
           
        }

        /// <summary>
        /// Read the request header.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        private string GetRequestHeaders(ActionContext context)
        {
            string headerString = string.Empty;
            var requestHeaders = context.HttpContext.Request.Headers;
            foreach (var header in requestHeaders)
            {
                string key = header.Key;
                List<string> valueList = header.Value.ToList();
                string valueString = string.Empty;
                foreach (var v in valueList)
                {
                    valueString = valueString + v + "-";
                }
                headerString = headerString + key + ": " + valueString + Environment.NewLine;
            }

            return headerString;
        }
    }
}

