﻿using Microsoft.AspNetCore.Mvc;
using OneClick.KM.BAL.V1;
using OneClick.KM.Model;
using OneClick.KM.Model.Account;
using OneClick.KM.Model.ClientManagement;
using System;
using System.Threading.Tasks;

namespace OneClick.KM.API.Controllers
{
    [ApiVersion("2.0")]
    [Route("api/[controller]")]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        public Response responseBody;
        AccountBAL accountBAL;
        public AccountController()
        {
            accountBAL = new AccountBAL();
        }
        #region [Agent]
        [HttpPost]
        public async Task<Response> ValidateLogin(Login request)
       {
            return await new AccountBAL().ValidateLoginBAL(request);

        }
        [HttpPost]
        public async Task<Response> GetActiveSession(ClientBaseModel request)
        {
            return await accountBAL.GetActiveSessionListBAL(request);

        }

        [HttpPost("LogoutSession")]
        public async Task<APIResponseMessage> LogoutSession(BaseModel request)
        {
            return await new AccountBAL().LogoutSessionBAL(request);
        }

        [HttpPost]
        public async Task<Response> ContinueSession(ActiveUserSessionDet request)
        {
           
                return await accountBAL.ContinueSessionBAL(request);
            
        }


        [HttpPost]
        public async Task<Response> SSOValidateLogin(SSOLogin request)
        {
            
            return await accountBAL.SSOValidateLoginBAL(request);
            
        }

        [HttpPost("SaveResetPassword")]
        public async Task<Response>SaveResetPassword(ResetPassword baseModel)
        { 
                return await accountBAL.SaveResetPasswordBAL(baseModel);
        }
        [HttpPost]

        public async Task<APIResponseMessage> UpdatePortalCode(BaseModel request)
        {

            return await accountBAL.UpdatePortalBAL(request);
        }

        [HttpPost("ValidatePortalDLogin")]
        public async Task<Response> ValidatePortalDLogin(PortalDLogin request)
        {
            return await accountBAL.ValidatePortalDLoginBAL(request);
        }
    

        #endregion

            #region [Authoring]

            #region Login
        [HttpPost("login")]
        public async Task<Response> login(LoginProp login)
        {
            if (accountBAL == null)
                accountBAL = new AccountBAL();

          //  Response.Headers.Add("token", "gdfrhfdhdshdsfhedhrtehtrhht_mghjytjtyjytjytjtjt");
            return await accountBAL.LoginBAL(login);
        }
        #endregion

        #region Logout
        [HttpPost]
        public async Task<ActionResult<Response>> Logout(LogoutProp logout)
        {   
           return await accountBAL.LogoutBAL(logout);
            
        }

        #endregion

        #region InsertForgotPassword
       
        [HttpPost("InsertForgotPassword")]
        public async Task<ActionResult<Response>> InsertForgotPassword(InsertForgetPassword request)
        {
            
            return await accountBAL.InsertForgotPasswordBAL(request);
        }

        #endregion
        #region NewUserChangePass
        [HttpPost("NewUserChangePass")]
        public async Task<Response> NewUserChangePass(ChangePassword userdetail)
        {
            return await accountBAL.NewUserChangePassBAL(userdetail);
        }
        #endregion

        #region ResetPassword
        [HttpPost("resetpassword")]
        public async Task<ActionResult<Response>> ResetPassword(UserBasic objuser)
        {

            return await accountBAL.ResetPasswordBAL(objuser);
        }
        #endregion

        #region UpdateUserResertPass
        [HttpPost("UpdateUserResetPassword")]
        public async Task<Response> UpdateUserResetPassword(ChangePassword userdetail)
        {

            return await accountBAL.UpdateUserResetPasswordBAL(userdetail);
        }
        #endregion
        [HttpPost("ChangeExpirePassword")]
        public async Task<Response> ChangeExpirePassword(ChangePassword userdetail)
        {
            return await accountBAL.ChangeExpirePasswordBAL(userdetail);
        }
       

            #region Validate Request

            //public string LoginValidateRequest(LoginProp login)
            //{
            //    if (string.IsNullOrWhiteSpace(login.UserName))
            //    {
            //        return "Username Can't be Empty";
            //    }
            //    if (string.IsNullOrWhiteSpace(login.Password))
            //    {
            //        return "Password Can't be Empty";
            //    }
            //    if (string.IsNullOrWhiteSpace(login.DomainName))
            //    {
            //        return "DomainName Can't be Empty";
            //    }

            //    return "success";



            //}
            //public async Task<Response> GetAllClientInfo(string ShortCode)
            //{
            //  return await accountBAL.GetAllClientInfoBAL(ShortCode);
            //}



            #endregion
            #endregion

        }
}
