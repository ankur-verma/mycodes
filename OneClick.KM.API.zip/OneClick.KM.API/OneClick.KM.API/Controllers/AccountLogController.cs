﻿using Microsoft.AspNetCore.Mvc;
using OneClick.KM.BAL.log.V1;
using OneClick.KM.Model;
using OneClick.KM.Model.Mongo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OneClick.KM.API.Controllers
{
    [ApiVersion("2.0")]
    [Route("api/[controller]")]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AccountLogController
    {
        public AccountLogBAL _AccoumtLogBAL;
        //Getting Instance for cahce management interface
        public AccountLogController()
        {
            _AccoumtLogBAL = new AccountLogBAL();
        }
        [HttpPost("LoginDetailsData")]
        public async Task<Response> LoginDetailsData(UserLoginLogs mlogin)
        {
            return await _AccoumtLogBAL.LoginDetailsDataBAL(mlogin);
        }

        [HttpPost("InsertMacroLogs")]
        public async Task<Response> InsertMacroLogs(MacroLogs macLogs)
        {

            return await _AccoumtLogBAL.InsertMacroLogsBAL(macLogs);
        }

        [HttpPost("InsertUser_Interaction")]
        public async Task<Response> InsertUser_Interaction(UserInteractions usr_int)
        {
            return await _AccoumtLogBAL.InsertUser_InteractionBAL(usr_int);
        }

        [HttpPost("GetUserInteractions")]
        public async Task<Response> GetUserInteractions(UserInteractions usr_int)
        {
            return await _AccoumtLogBAL.GetUserInteractionsBAL(usr_int);
        }


        [HttpPost("GetInteractionsById")]
        public async Task<Response> GetInteractionsById(UserInteractions usr_int)
        {
            return await _AccoumtLogBAL.GetInteractionsByIdBAL(usr_int);
        }
        [HttpPost("InsertMicroUtilVisit")]
        public async Task<Response> InsertMicroUtilVisit(MicroUtility objMicroUtil)
        {
            return await _AccoumtLogBAL.InsertMicroUtilVisitBAL(objMicroUtil);
        }

        [HttpPost("UpdateArticleLog")]
        public async Task<Response> UpdateArticleLog(UserInteractions usr_int)
        {
            return await _AccoumtLogBAL.UpdateArticleLogBAL(usr_int);
        }

        [HttpPost("InsertErrorLogs")]
        public async Task<Response> InsertErrorLogs([FromBody] ErrorLogs errLogs)
        {
            return await _AccoumtLogBAL.InsertErrorLogsBAL(errLogs);
        }

        [HttpPost("GetInteractionsDetailById")]
        public async Task<Response> GetInteractionsDetailById(GHStepInteractions mGHStepInteractions)
        {
            return await _AccoumtLogBAL.GetInteractionsDetailByIdBAL(mGHStepInteractions);

        }
    }

    }
