﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;

using OneClick.KM.Core.Utility;
using OneClick.KM.Logger;

using OneClick.KM.Model.ClientManagement;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace OneClick.KM.API.Middleware
{
    public class ApiLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        public ApiLoggingMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext httpContext)
        {
			string clientId = string.Empty;
			string clientShortCode = string.Empty;
			bool IsValid = false;
			try
            {
                var request = httpContext.Request;
                if (request.Path.StartsWithSegments(new PathString("/api")))
                {                   var stopWatch = Stopwatch.StartNew();
                    var requestTime = DateTime.UtcNow;

					var requestBodyContent = await RequestResponseService.ReadRequestBody(request);
                    //LogHelper.Info(AppSettings.APILogFormatter(requestTime, stopWatch.ElapsedMilliseconds, 1222, request.Method, request.Path, request.QueryString.ToString(), requestBodyContent, requestBodyContent), clientId);
                    clientId = JsonSerializer.Deserialize<ClientMaster>(requestBodyContent).ClientId;
                    if (!String.IsNullOrEmpty(clientId))
                    {
                        IsValid = await ValidateClientId(clientId);
                    }
                    else
                    {
                        clientShortCode = JsonSerializer.Deserialize<ClientMaster>(requestBodyContent).ClientShortCode;
                        if (!String.IsNullOrEmpty(clientShortCode))
                        {
                            IsValid = await ValidateClientShortCode(clientShortCode);
                        }
                        else 
                        {
                            var x = request.Path;

                        }
                    }
                   
                   if (IsValid)
                    {
                        var originalBodyStream = httpContext.Response.Body;
                        using (var responseBody = new MemoryStream())
                        {
                            var response = httpContext.Response;
                            response.Body = responseBody;
                            await _next(httpContext);
                            stopWatch.Stop();
                            string responseBodyContent = null;
                            responseBodyContent = await RequestResponseService.ReadResponseBody(response);
                            await responseBody.CopyToAsync(originalBodyStream);
                            LogHelper.Info(AppSettings.APILogFormatter(requestTime, stopWatch.ElapsedMilliseconds, response.StatusCode, request.Method, request.Path, request.QueryString.ToString(), requestBodyContent, responseBodyContent), clientId);
                        }
                    }
					else
					{
						Model.Response error = new Model.Response();
						error.Error.ErrorCode = "-999";
						error.Error.ErrorDetail = "Client does not exists or subscription expired !";
						var res = Newtonsoft.Json.JsonConvert.SerializeObject(error);
						var originalBodyStream = httpContext.Response.Body;
						using (var responseBody = res.ToStream())
						{
							var response = httpContext.Response;							
							response.Body = responseBody;
							response.Headers.Add("Validation","-1");
							stopWatch.Stop();
							string responseBodyContent = null;
							responseBodyContent = await RequestResponseService.ReadResponseBody(response);
							await responseBody.CopyToAsync(originalBodyStream);
							LogHelper.Info(AppSettings.APILogFormatter(requestTime, stopWatch.ElapsedMilliseconds, response.StatusCode, request.Method, request.Path, request.QueryString.ToString(), requestBodyContent, responseBodyContent), clientId);
						}
						// await _next(httpContext);
					}
				}
                else
                {
                    await _next(httpContext);
                }
            }
            catch (Exception)
            {
                await _next(httpContext);
            }
        }

        private async Task<bool> ValidateClientId(string clientId)
        {
            return await Task.Run(() =>
            {
               var obj = Caching.CacheHelper.ClientDetailFromCache(clientId);
				if (obj == null)
				{
					return false;
				}
                return true;
            });
        }
		private async Task<bool> ValidateClientShortCode(string clientShortCode)
		{
			return await Task.Run(() =>
			{
				var obj = Caching.CacheHelper.GetClientId(clientShortCode);
				if (obj == null)
				{
					return false;
				}
				return true;
			});
		}

	}

    public static class ExtenssionMethod
    {
        public static Stream ToStream(this string str)
        {
            MemoryStream stream = new MemoryStream();
            StreamWriter writer = new StreamWriter(stream);
            writer.Write(str);
            writer.Flush();
            stream.Position = 0;
            return stream;
        }
    }

}
