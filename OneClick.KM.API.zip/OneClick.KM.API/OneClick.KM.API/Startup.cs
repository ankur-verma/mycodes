﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Serialization;
using OneClick.KM.API.Middleware;
using OneClick.KM.Core;

namespace OneClick.KM.API
{
	public class Startup
	{
		public Startup(IConfiguration configuration)
		{
			Configuration = configuration;
		}

		public IConfiguration Configuration { get; }

		// This method gets called by the runtime. Use this method to add services to the container.
		public void ConfigureServices(IServiceCollection services)
		{
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2).AddJsonOptions(options => options.SerializerSettings.ContractResolver = new DefaultContractResolver());
					
			services.AddMvc(options => options.Filters.Add(new ApiFilters.ApiException())).AddViewLocalization()
				.AddDataAnnotationsLocalization();
			services.AddApiVersioning
                (o =>
                {
                    o.ReportApiVersions = true;
                    o.AssumeDefaultVersionWhenUnspecified = true;
                    o.DefaultApiVersion = new ApiVersion(2, 0);
                    o.ApiVersionReader = new HeaderApiVersionReader("api-version");					
                    //if you want to allow any of the versions if not found
                    // o.ApiVersionSelector = new CurrentImplementationApiVersionSelector(o);
                });
			CultureInfo newCulture = (CultureInfo)System.Threading.Thread.CurrentThread.CurrentCulture.Clone();
			newCulture.DateTimeFormat.ShortDatePattern = "dd-mm-yyyy";
			newCulture.DateTimeFormat.DateSeparator = "-";			
			services.Configure<RequestLocalizationOptions>(
				options =>
				{
					var supportedCultures = new List<CultureInfo>
						{
							new CultureInfo("en-US"),
							new CultureInfo("de-CH"),
							new CultureInfo("fr-CH"),
							new CultureInfo("it-CH"),
							new CultureInfo(newCulture.DateTimeFormat.ShortDatePattern),
							new CultureInfo(newCulture.DateTimeFormat.DateSeparator)
						};
					options.DefaultRequestCulture = new RequestCulture(culture: "en-US", uiCulture: "en-US");
					options.SupportedCultures = supportedCultures;
					options.SupportedUICultures = supportedCultures;					
				});
			services.AddHttpClient();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
		{
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for 
                // production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
			 app.UseMiddleware<ApiLoggingMiddleware>();
            //app.UseDefaultFiles();
             app.UseStaticFiles();
            //app.UseHttpsRedirection();
            
            app.UseMvc(routes =>
            {
                routes.MapRoute("default", "{controller=Home}/{action=Index}/{id?}");
            });

            //app.Run(async (context) =>
            //{
            //    await context.Response.w("hello world <br>");
            //});
        }
		//public static IConfiguration GetConfig()
		//{
		//	var builder = new ConfigurationBuilder().SetBasePath(System.AppContext.BaseDirectory).AddJsonFile("appSettings.js", optional: true, reloadOnChange: true);			
		//	return builder.Build();
		//}
	}
}
