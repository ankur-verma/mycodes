﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.APICall
{
    public enum APIMethodType
    {
        GET,
        POST,
        DELETE,
        PATCH,
        PUT
    }
}
