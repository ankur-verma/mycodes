﻿using OneClick.KM.APICall;
using OneClick.KM.Core.Utility;
using OneClick.KM.Logger;
using OneClick.KM.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.APICall
{
    public static class ApiCall
    {
        private static HttpClient client = new HttpClient();

    static ApiCall()
    {
        client.DefaultRequestHeaders.Add("api-version", "2.0");
        client.DefaultRequestHeaders.Add("Authorization", string.Format("Value {0}", "0neC!licKJi0"));
        client.DefaultRequestHeaders.Add("UserId", "295");
        client.DefaultRequestHeaders.Add("sessionId", "1000");
        client.DefaultRequestHeaders.Add("TabSessionId", "1000XZ");
        client.DefaultRequestHeaders.ConnectionClose = true;
    }
    public static async Task<ErrorProp> CallWebApi(ApiProp objprop)
    {
            return await Task.Run(() =>
            {
              ErrorProp errReturn = new ErrorProp();                        
              string url = Path.Combine(objprop.Api_Uri, objprop.Api_Name);                
                try
                {
                    HttpResponseMessage response = null;					
					var postContent = new StringContent(objprop.DataForPost, System.Text.Encoding.UTF8, objprop.ContentType);
					string requestLog = "APIName: " + objprop.Api_Uri + "/" + objprop.Api_Name + "\n\rRequested Data: " + objprop.DataForPost;
					LogHelper.Info(requestLog, objprop.ClientId);
					if (objprop.Method == APIMethodType.GET.ToString())
                    {
                        response = client.GetAsync(url).Result;
                    }
                    else if (objprop.Method.ToUpper() == APIMethodType.POST.ToString())
                    {
                        //var postContent = new StringContent(objprop.DataForPost, System.Text.Encoding.UTF8, objprop.ContentType);
                        response = client.PostAsync(url, postContent).Result;
                    }
                    else if (objprop.Method == APIMethodType.PUT.ToString())
                    {
                       // var postContent = new StringContent(objprop.DataForPost, System.Text.Encoding.UTF8, objprop.ContentType);
                        response = client.PutAsync(url, postContent).Result;

                    }
                    else if (objprop.Method == APIMethodType.DELETE.ToString())
                    {
                        response = client.DeleteAsync(url).Result;

                    }
                    else if (objprop.Method.ToUpper() == APIMethodType.PATCH.ToString())
                    {
                       // var postContent = new StringContent(objprop.DataForPost, System.Text.Encoding.UTF8, objprop.ContentType);
                        var method = new HttpMethod(objprop.Method);
                        var request = new HttpRequestMessage(method, url)
                        {
                            Content = postContent
                        };
                        response = client.SendAsync(request).Result;
                    }
                    var result = response.Content.ReadAsStringAsync().Result;
                    if (response.IsSuccessStatusCode)
                    {
						string log = "Response:-APIName: " + objprop.Api_Uri + "/" + objprop.Api_Name + "\r\nResponse Data: " + result;
						LogHelper.Info(log, objprop.ClientId);
						errReturn.ErrorCode = "0";
                        errReturn.ErrorDetail = "Success";
                    }
                    else
                    {
                        string ErrorDetails = string.Empty;
                        if (response.StatusCode.ToString() == "BadRequest" || response.StatusCode.ToString() == "400")
                        {
                            errReturn.ErrorCode = (objprop.APIFrom == "ES") ? "ES_ERR_400" : "API_ERR_400";
                            errReturn.ErrorDetail = "There is some issue occured, please contact to Application Administrator.";

                            ErrorDetails = response.Content.ReadAsStringAsync().Result;
                        }
                        else if (response.StatusCode.ToString() == "NotFound" || response.StatusCode.ToString() == "404")
                        {
                            errReturn.ErrorCode = (objprop.APIFrom == "ES") ? "ES_ERR_404" : "API_ERR_404";
                            errReturn.ErrorDetail = "There is some issue occured, please contact to Application Administrator.";
                            ErrorDetails = response.Content.ReadAsStringAsync().Result;
                        }
                        else if (response.StatusCode.ToString() == "InternalServerError" || response.StatusCode.ToString() == "500")
                        {
                            errReturn.ErrorCode = (objprop.APIFrom == "ES") ? "ES_ERR_500" : "API_ERR_500";
                            errReturn.ErrorDetail = "There is some issue occured, please contact to Application Administrator.";
                            ErrorDetails = response.Content.ReadAsStringAsync().Result;
                        }
                        else if (response.StatusCode.ToString().Contains("Gateway") || response.StatusCode.ToString().Contains("BadGateway") || response.StatusCode.ToString() == "502")
                        {
                            errReturn.ErrorCode = (objprop.APIFrom == "ES") ? "ES_ERR_502" : "API_ERR_502";
                            errReturn.ErrorDetail = "There is some issue occured, please contact to Application Administrator.";
                            ErrorDetails = response.Content.ReadAsStringAsync().Result;
                        }
                        else if (response.StatusCode.ToString() == "ServiceUnavailable" || response.StatusCode.ToString() == "503")
                        {
                            errReturn.ErrorCode = (objprop.APIFrom == "ES") ? "ES_ERR_503" : "API_ERR_503";
                            errReturn.ErrorDetail = "There is some issue occured, please contact to Application Administrator.";
                            ErrorDetails = response.Content.ReadAsStringAsync().Result;
                        }
                        else if (response.StatusCode.ToString() == "334") // For Data Base Error
                        {
                            //errReturn.ErrorCode = "DB_ERR_01017";
                            errReturn.ErrorCode = response.Content.ReadAsStringAsync().Result.Substring(1, response.Content.ReadAsStringAsync().Result.IndexOf(":") - 1);
                            errReturn.ErrorDetail = "There is some issue occured, please contact to Application Administrator.";
                            ErrorDetails = response.Content.ReadAsStringAsync().Result.Substring(response.Content.ReadAsStringAsync().Result.IndexOf(":") + 1);
                        }
                        else if (response.StatusCode.ToString() == "335") // for Mogo DB Errors
                        {
                            // errReturn.ErrorCode = "API_MD_ERR_101";
                            errReturn.ErrorCode = response.Content.ReadAsStringAsync().Result.Substring(1, response.Content.ReadAsStringAsync().Result.IndexOf(":") - 1);
                            errReturn.ErrorCode = ((errReturn.ErrorCode.Length <= 15) ? errReturn.ErrorCode : errReturn.ErrorCode.Substring(0, 15));
                            errReturn.ErrorDetail = "There is some issue occured, please contact to Application Administrator.";
                            ErrorDetails = response.Content.ReadAsStringAsync().Result.Substring(response.Content.ReadAsStringAsync().Result.IndexOf(":") + 1);
                        }
                        else
                        {
                            errReturn.ErrorCode = (objprop.APIFrom == "ES") ? "ES_ERR_" + response.StatusCode.ToString() : "API_ERR_" + response.StatusCode.ToString();
                            errReturn.ErrorDetail = response.Content.ReadAsStringAsync().Result;
                            ErrorDetails = response.Content.ReadAsStringAsync().Result;
                        }
						//ErrorLog.Error(errReturn.ErrorCode + " : " + response.ReasonPhrase.ToString() + " : Message- " + ErrorDetails + " : URL- " + response.RequestMessage.RequestUri);
						LogHelper.Info("Response:-APIName: " + objprop.Api_Uri + "/" + objprop.Api_Name + objprop.UserId + objprop.UserName + "\r\nResponseData: " + errReturn.ErrorCode + " || " + ErrorDetails, objprop.ClientId);
                       //UpdateLogInAPI(errReturn.ErrorCode, url, objprop.UserId, objprop.UserName, System.DateTime.Now, ErrorDetails, "", "", "", ErrorDetails);
                    }
                    errReturn.ReturnValue = result;
                }
                catch (AggregateException ex)
                {
                    errReturn.ErrorCode = (objprop.APIFrom == "ES") ? "ES_ERR_101" : "API_ERR_101";
                    errReturn.ReturnValue = "error";
                    //WebAPILogs.Debug("Response:-APIName: " + objprop.Api_Uri + "/" + objprop.Api_Name + "\r\nResponseData: " + ctl.LogWriter(ex));
                    //ErrorLog.Debug(errReturn.ErrorCode + " : From Exceptions Block : Message- " + ex.Message + " : InnerException- " + ex.InnerException + " : URL- " + objprop.Api_Uri + "/" + objprop.Api_Name + objprop.UserId + objprop.UserName);
                    //UpdateLogInAPI(errReturn.ErrorCode, url, objprop.UserId, objprop.UserName, System.DateTime.Now, ex.Message, (ex.InnerException != null) ? Convert.ToString(ex.InnerException) : "", ex.StackTrace, ex.Source, "");
                    errReturn.ErrorDetail = "There is some issue occured, please contact to Application Administrator.";
                    LogHelper.Debug(Core.Utility.AppSettings.LogFormatter(ex), objprop.ClientId);
                    LogHelper.Error(ex.Message, objprop.ClientId);

                }
                catch (HttpRequestException ex)
                {
                    
                    errReturn.ErrorCode = (objprop.APIFrom == "ES") ? "ES_ERR_102" : "API_ERR_102";
                    errReturn.ReturnValue = "error";
                    //WebAPILogs.Debug("Response:-APIName: " + objprop.Api_Uri + "/" + objprop.Api_Name + "\r\nResponseData: " + ctl.LogWriter(ex));
                    //ErrorLog.Debug(errReturn.ErrorCode + " : From Exceptions Block : Message- " + ex.Message + " : InnerException- " + ex.InnerException + " : URL- " + objprop.Api_Uri + "/" + objprop.Api_Name + objprop.UserId + objprop.UserName);
                    //UpdateLogInAPI(errReturn.ErrorCode, url, objprop.UserId, objprop.UserName, System.DateTime.Now, ex.Message, (ex.InnerException != null) ? Convert.ToString(ex.InnerException) : "", ex.StackTrace, ex.Source, "");
                    errReturn.ErrorDetail = "There is some issue occured, please contact to Application Administrator.";
                    LogHelper.Debug(Core.Utility.AppSettings.LogFormatter(ex), objprop.ClientId);
                    LogHelper.Error(ex.Message, objprop.ClientId);
                }
                catch (Exception ex)
                {
                    errReturn.ErrorCode = (objprop.APIFrom == "ES") ? "ES_ERR_103" : "API_ERR_103";
                    errReturn.ReturnValue = "error";
                    //WebAPILogs.Error("Response:-APIName: " + objprop.Api_Uri + "/" + objprop.Api_Name + "\r\nResponseData: " + ctl.LogWriter(ex));
                    //ErrorLog.Error(errReturn.ErrorCode + " : From Exceptions Block : Message- " + ex.Message + " : InnerException- " + ex.InnerException + " : URL- " + objprop.Api_Uri + "/" + objprop.Api_Name);
                    //UpdateLogInAPI(errReturn.ErrorCode, url, objprop.UserId, objprop.UserName, System.DateTime.Now, ex.Message, (ex.InnerException != null) ? Convert.ToString(ex.InnerException) : "", ex.StackTrace, ex.Source, "");
                    errReturn.ErrorDetail = "There is some issue occured, please contact to Application Administrator.";
                    LogHelper.Debug(Core.Utility.AppSettings.LogFormatter(ex), objprop.ClientId);
                    LogHelper.Error(ex.Message, objprop.ClientId);
                }
				
				return errReturn;

            });
    }
    //public void LogError(Exception ex)
    //{
    //	StringBuilder msg = new StringBuilder();
    //	while (ex != null)
    //	{
    //		msg.Append(ex.GetType().FullName);
    //		msg.Append("Message : " + ex.Message);
    //		msg.Append("StackTrace : " + ex.StackTrace);
    //		msg.Append("InnerException : " + ex.InnerException);
    //		msg.Append("Source : " + ex.Source);
    //		msg.Append("HResult : " + ex.HResult);
    //		ex = ex.InnerException;
    //	}
    //	_log.Error(msg.ToString());
    //}
    //private static string GetRequestHeaders(ApiProp objprop)
    //{
    //    // Note you can replace the type names sucha as string, HttpRequestHeaders, List<KeyValuePair<string, IEnumerable<string>>>
    //    // with var keyword where ever possible for readability.
    //    string headerString = string.Empty;
    //    List<ApiHeader> lstheader = new List<ApiHeader>();
    //    lstheader = objprop.HeaderList;
    //    foreach (var header in lstheader)
    //    {
    //        string key = header.RequestHeader;
    //        string valueList = header.RequestHeaderValue;
    //        headerString = headerString + key + ": " + valueList + Environment.NewLine;
    //    }
    //    return headerString;
    //}

    //public static ErrorProp UpdateLogInAPI(string Code, string URL, string Userid, string Username, DateTime DateTime, string Message, string InnerException, string StackTrac, string Source, string ErrorDetails)
    //{
    //    var localIP = AppSettings.GetLocalIPAddress();
    //    try
    //    {
    //        ErrorLogs obj = new ErrorLogs();
    //        obj.ErrorCode = Code;
    //        obj.Url = URL;
    //        obj.UserId = Userid;
    //        obj.UserName = Username;
    //        obj.ErrorDate = DateTime;
    //        obj.Message = Message;
    //        obj.InnerException = InnerException;
    //        obj.StackTrace = StackTrac;
    //        obj.Source = Source;
    //        obj.ErrorDetails = ErrorDetails;
    //        obj.SourceIP = localIP;
    //        ApiProp apiRequest = new ApiProp();
    //        apiRequest.Api_Name = ApiMethodNames.ErrorLogInsert;
    //        apiRequest.Method = APIMethodType.POST.ToString();
    //        apiRequest.DataForPost = JsonConvert.SerializeObject(obj);
    //        string url = Path.Combine(apiRequest.Api_Uri, apiRequest.Api_Name);
    //        HttpResponseMessage response = null;
    //        var postContent = new StringContent(apiRequest.DataForPost, System.Text.Encoding.UTF8, apiRequest.ContentType);
    //        response = client.PostAsync(url, postContent).Result;
    //    }
    //    catch (Exception ex)
    //    {
    //        ErrorLog.Error("API_ERR_UpDateAPILogs : From Exceptions Block : Message- " + ex.Message + " : InnerException- " + ex.InnerException + " : URL- " + URL + " : SOurce IP- " + localIP);
    //    }
    //    return null;
    //}
}
}
