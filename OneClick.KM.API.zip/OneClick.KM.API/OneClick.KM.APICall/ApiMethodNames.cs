﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.APICall
{
    public class ApiMethodNames
    {
        #region [ Articles ]

        public const string ArticleList = "api/GetArticles";
        public const string ArticleDetails = "api/article/ArticleDetail";
        public const string GroupLinkContent = "api/article/ArticleGroupContent";
        public const string BreadCrumbLink = "api/article/GetBreadcrumb";

        public const string ArticlesByMenu = "api/GetArticlesByMenu";
        public const string ArticleAttach = "api/GetArticleAttach";
        #endregion

        public const string TopicTree = "api/GetTopicTree";
        // public const string Login = "api/Login";
        public const string News = "api/GetNews";
        public const string Menu = "api/GetMenu";
        public const string UserInteraction = "api/User/GetUserInteractions";
        public const string InteractionById = "api/User/GetInteractionsById";
        public const string InteractionDetailById = "api/User/GetInteractionDetailById";
        public const string Logout = "api/Logout";
        public const string SaveUserInteraction = "api/User/InsertUser_Interaction";
        public const string SaveMicorUtility = "api/User/InsertMicroUtilVisit";
        public const string Attachment_Download_SubUrl = "DownloadAttachment?attachmentcode=";
        #region [ Suggestions ]
        public const string SuggestDelete = "api/SuggestDelete";
        // public const string MysubmitSuggestions= "api/MySuggestions";
        public const string Suggestions = "api/SaveFeedbackMSTDTL";
        public const string Suggestion = "api/MySuggestion";

        public const string SuggestionApprove = "api/SuggestionApproval";
        #endregion

        #region [ StoreLocator ]
        public const string JioState = "api/GetState";
        public const string StoreLocality = "api/StoreLocality";
        public const string StorLocator = "api/StorLocator";
        public const string JioCity = "api/GetCity";

        #endregion

        #region [ Links ]

        public const string UseFulLinks = "api/GetUsefulLinks";
        public const string QuickLinks = "api/GetQuickLinks";
        public const string QuickLinksGroup = "api/Link/QuickLinkGroup";
        #endregion

        #region [ Guided Help]

        public const string GuidedHelp = "api/GuidedHelp";
        public const string GuidedHelpQA = "api/GHGetQA";
        public const string GuidedHelpArticleDTL = "api/GetGHArticleDetails";

        #endregion

        #region [ FeedBack]
        public const string SaveFeedBack = "api/SaveFeedBack";
        public const string FeedBackQuestion = "api/GetFeedBackQuestion";
        public const string FeedBackDetails = "api/SaveFeedBackDetails";
        public const string FeedBackMaster = "api/SaveFeedbackMaster";
        public const string FeedbackDetailV = "api/SaveFeedbackDetailV1";

        #endregion

        #region [ Bookmarks ]
        public const string BookMarkList = "api/GetBookMarkList";
        public const string SaveBookMark = "api/SaveBookMark";
        public const string BookMarkByMenuCode = "api/GetBookMarksByMenuID";
        public const string DeleteBookMark = "api/BookmarkDelete";
        #endregion

        #region [ Search ]

        /// <summary>
        /// For advance search, getting topics
        /// "api/Search/Topic"
        /// </summary>
        public const string SearchTopicList = "api/Search/Topic";

        /// <summary>
        /// "api/Search/Configuration" to get search configuration
        /// Based on configuration elastic search work
        /// </summary>
        public const string SearchConfiguration = "api/Search/Configuration";

        /// <summary>
        /// api/elasticsearch/searchArticleSuggestion
        /// </summary>
        public const string GetTitleSuggestion = "api/elasticsearch/searchArticleSuggestion";

        /// <summary>
        /// Get keyword suggestion
        /// api/elasticsearch/searchKeywordSuggestion
        /// </summary>
        public const string GetSuggestion = "api/elasticsearch/searchKeywordSuggestion";
        /// <summary>
        /// api/elasticsearch/search
        /// </summary>
        public const string SearchArticles = "api/elasticsearch/search";

        /// <summary>
        /// api/elasticsearch/updatehitcount
        /// </summary>
        public const string SaveArticlesReadCount = "api/elasticsearch/updatehitcount";

        /// <summary>
        /// api/elasticsearch/addsuggestion
        /// </summary>
        public const string AddSuggestion = "api/elasticsearch/addsuggestion";
        public const string SearchData = "api/SearchInfo/SearchData";

        public const string MostUsedFaq = "api/elasticsearch/mostusedfaq";

        #endregion

        #region [Submit Suggestions]
        // public const string SuggestionApproval = "api/SuggestionApproval";
        #endregion

        #region[Login]
        public const string Login = "api/Login";
        public const string SSOLogin = "api/SSOLogin";
        public const string PortalDLogin = "api/PortalDLogin";
        public const string ActiveSessions = "api/ActiveSessions";
        public const string LoginLogs = "api/LoginLogs/LoginDetailsData";
        public const string ChangePassword = "api/SaveChangePassword";
        public const string HintQuestion = "api/GetHintQuestions";
        public const string VerifyPortalName = "api/GetPortalName/UserPortal";
        #endregion

        #region[Errors]
        public const string ErrorLogInsert = "api/ErrorLog/InsertErrorLogs";
        #endregion

        #region[MacroLog]
        public const string InsertMacroLogs = "api/MacroLog/InsertMacroLogs";
        #endregion

       // ImagebankApi

    }
}
