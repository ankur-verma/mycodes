﻿using OneClick.KM.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.APICall
{
   public class ApiProp
    {
        public ApiProp()
        {
            Api_Name = string.Empty;
            HeaderList = new List<ApiHeader>();
            ContentType = "application/json";
            Method = APIMethodType.POST.ToString();           
        }
        public string Api_Uri { get; set; }
        public string Api_Name { get; set; }
        public string ClientId { get; set; }
        public string ContentType { get; set; }
        public List<ApiHeader> HeaderList { get; set; }
        public String Method { get; set; }
        public string DataForPost { get; set; }
        public string APIFrom { get; set; }
        public string UserId { get; set; }
        public string UserName { get; set; }

       
    }
    public class ApiHeader
    {
        public string RequestHeader { get; set; }
        public string RequestHeaderValue { get; set; }
    }
    //public class ErrorProp
    //{
    //    public string ErrorCode { get; set; }
    //    public string ErrorDetail { get; set; }
    //    public string ReturnValue { get; set; }
    //    public string MessageType { get; set; }
    //    public string Redirect { get; set; }
    //    public string ActualError { get; set; }

    //}
}
