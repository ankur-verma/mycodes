﻿using Newtonsoft.Json;
using OneClick.KM.Core;
using OneClick.KM.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.APICall
{
   public static class PushDataToElasticSearch
    {
        public static async Task<ErrorProp> PushToElasticSearch(string datatopush, string Key, string ClientId)
        {
            ErrorProp err = new ErrorProp();


            //CacheModel _CacheModel = new CacheModel();
            //_CacheModel.ClientId = ClientId;
            //_CacheModel.DataToBeCached = datatopush;
            //_CacheModel.Key = Key;
            //_CacheModel.TimeInMinutes =  Convert.ToInt32(ConfigHelper.CacheTime);;
            //var SerializedRedisModelData = JsonConvert.SerializeObject(_CacheModel);

            //ApiProp apiProp = new ApiProp();
            //apiProp.ClientId = ClientId;
            //apiProp.Api_Uri = ConfigHelper.RedisUri;
            //apiProp.Api_Name = AppKeys.RedisSendObject;
            //apiProp.Method = OneClick.KM.APICall.APIMethodType.POST.ToString(); //
            //apiProp.DataForPost = SerializedRedisModelData;//  Serialise Model into json                           
            //err = await ApiCall.CallWebApi(apiProp); //  Api call for Redis
            return err;
        }
    }
}
