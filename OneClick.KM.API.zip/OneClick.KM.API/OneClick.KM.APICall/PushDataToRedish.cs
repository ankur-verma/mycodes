﻿using Newtonsoft.Json;
using OneClick.KM.Core;
using OneClick.KM.Model;
using OneClick.KM.Model.Caching;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.APICall
{
    public static class PushDataToRedish
    {
        public static async Task<ErrorProp> PushArticleToRedis(string datatopush, string Key, string ClientId)
        {
            ErrorProp err = new ErrorProp();


            CacheModel _CacheModel = new CacheModel();
            _CacheModel.ClientId = ClientId;
            _CacheModel.DataToBeCached = datatopush;
            _CacheModel.Key = Key;
            _CacheModel.TimeInMinutes = Convert.ToInt32(ConfigHelper.CacheTime); 
            var SerializedRedisModelData = JsonConvert.SerializeObject(_CacheModel);

            ApiProp apiProp = new ApiProp();
            apiProp.ClientId = ClientId;
            apiProp.Api_Uri = ConfigHelper.RedisUri;
            apiProp.Api_Name = AppKeys.RedisSendObject;
            apiProp.Method = OneClick.KM.APICall.APIMethodType.POST.ToString(); //
            apiProp.DataForPost = SerializedRedisModelData;//  Serialise Model into json                           
            err = await ApiCall.CallWebApi(apiProp); //  Api call for Redis
            return err;
        }        



        #region [Add Guided help scenario details to Cache]
        public static async Task<ErrorProp> DataPushToCache(string key, object dataToBePushed, string clientId, int timeToPreserve = 0)
        {
            ErrorProp errProp = new ErrorProp();
            string scenarioKey = string.Empty;
            try
            {
                CacheModel cacheModel = new CacheModel();

                if (timeToPreserve == 0)
                {
                    cacheModel.TimeInMinutes = Convert.ToInt32(ConfigHelper.CacheTime);
                }
                else
                {
                    cacheModel.TimeInMinutes = timeToPreserve;
                }

                cacheModel.ClientId = clientId; // why it is required ?
                cacheModel.DataToBeCached = JsonConvert.SerializeObject(dataToBePushed);
                cacheModel.Key = key;
                var SerializedModelData = JsonConvert.SerializeObject(cacheModel);
                ApiProp apiProp = new ApiProp();
                apiProp.ClientId = clientId;
                apiProp.Api_Uri = ConfigHelper.RedisUri;
                apiProp.Api_Name = AppKeys.RedisSendObject;
                apiProp.Method = OneClick.KM.APICall.APIMethodType.POST.ToString(); //
                apiProp.DataForPost = SerializedModelData;//  Serialise Model into json                           
                errProp = await ApiCall.CallWebApi(apiProp); //  Api call for Redis			
            }
            catch (Exception ex)
            {
                errProp.ErrorCode = "-1";
                errProp.ErrorDetail = ex.ToString();
            }
            return errProp;
        }
        public static async Task<ErrorProp> RemoveDataFromCache(string key, string clientId)
        {
            ErrorProp errProp = new ErrorProp();
            string scenarioKey = string.Empty;
            try
            {
                CacheModel cacheModel = new CacheModel();
                cacheModel.Key = key;
                cacheModel.ClientId = clientId;
                var SerializedModelData = JsonConvert.SerializeObject(cacheModel);
                ApiProp apiProp = new ApiProp();
                apiProp.ClientId = clientId;
                apiProp.Api_Uri = ConfigHelper.RedisUri;
                apiProp.Api_Name = AppKeys.RedisDelObject;
                apiProp.Method = OneClick.KM.APICall.APIMethodType.POST.ToString(); //
                apiProp.DataForPost = SerializedModelData;//  Serialise Model into json                           
                errProp = await ApiCall.CallWebApi(apiProp); //  Api call for Redis			
            }
            catch (Exception ex)
            {
                errProp.ErrorCode = "-1";
                errProp.ErrorDetail = ex.ToString();
            }
            return errProp;
        }
        #endregion


    }



}
