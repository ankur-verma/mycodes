﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.APICall.Utility
{
    public class CustomLogs
    {
        public string LogWriter(Exception ex)
        {
            StringBuilder msg = new StringBuilder();
            while (ex != null)
            {
                msg.Append("\r\n");
                msg.Append(DateTime.Now.ToString());
                msg.Append("\r\n" + ex.GetType().FullName);
                msg.Append("\r\nMessage : " + ex.Message);
                msg.Append("\r\nStackTrace : " + ex.StackTrace);
                msg.Append("\r\nInnerException : " + ex.InnerException);
                msg.Append("\r\nSource : " + ex.Source);
                msg.Append("\r\nHResult : " + ex.HResult);
                //msg.Append("\r\n"+ex.TargetSite);
                ex = ex.InnerException;
            }
            return msg.ToString();
        }
        public string WithoutTrace(Exception ex)
        {
            StringBuilder msg = new StringBuilder();
            while (ex != null)
            {
                msg.Append("\r\n");
                msg.Append(DateTime.Now.ToString());
                msg.Append("\r\n" + ex.GetType().FullName);
                msg.Append("\r\nMessage : " + ex.Message);
                //  msg.Append("\r\nStackTrace : " + ex.StackTrace);
                msg.Append("\r\nInnerException : " + ex.InnerException);
                msg.Append("\r\nSource : " + ex.Source);
                msg.Append("\r\nHResult : " + ex.HResult);
                //msg.Append("\r\n"+ex.TargetSite);
                ex = ex.InnerException;
            }
            return msg.ToString();

        }
    }
}
