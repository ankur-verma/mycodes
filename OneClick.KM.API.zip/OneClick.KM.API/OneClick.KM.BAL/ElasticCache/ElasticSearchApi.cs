﻿using Newtonsoft.Json;
using OneClick.KM.APICall;
using OneClick.KM.Core.Security;
using OneClick.KM.Core.Utility;
using OneClick.KM.Model;
using OneClick.KM.Model.ElasticCache;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.BAL.ElasticCache
{
    class ElasticSearchApi
    {
        //public static ErrorProp UpdateElasticSearch(ElasticSearchProp jsonBody, string userid, string sessionid)
        //{
        //    String elasticUrl = CAppSettings.GetConfigurationValue(ErrorCodeElasticSearch.ElasticSearchInsertURL);//("ElasticSearchInsertURL");

        //    if (elasticUrl != null && !string.IsNullOrWhiteSpace(elasticUrl))
        //    {
        //        try
        //        {
        //            // Prepare API Request Parameters
        //            ApiProp apiRequest = new ApiProp();
        //            apiRequest.Api_Uri = elasticUrl;
        //            apiRequest.Api_Name = "";
        //            apiRequest.HeaderList = PrepareRequestHeaderFeilds(sessionid, userid);
        //            apiRequest.DataForPost = JsonConvert.SerializeObject(jsonBody);

        //            Logger.ESLog.Info(" Initiating Elastic search. Request URL: " + apiRequest.Api_Uri + ", Request Data:" + apiRequest.DataForPost.ToString());

        //            //ElasticSearchApiCall connection = new ElasticSearchApiCall();

        //            // Accept Web Response
        //            ErrorProp result = connection.CallWebApi(apiRequest);
        //            if (result.ErrorCode == "0")
        //            {
        //                if (result.ReturnValue != null && result.ReturnValue != "")
        //                {
        //                    var elasticData = JsonConvert.DeserializeObject<Dictionary<string, string>>(result.ReturnValue);
        //                    result.ErrorCode = (elasticData["Code"] == "200") ? "0" : elasticData["Code"];
        //                    result.ErrorDetail = elasticData["Message"];
        //                    result.ReturnValue = null;
        //                }
        //            }
        //            //else
        //            //{
        //            //    result.ErrorCode =  result.ErrorCode;
        //            //}

        //            Logger.ESLog.Info(" Closing Elastic search. Response Data: " + result.GetMessageInfo);

        //            return result;
        //        }
        //        catch (Exception ex)
        //        {
        //            Logger.ESLog.Error(" Exception in calling Elastic search. Details: " + ex.ToString());
        //            throw ex;
        //        }
        //    }
        //    else
        //    {
        //        ErrorProp result = new ErrorProp();
        //        result.ErrorCode = ErrorCodeElasticSearch.AUAES503;
        //        result.ErrorDetail = ErrorCodeElasticSearch.AUAES503Msg;
        //        return result;
        //    }
        //}

        //public static ErrorProp DeleteElasticSearch(ElasticSearchProp jsonBody, string userid, string sessionid)
        //{
        //    String elasticUrl = CAppSettings.GetConfigurationValue(ErrorCodeElasticSearch.ElasticSearchDeleteURL);//("ElasticSearchDeleteURL");

        //    if (elasticUrl != null && !string.IsNullOrWhiteSpace(elasticUrl))
        //    {
        //        try
        //        {
        //            // Prepare API Request Parameters
        //            ApiProp apiRequest = new ApiProp();
        //            apiRequest.Api_Uri = elasticUrl;
        //            apiRequest.Api_Name = "";
        //            apiRequest.HeaderList = PrepareRequestHeaderFeilds(sessionid, userid);
        //            apiRequest.DataForPost = JsonConvert.SerializeObject(jsonBody);

        //            Logger.ESLog.Info(" Initiating Elastic search Deletion. Request URL: " + apiRequest.Api_Uri
        //                + ", Request Data:" + apiRequest.DataForPost.ToString());

        //            // Initiate Web Request Connection
        //            // ElasticSearchApiCall connection = new ElasticSearchApiCall();

        //            // Accept Web Response
        //            ErrorProp result = connection.CallWebApi(apiRequest);
        //            if (result.ErrorCode == "0")
        //            {
        //                if (result.ReturnValue != null &&
        //                    result.ReturnValue != "")
        //                {
        //                    var elasticData = JsonConvert.DeserializeObject<Dictionary<string, string>>(result.ReturnValue);

        //                    // error code 220 (success) and 404 (Data Not Found), are considered to be success for Authoring tool
        //                    result.ErrorCode = ((elasticData["Code"] == "200") || (elasticData["Code"] == "404")) ? "0" : elasticData["Code"];
        //                    result.ErrorDetail = (elasticData["Code"] == "404") ? "Success" : elasticData["Message"];
        //                    result.ReturnValue = null;
        //                }
        //            }

        //           // Logger.ESLog.Info(" Closing Elastic search deletion. Response Data: " + result.GetMessageInfo);

        //            return result;
        //        }
        //        catch (Exception ex)
        //        {
        //            //Logger.ESLog.Error(" Exception in calling Elastic search deletion. Details: " + ex.ToString());
        //            throw ex;
        //        }
        //    }
        //    else
        //    {
        //        ErrorProp result = new ErrorProp();
        //        result.ErrorCode = ErrorCodeElasticSearch.AUAES503;
        //        result.ErrorDetail = ErrorCodeElasticSearch.AUAES503Msg;
        //        return result;
        //    }
        //}
    }
}
