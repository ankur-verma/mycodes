﻿using Newtonsoft.Json;
using OneClick.KM.APICall;
using OneClick.KM.Core;
using OneClick.KM.Core.Security;
using OneClick.KM.Model;
using OneClick.KM.Model.ElasticCache;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.BAL.ElasticCache
{
    public  class ElasticSearchLogic
    {
        public async Task<ErrorProp> UpdateElasticSearch(ElasticSearchProp objArticle, string userId, string sessionId)
        {
            ErrorProp error = new ErrorProp();
            try
            {
                if (objArticle.Searchable)
                {
                    // string iselasticEnable = CAppSettings.GetConfigurationValue("IsElasticEnable", true);
                    error = ErrorCodeElasticSearch.CheckElasticWebConfig(ErrorCodeElasticSearch.IsElasticEnable);
                    if (error.ErrorCode == "0")
                    {
                        // update elastic search from elastic search api
                        ErrorProp errorAPI = await ImpUpdateElasticSearch(objArticle, userId, sessionId);
                        error.ErrorCode = errorAPI.ErrorCode;
                        if (error.ErrorCode != "0")
                        {
                            error.ErrorCode = error.ErrorCode;
                            error.ErrorDetail = "Error updating Elastic search, Article Code: " + objArticle.ArticleId + ". Details: " + errorAPI.ErrorDetail;
                        }
                        else
                        {
                            error.ErrorDetail = errorAPI.ErrorDetail;
                        }
                    }

                }
                else
                {
                    // Not a searchable article
                    error.ErrorCode = "0";

                }








                /*
                if (objArticle.Searchable)
                {
                    string iselasticEnable = CAppSettings.GetConfigurationValue("IsElasticEnable", true);

                    if(iselasticEnable != null && iselasticEnable != "")
                    {
                        if(iselasticEnable == "Y")
                        {
                            // update elastic search from elastic search api
                            KMS.Authoring.Core.ApiCall.ErrorProp errorAPI = ElasticSearchApi.UpdateElasticSearch(objArticle, userId, sessionId);

                            error.ErrorCode = errorAPI.ErrorCode;

                            if (error.ErrorCode != "0")
                            {
                                error.ErrorCode = "ES" + error.ErrorCode;
                                error.ErrorDetail = "Error updating Elastic search, Article Code: " + objArticle.ArticleId + ". Details: " + errorAPI.ErrorDetail ;
                            }
                            else
                            {
                                error.ErrorDetail = errorAPI.ErrorDetail;
                            }     
                        }
                        else
                        {
                            // elastic search feature is not enable
                            error.ErrorCode = "0";
                            Logger.ESLog.Info("Elastic Info : " + CommonMethods.GetError(ErrorCodeElasticSearch.AUAES502));
                        }
                    }
                    else
                    {

                        //ErrorCodeElasticSearch
                        error = CommonMethods.GetError(ErrorCodeElasticSearch.AUAES503);
                        //error = CommonMethods.GetError("AUA103", "IsElasticEnable configuration is not available in config file");
                    }
                }
                else
                {
                    // Not a searchable article
                    error.ErrorCode = "0";
                    
                }
                */

                return error;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<ErrorProp> DeleteElasticSearch(List<Portal> portal, string articleCode, string userId, Boolean isSearchable, string sessionId,string clientId)
        {
            ErrorProp error = new ErrorProp();

            try
            {

                // string iselasticEnable = CAppSettings.GetConfigurationValue("IsElasticEnable", true);
                //error = ErrorCodeElasticSearch.CheckElasticWebConfig(ErrorCodeElasticSearch.IsElasticEnable);
                //if (error.ErrorCode == "0")
                //{
                    ErrorProp errorAPI;
                    ElasticSearchProp objArticle = new ElasticSearchProp();
                string shortcode = Factory.ConfigurationCalling.GetClientShortCode(clientId);
                string Eskey = clientId + "_" + shortcode.ToLower();
                objArticle.ClientId = Eskey;
                 objArticle.UserId = userId;
                objArticle.Portal = portal;
                    objArticle.ArticleId = articleCode;

                    errorAPI =await ImpDeleteElasticSearch(objArticle, userId, sessionId);

                    error.ErrorCode = errorAPI.ErrorCode;

                    if (error.ErrorCode != "0")
                    {
                        error.ErrorCode = "ES" + errorAPI.ErrorCode; //"ES" + errorAPI.ErrorCode;
                        error.ErrorDetail = "Error deleting Elastic search entry, Article Code:" + articleCode + " Message: " + errorAPI.ErrorDetail;
                    }
                    else
                    {
                        error.ErrorDetail = errorAPI.ErrorDetail;
                    }
                //}



                /*
                string iselasticEnable = CAppSettings.GetConfigurationValue("IsElasticEnable", true);

                if(iselasticEnable == "Y")
                {
                    KMS.Authoring.Core.ApiCall.ErrorProp errorAPI;
                    ElasticSearchProp objArticle = new ElasticSearchProp();
                    objArticle.Portal = portal;
                    objArticle.ArticleId = articleCode;

                    errorAPI = ElasticSearchApi.DeleteElasticSearch(objArticle, userId, sessionId);

                    error.ErrorCode = errorAPI.ErrorCode;

                    if (error.ErrorCode != "0")
                    {
                        error.ErrorCode = "ES" + errorAPI.ErrorCode;
                        error.ErrorDetail = "Error deleting Elastic search entry, Article Code:" + articleCode + " Message: " + errorAPI.ErrorDetail;
                    }
                    else
                    {
                        error.ErrorDetail = errorAPI.ErrorDetail;
                    }
                }
                else
                {
                    error.ErrorCode = "0";
                    // error.ErrorDetail = "Article not content type article";
                }  */

                return error;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }





        public static async Task<ErrorProp> ImpUpdateElasticSearch(ElasticSearchProp jsonBody, string userid, string clientIdShortCode)
        {
            String elasticUrl = ConfigHelper.SearchUri;//("ElasticSearchInsertURL");

            if (elasticUrl != null && !string.IsNullOrWhiteSpace(elasticUrl))
            {
                try
                {
                    jsonBody.UserId = userid;
                    jsonBody.ClientId = clientIdShortCode;// "00001_voda";
                    // Prepare API Request Parameters
                    ApiProp apiRequest = new ApiProp();
                    apiRequest.Api_Uri = ConfigHelper.SearchUri;
                    apiRequest.Api_Name = AppKeys.SearchInsert;
                   // apiRequest.HeaderList = PrepareRequestHeaderFeilds(sessionid, userid);
                    apiRequest.DataForPost = JsonConvert.SerializeObject(jsonBody);

                  //  Logger.ESLog.Info(" Initiating Elastic search. Request URL: " + apiRequest.Api_Uri + ", Request Data:" + apiRequest.DataForPost.ToString());

                    //ElasticSearchApiCall connection = new ElasticSearchApiCall();

                    // Accept Web Response
                    ErrorProp result = await ApiCall.CallWebApi(apiRequest);
                    if (result.ErrorCode == "0")
                    {
                        if (result.ReturnValue != null && result.ReturnValue != "")
                        {
                            var elasticData = JsonConvert.DeserializeObject<Dictionary<string, string>>(result.ReturnValue);
                            result.ErrorCode = (elasticData["code"] == "200") ? "0" : elasticData["code"];
                            result.ErrorDetail = elasticData["message"];
                            result.ReturnValue = null;
                        }
                    }
                    //else
                    //{
                    //    result.ErrorCode =  result.ErrorCode;
                    //}

                    //Logger.ESLog.Info(" Closing Elastic search. Response Data: " + result.GetMessageInfo);

                    return result;
                }
                catch (Exception ex)
                {
                   // Logger.ESLog.Error(" Exception in calling Elastic search. Details: " + ex.ToString());
                    throw ex;
                }
            }
            else
            {
                ErrorProp result = new ErrorProp();
                result.ErrorCode = ErrorCodeElasticSearch.AUAES503;
                result.ErrorDetail = ErrorCodeElasticSearch.AUAES503Msg;
                return result;
            }
        }

        public static async  Task<ErrorProp> ImpDeleteElasticSearch(ElasticSearchProp jsonBody, string userid, string sessionid)
        {
            String elasticUrl = ConfigHelper.SearchUri;//("ElasticSearchDeleteURL");
            ErrorProp result = new ErrorProp();
            if (elasticUrl != null && !string.IsNullOrWhiteSpace(elasticUrl))
            {
                try
                {
                    // Prepare API Request Parameters
                    ApiProp apiRequest = new ApiProp();
                    apiRequest.Api_Uri = ConfigHelper.SearchUri;
                    apiRequest.Api_Name = AppKeys.SearchDelete;
                    apiRequest.HeaderList = PrepareRequestHeaderFeilds(sessionid, userid);
                    apiRequest.DataForPost = JsonConvert.SerializeObject(jsonBody);

                  //  Logger.ESLog.Info(" Initiating Elastic search Deletion. Request URL: " + apiRequest.Api_Uri
                    //    + ", Request Data:" + apiRequest.DataForPost.ToString());

                    // Initiate Web Request Connection
                    // ElasticSearchApiCall connection = new ElasticSearchApiCall();

                    // Accept Web Response
                     result = await ApiCall.CallWebApi(apiRequest);
                    if (result.ErrorCode == "0")
                    {
                        if (result.ReturnValue != null &&
                            result.ReturnValue != "")
                        {
                            var elasticData = JsonConvert.DeserializeObject<Dictionary<string, string>>(result.ReturnValue);

                            // error code 220 (success) and 404 (Data Not Found), are considered to be success for Authoring tool

                            //result.ErrorCode = elasticData["code"];
                            //result.ErrorDetail = elasticData["Message"];
                            //result.ReturnValue = null;

                            result.ErrorCode = ((elasticData["code"] == "200") || (elasticData["code"] == "404")) ? "0" : elasticData["code"];
                            result.ErrorDetail = (elasticData["code"] == "404") ? "Success" : elasticData["message"];
                            result.ReturnValue = null;
                        }
                    }

                    // Logger.ESLog.Info(" Closing Elastic search deletion. Response Data: " + result.GetMessageInfo);

                    return result;
                }
                catch (Exception )
                {
                    //Logger.ESLog.Error(" Exception in calling Elastic search deletion. Details: " + ex.ToString());
                    result.ErrorCode = "1";
                    result.ErrorDetail = "Error in elastic search";
                    return result;
                }
            }
            else
            {
               // ErrorProp result = new ErrorProp();
                result.ErrorCode = ErrorCodeElasticSearch.AUAES503;
                result.ErrorDetail = ErrorCodeElasticSearch.AUAES503Msg;
                return result;
            }
        }

        public async Task<ErrorProp> UpdatePortalMappingForArticles(string userId, string sessionId, List<PortalMapping> PortalMappingList)
        {
            ErrorProp errorResultant = new ErrorProp();

            try
            {

                errorResultant = ErrorCodeElasticSearch.CheckElasticWebConfig(ErrorCodeElasticSearch.IsElasticEnable);
                if (errorResultant.ErrorCode == "0")
                {
                    List<PortalMapping> NewPortalMappingList = new List<PortalMapping>();

                    // filter out searchable list of article portal map
                    foreach (PortalMapping mapTemp in PortalMappingList)
                    {
                        if (mapTemp.SearchableFlag != null &&
                            mapTemp.SearchableFlag != "" &&
                            mapTemp.SearchableFlag == "Y")
                        {
                            NewPortalMappingList.Add(mapTemp);
                        }
                    }


                    ErrorProp errorAPI = new ErrorProp();

                    if (NewPortalMappingList != null &&
                        NewPortalMappingList.Count > 0)
                    {
                        PortalUpdateRequest request = new PortalUpdateRequest
                        {
                            PortalMappingList = NewPortalMappingList
                        };

                        // update elastic search from elastic search api
                        errorAPI = await UpdatePortalMappingIntoElasticSearch(request, userId, sessionId);

                        errorResultant.ErrorCode = errorAPI.ErrorCode;
                    }
                    else
                    {
                        // by-pass if no searcble article portal map found
                        errorResultant.ErrorCode = "0";
                    }

                    if (errorResultant.ErrorCode != "0")
                    {
                        errorResultant.ErrorDetail = "Error updating portals into elastic search. Details: " + errorAPI.ErrorDetail;
                    }
                    else
                    {
                        errorResultant.ErrorDetail = errorAPI.ErrorDetail;
                    }

                }

                return errorResultant;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static async Task<ErrorProp> UpdatePortalMappingIntoElasticSearch(PortalUpdateRequest jsonBody, string userid, string sessionid)
        {
            String elasticUrl = ConfigHelper.SearchUri;//("ElasticSearchUpdatePortalURL");

            if (elasticUrl != null && !string.IsNullOrWhiteSpace(elasticUrl))
            {
                try
                {
                    // Prepare API Request Parameters
                    ApiProp apiRequest = new ApiProp();
                    apiRequest.Api_Uri = ConfigHelper.SearchUri;
                    apiRequest.Api_Name =AppKeys.UpdatePortalMapping;
                    apiRequest.HeaderList = PrepareRequestHeaderFeilds(sessionid, userid);
                    apiRequest.DataForPost = JsonConvert.SerializeObject(jsonBody);

                    //    Logger.ESLog.Info(" Initiating Elastic search for portal update. Request URL: " + apiRequest.Api_Uri
                    //     + ", Request Data:" + apiRequest.DataForPost.ToString());

                    // Initiate Web Request Connection
                    // ElasticSearchApiCall connection = new ElasticSearchApiCall();

                    // Accept Web Response

                    ErrorProp result = await ApiCall.CallWebApi(apiRequest);
                    if (result.ErrorCode == "0")
                    {
                        if (result.ReturnValue != null &&
                            result.ReturnValue != "")
                        {
                            var elasticData = JsonConvert.DeserializeObject<Dictionary<string, string>>(result.ReturnValue);

                            result.ErrorCode = (elasticData["Code"] == "200") ? "0" : elasticData["ErrorCode"];
                            result.ErrorDetail = elasticData["Message"];

                            result.ReturnValue = null;
                        }
                    }
                    //else
                    //{
                    //    result.ErrorCode = "ES01" + result.ErrorCode;
                    //}

                    //Logger.ESLog.Info(" Closing Elastic search for portal update. Response Data: " + result.GetMessageInfo.ToString());

                    // if elastic search returns "Not Found", make it a success error
                    if (result.ErrorCode == "ES-02")
                    {
                        result.ErrorCode = "0";
                    }

                    return result;
                }
                catch (Exception ex)
                {
                    // Logger.ESLog.Error(" Exception in calling Elastic search for portal update. Details: " + ex.ToString());
                    throw ex;
                }
            }
            else
            {
                ErrorProp result = new ErrorProp();
                result.ErrorCode = ErrorCodeElasticSearch.AUAES503;
                result.ErrorDetail = ErrorCodeElasticSearch.AUAES503Msg;
                return result;
            }
        }
        static List<ApiHeader> HeaderList = new List<ApiHeader>();
        static List<ApiHeader> PrepareRequestHeaderFeilds(string sessionid, string userid)
        {
            if (HeaderList.Count > 0)
            {
                HeaderList.Clear();
            }

            //List<ApiHeader> HeaderList = new List<ApiHeader>();

            HeaderList.Add(new ApiHeader
            {
                RequestHeader = "api-version",
               // RequestHeaderValue = CAppSettings.GetConfigurationValue("ElasticSearchApiVersion", true)
            });
            HeaderList.Add(new ApiHeader
            {
                RequestHeader = "Authorization",
                RequestHeaderValue = string.Format("{0}", CAppSettings.ApiSecurityKey)
            });
            HeaderList.Add(new ApiHeader
            {
                RequestHeader = "sessionId",
                RequestHeaderValue = sessionid
            });
            HeaderList.Add(new ApiHeader
            {
                RequestHeader = "userId",
                RequestHeaderValue = userid
            });

            return HeaderList;
        }


        public async Task<ErrorProp> UpdateArticleWeightageIntoElasticSearch(WeightageRequest jsonBody, string userid, string sessionid)
        {
            String elasticUrl = ConfigHelper.SearchUri; //("ElasticSearchUpdateWeightageURL");

            if (elasticUrl != null && !string.IsNullOrWhiteSpace(elasticUrl))
            {
                try
                {
                    // Prepare API Request Parameters
                    ApiProp apiRequest = new ApiProp();
                    apiRequest.Api_Uri = ConfigHelper.SearchUri;
                    apiRequest.Api_Name = AppKeys.UpdateWeightage;
                    apiRequest.HeaderList = PrepareRequestHeaderFeilds(sessionid, userid);
                    apiRequest.DataForPost = JsonConvert.SerializeObject(jsonBody);

                   // Logger.ESLog.Info(" Initiating Elastic search for weightage update. Request URL: " + apiRequest.Api_Uri
                     //   + ", Request Data:" + apiRequest.DataForPost.ToString());

                    // Initiate Web Request Connection
                    //ElasticSearchApiCall connection = new ElasticSearchApiCall();

                    // Accept Web Response
                    ErrorProp result = await ApiCall.CallWebApi(apiRequest);
                    if (result.ErrorCode == "0")
                    {
                        if (result.ReturnValue != null &&
                            result.ReturnValue != "")
                        {
                            var elasticData = JsonConvert.DeserializeObject<Dictionary<string, string>>(result.ReturnValue);

                            result.ErrorCode = (elasticData["code"] == "200" || elasticData["code"] == "201") ? "0" : elasticData["errorCode"];
                            result.ErrorDetail = elasticData["message"];

                            result.ReturnValue = null;
                        }
                    }


                 //   Logger.ESLog.Info(" Closing Elastic search for weightage update. Response Data: " + result.GetMessageInfo.ToString());

                    // if elastic search returns "Not Found", make it a success error
                    if (result.ErrorCode == "ES-02")
                    {
                        result.ErrorCode = "0";
                    }

                    return result;
                }
                catch (Exception ex)
                {
                  //  Logger.ESLog.Error(" Exception in calling Elastic search for weightage update. Details: " + ex.ToString());
                    throw ex;
                }
            }
            else
            {
                ErrorProp result = new ErrorProp();
                result.ErrorCode = ErrorCodeElasticSearch.AUAES503;
                result.ErrorDetail = ErrorCodeElasticSearch.AUAES503Msg;
                return result;
            }
        }
    }
}
