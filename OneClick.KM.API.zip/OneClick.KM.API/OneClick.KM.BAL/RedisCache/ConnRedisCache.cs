﻿using CachingFramework.Redis;
using OneClick.KM.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.BAL.RedisCache
{
    public class ConnRedisCache
    {
        private static RedisContext dbInstance;


        private ConnRedisCache()
        {
            //new RedisContext();
        }

        public static RedisContext GetCacheInstance()
        {
            try
            {
                string rcConn = OneClick.KM.Core.Utility.AppSettings.GetConfigurationValue("RedisCacheConnection");
                if (!string.IsNullOrEmpty(rcConn))
                {
                    if (dbInstance == null)
                    {
                        dbInstance = new RedisContext(rcConn);
                    }
                }
                else
                {
                    throw (new ApplicationException(ErrorCodeRedisCache.RC510));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dbInstance;
        }


    }
}
