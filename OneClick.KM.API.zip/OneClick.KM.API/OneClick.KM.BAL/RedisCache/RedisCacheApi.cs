﻿namespace OneClick.KM.BAL.RedisCache
{
    public class RedisCacheApi
    {

        //public HttpClient Client { get; }

       

        //public RedisCacheApi()
        //{
        //    Client.BaseAddress = new Uri("localhost:58402/");
          

         
        //}

        //public async Task<ErrorProp> SendtToRedis(string RequestApi)
        //{
        //    var request = new HttpRequestMessage(HttpMethod.Get,
        //        RequestApi);
          

        //    var response = await Client.GetAsync(RequestApi);

        //    response.EnsureSuccessStatusCode();



        //     var responseStream = await response.Content.ReadAsStreamAsync();

        //    return await JsonSerializer.
        //        <IEnumerable<string>>(responseStream.);


        //}



        }
    }
