﻿using OneClick.KM.APICall;
using OneClick.KM.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.BAL
{
	class TempClass
	{
		public ApiProp _apiRequest;
		//public ErrorProp InvokeApiService(string dataForPost, string apiName, string userId, string sessionId)
		//{
		//	_apiRequest.Api_Uri =ConfigHelper.;
		//	_apiRequest.Method = APIMethodType.POST.ToString();
		//	_apiRequest.DataForPost = dataForPost;
		//	_apiRequest.Api_Name = apiName;
		//	_apiRequest.APIFrom = "ES";
		//	_apiRequest.UserId = userId;
		//	var rresult = ApiCall.CallWebApi(_apiRequest);
		//	if (rresult.ErrorCode == "ES-12" || rresult.ErrorCode == "500" || rresult.ErrorCode == "InternalServerError")
		//	{
		//		rresult.ErrorCode = "ES-12";
		//		rresult.ErrorDetail = "There is some issue occured, please contact to Application Administrator.";
		//	}
		//	return rresult;
		//}

	}
}
