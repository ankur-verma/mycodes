﻿using OneClick.KM.Caching;
using OneClick.KM.Factory.Database.V1;
using OneClick.KM.Interfaces.Database.V1;
using OneClick.KM.Model;
using OneClick.KM.Model.Account;
using OneClick.KM.Model.ClientManagement;
using System;
using System.Threading.Tasks;

namespace OneClick.KM.BAL.V1
{
    public class AccountBAL
    {
        AccountFactory account = null;
        IAccount _AccountPortal = null;

        #region [Agent]

        public async Task<Response> ValidateLoginBAL(Login request)
        {

            Response responseBody = new Response();
            try
            {
                string ClientId = CacheHelper.GetClientId(request.ClientShortCode);
                if (String.IsNullOrEmpty(ClientId))
                {
                    ClientId = Convert.ToString(CacheHelper.ClientDetailFromCache(request.ClientShortCode));

                }
                if (ClientId != null)
                {
                    _AccountPortal = new AccountFactory(ClientId).AccountInstance();
                    var userData = await _AccountPortal.ValidateLogin(request);
                    responseBody.Result = userData;
                    responseBody.Error.ErrorCode = "0";
                    responseBody.Error.ErrorDetail = "Success";
                }
                else
                {
                    responseBody.Error.ErrorCode = "API_ERROR_1";
                    responseBody.Error.ErrorDetail = "Client Details not Found !!";
                }

            }
            catch (Exception ex)
            {
                responseBody.Error.ErrorCode = "1";
                responseBody.Error.ErrorDetail = ex.Message;
            }
            return responseBody;
        }

        #region[Get active session list from oracle db]
        public async Task<Response> GetActiveSessionListBAL(ClientBaseModel res)
        {

            Response responseBody = new Response();
            try
            {
                IAccount _account = new AccountFactory(res.ClientId).AccountInstance();
                var userData = await _account.GetActiveSessionList(res);
                responseBody.Result = userData;
                responseBody.Error.ErrorCode = "0";
                responseBody.Error.ErrorDetail = "Success";
            }
            catch (Exception ex)
            {
                responseBody.Error.ErrorCode = "1";
                responseBody.Error.ErrorDetail = ex.Message;
            }
            return responseBody;
        }

        public async Task<APIResponseMessage> LogoutSessionBAL(BaseModel request)
        {

            _AccountPortal = new AccountFactory(request.ClientId).AccountInstance();

            return await _AccountPortal.LogoutSession(request);
        }


        public async Task<Response> ContinueSessionBAL(ActiveUserSessionDet request)
        {

            _AccountPortal = new AccountFactory(request.ClientId).AccountInstance();

            Response responseBody = new Response();
            try
            {

                var userData = await _AccountPortal.ContinueSession(request);

                responseBody.Result = userData;
                responseBody.Error.ErrorCode = "0";
                responseBody.Error.ErrorDetail = "Success";
            }
            catch (Exception ex)
            {
                responseBody.Error.ErrorCode = "1";
                responseBody.Error.ErrorDetail = ex.Message;
            }
            return responseBody;
            //log.Info("Calling Login post method");
            // return await _AccountPortal.ContinueSession(request);
        }



        public async Task<Response> SSOValidateLoginBAL(SSOLogin request)
        {
            Response responseBody = new Response();
            try
            {
                string ClientId = CacheHelper.GetClientId(request.ClientShortCode);
                if (String.IsNullOrEmpty(ClientId))
                {
                    ClientId = Convert.ToString(CacheHelper.ClientDetailFromCache(request.ClientShortCode));



                }
                if (ClientId != null)
                {
                    _AccountPortal = new AccountFactory(ClientId).AccountInstance();
                    var userData = await _AccountPortal.SSOValidateLogin(request);
                    responseBody.Result = userData;
                    responseBody.Error.ErrorCode = "0";
                    responseBody.Error.ErrorDetail = "Success";
                }
                else
                {
                    responseBody.Error.ErrorCode = "API_ERROR_1";
                    responseBody.Error.ErrorDetail = "Client Details not Found !!";
                }



            }
            catch (Exception ex)
            {
                responseBody.Error.ErrorCode = "1";
                responseBody.Error.ErrorDetail = ex.Message;
            }
            return responseBody;



        }


        public async Task<Response> ValidatePortalDLoginBAL(PortalDLogin request)
        {
            _AccountPortal = new AccountFactory(request.ClientId).AccountInstance();
            Response responseBody = new Response();
            try
            {

                var userData = await _AccountPortal.ValidatePortalDLogin(request);

                responseBody.Result = userData;
                responseBody.Error.ErrorCode = "0";
                responseBody.Error.ErrorDetail = "Success";
            }
            catch (Exception ex)
            {
                responseBody.Error.ErrorCode = "1";
                responseBody.Error.ErrorDetail = ex.Message;
            }
            return responseBody;

        }


        public async Task<Response> SaveResetPasswordBAL(ResetPassword baseModel)
        {
            Response responseBody = new Response();


            string ClientId = CacheHelper.GetClientId(baseModel.ClientShortCode);
            if (String.IsNullOrEmpty(ClientId))
            {
                ClientId = Convert.ToString(CacheHelper.ClientDetailFromCache(baseModel.ClientShortCode));

            }
            if (ClientId != null)
            {
                _AccountPortal = new AccountFactory(ClientId).AccountInstance();
                var data = await _AccountPortal.SaveResetPassword(baseModel);
                responseBody.Error.ErrorCode = data.ErrorCode;
                responseBody.Error.ErrorDetail = data.Remarks;

            }

            else
            {
                responseBody.Error.ErrorCode = "API_ERROR_1";
                responseBody.Error.ErrorDetail = "Client Details not Found !!";
            }



            return responseBody;
        }

        public async Task<APIResponseMessage> UpdatePortalBAL(BaseModel request)
        {

            _AccountPortal = new AccountFactory(request.ClientId).AccountInstance();

            return await _AccountPortal.UpdatePortal(request);
        }

        #endregion

        #region [Authoring]

        #region Login


        public async Task<Response> LoginBAL(LoginProp login)
        {
            Response responseBody = new Response();

            string ClientId = CacheHelper.GetClientId(login.ClientShortCode);

            if (ClientId != null)
            {
                _AccountPortal = new AccountFactory(ClientId).AccountInstance();
            }

            string valid = LoginValidateRequest(login);

            if (valid == "success")
            {
                LoginProp lobjUserInput = new LoginProp();
                lobjUserInput.UserName = login.UserName;
                lobjUserInput.Password = login.Password;
                lobjUserInput.DomainName = login.DomainName;
                lobjUserInput.Attempts = login.Attempts;
                lobjUserInput.ClientId = ClientId;
                // lobjUserInput.WhetherKillSession = login.WhetherKillSession;
                lobjUserInput.WhetherKillSession = false;
                lobjUserInput.SessionId = login.SessionId;
                //  ConfigHelper applicationSetting
                LoginProp pLogin =  await _AccountPortal.Login(lobjUserInput, login.WhetherKillSession);
                lobjUserInput.SessionId = pLogin.SessionId;
                lobjUserInput.ClientId = pLogin.ClientCode;               


                responseBody.Result = lobjUserInput;
                responseBody.Error = lobjUserInput.Error;
            }
            else
            {
                responseBody.Error.ErrorCode = "AUA01";
                responseBody.Error.ErrorDetail = valid;
            }
            return responseBody;
        }
        #endregion

        #region Logout

        public async Task<Response> LogoutBAL(LogoutProp lobjUserInput)
        {
            _AccountPortal = new AccountFactory(lobjUserInput.ClientId).AccountInstance();
            Response responseBody = new Response();
            try
            {
                await _AccountPortal.Logout(lobjUserInput);

                responseBody.Result = "Success";
                responseBody.Error.ErrorCode = "0";
                responseBody.Error.ErrorDetail = "Success";
            }
            catch (Exception )
            {
                responseBody.Error.ErrorCode = "1";
                responseBody.Error.ErrorDetail = "Please enter valid client Id";
            }
            return responseBody;
        }

        #endregion

        #region InsertForgotPassword

        public async Task<Response> InsertForgotPasswordBAL(InsertForgetPassword request)
        {
            Response responseBody = new Response();
            if (request != null)
            {
                try
                {
                    string ClientId = CacheHelper.GetClientId(request.ClientShortCode);
                    string Password = string.Empty;
                    if (ClientId != null)
                    {
                        _AccountPortal = new AccountFactory(ClientId).AccountInstance();
                        request.ClientId = ClientId;
                        ErrorPropForAsync error = await _AccountPortal.InsertForgotPassword(request);
                        responseBody.Error = error.ErrorClassObj;
                        if (error.ErrorClassObj.ErrorCode == "0")
                        {
                            responseBody.Result = error.Result;
                        }
                    }

                }
                catch (Exception ex)
                {
                    responseBody.Error.ErrorCode = "-101";
                    responseBody.Error.ErrorDetail = ex.Message;
                }
            }
            else
            {
                responseBody.Error.ErrorCode = "101";
                responseBody.Error.ErrorDetail = "Parameters cannot be null";
            }

            return responseBody;
        }
        #endregion
        #region NewUserChangePass

        public async Task<Response> NewUserChangePassBAL(ChangePassword userdetail)
        {
            _AccountPortal = new AccountFactory(userdetail.ClientId).AccountInstance();
            Response responseBody = new Response();

            if (!string.IsNullOrEmpty(userdetail.UserName) && !string.IsNullOrEmpty(userdetail.CurrentPassword) && !string.IsNullOrEmpty(userdetail.NewPassword))
            {

                try
                {
                    ErrorProp _error = await _AccountPortal.NewUserChangePassLogic(userdetail);

                    responseBody.Error = _error;
                }
                catch (Exception ex)
                {
                    responseBody.Error.ErrorCode = "-101";
                    responseBody.Error.ErrorDetail = ex.Message;
                }
            }
            else
            {
                responseBody.Error.ErrorCode = "101";
                responseBody.Error.ErrorDetail = "Parameters cannot be left empty";
            }

            return responseBody;
        }
        #endregion

        #region ResetPassword
        public async Task<Response> ResetPasswordBAL(UserBasic objuser)
        {
            _AccountPortal = new AccountFactory(objuser.ClientId).AccountInstance();
            Response responseBody = new Response();
            if (objuser != null && objuser.UserName != null && objuser.Password != null && objuser.CurrentPassword != null)
            {
                try
                {
                    ErrorProp error = await _AccountPortal.ResetPassword(objuser);
                    if (error != null)
                    {
                        responseBody.Error = error;
                    }
                }
                catch (Exception ex)
                {
                    responseBody.Error.ErrorCode = "AUA101";
                    responseBody.Error.ErrorDetail = ex.Message;
                }
            }
            else
            {
                responseBody.Error = Model.CommonMethods.GetError("AUA104");
            }

            return responseBody;
        }
        #endregion

        #region[updateUserResetPassword]
        public async Task<Response> UpdateUserResetPasswordBAL(ChangePassword userdetail)
        {
            Response responseBody = new Response();

            if (userdetail != null &&
                userdetail.UserName != "" &&
                userdetail.UserName != null &&
                userdetail.CurrentPassword != "" &&
                userdetail.CurrentPassword != null &&
                userdetail.NewPassword != "" &&
                userdetail.NewPassword != null)
            {
                try
                {
                    _AccountPortal = new AccountFactory(userdetail.ClientId).AccountInstance();
                    ErrorProp _error = await _AccountPortal.UpdateUserResetPassword(userdetail);
                    responseBody.Error = _error;
                }
                catch (Exception ex)
                {
                    responseBody.Error = CommonMethods.GetError("AUA101", ex.ToString());
                }
            }
            else
            {
                responseBody.Error = CommonMethods.GetError("AUA01");
            }

            return responseBody;
        }

        #endregion

        public async Task<Response> ChangeExpirePasswordBAL(ChangePassword userdetail)
        {
            Response responseBody = new Response();

            if (userdetail.UserName != "" && userdetail.UserName != null &&
                userdetail.CurrentPassword != "" && userdetail.CurrentPassword != null &&
                userdetail.NewPassword != "" && userdetail.NewPassword != null)
            {

                try
                {
                    _AccountPortal = new AccountFactory(userdetail.ClientId).AccountInstance();
                    ErrorProp _error = await _AccountPortal.ChangeExpirePasswordLogic(userdetail);

                    responseBody.Error = _error;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            else
            {
                responseBody.Error = CommonMethods.GetError("AUA01");
            }

            return responseBody;
        }

        #region Validate Request

        public string LoginValidateRequest(LoginProp login)
        {
            if (string.IsNullOrWhiteSpace(login.UserName))
            {
                return "Username Can't be Empty";
            }
            if (string.IsNullOrWhiteSpace(login.Password))
            {
                return "Password Can't be Empty";
            }
            //if (string.IsNullOrWhiteSpace(login.DomainName))
            //{
            //    return "DomainName Can't be Empty";
            //}
            if (string.IsNullOrWhiteSpace(login.ClientShortCode))
            {
                return "Client Short Code Can't be Empty";
            }

            return "success";



        }
        #endregion
        #endregion

    }

}
#endregion