﻿using OneClick.KM.Factory.Logs.V1;
using OneClick.KM.Log.MongoDB.Interfaces;
using OneClick.KM.Model;
using OneClick.KM.Model.Mongo;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.BAL.log.V1
{
   public  class AccountLogBAL
    {
        public async Task<Response> LoginDetailsDataBAL(UserLoginLogs mlogin)
        {
            Response responseBody = new Response();
            ErrorProp error = new ErrorProp();
            try
            {
                IAccountLog _iAccountLog = new AccountLogsFactory(mlogin.ClientId).GetAccountLogsInstance();
                var reslt = await _iAccountLog.LoginDetailsData(mlogin);

                if (reslt != null)
                {
                    responseBody.Error.ErrorCode = "0";
                    responseBody.Result = reslt;
                }
            }
            catch (Exception ex)
            {
                responseBody.Error.ErrorCode = "AUA101";
                responseBody.Error.ErrorDetail = ex.Message;
            }
            
            return responseBody;
        }

        public async Task<Response> InsertMacroLogsBAL( MacroLogs macLogs)
        {
            Response responseBody = new Response();
            ErrorProp error = new ErrorProp();
            try
            {
                IAccountLog _iAccountLog = new AccountLogsFactory(macLogs.ClientId).GetAccountLogsInstance();

                var reslt = await _iAccountLog.InsertMacroLogs(macLogs);
            
                if (reslt != null)
                {
                    responseBody.Error.ErrorCode = "0";
                    responseBody.Result = reslt;
                }
            }
            catch (Exception ex)
            {
                responseBody.Error.ErrorCode = "AUA101";
                responseBody.Error.ErrorDetail = ex.Message;
            }

            return responseBody;
        }

        public async Task<Response> InsertUser_InteractionBAL(UserInteractions usr_int)
        {
           
            Response responseBody = new Response();
            ErrorProp error = new ErrorProp();
            try
            {
                IAccountLog _iAccountLog = new AccountLogsFactory(usr_int.ClientId).GetAccountLogsInstance();

                var reslt = await _iAccountLog.InsertUserInteraction(usr_int);

                if (reslt != null)
                {
                    responseBody.Error.ErrorCode = "0";
                    responseBody.Result = reslt;
                }
            }
            catch (Exception ex)
            {
                responseBody.Error.ErrorCode = "AUA101";
                responseBody.Error.ErrorDetail = ex.Message;
            }

            return responseBody;
        
    }

        public async Task<Response> GetUserInteractionsBAL( UserInteractions usr_int)
        {
            List<UserInteractions> user = new List<UserInteractions>();
           Response responseBody = new Response();
            ErrorPropForAsync  error = new ErrorPropForAsync();
            try
            {
                IAccountLog _iAccountLog = new AccountLogsFactory(usr_int.ClientId).GetAccountLogsInstance();

                var reslt = await _iAccountLog.GetUserInteractions(usr_int);
                user = error.Result as List<UserInteractions>;
                if (reslt != null)
                {
                    responseBody.Error.ErrorCode = "0";
                    responseBody.Result = reslt;
                }
            }
            catch (Exception ex)
            {
                responseBody.Error.ErrorCode = "AUA101";
                responseBody.Error.ErrorDetail = ex.Message;
            }

            return responseBody;

        
    }
        public async Task<Response> GetInteractionDetailById(GHStepInteractions mGHStepInteractions)
        {
            Response responseBody = new Response();
            ErrorPropForAsync error = new ErrorPropForAsync();
            try
            {
                IAccountLog _iAccountLog = new AccountLogsFactory(mGHStepInteractions.ClientId).GetAccountLogsInstance();

                var reslt = await _iAccountLog.GetInteractionDetailById(mGHStepInteractions);

                if (reslt != null)
                {
                    responseBody.Error.ErrorCode = "0";
                    responseBody.Result = reslt;
                }
            }
            catch (Exception ex)
            {
                responseBody.Error.ErrorCode = "AUA101";
                responseBody.Error.ErrorDetail = ex.Message;
            }

            return responseBody;
          


        }


        public async Task<Response> GetInteractionsByIdBAL( UserInteractions usr_int)
        {
           
            Response responseBody = new Response();
            ErrorPropForAsync error = new ErrorPropForAsync();
            try
            {
                IAccountLog _iAccountLog = new AccountLogsFactory(usr_int.ClientId).GetAccountLogsInstance();

                var reslt = await _iAccountLog.GetInteractionsById(usr_int);
              
                if (reslt != null)
                {
                    responseBody.Error.ErrorCode = "0";
                    responseBody.Result = reslt;
                }
            }
            catch (Exception ex)
            {
                responseBody.Error.ErrorCode = "AUA101";
                responseBody.Error.ErrorDetail = ex.Message;
            }

            return responseBody;

        }

        public async Task<Response> GetInteractionsDetailByIdBAL(GHStepInteractions mGHStepInteractions)
        {

            Response responseBody = new Response();
            ErrorPropForAsync error = new ErrorPropForAsync();
            try
            {
                IAccountLog _iAccountLog = new AccountLogsFactory(mGHStepInteractions.ClientId).GetAccountLogsInstance();

                var reslt = await _iAccountLog.GetInteractionDetailById(mGHStepInteractions);

                if (reslt != null)
                {
                    responseBody.Error.ErrorCode = "0";
                    responseBody.Result = reslt;
                }
            }
            catch (Exception ex)
            {
                responseBody.Error.ErrorCode = "AUA101";
                responseBody.Error.ErrorDetail = ex.Message;
            }

            return responseBody;

        }


        public async Task<Response> InsertMicroUtilVisitBAL(MicroUtility objMicroUtil)
        {

            Response responseBody = new Response();
            ErrorPropForAsync error = new ErrorPropForAsync();
            try
            {
                IAccountLog _iAccountLog = new AccountLogsFactory(objMicroUtil.ClientId).GetAccountLogsInstance();
                var reslt = await   _iAccountLog.InsertMicroUtilVisit(objMicroUtil);
       

                if (reslt != null)
            {
                responseBody.Error.ErrorCode = "0";
                responseBody.Result = reslt;
            }
          }
            catch (Exception ex)
            {
                responseBody.Error.ErrorCode = "AUA101";
                responseBody.Error.ErrorDetail = ex.Message;
            }

            return responseBody;

        }
        public async Task<Response> UpdateArticleLogBAL( UserInteractions usr_int)
        {
            //  return await _userService.UpdateArticleLog(usr_int);
            Response responseBody = new Response();
            ErrorPropForAsync error = new ErrorPropForAsync();
            try
            {
                IAccountLog _iAccountLog = new AccountLogsFactory(usr_int.ClientId).GetAccountLogsInstance();
                var reslt = await _iAccountLog.UpdateArticleLog(usr_int);


                if (reslt != null)
                {
                    responseBody.Error.ErrorCode = "0";
                    responseBody.Result = reslt;
                }
            }
            catch (Exception ex)
            {
                responseBody.Error.ErrorCode = "AUA101";
                responseBody.Error.ErrorDetail = ex.Message;
            }

            return responseBody;

        }


        public async Task<Response> InsertErrorLogsBAL( ErrorLogs errLogs)
        {
            //return await _errorLogService.InsertErrorLogs(errLogs);
            Response responseBody = new Response();
            ErrorPropForAsync error = new ErrorPropForAsync();
            try
            {
                IAccountLog _iAccountLog = new AccountLogsFactory(errLogs.ClientId).GetAccountLogsInstance();
                var reslt = await _iAccountLog.InsertErrorLogs(errLogs);


                if (reslt != null)
                {
                    responseBody.Error.ErrorCode = "0";
                    responseBody.Result = reslt;
                }
            }
            catch (Exception ex)
            {
                responseBody.Error.ErrorCode = "AUA101";
                responseBody.Error.ErrorDetail = ex.Message;
            }

            return responseBody;

        }

    











}
}
