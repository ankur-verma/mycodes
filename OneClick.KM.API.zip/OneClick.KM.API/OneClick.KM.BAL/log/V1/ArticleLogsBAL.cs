﻿using OneClick.KM.Factory.Database.V1;
using OneClick.KM.Factory.Logs.V1;
using OneClick.KM.Interfaces.Database.V1;
using OneClick.KM.Interfaces.Logs.V1;
using OneClick.KM.Model;
using OneClick.KM.Model.Mongo;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.BAL.log.V1
{
   public  class ArticleLogsBAL
    {

        public async Task<Response> PostArticleLogBAL(MongoDBLogs obj)
        {
            Response responseBody = new Response();
            ErrorProp error = new ErrorProp();
            try
            {

                IArtticleLog _iAccountLog = new ArticleLogsFactory(obj.ClientId).GetArticlesLogsInstance();
                var reslt = await _iAccountLog.PostArticleLogDal(obj);

                if (reslt != null)
                {
                    responseBody.Error.ErrorCode = "0";
                    responseBody.Result = reslt;
                }

            }
            catch (Exception ex)
            {
                responseBody.Error.ErrorCode = "AUA101";
                responseBody.Error.ErrorDetail = ex.Message;
            }

            return responseBody;
        }


        public async Task<Response> PostArticleLogDBBAL(ArticleContent mongoDBModel)
        {
            MongoDBLogs log = new MongoDBLogs();

            Response responseBody = new Response();
            ErrorProp error = new ErrorProp();
            try
            {

                IMongoDBLogs _iArticleLog = new MongoLogsFactory(mongoDBModel.ClientId).MongoLogInstance();
                var reslt = await  _iArticleLog.GetArticleDetailsForMongoDb(mongoDBModel.ArticleCode, mongoDBModel.FaqBusiCode);
                IArtticleLog _iAccountLog = new ArticleLogsFactory(mongoDBModel.ClientId).GetArticlesLogsInstance();
                var res = await _iAccountLog.PostArticleLogDal(reslt);
                if (res != null)
                {
                    responseBody.Error.ErrorCode = "0";
                    responseBody.Result = res;
                }

            }
            catch (Exception ex)
            {
                responseBody.Error.ErrorCode = "AUA101";
                responseBody.Error.ErrorDetail = ex.Message;
            }

            return responseBody;
        }

        








        //var obj = await mongoDBLogs.GetGuidedHelpLogsForMongoDb(mongoDBModel.ArticleCode, mongoDBModel.FaqBusiCode);
        //    return await new OneClick.KM.Log.MongoDB.V1.GuidedHelp.MongoGuidedHelp(mongoDBModel.ClientId).PostGuidedHelpLog(obj);
        //var obj = await mongoDBLogs.GetArticleDetailsForMongoDb(mongoDBModel.ArticleCode, mongoDBModel.FaqBusiCode);
        //return await new OneClick.KM.Log.MongoDB.V1.Article.ImpArticleLog(mongoDBModel.ClientId).PostArticleLogDal(obj);



    }
}
