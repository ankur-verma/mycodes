﻿using OneClick.KM.Factory.Logs.V1;
using OneClick.KM.Interfaces.Logs.V1;
using OneClick.KM.Model;
using OneClick.KM.Model.Mongo;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.BAL.log.V1
{
  public   class SearchLogBAL
    {

        public async Task<Response> SearchDataBAL(SearchDetail search)
        {
            Response responseBody = new Response();
            ErrorProp error = new ErrorProp();
            try
            {
                ISearchLog _Log = new SearchLogsFactory(search.ClientId).GetGuidedHelpLogsInstance();
                var reslt = await _Log.SearchData(search);

                if (reslt != null)
                {
                    responseBody.Error.ErrorCode = "0";
                    responseBody.Result = reslt;
                }

            }
            catch (Exception ex)
            {
                responseBody.Error.ErrorCode = "AUA101";
                responseBody.Error.ErrorDetail = ex.Message;
            }

            return responseBody;
        }


       
    }
}
