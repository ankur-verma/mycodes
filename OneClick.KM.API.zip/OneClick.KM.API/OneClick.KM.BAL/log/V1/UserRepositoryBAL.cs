﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.BAL.log.V1
{
  public class UserRepositoryBAL
    {

    }
}
