﻿using Newtonsoft.Json;
using OneClick.KM.Core;
using OneClick.KM.Model.Client;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Caching;

namespace OneClick.KM.Caching
{
    public static class CacheHelper
    {
        public static object ClientDetailFromCache(string key)
        {
            object retObj = null;
            MemoryCache memoryCache = MemoryCache.Default;
            retObj = memoryCache.Get(key);
            if (retObj == null)
            {
                retObj = AddClientDetailToCache(key);
            }
            return retObj;
        }
        public static object AddClientDetailToCache(string key)
        {
            try
            {
                object retObj = null;

                MemoryCache memoryCache = MemoryCache.Default;
                var configDetails = File.ReadAllText(Path.Combine(ConfigHelper.CurrentAppPath, "Clients\\" + key + ".json")).ToString();
                //var configDetails = File.ReadAllText(Path.Combine(ConfigHelper.CurrentAppPath, "Clients\\00001.json")).ToString();
                ClientConfigurations clientCon = new ClientConfigurations();

                clientCon = JsonConvert.DeserializeObject<ClientConfigurations>(configDetails);
                var LicenseExpiryDate = Convert.ToDateTime(clientCon.LicenseExpiryDate);
                var cuurentDateTime = DateTime.Now;

                var TotalMinutes = LicenseExpiryDate.Subtract(cuurentDateTime).TotalMinutes;
				if (TotalMinutes > 0)
				{
					var timeToPreserve = cuurentDateTime.AddMinutes(TotalMinutes);
					// var timeToPreserve = DateTime.UtcNow.AddMinutes(Convert.ToInt32(ConfigHelper.CacheTime));


					memoryCache.Add(key, clientCon, timeToPreserve);
					string knowledgeDb = clientCon.KnowledgeDb; //(from cl in clientCon.KnowledgeDb select cl).ToString();
					string knowledgeDbConnection = clientCon.KnowledgeDbConnection;
					string logDb = clientCon.LogDb;
					string logDbConnection = clientCon.LogDbConnection; // (from cl in clientCon.LogDb select cl).ToString();
					string ClientShortCode = clientCon.ClientShortCode;
					string MongoConnectionStringKey = clientCon.MongoConnectionStringKey;
					ClientRight ClientRights = clientCon.ClientRights;

					memoryCache.Add(key + AppKeys.DbType, knowledgeDb, timeToPreserve);
					memoryCache.Add(key + AppKeys.LogDb, logDb, timeToPreserve);
					memoryCache.Add(key + AppKeys.DbConnectionPrefix, knowledgeDbConnection, timeToPreserve);
					// memoryCache.Add(key + AppKeys.LogConnectionPrefix, logDbConnection, timeToPreserve);
					memoryCache.Add(key + AppKeys.DbPrefix, knowledgeDbConnection, timeToPreserve);
					// memoryCache.Add(key + AppKeys.LogPrefix, logDbConnection, timeToPreserve);
					memoryCache.Add(key + AppKeys.Right, ClientRights, timeToPreserve);
					memoryCache.Add(key + AppKeys.ClientShortCode, ClientShortCode, timeToPreserve);
					memoryCache.Add(key + AppKeys.KnowledgeDbConnection, knowledgeDbConnection, timeToPreserve);
					memoryCache.Add(key + AppKeys.MongoConnectionStringKey, MongoConnectionStringKey, timeToPreserve);
					memoryCache.Add(key + AppKeys.LicenseInfo, LicenseExpiryDate, timeToPreserve);
					retObj = memoryCache.Get(key);
				}				
                return retObj;
            }
            catch (Exception ex)
            {

                return null;
            }
           
        }
        public static object GetFromCache(string key)
        {
            MemoryCache memoryCache = MemoryCache.Default;
            return memoryCache.Get(key);
        }
        public static bool AddToCache(string key, object value, DateTimeOffset expiration)
        {
            MemoryCache memoryCache = MemoryCache.Default;
            return memoryCache.Add(key, value, expiration);
        }
        public static void DeleteFromCache(string key)
        {
            MemoryCache memoryCache = MemoryCache.Default;
            if (memoryCache.Contains(key))
            {
                memoryCache.Remove(key);
            }
        }

        public static string GetClientId(string clientShortCode)
        {
            List<ClientBasicData> clientList = new List<ClientBasicData>();
            MemoryCache memoryCache = MemoryCache.Default;
            clientList = (List<ClientBasicData>)memoryCache.Get(AppKeys.ClientList);
			if (clientList != null)
			{
				var clientId = clientList.Where(x => x.ClientShortCode.ToLower()==clientShortCode.ToLower()).Select(x => x.ClientId).FirstOrDefault();

				var LicenseExpiryDate = Convert.ToDateTime(GetFromCache(clientId + AppKeys.LicenseInfo));
				var cuurentDateTime = DateTime.Now;
				var TotalMinutes = LicenseExpiryDate.Subtract(cuurentDateTime).TotalMinutes;
				if (TotalMinutes <= 0)
				{
					clientId = null;
				}
					return clientId;
            }
            else
            {
                return AddClientBasic(clientShortCode);
            }
        }
        public static string AddClientBasic(string clientShortCode)
        {
            try
            {
				object retObj = null;
				var timeToPreserve = DateTime.UtcNow.AddMinutes(Convert.ToInt32(ConfigHelper.CacheTime));
                List<ClientBasicData> clientList = new List<ClientBasicData>();
                foreach (string file in Directory.EnumerateFiles(Path.Combine(ConfigHelper.CurrentAppPath, "Clients\\"), "*.json"))
                {
                    var configDetails = File.ReadAllText(file);
                    var clientMst = JsonConvert.DeserializeObject<ClientBasicData>(configDetails);
					clientList.Add(clientMst);
					var getDetails= AddClientDetailToCache(clientMst.ClientId);
				}
                MemoryCache memoryCache = MemoryCache.Default;
                memoryCache.Add(AppKeys.ClientList, clientList, timeToPreserve);
                var clientId = clientList.Where(x => x.ClientShortCode.ToLower()==clientShortCode.ToLower()).Select(x => x.ClientId).FirstOrDefault();
				if (!String.IsNullOrEmpty(clientId))
				{
					retObj =AddClientDetailToCache(clientId);
				}
				if (retObj == null)
				{
					clientId = null;
				}
				return clientId;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public static string GetConnetionStringByClient(string Client,string key)
        {
            string ConnetionString = string.Empty;
            ConnetionString = Convert.ToString(CacheHelper.GetFromCache(Client + key));
            if (string.IsNullOrEmpty(ConnetionString))
            {
                CacheHelper.AddClientDetailToCache(Client);
                ConnetionString = Convert.ToString(CacheHelper.GetFromCache(Client + key));
            }
            return ConnetionString;
        }

    }
}

