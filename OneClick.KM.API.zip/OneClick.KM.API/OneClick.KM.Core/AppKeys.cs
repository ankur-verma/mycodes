﻿namespace OneClick.KM.Core
{
    public static class AppKeys
    {
        public const string AppSettingFile = "appsettings.json";
        public const string KnowledgeDbConnection = "KnowledgeDbConnection";
        public const string MongoConnectionStringKey = "MongoConnectionStringKey";
        public const string LoggingKey = "Logging";
        public const string HostNameKey = "Hostname";
        public const string CacheTimeKey = "CacheTime";
        public const string DbConnectionPrefix = "Knowledge";
        public const string LogConnectionPrefix = "_Logger";
        public const string DbType = "DbType";
		public const string LogDb = "LogDb";
		public const string DbPrefix = "_DB";
        public const string LogPrefix = "Log";
        public const string ModuleCode = "ModuleCode";
        public const string ClientLogoPath = "ClientLogoPath";
        public const string RedisUri = "RedisUri";
        public const string RedisMacro = "MAC";
        public const string SearchUri = "SearchUri";
        public const string ClientShortCode = "ClientShortCode";
        public const string ClientConfigPath = "Clients\\";
        public const string ClientList = "ClientList";
        public const string Right = "Right";
        public const string LicenseInfo = "LicenseInfo"; 
        public const string ImageBankUrl = "ImageBankUrl";
		public const string AttachmentAccessedFromDB = "IsAttachmentAccessedFromDB";
        public const string DocBankPath = "DocBankPath";
        public const string ServiceUrl = "ServiceUrl";
        public const string DocBankURL = "DocBankURL";
        public const string ImageBank = "ImageBank";
        public const string DefaultElasticAttributeValue = "DefaultElasticAttributeValue";
        public const string ValidateRequesterUserName = "req_username";
        public const string ValidateRequesterPassword = "req_pwd";
        public const string RequesterUserName = "ip_req_username";
        public const string InputUserPassword = "user_password";
        public const string IPDefaultPassword = "ip_default_pwd";
        public const string ClientId = "ClientId";
        public const string IpUserName = "ip_user_name";
        public const string RequesterPassword = "ip_req_pwd";
        public const string UserOnboardCreatePassword = "UserOnboardCreatePassword";
        public const string UserOnboardResetPassword = "UserOnboardResetPassword";

        public const string UserCreateMessage = "User Created Successfully!";
        public const string UserUpdatedMessage = "User Updated Successfully!";
        #region [ref values return keys]
        public const string ArtStatus = "artStatus";
        public const string ArtSearchable = "artSeachable";
        public const string Command = "Command";
        public const string SuccessMsg = "SuccessMsg";
        public const string CacheId = "cacheId";
        public const string topicCacheDetailId = "topicCacheDetailId";
        public const string ArticleToPush = "articleToPush";
        public const string TopicCacheDetailId = "articleToPush";
        public const string MacroToPush = "macroToPush";
        public const string GhToPush = "ghToPush";
        public const string PortalToPush = "PortalToPush";
        public const string ArticleCodeList = "articleCodeList";
        public const string PortalCatDlt = "PortalCatDlt";
        public const string PortalCodes = "PortalCodes";
        public const string Keycodes = "Keycodes";
        public const string Portal = "Portals";
        public const string UserList = "userlist";
        public const string RoleList = "rolelist";
        public const string ModuleList = "Modulelist";

        #endregion

        #region [Unit Test]
        public const string Root = "/InputData/";
        public const string UserManageInputData = Root + "UserManageInputData.json";
        public const string UserManagerReportingUserListInputdata = Root + "UserManagerReportingUserListInputdata.json";
        public const string UserUpdateInputData = Root + "UserUpdateInputData.json";  
        public const string UpdateUserPortalsInputData = Root + "UpdateUserPortalsInputData.json";
        public const string ArticleInputData = Root + "ArticleInputData.json";               
        public const string FeedbackStatusUpdateInputData = Root + "FeedbackStatusUpdateInputData.json";
        public const string FeedbackDDlList = Root + "FeedbackDDlList.json";
        public const string SaveDisplayOrder = Root + "SaveDisplayOrder.json";
        public const string LinksINputData = Root + "LinksINputData.json";
        public const string ScenarioCreateInputData = Root + "ScenarioCreateInputData.json";
        public const string ClientInputData = Root + "InsertClientData.json";
        public const string ArticleOutageInputData = Root + "ArticleOutage.json";
        public const string ArticleOutageInput = Root + "ArticleOutage2.json";
        public const string ImageBankInputData = Root + "ImageBankInput.json";
        public const string AddTopicTreeInput = Root + "AddTopicTreeInput.json";
        public const string PortalCategoryMappingInput = Root + "PortalCategoryMappingInput.json";
        public const string LoginDetailsDataInput = Root + "LoginDetailsDataInput.json";
        public const string InsertMacroLogsInput = Root + "InsertMacroLogsInput.json";
        public const string UserInteractionsInput = Root + "UserInteractionsInput.json";
        public const string MicroUtilityInput = Root + "MicroUtilityInput.json";
        public const string InsertErrorLogsInput = Root + "InsertErrorLogsInput.json";

        #endregion
        #region[MangeOrdering]
        public const string ManageOrderingInputData = Root + "ManageOrderingInput.json";


        #endregion[MangeOrdering]
        
        public const string MacroInputData = Root + "MacroInputData.json";
        public const string KeywordInputData = Root + "KeywordInput.json";
      
        #region[Redis]
        public const string RedisHost = "";
        public const string RedisSendObject = "api/CacheAPI/SetObject";
        public const string RedisDelObject = "api/CacheAPI/DelObject";
        public const string RedisTreeKey = "TRE";
        public const string RedisArticleKey = "ART";
        public const string RedisGuidedHelp = "GHQ";
		public const string RedisQuestionKey = "QNA";
        public const string RedisAnswerKey = "ANSK";
        public const string RedisProductCatalogueList = "PCL";
        public const string RedisProductCatalogueArticles = "PCA";
        public const string RedisBriefing = "BCG";



        #endregion

        #region [Topic tree Keys]
        public const string AddTopicTree = "F";
        public const string DeleteTopicTree = "D";
        public const string EditTopicTree = "E";


        #endregion

        #region search api
        public const string SearchInsert = "api/article/insert";
        public const string SearchDelete = "api/article/delete";
        public const string UpdatePortalMapping = "api/Article/updateportalmapping";
        public const string UpdateWeightage = "api/Article/updateweightage";
        #endregion


        #region

        public const string AuthoringModuleCode = "0000000001";
        public const string AgentModuleCode = "0000000000";
        #endregion
        #region [Role Managerment]
        public const string ExsitStatus = "Y";
        public const string DeleteedStatus = "N";
        public const string GroupExistErrorCode = "3";
        public const string GroupExistErrorMessage = "Group Name Already exist";
        #endregion

        #region [Client Management]

        public const string LogoUploadServiceUrl = "ImageOperation/CopyFromBase64.ashx";
        public const string KnowledgeDBID = "CTM0001";
        public const string LogDBID = "CTM0004";
        public const string CacheDBID = "CTM0002";

        public const string IPConnPlaceholder = "<IP>";
        public const string PortConnPlaceholder = "<Port>";
        public const string ServiceNameConnPlaceholder = "<DbName>";
        public const string UserNameConnPlaceholder = "<UserName>";

        public const string PasswordConnPlaceholder = "<Password>";
      
        #endregion

        #region
        public const string CategoryMappedMessage = "Operation Successfully Performed!";
        #endregion

        public const string ApiConfig = "API";
    }
}

