﻿using Microsoft.Extensions.Configuration;

namespace OneClick.KM.Core
{
    /// <summary>
    /// class to get appsetting.json values
    /// </summary>
    public sealed class ApplicationSettings
    {
        public string ConnectionString { get; private set; }
        public string MConnectionString { get; private set; }
        public string Logging { get; private set; }
        public string Hostname { get; private set; }
        public string CacheTime { get; private set; }
        public string ModuleCode { get; private set; }
        
        public ApplicationSettings(IConfiguration configuration)
        {
            InitSettings(configuration);
        }
        private void InitSettings(IConfiguration configuration)
        {
            ConnectionString = configuration["ConnectionStrings"];
            Logging = configuration["Logging"];
            Hostname= configuration["Hostname"];
            CacheTime = configuration["CacheTime"];
            ModuleCode = configuration["ModuleCode"];
            MConnectionString = configuration["MConnectionStrings"];
        }
    }
}

