﻿using Microsoft.Extensions.Configuration;
using System;
using System.IO;

namespace OneClick.KM.Core
{
    public class ConfigHelper
    {
        public static readonly string _KnowledgeDbConnection = string.Empty;
        public static readonly string _mongoConnectionStringKey = string.Empty;
        public static readonly string _logging = string.Empty;
        public static readonly string _hostname = string.Empty;
        public static readonly string _cacheTime = string.Empty;
        public static readonly string CurrentAppPath = Directory.GetCurrentDirectory();
        public static readonly string _ModuleCode = string.Empty;
        public static readonly string _SearchUri = string.Empty;
        public static readonly string _imageBankUrl= string.Empty;
        public static readonly string _docBankPath = string.Empty;
        public static readonly string _serviceUrl = string.Empty;
        public static readonly string _docBankURL = string.Empty;
        public static readonly string _imageBankPath = string.Empty;
        public static readonly string _ClientLogoPath = string.Empty;

        public static readonly string _UserOnboardCreatePassword = string.Empty;
        public static readonly string _UserOnboardResetPassword = string.Empty;

        public static readonly string _RedisUri = string.Empty;
        public static readonly string _DefaultElasticAttributeValue = string.Empty;
		public static readonly string _AttachmentAccessedFromDB = string.Empty;



		// DocBankPath
		static ConfigHelper()
        {
            var configurationBuilder = new ConfigurationBuilder();
            var path = Path.Combine(CurrentAppPath, AppKeys.AppSettingFile);
            configurationBuilder.AddJsonFile(path, false);
            var root = configurationBuilder.Build();
            _KnowledgeDbConnection = root.GetSection(AppKeys.KnowledgeDbConnection).Value;
            _mongoConnectionStringKey = root.GetSection(AppKeys.MongoConnectionStringKey).Value;
            _logging = root.GetSection(AppKeys.LoggingKey).Value;
            _hostname = root.GetSection(AppKeys.HostNameKey).Value;
            _cacheTime = root.GetSection(AppKeys.CacheTimeKey).Value;
            _ModuleCode = root.GetSection(AppKeys.ModuleCode).Value;
            _ClientLogoPath = root.GetSection(AppKeys.ClientLogoPath).Value;

            _UserOnboardCreatePassword = root.GetSection(AppKeys.UserOnboardCreatePassword).Value;
            _UserOnboardResetPassword = root.GetSection(AppKeys.UserOnboardResetPassword).Value;

            _RedisUri = root.GetSection(AppKeys.RedisUri).Value;
            _SearchUri = root.GetSection(AppKeys.SearchUri).Value;
            _imageBankUrl = root.GetSection(AppKeys.ImageBankUrl).Value;
            _docBankPath = root.GetSection(AppKeys.DocBankPath).Value;
            _serviceUrl =root.GetSection(AppKeys.ServiceUrl).Value;
            _docBankURL= root.GetSection(AppKeys.DocBankURL).Value;
            _imageBankPath = root.GetSection(AppKeys.ImageBank).Value;
            _DefaultElasticAttributeValue = root.GetSection(AppKeys.DefaultElasticAttributeValue).Value;
			_AttachmentAccessedFromDB= root.GetSection(AppKeys.AttachmentAccessedFromDB).Value;

		}
        public static string DefaultElasticAttributeValue
        {
            get => _DefaultElasticAttributeValue;
        }
        public static string ImageBankPath
        {
            get => _imageBankPath;
        }
        public static string ServiceUrl
        {
            get => _serviceUrl;
        }
        public static string DocBankPath
        {
            get => _docBankPath;
        }
        public static string DocBankURL
        {
            get => _docBankURL;
        }
        public static string ImageBankUrl
        {
            get => _imageBankUrl;
        }
        public static string KnowledgeDbConnection
        {
            get => _KnowledgeDbConnection;
        }

        public static string MongoConnectionStringKey
        {
            get => _mongoConnectionStringKey;
        }
        public static string Logging
        {
            get => _logging;
        }
        public static string HostName
        {
            get => _hostname;
        }
        public static string CacheTime
        {
         get => _cacheTime;
        }
        public static string ModuleCode
        {
            get => _ModuleCode;
        }
        public static string SearchUri
        {
            get => _SearchUri;
        }
        public static string RedisUri
        {
            get => _RedisUri;
        }
		public static string AttachmentAccessedFromDB
		{
			get => _AttachmentAccessedFromDB;
		}

        public static string ClientLogoPath
        {
            get => _ClientLogoPath;
        }
        public static string UserOnboardCreatePassword
        {
            get => _UserOnboardCreatePassword;
        }
        public static string UserOnboardResetPassword
        {
            get => _UserOnboardResetPassword;
        }

      
    }  




}

