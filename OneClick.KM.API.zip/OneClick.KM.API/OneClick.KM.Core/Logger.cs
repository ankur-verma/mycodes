﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.Core
{
    public static class Logger
    {
        //public static ILog AppLog = LogManager.GetLogger("ApplicationLog");
        //public static ILog ESLog = LogManager.GetLogger("ESLog");
        //public static ILog RedisLog = LogManager.GetLogger("RedisLog");
        //public static ILog InfosecLog = LogManager.GetLogger("InfosecLog")();

    }
}
