﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.Core.Security
{
	public class Base64
	{
		private static readonly char[] Alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".ToCharArray();
		private static readonly int[] ToInt = new int[128];
		static Base64()
		{
			for (var i = 0; i < Alphabet.Length; i++)
			{
				ToInt[Alphabet[i]] = i;
			}
		}

		/// <summary>
		/// Encrypt the string for Vodafone
		/// </summary>
		/// <param name="pstrStringToEncrypt">string to incrypt</param>
		/// <returns>Encrypted string</returns>
		public static String Encode(string pstrStringToEncrypt)
		{
			try
			{
				byte[] buf = Encoding.UTF8.GetBytes(pstrStringToEncrypt);
				var size = buf.Length;
				var ar = new char[((size + 2) / 3) * 4];
				var a = 0;
				var i = 0;
				while (i < size)
				{
					var b0 = buf[i++];
					var b1 = (byte)((i < size) ? buf[i++] : 0);
					var b2 = (byte)((i < size) ? buf[i++] : 0);
					const int mask = 0x3F;
					ar[a++] = Alphabet[(b0 >> 2) & mask];
					ar[a++] = Alphabet[((b0 << 4) | ((b1 & 0xFF) >> 4)) & mask];
					ar[a++] = Alphabet[((b1 << 2) | ((b2 & 0xFF) >> 6)) & mask];
					ar[a++] = Alphabet[b2 & mask];
				}
				switch (size % 3)
				{
					case 1:
						ar[--a] = '=';
						ar[--a] = '=';
						break;
					case 2:
						ar[--a] = '=';
						break;
				}
				return new String(ar);
			}
			catch (Exception ex)
			{
				//ErrorLogger.InsertErrorV1(pstrStringToEncrypt, ex);
				throw new Exception(ex.Message, ex);
			}
		}

		/// <summary>
		/// Decrypt the string for Vodafone
		/// </summary>
		/// <param name="s">Encrypted String</param>
		/// <returns>Decrypted String</returns>
		public static String Decode(String s)
		{
			try
			{
				var delta = s.EndsWith("==") ? 2 : s.EndsWith("=") ? 1 : 0;
				var buffer = new byte[(s.Length) * 3 / 4 - delta];
				const int mask = 0xFF;
				var index = 0;
				for (var i = 0; i < s.Length; i += 4)
				{
					var c0 = ToInt[s[i]];
					var c1 = ToInt[s[i + 1]];
					buffer[index++] = (byte)(((c0 << 2) | (c1 >> 4)) & mask);
					if (index >= buffer.Length)
					{
						return Encoding.UTF8.GetString(buffer);
					}
					var c2 = ToInt[s[i + 2]];
					buffer[index++] = (byte)(((c1 << 4) | (c2 >> 2)) & mask);
					if (index >= buffer.Length)
					{
						return Encoding.UTF8.GetString(buffer);
					}
					var c3 = ToInt[s[i + 3]];
					buffer[index++] = (byte)(((c2 << 6) | c3) & mask);
				}
				return Encoding.UTF8.GetString(buffer);
			}
			catch (Exception ex)
			{
				//ErrorLogger.InsertErrorV1(s, ex);
				throw new Exception(ex.Message, ex);
			}
		}

		public static string ChangeString(string pstrOriginalString)
		{
			try
			{
				int lintLenth = pstrOriginalString.Length;
				string leftString = "";
				if (lintLenth % 2 != 0)
				{
					leftString = pstrOriginalString.Substring(lintLenth - 1, 1);
					pstrOriginalString = pstrOriginalString.Substring(0, lintLenth - 1);
				}
				string lstrFirstHalf = pstrOriginalString.Substring(0, lintLenth / 2);
				string lstrSecondHalf = pstrOriginalString.Substring(lintLenth / 2);

				lstrFirstHalf = SwapFirstToLast(lstrFirstHalf);
				lstrSecondHalf = SwapFirstToNext(lstrSecondHalf);

				string lstrConvertedString = lstrFirstHalf + lstrSecondHalf;
				return lstrConvertedString + leftString;
			}
			catch (Exception ex)
			{
				//ErrorLogger.InsertErrorV1(pstrOriginalString, ex);
				throw new Exception(ex.Message, ex);
			}
		}

		private static string SwapFirstToLast(string pstrOriginalString)
		{
			try
			{
				int lintLength = pstrOriginalString.Length;
				if (lintLength % 2 == 0)
				{
					char[] charArray = pstrOriginalString.ToCharArray();
					Array.Reverse(charArray);
					return new string(charArray);
				}
				else
				{
					string leftString = pstrOriginalString.Substring(lintLength - 1);
					char[] charArray = pstrOriginalString.Substring(0, lintLength - 1).ToCharArray();
					Array.Reverse(charArray);
					return new string(charArray) + leftString;
				}
			}
			catch (Exception ex)
			{
				//ErrorLogger.InsertErrorV1(pstrOriginalString, ex);
				throw new Exception(ex.Message, ex);
			}
		}

		private static string SwapFirstToNext(string pstrOriginalString)
		{
			try
			{
				int lintLength = pstrOriginalString.Length;

				if (lintLength % 2 == 0)
				{
					char[] stringArray = pstrOriginalString.ToCharArray();
					int counter = 0;
					for (; counter < lintLength; counter += 2)
					{
						char temp = stringArray[counter];
						stringArray[counter] = stringArray[counter + 1];
						stringArray[counter + 1] = temp;
					}
					return new string(stringArray);
				}
				else
				{
					string leftString = pstrOriginalString.Substring(lintLength - 1);
					char[] stringArray = pstrOriginalString.Substring(0, lintLength - 1).ToCharArray();
					int counter = 0;
					for (; counter < stringArray.Length; counter += 2)
					{
						char temp = stringArray[counter];
						stringArray[counter] = stringArray[counter + 1];
						stringArray[counter + 1] = temp;
					}
					return new string(stringArray) + leftString;
				}
			}
			catch (Exception ex)
			{
				//ErrorLogger.InsertErrorV1(pstrOriginalString, ex);
				throw new Exception(ex.Message, ex);
			}
		}

	}
}
