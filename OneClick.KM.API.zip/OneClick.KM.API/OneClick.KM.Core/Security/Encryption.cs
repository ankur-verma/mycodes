﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace OneClick.KM.Core.Security
{
    public class Encryption
    {
        public Encryption()
        {
        }

        //Initialized Key
        byte[] key = { };
        //Initilized Digest
        byte[] IV = { 0X12, 0X34, 0X56, 0X78, 0X90, 0XAB, 0XCD, 0XEF };

        //public string iGenDcrypt(object mConnectionString)
        //{
        //    throw new NotImplementedException();
        //}

        //Define Encryption Key
        string mstrEncryptionKey = "1234567890";
		string aes256EncryptionKey = "1234567890";
        //If name of the documeny is Requied

        #region// i-Gen Encrypt
        public string iGenEncrypt(string stringToEncrypt)
        {
            try
            {
                return TripleDESEncode(Encrypt(stringToEncrypt));
            }
            catch (Exception ex)
            {
                //ErrorLogger.InsertErrorV1(stringToEncrypt, ex);
                throw new Exception(ex.Message, ex);
            }
        }
        #endregion

        #region// i-Gen Dcrypt
        public string iGenDcrypt(string stringToEncrypt)
        {
            try
            {
                return Decrypt(TripleDESDecode(stringToEncrypt));
            }
            catch (Exception ex)
            {
                //ErrorLogger.InsertErrorV1(stringToEncrypt, ex);
                throw new Exception(ex.Message, ex);
            }
        }
        #endregion

        #region// DESCrypto
        public string Encrypt(string stringToEncrypt)
        {
            try
            {
                string SEncryptionKey = mstrEncryptionKey;
                key = System.Text.Encoding.UTF8.GetBytes(SEncryptionKey.Substring(0, 8));
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                byte[] inputByteArray = Encoding.UTF8.GetBytes(stringToEncrypt);
                MemoryStream ms = new MemoryStream();
                CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(key, IV), CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();
                //Convert.ToBase64String(ms.ToArray()).Replace('=', '@');
                return Convert.ToBase64String(ms.ToArray()).Replace('=', '@').Replace("+", "~!");
                //return Convert.ToBase64String(ms.ToArray()).Replace('=', '@');
            }
            catch (Exception ex)
            {
                //ErrorLogger.InsertErrorV1(stringToEncrypt, ex);
                throw new Exception(ex.Message, ex);
            }
        }
        #endregion

        #region// DESDrypto
        public string Decrypt(string stringToDecrypt)
        {
            string SEncryptionKey = mstrEncryptionKey;
            byte[] inputByteArray = new byte[stringToDecrypt.Length];
            // inputByteArray.Length = stringToDecrypt.Length;
            // inputByteArray.Length = stringToDecrypt.Length;
            try
            {
                key = System.Text.Encoding.UTF8.GetBytes(SEncryptionKey.Substring(0, 8));
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                inputByteArray = Convert.FromBase64String(stringToDecrypt.Replace('@', '=').Replace("~!", "+"));
                //inputByteArray = Convert.FromBase64String(stringToDecrypt.Replace('@', '='));
                MemoryStream ms = new MemoryStream();
                CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(key, IV), CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();
                System.Text.Encoding encoding = System.Text.Encoding.UTF8;
                return encoding.GetString(ms.ToArray());
            }
            catch (Exception ex)
            {
                //ErrorLogger.InsertErrorV1(stringToDecrypt, ex);
                throw new Exception(ex.Message, ex);
            }
            finally
            {
            }

        }
        #endregion

        #region// TripleEncoding
        public string TripleDESEncode(string value)
        {
            try
            {
                string key = "a1B@c3D$";
                System.Security.Cryptography.TripleDESCryptoServiceProvider des = new System.Security.Cryptography.TripleDESCryptoServiceProvider();
                des.IV = new byte[8];
                System.Security.Cryptography.PasswordDeriveBytes pdb = new System.Security.Cryptography.PasswordDeriveBytes(key, new byte[-1 + 1]);
                des.Key = pdb.CryptDeriveKey("RC2", "MD5", 128, new byte[8]);
                System.IO.MemoryStream ms = new System.IO.MemoryStream((value.Length * 2) - 1);
                System.Security.Cryptography.CryptoStream encStream = new System.Security.Cryptography.CryptoStream(ms, des.CreateEncryptor(), System.Security.Cryptography.CryptoStreamMode.Write);
                byte[] plainBytes = System.Text.Encoding.UTF8.GetBytes(value);
                encStream.Write(plainBytes, 0, plainBytes.Length);
                encStream.FlushFinalBlock();
                byte[] encryptedBytes = new byte[(int)ms.Length - 1 + 1];
                ms.Position = 0;
                ms.Read(encryptedBytes, 0, (int)ms.Length);
                encStream.Close();
                return Convert.ToBase64String(encryptedBytes);
            }
            catch (Exception ex)
            {
                //ErrorLogger.InsertErrorV1(value, ex);
                throw new Exception(ex.Message, ex);
            }
        }

        public string TripleDESDecode(string value)
        {
            try
            {
                string key = "a1B@c3D$";
                System.Security.Cryptography.TripleDESCryptoServiceProvider des = new System.Security.Cryptography.TripleDESCryptoServiceProvider();
                des.IV = new byte[8];
                System.Security.Cryptography.PasswordDeriveBytes pdb = new System.Security.Cryptography.PasswordDeriveBytes(key, new byte[-1 + 1]);
                des.Key = pdb.CryptDeriveKey("RC2", "MD5", 128, new byte[8]);
                byte[] encryptedBytes = Convert.FromBase64String(value);
                System.IO.MemoryStream ms = new System.IO.MemoryStream(value.Length);
                System.Security.Cryptography.CryptoStream decStream = new System.Security.Cryptography.CryptoStream(ms, des.CreateDecryptor(), System.Security.Cryptography.CryptoStreamMode.Write);
                decStream.Write(encryptedBytes, 0, encryptedBytes.Length);
                decStream.FlushFinalBlock();
                byte[] plainBytes = new byte[(int)ms.Length - 1 + 1];
                ms.Position = 0;
                ms.Read(plainBytes, 0, (int)ms.Length);
                decStream.Close();
                return System.Text.Encoding.UTF8.GetString(plainBytes);
            }
            catch (Exception ex)
            {
                //ErrorLogger.InsertErrorV1(value, ex);
                throw new Exception(ex.Message, ex);
            }
        }
		#endregion

		#region[AES 256]
		#region [Encrytpion]	
		#region[EncrytpText]
		public string AES256EncryptText(string input)
		{
			// Get the bytes of the string			
			byte[] bytesToBeEncrypted = Encoding.UTF8.GetBytes(input);
			byte[] passwordBytes = Encoding.UTF8.GetBytes(aes256EncryptionKey);
			// Hash the password with SHA256
			passwordBytes = SHA256.Create().ComputeHash(passwordBytes);
			byte[] bytesEncrypted = AES_Encrypt(bytesToBeEncrypted, passwordBytes);
			string result = Convert.ToBase64String(bytesEncrypted);
			return result;
		}
		#endregion[EncrytpText]
		#region[EncrytpFile]
		public void EncryptFile(string sourceFilePath, string outputFilePath)
		{
			string file = sourceFilePath;
			byte[] bytesToBeEncrypted = File.ReadAllBytes(file);
			byte[] passwordBytes = Encoding.UTF8.GetBytes(aes256EncryptionKey);
			// Hash the password with SHA256
			passwordBytes = SHA256.Create().ComputeHash(passwordBytes);
			byte[] bytesEncrypted = AES_Encrypt(bytesToBeEncrypted, passwordBytes);
			File.WriteAllBytes(outputFilePath, bytesEncrypted);
		}
		#endregion[EncrytpFile]
		#region[EncrytptionMethod]
		public byte[] AES_Encrypt(byte[] bytesToBeEncrypted, byte[] passwordBytes)
		{
			byte[] encryptedBytes = null;
			// Set your salt here, change it to meet your flavor:
			// The salt bytes must be at least 8 bytes.
			byte[] saltBytes = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };
			using (MemoryStream ms = new MemoryStream())
			{
				using (RijndaelManaged AES = new RijndaelManaged())
				{
					AES.KeySize = 256;
					AES.BlockSize = 128;
					var key = new Rfc2898DeriveBytes(passwordBytes, saltBytes, 1000);
					AES.Key = key.GetBytes(AES.KeySize / 8);
					AES.IV = key.GetBytes(AES.BlockSize / 8);
					AES.Mode = CipherMode.CBC;
					using (var cs = new CryptoStream(ms, AES.CreateEncryptor(), CryptoStreamMode.Write))
					{
						cs.Write(bytesToBeEncrypted, 0, bytesToBeEncrypted.Length);
						cs.Close();
					}
					encryptedBytes = ms.ToArray();
				}
			}
			return encryptedBytes;
		}
		#endregion[EncrytptionMethod]
		#endregion[Encryption]
		#region[Decryption]
		#region[DecrytpText]
		public string AES256DecryptText(string input)
		{
			// Get the bytes of the string
			byte[] bytesToBeDecrypted = Convert.FromBase64String(input);
			byte[] passwordBytes = Encoding.UTF8.GetBytes(aes256EncryptionKey);
			passwordBytes = SHA256.Create().ComputeHash(passwordBytes);
			byte[] bytesDecrypted = AES_Decrypt(bytesToBeDecrypted, passwordBytes);
			string result = Encoding.UTF8.GetString(bytesDecrypted);
			return result;
		}
		#endregion[DecrytpText]
		#region[DencrytpFile]
		public void DecryptFile(string sourceFilePath, string outputFilePath)
		{
			byte[] bytesToBeDecrypted = File.ReadAllBytes(sourceFilePath);
			byte[] passwordBytes = Encoding.UTF8.GetBytes(aes256EncryptionKey);
			passwordBytes = SHA256.Create().ComputeHash(passwordBytes);
			byte[] bytesDecrypted = AES_Decrypt(bytesToBeDecrypted, passwordBytes);
			File.WriteAllBytes(outputFilePath, bytesDecrypted);
		}
		#endregion[DencrytpFile]
		#region[DencrytptionMethod]
		public byte[] AES_Decrypt(byte[] bytesToBeDecrypted, byte[] passwordBytes)
		{
			byte[] decryptedBytes = null;
			// Set your salt here, change it to meet your flavor:
			// The salt bytes must be at least 8 bytes.
			byte[] saltBytes = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };
			using (MemoryStream ms = new MemoryStream())
			{
				using (RijndaelManaged AES = new RijndaelManaged())
				{
					AES.KeySize = 256;
					AES.BlockSize = 128;
					var key = new Rfc2898DeriveBytes(passwordBytes, saltBytes, 1000);
					AES.Key = key.GetBytes(AES.KeySize / 8);
					AES.IV = key.GetBytes(AES.BlockSize / 8);
					AES.Mode = CipherMode.CBC;
					using (var cs = new CryptoStream(ms, AES.CreateDecryptor(), CryptoStreamMode.Write))
					{
						cs.Write(bytesToBeDecrypted, 0, bytesToBeDecrypted.Length);
						cs.Close();
					}
					decryptedBytes = ms.ToArray();
				}
			}
			return decryptedBytes;
		}
		#endregion[DencrytptionMethod]
		#endregion[Decryption]
		#endregion[AES 256]
	}
}
