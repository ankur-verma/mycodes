﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;


namespace OneClick.KM.Core.Security
{
    public class PasswordEncrption
    {
        /// <summary>
        /// Generate SHA256 hash value for given string
        /// </summary>
        /// <param name="pstrStringToEncrypt">string to hash</param>
        /// <param name="pstrSalt">salt string</param>
        /// <returns>hashed string</returns>
        public static String GetSHA256Password(string pstrStringToEncrypt, string pstrSalt)
        {
            if (string.IsNullOrEmpty(pstrStringToEncrypt) || string.IsNullOrEmpty(pstrSalt))
                throw (new ApplicationException("Argument cann't be null in the function GetSHA256Password (KMS_Core_Security)"));

            var newSalt = Base64.ChangeString(pstrSalt.ToUpper());
            return ComputeHash(pstrStringToEncrypt, new SHA256CryptoServiceProvider(), Encoding.UTF8.GetBytes(newSalt.ToUpper()));
        }
        public static String GenerateRandomPaassword()
        {
            string pstrStringToEncrypt = DateTime.Now.Day.ToString();
            Random rnd = new Random();

            int FirstRandomNumber = rnd.Next(1, 100);
            int SecondRandomNumber = rnd.Next(1, 100);
            pstrStringToEncrypt = pstrStringToEncrypt + FirstRandomNumber.ToString() +SecondRandomNumber.ToString();

            return pstrStringToEncrypt;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        /// <param name="algorithm"></param>
        /// <param name="salt"></param>
        /// <returns></returns>
        private static string ComputeHash(string input, HashAlgorithm algorithm, Byte[] salt)
        {
            StringBuilder Sb = new StringBuilder();
            Byte[] inputBytes = Encoding.UTF8.GetBytes(input);

            // Combine salt and input bytes
            Byte[] saltedInput = new Byte[salt.Length + inputBytes.Length];
            salt.CopyTo(saltedInput, 0);
            inputBytes.CopyTo(saltedInput, salt.Length);

            Byte[] hashedBytes = algorithm.ComputeHash(saltedInput);

            foreach (Byte b in hashedBytes)
                Sb.Append(b.ToString("x2", CultureInfo.InvariantCulture));

            return Sb.ToString();
        }

    }
}

