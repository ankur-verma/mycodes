﻿using System;
using System.Collections.Specialized;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace OneClick.KM.Core.Security
{
    public class QueryString : NameValueCollection
    {
        //Initialized Key
        byte[] key = { };
        //Initilized Digest
        readonly private byte[] IV = { 0X12, 0X34, 0X56, 0X78, 0X90, 0XAB, 0XCD, 0XEF };
        //Define Encryption Key
        string mstrEncryptionKey = "1234567890";
        //If name of the documeny is Requied
        private string document;
        //Application Path Details


        #region Encrypt
        /// <summary>
        /// #pp:01092008 To Encrypt the Query String
        /// </summary>
        /// <param name="stringToEncrypt"></param>
        /// <param name="SEncryptionKey"></param>
        /// <returns></returns>
        public string Encrypt(string stringToEncrypt, string SEncryptionKey)
        {
            try
            {
                //#pp:01092008Form Key from the Encryption key characters
                key = System.Text.Encoding.UTF8.GetBytes(SEncryptionKey.Substring(0, 8));
                //#pp:01092008 Crypto Service Object
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                //#pp:01092008 form the byte stream of the Encrypting String
                byte[] inputByteArray = Encoding.UTF8.GetBytes(stringToEncrypt);
                MemoryStream ms = new MemoryStream();
                //#pp:01092008 Appry Encryption Algo
                CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(key, IV), CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();
                //Convert.ToBase64String(ms.ToArray()).Replace('=', '@');
                return Convert.ToBase64String(ms.ToArray()).Replace("=", "$@");

            }
            catch (Exception ex)
            {
                return ex.Message.ToString();
            }
            finally
            {
            }

        }
        #endregion

        
        #region EncryptQueryString
        /// <summary>
        /// #pp:01092008 Here the Main Functioning of Encryption is being Done
        /// </summary>
        /// <param name="queryString"></param>
        /// <returns></returns>
        public static QueryString EncryptQueryString(QueryString queryString)
        {

            QueryString newQueryString = new QueryString();
            string nm = String.Empty;
            string val = String.Empty;
            foreach (string name in queryString)
            {
                nm = name;
                val = queryString[name];
                //#pp:01092008 Encrypt the name and value pair
                newQueryString.Add(newQueryString.Encrypt(nm, newQueryString.mstrEncryptionKey), newQueryString.Encrypt(val, newQueryString.mstrEncryptionKey));
            }
            return newQueryString;
        }
        #endregion
        
        #region formSecureQuery
        /// <summary>
        /// #pp:01092008 To form the Secure Query
        /// </summary>
        /// <param name="PageName"></param>
        /// <param name="qs"></param>
        /// <returns></returns>
        public static string formSecureQuery(String PageName, QueryString qs)
        {
            string _path = System.Configuration.ConfigurationManager.AppSettings["AppFolderName"].ToString();
            //#pp:01092008 To be called from the Page with Querystring as pass variable
            QueryString qsEncrypted = EncryptQueryString(qs);
            //#pp:01092008 Return the Encryped Url
            _path = _path + "/" + PageName;
            return (_path += qsEncrypted.ToString());
        }
        #endregion
       
    }
}
