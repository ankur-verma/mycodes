﻿
using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace OneClick.KM.Core.Utility
{
    public class AppSettings
	{
        public const string ApiSecurityKey = "Value 0neC!licKJi0";
        //private readonly IOptions<AppSettings> appSettings;
        public static string GetConfigurationValue(string pstrKey)
		{
			var configurationValue = "";// appSettings.Value; // ConfigurationManager.AppSettings[pstrKey]; -- Need to implement
			if (configurationValue != null) return configurationValue;
			throw (new ApplicationException("Configuration Tag is missing web.config. It should contain   <add key=\"" + pstrKey + "\" value=\"?\"/>"));
		}
		public static string GetLocalIPAddress()
		{
			var host = Dns.GetHostEntry(Dns.GetHostName());
			foreach (var ip in host.AddressList)
			{
				if (ip.AddressFamily == AddressFamily.InterNetwork)
				{
					return ip.ToString();
				}
			}
			throw (new ApplicationException("No network adapters with an IPv4 address in the system!"));
		}

		public static string APILogFormatter(DateTime RequestTime, long ResponseMillis, int StatusCode, string Method, string Path, string QueryString, string RequestBody, string ResponseBody)
		{
			StringBuilder msg = new StringBuilder();
            msg.Append("\r\n\n================================ Start ======================================  \n");
            msg.Append("\r\nRequestTime    : " + RequestTime);
			msg.Append("\r\nResponseMillis : " + ResponseMillis);
			msg.Append("\r\nStatusCode     : " + StatusCode);
			msg.Append("\r\nMethod         : " + Method);
			msg.Append("\r\nPath           : " + Path);
#if DEBUG 
            msg.Append("\r\nProc Name      : " + readprocname());
#endif
            msg.Append("\r\nQueryString    : " + QueryString);
			msg.Append("\r\nRequestBody    : " + RequestBody);
			msg.Append("\r\nResponseBody   : " + ResponseBody);
            msg.Append("\r\n\n================================ End ======================================  \n");
            return msg.ToString();
		}
        public static string readprocname()
        {
            string procname = string.Empty;
                if (!System.IO.Directory.Exists(@"D:\mySqlProc"))
                {
                    System.IO.Directory.CreateDirectory(@"D:\mySqlProc");
                    if (!System.IO.File.Exists(@"D:\mySqlProc\procName.txt"))
                    {
                        System.IO.File.Create(@"D:\mySqlProc\procName.txt");
                    }
                }

            string[] lines = File.ReadAllLines(@"D:\mySqlProc\procName.txt");

            procname = string.Join(",", lines);
            File.WriteAllText(@"D:\mySqlProc\procName.txt", String.Empty);
           return procname;
        }
        public static string LogFormatter(Exception ex,string err="")
		{
			StringBuilder msg = new StringBuilder();
            msg.Append("\r\n================================ Start ======================================  \n");
            msg.Append("\r\n"+err);
            while (ex != null)
			{				
				msg.Append(DateTime.Now.ToString());
				msg.Append("\r\n" + ex.GetType().FullName);
				msg.Append("\r\nMessage        : " + ex.Message);
				msg.Append("\r\nStackTrace     : " + ex.StackTrace);
				msg.Append("\r\nInnerException : " + ex.InnerException);
				msg.Append("\r\nSource         : " + ex.Source);
				msg.Append("\r\nHResult        : " + ex.HResult);
				//msg.Append("\r\n"+ex.TargetSite);
				ex = ex.InnerException;
			}
            msg.Append("\r\n\n================================ End ====================================== \n");
            return msg.ToString();

		}
		public static string WithoutTraceLogFormatter(Exception ex)
		{
			StringBuilder msg = new StringBuilder();
            msg.Append("\r\n\n================================ Start ====================================== \n");
            while (ex != null)
			{
				msg.Append("\r\n");
				msg.Append(DateTime.Now.ToString());
				msg.Append("\r\n" + ex.GetType().FullName);
				msg.Append("\r\nMessage        : " + ex.Message);
				//  msg.Append("\r\nStackTrace : " + ex.StackTrace);
				msg.Append("\r\nInnerException : " + ex.InnerException);
				msg.Append("\r\nSource         : " + ex.Source);
				msg.Append("\r\nHResult        : " + ex.HResult);
				//msg.Append("\r\n"+ex.TargetSite);
				ex = ex.InnerException;
			}
            msg.Append("\r\n\n================================ End ======================================  \n");
            return msg.ToString();
		}
		public static string LogFormResponse(Exception ex, string err = "")
		{
			StringBuilder msg = new StringBuilder();		
			while (ex != null)
			{
				msg.Append(DateTime.Now.ToString());
				msg.Append(" || " + ex.GetType().FullName);
				msg.Append(" || Message        : " + ex.Message);
				msg.Append(" || nStackTrace     : " + ex.StackTrace);
				msg.Append(" || InnerException : " + ex.InnerException);
				msg.Append(" || Source         : " + ex.Source);
				msg.Append(" || HResult        : " + ex.HResult);
				//msg.Append("\r\n"+ex.TargetSite);
				ex = ex.InnerException;
			}			
			return msg.ToString();

		}
	}
}
