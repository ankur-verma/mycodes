﻿using OneClick.KM.Core.Security;
using System;
using System.Collections.Generic;
using System.Text;
using System.Transactions;

namespace OneClick.KM.Core.Utility
{
    public class CommonUtility
    {


        public static string GetEncryptedUrl(string strPath, string serverUrl)
        {
            var queryString = new QueryString
                                  {
                                      {"ID", strPath}
                                  };
            var returnUrl = QueryString.formSecureQuery(serverUrl, queryString);
            return returnUrl.IndexOf("/") == 0 ? returnUrl.Substring(1) : returnUrl;
        }

        public static TransactionScope CreateAsyncTransactionScope(IsolationLevel isolationLevel = IsolationLevel.ReadCommitted)
        {
            var transactionOptions = new TransactionOptions
            {
                IsolationLevel = isolationLevel,
                Timeout = TransactionManager.MaximumTimeout
            };
            return new TransactionScope(TransactionScopeOption.Required, transactionOptions, TransactionScopeAsyncFlowOption.Enabled);
        }
        public static string DateTimeConversion(string dateTime)
        {
            return (!string.IsNullOrWhiteSpace(dateTime) ? Convert.ToDateTime(dateTime).ToString("dd MMM yyyy HH:mm:ss") : "");
        }
        public static string AddSeparater(string First, string Second)
        {
            string newString = string.Empty;
            newString = First + "_" + Second;
            return newString;
        }
        public static string AddSeparater(string First, string Second,string third)
        {
            string newString = string.Empty;
            newString = First + "_" + Second +"_" + third;
            return newString;
        }

        public static string CalculateTotalMinutesFromNow(DateTime futureDate)
        {
            if (futureDate != null)
            {
                return Convert.ToInt32(futureDate.Subtract(DateTime.Now).TotalMinutes).ToString();
            }
            else
            {
                return "";
            }
        }

        public static string GetImagePath(string path)
        {
            string pathtemp = string.Empty;
            if (!string.IsNullOrWhiteSpace(path))
            {

                pathtemp = path.Substring(0, (path.LastIndexOf('/') + 1));

            }
            return pathtemp;
        }



    }
}
