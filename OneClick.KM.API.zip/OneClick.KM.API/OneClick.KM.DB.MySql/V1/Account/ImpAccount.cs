﻿using MySql.Data.MySqlClient;
using OneClick.KM.Core;
using OneClick.KM.Core.Security;
using OneClick.KM.Interfaces.Database.V1;
using OneClick.KM.Model;
using OneClick.KM.Model.Account;
using OneClick.KM.Model.ClientManagement;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using static OneClick.KM.DB.MySql.MySqlParams;

namespace OneClick.KM.DB.MySql.V1.Account
{
    public class ImpAccount : MySqlDBHelper, IAccount
    {
        public ImpAccount(string clientId) : base(clientId)
        {
        }
        public ImpAccount()
        { }
        #region [Agent Login ]

        #region[ValidateLogin This  method used  for validate  the user]
        public async Task<UserData> ValidateLogin(Login login)
        {
            UserData uData = new UserData();
            return await Task.Run(() =>
            {
                OpenConnection();
                Command.CommandText = MySqlProcedureNames.AgentLogin;
                Command.CommandType = CommandType.StoredProcedure;               

                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.UserName, login.UserName));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.UserPassword, PasswordEncrption.GetSHA256Password(login.UserPassword, login.UserName)));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.Domain, login.Domain));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.IpAddress, login.IpAddress));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorDesc)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPUserUid)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OpuserDisplaynameDuplicat)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPClientCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPPortalCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPPortalName)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPDesignationName)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPSessionCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.IOAttempts, login.Attempts)).Direction = ParameterDirection.InputOutput;
              
                try
                {
                     
                        MySqlDataReader objReader = Command.ExecuteReader();
                   
                    if(objReader.HasRows)
                    {
                        while (objReader.Read())
                        {
                            var activePortalList = new ActivePortalList();
                            activePortalList.PortalCode = objReader["PORTAL_CODE"].ToString();
                            activePortalList.PortalName = objReader["PORTAL_NAME"].ToString();
                            activePortalList.DefaultPortal = objReader["DEF_PORTAL"].ToString();
                            //objUser.UserName = objReader["user_name"].ToString();
                            //objUser.PortalCode = objReader["first_name"].ToString();
                            //objUser.UserDisplayName = objReader["op_user_displayname"].ToString();
                            //objUser.LoginDate = Convert.ToDateTime(objReader["login_time"]);
                            //uData.UserRole = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPDesignationName)].Value.ToString();
                            uData.ActivePortalList.Add(activePortalList);
                        }
                        objReader.NextResult();
                        while (objReader.HasRows && objReader.Read())
                        {
                            var activePortalList = new ActivePortalList();
                            activePortalList.PortalCode = objReader["portal_code"].ToString();
                            activePortalList.PortalName = objReader["portal_name"].ToString();
                            uData.DefaultPortalList.Add(activePortalList);
                        }
                        objReader.NextResult();
                        uData.ErrorCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString();
                        uData.Remarks = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorDesc)].Value.ToString();
                        uData.ClientCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPClientCode)].Value.ToString();
                        uData.DisplayName = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OpuserDisplaynameDuplicat)].Value.ToString();
                        uData.IopATTEMPTS = 0;
                        uData.PortalCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPPortalCode)].Value.ToString();
                        uData.PortalName = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPPortalName)].Value.ToString();
                        uData.UserRole = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPDesignationName)].Value.ToString();
                        uData.SessionId = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPSessionCode)].Value.ToString();
                        uData.UserId = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPUserUid)].Value.ToString();
                        // Getting Portal List
                        uData.ErrorCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString();
                      
                    }
                    else
                    {
                        uData.ErrorCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString();
                        uData.Remarks = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorDesc)].Value.ToString();
                        uData.IopATTEMPTS = Convert.ToString(Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.IOAttempts)].Value) == null ? 0 : Convert.ToInt32(Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.IOAttempts)].Value.ToString());
                    }
                }


                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    CloseConnection();
                }
                return uData;

            });
        }

        #region[Get active sessions list]
        public async Task<UserData> GetActiveSessionList(ClientBaseModel clientBaseModel)
        {
            UserData uData = new UserData();
            return await Task.Run(() =>
            {
                OpenConnection();
                Command.CommandText = MySqlProcedureNames.GetUserActiveSessions;
                Command.CommandType = CommandType.StoredProcedure;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.UserId, clientBaseModel.UserId));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.ClientId, clientBaseModel.ClientId));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorDesc)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPActivesessions)).Direction = ParameterDirection.Output;
                try
                {
                    MySqlDataReader objReader = Command.ExecuteReader();
                    if (objReader.HasRows)                
                    {
                        while (objReader.Read())
                        {
                            var objUser = new ActiveUserSessionDet();
                            objUser.ActiveSessionID = objReader["SESSION_ID"].ToString();
                            objUser.UserID = objReader["user_uid"].ToString();
                            objUser.UserName = objReader["user_name"].ToString();
                            objUser.PortalCode = objReader["portal_code"].ToString();
                            objUser.PortalName = objReader["portal_name"].ToString();
                            objUser.LoginDate = Convert.ToDateTime(objReader["login_time"]);
                            uData.ActiveSession.Add(objUser);
                        }
                        objReader.NextResult();
                        uData.ErrorCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString();
                        uData.Remarks = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorDesc)].Value.ToString();
                    }
                    else
                    {
                        uData.ErrorCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString();
                        uData.Remarks = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorDesc)].Value.ToString();
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    CloseConnection();
                }
                return uData;

            });

        }

        #endregion [Get active sessions list]




        #endregion

        #region[Logout  This method used to logout the application]

        public async Task<APIResponseMessage> LogoutSession(BaseModel logout)
        {
            APIResponseMessage response = new APIResponseMessage();
            return await Task.Run(() =>
            {


                OpenConnection();
                BeginTrans();
                Command.CommandText = MySqlProcedureNames.AgentLogout;
                Command.CommandType = CommandType.StoredProcedure;

                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.SessionId, logout.SessionId));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.UserUid, logout.UserId));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorCode)).Direction = ParameterDirection.Output;

                try
                {
                    Command.ExecuteNonQuery();
                    response.ErrorCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString();

                    if (response.ErrorCode != "0")
                    {
                        RollbackTrans();
                    }
                    else
                    {
                        response.Remarks = "Log out successfully!";
                        CommitTrans();
                    }
                }

                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    CloseConnection();
                }
                return response;

            });

        }
        #endregion

        #region[ActiveSession  This method used for check   session is active or kill ]
        public async Task<UserData> ContinueSession(ActiveUserSessionDet activeSession)
        {
            UserData uData = new UserData();
            return await Task.Run(() =>
            {
                OpenConnection();

                Command.CommandText = MySqlProcedureNames.MultipleSession;
                Command.CommandType = CommandType.StoredProcedure;

                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.SessionId, activeSession.ActiveSessionID));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.UserUid, activeSession.UserID));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.PortalCode, activeSession.PortalCode));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.WhetherKill, activeSession.Action));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.IpAddress, activeSession.IpAddress));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorDesc)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPUserUid, activeSession.UserID)).Direction = ParameterDirection.InputOutput;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPUserName)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPClientCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPPortalCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPSessionCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPDisplayName)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPDesignationName)).Direction = ParameterDirection.Output;
               // Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPActivePortalList)).Direction = ParameterDirection.Output;

                try
                {

                    MySqlDataReader lobjDtReader = Command.ExecuteReader();

                    if (lobjDtReader.HasRows)
                    {
                       
                        while (lobjDtReader.Read())
                        {
                            var activePortalList = new ActivePortalList();
                            activePortalList.PortalCode = lobjDtReader["portal_code"].ToString();
                            activePortalList.PortalName = lobjDtReader["portal_name"].ToString();
                            activePortalList.DefaultPortal = lobjDtReader["def_portal"].ToString();
                            uData.ActivePortalList.Add(activePortalList);
                        }
                        lobjDtReader.NextResult();
                        uData.ErrorCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString();
                        uData.Remarks = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorDesc)].Value.ToString();
                        uData.ClientCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPClientCode)].Value.ToString();
                        uData.UserName = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPUserName)].Value.ToString();
                        uData.DisplayName = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPDisplayName)].Value.ToString();
                        uData.PortalCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPPortalCode)].Value.ToString();
                        uData.UserId = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPUserUid)].Value.ToString();
                        uData.UserRole = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPDesignationName)].Value.ToString();
                    }
                    else
                    {
                        uData.ErrorCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString();
                        uData.Remarks = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorDesc)].Value.ToString();
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    CloseConnection();
                }
                return uData;

            });

        }
        #endregion

        #region[SSOValidateLogin This method used to validate  SSOLogin  for application ]
        public async Task<UserData> SSOValidateLogin(SSOLogin login)
        {
            UserData uData = new UserData();
            return await Task.Run(() =>
            {
                OpenConnection();

                Command.CommandText = MySqlProcedureNames.SSOLogin;
                Command.CommandType = CommandType.StoredProcedure;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.UserName, login.UserName));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.PortalName, login.Url));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.CallJioId, login.ServiceId));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorDesc)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPUserUid)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPUserDisplayNameDuplicate)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPClientCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPPortalCode)).Direction = ParameterDirection.Output;
				Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPPortalName)).Direction = ParameterDirection.Output;
				Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPDesignationName)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPSessionCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.IOAttempts, login.Attempts)).Direction = ParameterDirection.InputOutput;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPActivesessions)).Direction = ParameterDirection.Output;


				try
				{

					MySqlDataReader objReader = Command.ExecuteReader();

					if (objReader.HasRows)
					{
						while (objReader.Read())
						{
							var activePortalList = new ActivePortalList();
							activePortalList.PortalCode = objReader["PORTAL_CODE"].ToString();
							activePortalList.PortalName = objReader["PORTAL_NAME"].ToString();
							activePortalList.DefaultPortal = objReader["DEF_PORTAL"].ToString();
							//objUser.UserName = objReader["user_name"].ToString();
							//objUser.PortalCode = objReader["first_name"].ToString();
							//objUser.UserDisplayName = objReader["op_user_displayname"].ToString();
							//objUser.LoginDate = Convert.ToDateTime(objReader["login_time"]);
							//uData.UserRole = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPDesignationName)].Value.ToString();
							uData.ActivePortalList.Add(activePortalList);
						}
						objReader.NextResult();
						while (objReader.HasRows && objReader.Read())
						{
							var activePortalList = new ActivePortalList();
							activePortalList.PortalCode = objReader["portal_code"].ToString();
							activePortalList.PortalName = objReader["portal_name"].ToString();
							uData.DefaultPortalList.Add(activePortalList);
						}
						objReader.NextResult();
						uData.ErrorCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString();
						uData.Remarks = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorDesc)].Value.ToString();
						uData.ClientCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPClientCode)].Value.ToString();
						uData.DisplayName = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OpuserDisplaynameDuplicat)].Value.ToString();
						uData.IopATTEMPTS = 0;
						uData.PortalCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPPortalCode)].Value.ToString();
						uData.PortalName = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPPortalName)].Value.ToString();
						uData.UserRole = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPDesignationName)].Value.ToString();
						uData.SessionId = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPSessionCode)].Value.ToString();
						uData.UserId = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPUserUid)].Value.ToString();
						// Getting Portal List
						uData.ErrorCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString();

					}
					else
					{
						uData.ErrorCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString();
						uData.Remarks = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorDesc)].Value.ToString();
						uData.IopATTEMPTS = Convert.ToString(Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.IOAttempts)].Value) == null ? 0 : Convert.ToInt32(Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.IOAttempts)].Value.ToString());
					}
				}


				catch (Exception ex)
				{
					throw ex;
				}
				finally
				{
					CloseConnection();
				}
				return uData;

			});
		}
		#endregion

		#region[ResetPassword  This method used for reset Password]
		public async Task<APIResponseMessage> SaveResetPassword(ResetPassword objuser)
        {
            APIResponseMessage response = new APIResponseMessage();
            await Task.Run(() =>
            {
                OpenConnection();
                Command.CommandText = MySqlProcedureNames.SaveResetPassword;
                Command.CommandType = CommandType.StoredProcedure;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.UserName, objuser.UserName));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.CurrUserPassword, PasswordEncrption.GetSHA256Password(objuser.OldPassword, objuser.UserName)));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.NewUserPassword, PasswordEncrption.GetSHA256Password(objuser.Password, objuser.UserName)));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.HintQue, ""));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.HintAns, Base64.Encode("ABC")));//Discussion:pass a value  Like "ABC"
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.Domain, objuser.PortalCode));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorDesc)).Direction = ParameterDirection.Output;
                try
                {
                    Command.ExecuteNonQuery();
                    response.ErrorCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString();
                    response.Remarks = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorDesc)].Value.ToString();

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    CloseConnection();
                }
            });
            return response;

        }
        #endregion

        #region[UpdatePortal]
        public async Task<APIResponseMessage> UpdatePortal(BaseModel portal)
        {
            APIResponseMessage response = new APIResponseMessage();
            return await Task.Run(() =>
            {


                OpenConnection();
                BeginTrans();

                Command.CommandText = MySqlProcedureNames.UpdatePortal;
                Command.CommandType = CommandType.StoredProcedure;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.UserId, portal.UserId));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.ClientId, portal.ClientId));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.Domain, portal.PortalCode));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.IP_SESSIONID, portal.SessionId));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorDesc)).Direction = ParameterDirection.Output;

                try
                {
                    Command.ExecuteNonQuery();
                    response.ErrorCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString();
                    response.Remarks = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorDesc)].Value.ToString();

                    if (response.ErrorCode != "0")
                    {
                        RollbackTrans();
                    }
                    else
                    {
                        CommitTrans();
                        response.Remarks = "Update Successfully!";

                    }
                }

                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    CloseConnection();
                }
                return response;

            });

        }
        #endregion

        public async Task<UserData> ValidatePortalDLogin(PortalDLogin login)
        {
            ErrorProp errr = new ErrorProp();
            UserData uData = new UserData();
            return await Task.Run(() =>
            {

                try
                {
                    OpenConnection();

                    Command.CommandText = MySqlProcedureNames.ValidatePortalDLogin;
                    Command.CommandType = CommandType.StoredProcedure;
                    
                    Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.UserIdDuplicate, login.UserID));
                    Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.PortalName, login.PortalName));
                    Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.IpUserType, login.UserType));
                    Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorCode)).Direction = ParameterDirection.Output;
                    Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorDesc)).Direction = ParameterDirection.Output;
                    Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPUserUid)).Direction = ParameterDirection.Output;
                    Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPUserDisplayNameDuplicate)).Direction = ParameterDirection.Output;
                    Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPClientCode)).Direction = ParameterDirection.Output;
                    Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPPortalCode)).Direction = ParameterDirection.Output;
                    Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPDesignationName)).Direction = ParameterDirection.Output;
                    Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPSessionCode)).Direction = ParameterDirection.Output;
                    Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.IOAttempts, login.Attempts)).Direction = ParameterDirection.InputOutput;
                   
                    var lobjDtReader = Command.ExecuteReader();
                  
                    if (lobjDtReader.HasRows)
                    {

                        while (lobjDtReader.Read())
                        {
                            var objUser = new ActiveUserSessionDet();
                            objUser.ActiveSessionID = lobjDtReader["session_id"].ToString();
                            objUser.UserID = lobjDtReader["user_uid"].ToString();
                            objUser.UserName = lobjDtReader["user_name"].ToString();
                            objUser.PortalCode = lobjDtReader["portal_code"].ToString();
                            objUser.PortalName = lobjDtReader["portal_name"].ToString();
                            objUser.LoginDate = Convert.ToDateTime(lobjDtReader["login_time"]);
                            
                            uData.ActiveSession.Add(objUser);
                        }
                        lobjDtReader.NextResult();
                        uData.UserRole = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPSessionCode)].Value.ToString();
                        uData.ErrorCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString();
                        uData.Remarks = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorDesc)].Value.ToString();
                        uData.ClientCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPClientCode)].Value.ToString();
                        uData.DisplayName = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPUserDisplayNameDuplicate)].Value.ToString();
                        uData.IopATTEMPTS = Convert.ToInt32(Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.IOAttempts)].Value = "0");
                        uData.PortalCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPPortalCode)].Value.ToString();
                        uData.UserRole = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPDesignationName)].Value.ToString();
                        uData.SessionId = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPSessionCode)].Value.ToString();
                        uData.UserId = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPUserUid)].Value.ToString();
                    }
                    
                    else
                    {
                        uData.ErrorCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString();
                        uData.Remarks = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorDesc)].Value.ToString();
                        uData.IopATTEMPTS = Convert.ToString(Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.IOAttempts)].Value) == null ? 0 : Convert.ToInt32(Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.IOAttempts)].Value.ToString());
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    CloseConnection();
                }
                return uData;

            });

        }


        #endregion



        #region [Authoring Login ] 
        #region [Login  This method used to login the Application] 
        public async Task<LoginProp> Login(LoginProp pLogin, bool pWhetherKillSession)
        {
            return await Task.Run(() =>
            {

                OpenConnection();
                Command.Parameters.Clear();
                Command.CommandText = MySqlProcedureNames.AuthLogin;
                Command.CommandType = CommandType.StoredProcedure;

                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.UserName, pLogin.UserName));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.Password, PasswordEncrption.GetSHA256Password(pLogin.Password, pLogin.UserName)));
                //Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.Domain, pLogin.DomainName));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.IpAddress, pLogin.IpAddress));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.ModuleCode, ConfigHelper.ModuleCode)); // Discussion:pass a value Like "ModuleCode"
                                                                                                                                //  Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.WhetherKillsession, pWhetherKillSession.ToString()));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.WhetherKillsession, 0));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorDesc)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPUserUid)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPUserDisplayNameDuplicate)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPClientCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPUserStatus)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.IOAttempts, pLogin.Attempts)).Direction = ParameterDirection.InputOutput;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.IOPSessionId, pLogin.SessionId)).Direction = ParameterDirection.InputOutput;
               // Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPRoles)).Direction = ParameterDirection.Output;

                try
                {
                    using (var lobreader = Command.ExecuteReader())
                    {
                        while (lobreader.Read())
                        {
                            GroupProp grpLst = new GroupProp();
                            grpLst.GroupCode = lobreader["group_code"].ToString();
                            grpLst.GroupName = lobreader["group_name"].ToString();
                            grpLst.GroupShortCode = lobreader["grp_short_code"].ToString();
                            grpLst.UserId = lobreader["user_uid"].ToString();
                            pLogin.GroupLst.Add(grpLst);
                        }
                    
                       lobreader.NextResult();
                        pLogin.Error.ErrorCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString();
                        pLogin.Error.ErrorDetail = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorDesc)].Value.ToString();
                        pLogin.UserId = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPUserUid)].Value.ToString();
                        pLogin.DisplayName = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPUserDisplayNameDuplicate)].Value.ToString();
                        pLogin.ClientCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPClientCode)].Value.ToString();
                        pLogin.Status = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPUserStatus)].Value.ToString();

                        if (!string.IsNullOrEmpty(Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.IOAttempts)].Value.ToString()))
                            pLogin.Attempts = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.IOAttempts)].Value.ToString();

                        pLogin.SessionId = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.IOPSessionId)].Value.ToString();


                        if (pLogin.Error.ErrorCode != "0")
                        {
                            pLogin.Error.ErrorCode = ErrorCodeConstant.AppendErrorCodePrefix(pLogin.Error.ErrorCode);
                            pLogin.Error.ErrorDetail = pLogin.Error.ErrorDetail;// + " || Please see this procedure to fix the issue in database: Package and Procedure Name " + Command.CommandText;
                        }
                        // return pLogin;
                    }

                }

                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {


                    CloseConnection();
                }

                return pLogin;
            });
        }
        #endregion

        #region [Logout Authoring Logout This method is used to logout the Application] 
        public async Task<string> Logout(LogoutProp pobjUserLogin)
        {

            String ErrorPropcode = "";
            return await Task.Run(() =>
            {
                OpenConnection();
                BeginTrans();
                Command.CommandText = MySqlProcedureNames.AuthLogout;
                Command.CommandType = CommandType.StoredProcedure;

                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.SessionId, pobjUserLogin.SessionID));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.UserUid, pobjUserLogin.UserID));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorCode)).Direction = ParameterDirection.Output;

                try
                {
                    Command.ExecuteNonQuery();
                    ErrorPropcode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString();
                    if (ErrorPropcode != "0")
                    {
                        RollbackTrans();
                    }
                    else
                    {
                        CommitTrans();

                    }
                }

                catch (Exception ex)
                {
                    RollbackTrans();
                    throw ex;
                }
                finally
                {
                    Command.Dispose();
                    CloseConnection();
                }
                return ErrorPropcode;

            });

        }
        #endregion

        #region [ InsertforgetPasword  This method  used for update forget password  ] 
        public async Task<ErrorPropForAsync> InsertForgotPassword(InsertForgetPassword pobjForgotPassword)
        {
            string Password = "";
            ErrorProp _error = new ErrorProp();
            ErrorPropForAsync errorPropForAsync = new ErrorPropForAsync();
            errorPropForAsync.Result = Password;
            return await Task.Run(() =>
            {
                OpenConnection();
               

                Command.CommandText = MySqlProcedureNames.AuthInsertForgotPassword;
                Command.CommandType = CommandType.StoredProcedure;              

                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.UserName, pobjForgotPassword.UserName));               
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.IpUserPassword, PasswordEncrption.GetSHA256Password(pobjForgotPassword.Password.Trim(), pobjForgotPassword.UserName)));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.HintQue, pobjForgotPassword.HintQuesCode.ToString()));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.HintAns, AES256Encryption.Encode(pobjForgotPassword.HintAns)));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.Domain, pobjForgotPassword.Domain));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorDesc)).Direction = ParameterDirection.Output;

                try
                {
                    using (var lobreader = Command.ExecuteReader())
                    {
                        _error.ErrorCode = Convert.ToString(Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString());
                        _error.ErrorDetail = Convert.ToString(Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorDesc)].Value.ToString());
                        errorPropForAsync.ErrorClassObj = _error;
                        if (_error.ErrorCode != "0")
                        {
                           RollbackTrans();
                        }
                        else
                        {
                            Password = pobjForgotPassword.Password;
                            errorPropForAsync.Result = Password;
                           CommitTrans();
                        }
                    }
                    return errorPropForAsync;
                }
                catch (Exception ex)
                {
                   RollbackTrans();
                    throw ex;
                }
                finally
                {
                    CloseConnection();
                }

            });

        }
        #endregion

        #region[NewUserChangePassLogic change password functionality is implemented on first login. When authoring user try to login first time]
        public async Task<ErrorProp> NewUserChangePassLogic(ChangePassword Userdetail)
        {
            ErrorProp error = new ErrorProp();
            return await Task.Run(() =>
            {
                OpenConnection();
               // BeginTrans();
                Command.CommandText = MySqlProcedureNames.AuthNewUserChangePassword;
                Command.CommandType = CommandType.StoredProcedure;
                
                Command.Parameters.Clear();
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.UserName, Userdetail.UserName));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.CurrUserPassword, PasswordEncrption.GetSHA256Password(Userdetail.CurrentPassword.Trim(), Userdetail.UserName.ToLower())));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.NewUserPassword, PasswordEncrption.GetSHA256Password(Userdetail.NewPassword.Trim(), Userdetail.UserName.ToLower())));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.HintQue, Userdetail.Hintque));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.HintAns, AES256Encryption.Encode(Userdetail.HintAns)));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.Domain, Userdetail.Domain));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorDesc)).Direction = ParameterDirection.Output;

                try
                {
                    Command.ExecuteNonQuery();

                    error.ErrorCode = Convert.ToString(Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString());
                    error.ErrorDetail = Convert.ToString(Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorDesc)].Value.ToString());

                    if (error.ErrorCode == "0")
                    {
                       // CommitTrans();
                    }
                    else
                    {
                      //  RollbackTrans();
                    }
                }
                catch (Exception ex)
                {
                   // RollbackTrans();
                    throw ex;
                }
                finally
                {
                   Command.Dispose();
                    CloseConnection();
                }
                return error;

            });
        }
        #endregion

        #region[ChangeExpirePasswordLogic This Api is used for change expire password ]
        public async Task<ErrorProp> ChangeExpirePasswordLogic(ChangePassword Userdetail)
        {
            ErrorProp error = new ErrorProp();

            return await Task.Run(() =>
            {
                OpenConnection();
                BeginTrans();
                Command.CommandText = MySqlProcedureNames.AuthChangeExpirePassword;
                Command.CommandType = CommandType.StoredProcedure;


                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.UserName, Userdetail.UserName));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.CurrUserPassword, PasswordEncrption.GetSHA256Password(Userdetail.CurrentPassword.Trim(), Userdetail.UserName.ToLower())));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.NewUserPassword, PasswordEncrption.GetSHA256Password(Userdetail.NewPassword.Trim(), Userdetail.UserName.ToLower())));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.HintQue, Userdetail.Hintque));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.HintAns, AES256Encryption.Encode(Userdetail.HintAns)));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.Domain, Userdetail.Domain));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorDesc)).Direction = ParameterDirection.Output;
                try
                {


                    Command.ExecuteNonQuery();

                    error.ErrorCode = Convert.ToString(Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString());
                    error.ErrorDetail = Convert.ToString(Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorDesc)].Value.ToString());

                    if (error.ErrorCode == "0")
                    {
                        CommitTrans();
                    }
                    else
                    {
                        error.ErrorCode = "AUD" + error.ErrorCode;
                        RollbackTrans();
                    }
                }
                catch (Exception ex)
                {
                    RollbackTrans();
                    throw ex;
                }
                finally
                {
                    Command.Dispose();
                    CloseConnection();
                }

                return error;

            });

        }
        #endregion

        #region [ResetPassword This Api used  for reset the Password]
        public async Task<ErrorProp> ResetPassword(UserBasic objuser)
        {
            ErrorProp errorResultant = new ErrorProp();
            return await Task.Run(() =>
            {
                OpenConnection();
                BeginTrans();
                Command.CommandText = MySqlProcedureNames.AuthResetPassword;
                Command.CommandType = CommandType.StoredProcedure;

 

                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.UserName, objuser.UserName));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.NewUserPassword, PasswordEncrption.GetSHA256Password(objuser.Password.Trim(), objuser.UserName)));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.HintQue, objuser.HintQuestion));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.HintAns, (objuser.HintAnswer != null && objuser.HintAnswer != "") == true ? AES256Encryption.Encode(objuser.HintAnswer) : objuser.HintAnswer));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.Domain, objuser.Domain));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.IpCurrPassword, PasswordEncrption.GetSHA256Password(objuser.CurrentPassword.Trim(), objuser.UserName)));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorDesc)).Direction = ParameterDirection.Output;
                try
                {
                    Command.ExecuteNonQuery();
                    errorResultant.ErrorCode = Convert.ToString(Convert.ToString(Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value));
                    errorResultant.ErrorDetail = Convert.ToString(Convert.ToString(Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorDesc)].Value));
                    if (errorResultant.ErrorCode == "0")
                    {
                        CommitTrans();
                    }
                    else
                    {
                        RollbackTrans();
                    }
                    return errorResultant;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    CloseConnection();
                }
            });
        }


        #endregion



        public async Task<ErrorProp> UpdateUserResetPassword(ChangePassword Userdetail)
        {
            ErrorProp error = new ErrorProp();
            return await Task.Run(() =>
            {
                OpenConnection();
                BeginTrans();
                Command.CommandText = MySqlProcedureNames.AuthUpdateUserResetPassword;
                Command.CommandType = CommandType.StoredProcedure;

                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.UserName, Userdetail.UserName));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.CurrUserPassword, PasswordEncrption.GetSHA256Password(Userdetail.CurrentPassword.Trim(), Userdetail.UserName.ToLower())));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.NewUserPassword, PasswordEncrption.GetSHA256Password(Userdetail.NewPassword.Trim(), Userdetail.UserName.ToLower())));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.HintQue, Userdetail.Hintque));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.HintAns, Userdetail.HintAns == null ? null : AES256Encryption.Encode(Userdetail.HintAns)));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.Domain, Userdetail.Domain));
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorCode)).Direction = ParameterDirection.Output;
                Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorDesc)).Direction = ParameterDirection.Output;

                try
                {
                    Command.ExecuteNonQuery();

                    error.ErrorCode = Convert.ToString(Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString());
                    error.ErrorDetail = Convert.ToString(Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorDesc)].Value.ToString());

                    if (error.ErrorCode == "0")
                    {
                        CommitTrans();
                    }
                    else
                    {
                        error.ErrorCode = "AUD" + error.ErrorCode;
                        RollbackTrans();
                    }
                }
                catch (Exception ex)
                {
                    RollbackTrans();
                    throw ex;
                }
                finally
                {
                    Command.Dispose();
                    CloseConnection();
                }
                return error;

            });
        }

        #endregion

        //public async Task<ErrorProp> GetAllClientInfo(string ShortCode)
        //{
        //    ErrorProp errorResultant = new ErrorProp();
        //    List<ClientMaster> ClientList = new List<ClientMaster>();
        //    OpenConnection();
        //    Command.CommandText = ProcedureNames.GetAllClient;
        //    Command.CommandType = CommandType.StoredProcedure;
        //    Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.IpShortCode, ShortCode));
        //   // Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OpAllClient)).Direction = ParameterDirection.Output;
        //    Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorCode)).Direction = ParameterDirection.Output;
        //    Command.Parameters.Add(MySqlParams.MySqlParameterInstance(MySqlParamName.OPErrorDesc)).Direction = ParameterDirection.Output;
        //    try
        //    {
        //        var api_mstReader = await Command.ExecuteReaderAsync();
        //        errorResultant.ErrorCode = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorCode)].Value.ToString(); ;
        //        errorResultant.ErrorDetail = Command.Parameters[MySqlParams.GetParameterName(MySqlParamName.OPErrorDesc)].Value.ToString();
        //        if (errorResultant.ErrorCode == "0")
        //        {
        //            while (await api_mstReader.ReadAsync())
        //            {
        //                ClientMaster obj = new ClientMaster();
        //                obj.ClientId = api_mstReader["client_id"].ToString();
        //                obj.ClientName = api_mstReader["client_name"].ToString();
        //                obj.ClientShortCode = api_mstReader["short_code"].ToString();

        //                ClientList.Add(obj);
        //            }
        //            errorResultant.ResponseData = ClientList;
        //            CacheHelper.AddClientmaster(ClientList, ShortCode);
        //        }
        //        else
        //        {
        //            errorResultant.ErrorCode = "AUD" + errorResultant.ErrorCode;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        errorResultant.ErrorCode = "-1";
        //        errorResultant.ErrorDetail = ex.Message.ToString();
        //    }
        //    finally
        //    {
        //        CloseConnection();
        //    }
        //    return errorResultant;

        //}

    }
}
