﻿using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using OneClick.KM.Caching;
using OneClick.KM.Core;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Text;

namespace OneClick.KM.DB.MySql
{
    public class MySqlDBHelper
    {
        #region// Properties
        private MySqlCommand _pCommand = null;
        private MySqlConnection _pConnection;
        private MySqlTransaction _pDBtransaction;
        private String _pstrConnectionString = string.Empty;
        public IConfiguration _iConfiguration;
        public string ClientId;
        public MySqlDBHelper(string ClientId)
        {
            this.ClientId = ClientId;
        }
        public MySqlDBHelper()
        {

        }
        string lastproc = "";
        public MySqlCommand Command
        {
            get
            { return _pCommand; }
            set
            {
                _pCommand = value;

            #if DEBUG
                if (!string.IsNullOrEmpty(_pCommand.CommandText))
                {
                    if (lastproc != _pCommand.CommandText)
                    {
                        writeprocname(_pCommand.CommandText);
                    }
                    lastproc = _pCommand.CommandText;
                }
            #endif

            }
        }
        public MySqlConnection Connection
        {
            get
            { return _pConnection; }
            set
            { _pConnection = value; }
        }
        public MySqlTransaction Transaction
        {
            get
            { return _pDBtransaction; }
            set
            { _pDBtransaction = value; }
        }
        public String ConnectionString
        {
            set
            { _pstrConnectionString = value; }
        }
        #endregion
        #region[Methods]
        public void OpenConnection()
        {
            try
            {
                var objCEncryption = new Core.Security.Encryption();
                string _path = CacheHelper.GetConnetionStringByClient(ClientId, AppKeys.KnowledgeDbConnection);
                _path = objCEncryption.iGenDcrypt(_path);
                // string _path = @"Server = 172.29.8.132; Port = 3306; Database = ngage_dev_oc; Uid = ngagedevocadmin; Pwd = ngage#dev#oc; Connect Timeout=21600;";
                // string  _path = @"Server=172.29.8.132;Port=3306;Database=ngagedev;Uid=ngagedevocadmin;Pwd=ngage#789dev;";
                //_path = @"Server = 172.29.8.132; Port = 3306; Database = ngage_test_oc; Uid = ngagetestocadmin; Pwd = ngage#test#oc#54;";// test  enviment

                if (_pstrConnectionString != "")
                {
                    _path = _pstrConnectionString;
                }
                Connection = new MySqlConnection(_path);
                Connection.Open();
                Command = new MySqlCommand();
                Command = Connection.CreateCommand();
            }
            catch (Exception ex)
            {
                if (Connection.State == ConnectionState.Open)
                {
                    Connection.Close();
                }
                throw ex;
            }
        }
        public void BeginTrans()
        {
            Transaction = Connection.BeginTransaction();
            Command.Transaction = Transaction;
        }
        public void CommitTrans()
        {
            if (Transaction != null)
                Transaction.Commit();
        }
        public void RollbackTrans()
        {
            if (Transaction != null)
                Transaction.Rollback();
        }
        public void CloseConnection()
        {
           string proc  = Command.CommandText;
            if (Command != null)
                Command.Dispose();
            if (Connection.State == ConnectionState.Open)
            {               
                Connection.Close();
            }
            #if DEBUG
             writeprocname(proc);
            #endif
        }

        private void writeprocname(string  proc)
        {
         //   if (!string.IsNullOrEmpty(proc) && proc != "proc_check_session")
            {
                if (!System.IO.Directory.Exists(@"D:\mySqlProc"))
                {
                    System.IO.Directory.CreateDirectory(@"D:\mySqlProc");
                    if (!System.IO.File.Exists(@"D:\mySqlProc\procName.txt"))
                    {
                        System.IO.File.Create(@"D:\mySqlProc\procName.txt");
                    }
                }
                using (System.IO.StreamWriter file =
                new System.IO.StreamWriter(@"D:\mySqlProc\procName.txt", true))
                {
                    file.WriteLine(proc);
                    file.Dispose();
                    file.Close();
                }
            }
        }

        public MySqlParameter[] ExecuteProcedure(String pstrProcName, MySqlParameter[] pobjPrm)
        {
            try
            {
                Command.CommandType = CommandType.StoredProcedure;
                Command.CommandText = pstrProcName;
                Command.ExecuteNonQuery();
                return pobjPrm;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion
    }
}
