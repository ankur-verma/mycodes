﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.DB.MySql
{

    public class MySqlParams
    {
        public enum MySqlParamName
        {

            Ipqaaccessoriesid,
            IpProductCatalogId,
            IpProductCatalogName,
            IpComponentId,
            IpComponentTypeId,
            IpComponentConnString,
            AttributeId,
            IpClientName,
            IpClientShortCode,
            IpLicenseKey,
            IpValidUpto,
            IpTheme,
            IpSubDomain,
            IpHostedOnOc,
            IpPasswordResetDaysDuplicate,
            IpPasswordResetDays,
            IpClientUserSession,
            IpClientUserSessionDuplicate,
            IpDefaultUsername,
            IpDefaultPassword,
            OpClientId,
            IpClientDetail,
            IpLanguageId,
            IpFeatureCode,
            IpFeatureCodeDuplicate,
            IpClientComponent,
            ClientUserSession,
            OPFeatureData,
            OpComponentData,
            OpComponentTypeData,
            OPLangData,
            OpClientBasicDetail,
            OpClientDtl,
            ClientId,
            OpClientInfo,
            OpAllClient, //Add by raman
            IOErrorDesc,
            IOUserUid,
            IOAttempts,
            IOPLanguageCode,
            IOPSessionId,
            IOPUserUid,
            Action,
            ActionRemark,
            ActionRemarkDuplicat,
            ActionType,
            Activity,
            ActivityDescription,
            ActivityName,
            AnswerCode,
            JsonType,
            AnswerDescription,
            AreaServiceIncharge,
            ArtCommentType,
            ArtComments,
            ArtMstCode,
            ArticleCode,
            ArticleFbId,
            ArticleFeedbackId,
            ArticleMstCode,
            ArticleScope,
            ArticleSumm,
            ArticleTitle,
            ArticleType,
            ArticleTypeValue,
            AuthPassword,
            AuthUsername,
            AuthorRemark,
            BatchId,
            Browsable,
            BusiCode,
            CallJioId,
            CallType,
            CanExpire,
            CatTypeCode,
            CategoryCode,
            IPCategoryCode,
            //CategoryCode,
            //CategoryCode,
            CityName,
            ClientCode,

            //ClientCode,
            CloneScenarioCode,
            Comment,
            CommentType,
            CopyUser,
            CreatedBy,
            CurrStatus,
            CurrUserPassword,
            CustomerId,
            DefEsclToLead,
            DesignationCode,
            DeviceMobilityLead,
            DeviceStateHead,
            DisplayName,
            DisplayOrder,
            Domain,
            EmailId,
            IpEmailId,
            EndDate,
            EndIndex,
            IpEndIndex,
            FaqAttachmentCode,
            FaqBusiCode,
            Ipnewfaqbusicode,
            FaqVersion,
            FbStatus,
            FeedbackId,
            FeedbackType,
            FirstName,
            IpFirstName,// duplicate from database
            Flag,
            GroupCode,
            HintAns,
            HintQues,
            Identifier,
            IpAddress,
            IsAllPortal,
            IsCharacter,
            IsstartQuestion,
            Jcm,
            Jiostate,
            KeyCode,
            KeyName,
            Keytext,
            Landmark,
            LastName,
            IpLastName,
            LinkType,
            LinkUrl,
            Locality,
            LocationCode,
            LocationName,
            LoginUserUid,
            MacroDesc,
            MacroId,
            OpMacroId,
            MacroName,
            MacroType,
            MacroTypeCode,
            MacroTypeName,
            MenuCode,
            ModuleCode,
            NewPassword,
            NewQuestionCode,
            NewUserPassword,
            NewsDesc,
            NewsFlag,
            NextQuestionCode,
            NhqCoordinator,
            NoPortal,
            NoUsers,
            OpeningDays,
            OpeningTimings,
            ParentMacroCode,
            Password,
            Pincode,
            PortalAuthDomain,
            PortalCode,
            IpKeyDtlCode,

            IpFormStatus,
            IpKeyType,
            IpKeyDisplayName,
            IpDiscription,
            IpMandatory,
            IpPrimary,
            IpFormId,
            IpFormName,
            OpFormId,
            OpkeyDtlCode,
            OpKeydtlOption,

            IpValueType,
            PortalDomain,
            PortalList,
            PortalName,
            ProactiveInfo,
            QuestionCode,
            QuestionName,
            QuestionDescription,
            QuestionType,
            QuickFlagLink,
            QuickLinkFlag,
            QuickLinkGroupCode,
            QuickLinkText,
            Rating,
            RegionalSpoc,
            Remark,
            ReportingTo,
            IpReportingTo,// duplicate
            RequestType,
            ResetBy,
            ResolutionText,
            ReviveStatus,
            Role,
            Rsm,
            ScenarioCode,
            //ScenarioCode,
            ScenarioPriority,
            ScenarioScope,
            ScenarioTitle,
            ScenarioTooltip,
            ScenarioVersion,
            SearchCriteria,
            SearchText,
            SearchType,
            Searchable,
            SelfStatus,
            ServiceCenterName,
            SessionCode,
            SessionId,
            //SessionId,
            Source,
            OPMapRoleLIst,
            SrchCrit,
            StartDate,
            StartIndex,
            IpStartIndex,
            State,
            ArticleSection,
            StateName,
            Status,
            IpStatus,
            StoreAddress,
            StoreType,
            StoreTypeCode,
            StoreCode,
            StoretypeName,
            SubSubCatCode,
            SubCatCode,
            SubcategoryCode,
            SuggestionRemark,
            SupRemark,
            SystemTag,
            Tooltip,
            UlDisplayName,
            UlTooltip,
            UpdStatus,
            UsefulLinkCode,
            UserActivity,
            UserCreatedBy,
            UserId,
            IpUserId,
            UserIdDuplicate,
            GroupName,
            UserInput,
            UserPassword,
            UserType,
            IpUserType, // duplicate
            UserUid,

            //UserUid,
            UserName,
            WhetherKill,
            WhetherKillsession,
            OPAccessoriesProps,
            OPActivesessions,
            OPAnswerData,
            OPNewAnswerCode,
            //OPAnswerData,
            OPAnswerMapping,
            OPAnswerProps,
            OPArtAttachment,
            OPArtComments,
            OPArtCommentsData,
            OPArtData,
            OpToLinkId,
            OPArtRating,
            OPArtRelArticles,
            OPArtattachment,
            //  OPArtdata,
            OPArticleFeedbackId,
            OPGetStoreLoct,
            OPArticleList,
            OPArticleMstCode,
            OPAttachGhName,
            OPBatchCode,
            OPBookmarkData,
            OPBrokenData,
            OPBusinessArtData,
            OPBusinessArtData1,
            OPCategoryType,
            OPClientCode,
            OPClientDtls,
            OPCoverArt,
            OPData,
            //OPData,
            OPDataBrokenLinks,
            //   OPDataBrokenlinks,
            OPDataList,
            OPData1,
            OPDesignationName,
            //OPDesignationName,
            OPDesignations,
            OPDetails,
            OPDisplayName,
            OPErrorCode,
            OPArtCount,
            OpGetPortalRating,
            OPErrorDesc,
            OPErrorDetail,
            OPErrorMsg,
            OPGroupCode,
            OPErrorpropCode,
            OPFbHead,
            OPFbRating,
            OPFbStatus,
            OPGetData,
            //OPGetData,
            OPGetKeys,
            OPGetKeywords,
            OPGetQueDtl,
            OPGetRoles,
            OPHighData,
            OpLowData,
            //OPHighData,
            OPInterlinkedArt,
            OPL1Data,
            OPLocationList,
            OPMacroId,
            OPMacroType,
            OPMappedList,
            OPMenuData,
            OPNewQuestionCode,
            OPNewScenarioCode,
            OPNewsData,
            OPPortalCode,
            OPPortalName,
            OPPortalData,
            OPPortalDtls,
            OPPortalList,
            OPPortalSumm,
            OPQueAccessories,
            //OPQueAccessories,
            OPQuesAnsdata,
            OPQuestionBroken,
            OPQuestionCode,
            OPQuestionData,
            //OPQuestionData,
            OPQuestionProps,
            OPQuickLink,
            OPQuickLinkData,
            OPRelatedArt,
            OPRoles,
            OPRoleList,
            OPRoleActionList,
            OPStatus,
            OPScenarioCode,
            OPScenarioProps,
            OPSearchFlag,
            OPSessionCode,
            OPStartDetail,
            OPStartQuestion,
            OPStoreCode,
            OPArticles,
            OPStoreTypeCode,
            OPStoreTypeList,
            //OPStoreTypeList,
            OPTopicTreeCat,
            OPTopicTreeSubsubcat,
            OPTopicTreeSubcat,
            //OPTopicTreeSubsubcat,
            OPUsefulData,
            OPUserData,
            OPUserDisplayName,
            OPUserDisplayNameDuplicate,
            OPUserModules,
            OPUserName,
            OPUserPortals,
            OPUserRoles,
            OPUserStatus,
            OPUserUid,
            OPUsers,
            OPWt,
            ClientName, //add jaspreet
            OPPORTAL,
            OPCacheId,
            OPArtDtls,
            OPKeywords,
            OPAttachment,
            OPRelArticle,
            OpWeightAgeProps,
            IpCacheId,
            IpArticleCodes,
            IpPortal,
            OPTopicCached,
            OPGHData,
            OPMacroData,
            OpScnearioPropsGh,
            OpQuestionsProp_Gh,
            OpAnswerPropsGh,
            OpAccessoriesrPropsGh,
            IpDetailId,
            IpResponseMessage,
            IpCached,
            Weightage,
            OPNewFaqBusiCode,
            OPNewFaqBusiCode_1,
            OPHeader,
            OPContent,
            ContentCode,
            ContentName,
            IsCategory,
            IsCoverType,
            FaqBusiCont,
            LanguageCode,
            LinkedCode,
            LinkedMacroCode,
            FilePath,
            ContentType,
            Content,
            FaqBusiStatus,
            OPArticleMacro,
            OPArticleLink,
            OPGetContent,
            OpTotalData,
            ContentTypeCode,
            FaqBusiScope,
            ArticlePriority,
            ArtFrequency,
            ArticleTooltip,
            // ArticleSection,
            OPFaqBusiCode,
            OPFaqBusiCode1,
            OPFaqBusiVer,
            OPFaqBusiVer1,
            ContentTypeValue,
            BookmarkCode,
            BusinessCode,
            //  StoreTypeCode,
            //QuestionName,
            OPGetPortalRating,
            // OPTopicTreeSubcat,
            OPRedisList,
            ActionFor,
            MapId,
            OPMapId,
            IpAddRequestNo,
            OPMapData,
            OPData2,
            OPData3,
            IpReqDtlId,
            IpFromCategoryCode,
            IpFromSubCategoryCode,
            IpFromSubSubCategoryCode,
            IpToPortalCode,
            OPCatPortalSum,
            FrmCategoryCode,
            FromSubCategoryCode,
            IpIsMainCategory,
            IpToCategoryCode,
            IpToSubCategoryCode,
            IpToSubSubCategoryCode,
            IpCount,
            IORequestNo,
            IpClientCode,
            OPCatPortal,
            IpBookmark,
            ArticleVersion,
            ArticleFrequency,
            // OpuserDisplayname,
            OpuserDisplaynameDuplicat,
            OPActivesessionsDuplicate,
            FeedbackIdDuplicate,
            AuthorRemarkDuplicate,
            ArtRating,
            FBStatus,
            //OPActivesessionsDuplicate,
            OPActivePortalList,
            OP_Def_Portal,
            IpUserPassword,
            HintQue,
            OpGetQlGroup,
            OpGetMacroType,
            FileName,
            Extension,
            OPAttachCode,
            AttachmentCode,
            IpTag,
            IpTitle,
            IpBodyContent,
            SearchKey,
            SearchValue,
            ImageName,
            ImagePath,
            ImageExtType,
            ImageGroup,
            IpImageCode,
            OpImageCode,
            OpTotalCode,
            IpMetaTgs,
            IpTopicName,
            OputhArticleList,
            OpAllCat,
            IpStoretypeCode,
            IpRelatedArticleType,
            IpRelatedArticleCode,
            OpErrorPropMes,
            OpGetQueDtls,
            TopicId,
            OPCatById,
            PortalId,
            IpGroupId,
            OpArticleAttribute,
            OpTopicLink,
            LinkId,
            ParentId,
            ChildId,
            LevelId,
            TopicOrder,
            OpTotalDataDuplicate,
            OpCat,
            IpLinkedCode,
            IpMacLinkedCode,
            IpImgLinkedCode,
            OpTopicData,
            IpArticleId,
            AttributeType,
            IpArtState,
            CircleCode,
            Version,
            IpMapStatus,
            IpAvailInEs,
            IpDescription,
            IpFromPortalId,
            IpToPortalId,
            IpFromTopicId,
            IpToTopicId,
            IpFromLevelId,
            IpToLevelId,
            IpFromLinkId,
            IpToLinkId,
            IpRequestId,
            ArtSummary,
            OPArtBrokenData,
            IpArtMapId,
            OpIsportalMap,
            OpWeightageProps,
            OpPortalMapStatus,
            OpPortalArtState,
            IpQueCode,
            MapStatusName,
            ForceDeleteFlag,
            ContentValue,
            OPNewsInfo,
            OPArticleWeightage,
            OPQuickLinkInfo,
            IpLanguageIdDuplicate,
            IsWorkflow,
            IsAttachment,
            Scope,
            IsRelatedArticle,
            OPContentTypeCode,
            FeatureId,
            IP_SESSIONID,
            IpSessionId,
            IP_USER_UID,
            ActivityCode,
            SubActivityCode,
            OpGroupSmid,
            IpGroupSmid,
            ActionId,
            GroupShortCode,
            OpRoleContentList,

            IpPortalDuplicate,
            IpStatename,
            StoreTypeDuplicate,
            IpCatCode,
            OpImagecodeDuplicate,
            ImageCode,
            ActionTypeDuplicate,
            OPGroupCodeDuplicate,
            IpContTypeCode,
            StartIndexDuplicate,
            EndIndexDuplicate,
            ArtType,
            ArtCode,
            OPStartDetailDuplicate,
            IpIsStartQuestionDuplicate,
            AccessoriesCode,
            ScopeDuplicate,
            IpWorkflow,
            IpStartDateDuplicate,
            IpEndDateDuplicate,
            OpContentTypeCode,
            OPWtCode,
            Value,
            IpCurrPassword,
            IsCoverPageFlag,
            OpProductCatalogId,
            IpProdCatId,
            IpProdCatMapId,
            Ip_articlecode,
            Ip_faqbusicode,
            ip_keydtl_code,
            Ip_Keydtl_Option,

            ip_operator,
            ip_valuetype,
            IsAutomationQuestion,
            Ip_Key_Type,
            Op_article_code,
            IsAutoMation,
            // Op_article_code,
            ip_option_code,
            ApiId,
            ApiName,
            ApiUrl,
            ApiTypeCode,
            ApiMethodCode,
            EventCode,
            OPApiID,
            ParameterType,
            OurParameter,
            ClientParameter,
            ApiDtlId,
            OpApiDtlId,
            IPApiId,
            IPApiName,
            ip_formname,
            ip_form_key,
            ip_method_type,
            ip_ApiId,
            ip_content_type,
            BrifingConfigCode,
            NoOfDays,
            NoOfAttempts,
            NoOfQueInPool,
            NoOfRandomQue,
            CanSkip,
            IpAssessmentName,
            IpQuestionType,
            IpAssessmentDuration,
            IpPassingCriteria,
            OpAssessmentCode,
            IpAssessmentCode,
            ip_question_sr_no,
            ip_assessment_question_name,
            ip_answer_type,
            ip_question_score,
            ip_delete_flag,
            op_assessment_question_code,
            op_assessment_answer_code,
            ip_assessment_question_code,
            ip_assessment_answer_description,
            ip_answer_score,
            ip_answer_is_correct,
            ip_display_order,
            ip_question_type,
            ip_assessment_duration,
            ip_passing_criteria,
            ip_assessment_code,
            ip_assessment_answer_code,
          //  UserNamesmall,
            IpIpAddress,
            op_can_skip,
            op_briefing_list,
            OpTotalAttempt,
            OpUsersAttempt,
            OpBriefingInfo,
            OpAssessmentInfo,
            OpQueInfo,
            OpAansInfo,
            IpPassFailFlag,
            IpTotalScore,
            IpTimeTakenInMinutes,
            IpHasSkip,
            OpAssessmentResultCode,
            IpAssessmentQuestionCcode,
            IpAssessmentAnswerCode,
            IpAssessmentResultCode



        }
        private static Dictionary<MySqlParamName, string> DbParameters = new Dictionary<MySqlParamName, string>();
        static MySqlParams()
        {
            
           // DbParameters.Add(MySqlParamName.UserNamesmall, "ip_user_name");​
            DbParameters.Add(MySqlParamName.IpIpAddress, "ip_ip_address");
            DbParameters.Add(MySqlParamName.op_can_skip, "op_can_skip");
            DbParameters.Add(MySqlParamName.op_briefing_list, "op_briefing_list");
            DbParameters.Add(MySqlParamName.OpTotalAttempt, "op_total_attempt");
            DbParameters.Add(MySqlParamName.OpUsersAttempt, "op_users_attempt");
            DbParameters.Add(MySqlParamName.OpBriefingInfo, "op_briefing_info");
            DbParameters.Add(MySqlParamName.OpAssessmentInfo, "op_assessment_info");
            DbParameters.Add(MySqlParamName.OpQueInfo, "op_que_info");
            DbParameters.Add(MySqlParamName.OpAansInfo, "op_ans_info");
            DbParameters.Add(MySqlParamName.OpAssessmentResultCode, "op_assessment_result_code");
            DbParameters.Add(MySqlParamName.IpAssessmentQuestionCcode, "ip_assessment_question_code");
            DbParameters.Add(MySqlParamName.IpAssessmentAnswerCode, "ip_assessment_answer_code");
            DbParameters.Add(MySqlParamName.IpAssessmentResultCode, "ip_assessment_result_code");



            DbParameters.Add(MySqlParamName.Ipqaaccessoriesid, "ip_qa_accessories_id");
            DbParameters.Add(MySqlParamName.IsAutoMation, "IP_IS_AUTOMATION");
            DbParameters.Add(MySqlParamName.Op_article_code, "op_article_code");
            DbParameters.Add(MySqlParamName.Ip_faqbusicode, "Ip_faqbusicode");
            DbParameters.Add(MySqlParamName.Ipnewfaqbusicode, "ip_new_faq_busi_code");
            DbParameters.Add(MySqlParamName.Ip_articlecode, "ip_articlecode");
            DbParameters.Add(MySqlParamName.IpProdCatMapId, "ip_prod_cat_map_id");
            DbParameters.Add(MySqlParamName.IpProdCatId, "ip_prod_cat_id");
            DbParameters.Add(MySqlParamName.OpProductCatalogId, "OP_prod_catalog_id");
            DbParameters.Add(MySqlParamName.IpProductCatalogId, "ip_catalog_id");
            DbParameters.Add(MySqlParamName.IpProductCatalogName, "ip_Catalog_Name");
            DbParameters.Add(MySqlParamName.IsCoverPageFlag, "ip_cover_page_flag");
            DbParameters.Add(MySqlParamName.IpCurrPassword, "IP_CURR_PASSWORD");
            DbParameters.Add(MySqlParamName.Value, "IP_VALUE");
            DbParameters.Add(MySqlParamName.IpWorkflow, "IP_WORKFLOW");
            DbParameters.Add(MySqlParamName.OPWtCode, "OP_WT_CODE");
            DbParameters.Add(MySqlParamName.OpContentTypeCode, "OP_CONTENT_TYPE_CODE");
            DbParameters.Add(MySqlParamName.ScopeDuplicate, "IP_SCOPE");
            DbParameters.Add(MySqlParamName.AccessoriesCode, "IP_ACCESSORIES_CODE");
            DbParameters.Add(MySqlParamName.IpIsStartQuestionDuplicate, "IP_IS_START_QUESTION");
            DbParameters.Add(MySqlParamName.IpEndDateDuplicate, "IP_ENDDATE");
            DbParameters.Add(MySqlParamName.IpStartDateDuplicate, "IP_STARTDATE");
            DbParameters.Add(MySqlParamName.OPStartDetailDuplicate, "OP_STARTDETAIL");
            DbParameters.Add(MySqlParamName.ArtCode, "IP_ART_CODE");
            DbParameters.Add(MySqlParamName.ArtType, "IP_ART_TYPE");
            DbParameters.Add(MySqlParamName.IpContTypeCode, "IP_CONT_TYPECODE");
            DbParameters.Add(MySqlParamName.ImageCode, "Ip_image_code");
            DbParameters.Add(MySqlParamName.OpImagecodeDuplicate, "op_imagecode");
            DbParameters.Add(MySqlParamName.IpCatCode, "ip_cat_code");
            DbParameters.Add(MySqlParamName.IpStatename, "ip_statename");
            DbParameters.Add(MySqlParamName.IpPortalDuplicate, "ip_portal");
            DbParameters.Add(MySqlParamName.IpStatus, "IP_USER_STATUS");
            DbParameters.Add(MySqlParamName.OpRoleContentList, "OP_ROLE_CONTENT_LIST");
            DbParameters.Add(MySqlParamName.GroupShortCode, "IP_GRP_SHT_CODE");
            DbParameters.Add(MySqlParamName.ActionId, "IP_ACTION_ID");
            DbParameters.Add(MySqlParamName.OpGroupSmid, "OP_GROUP_SMID");
            DbParameters.Add(MySqlParamName.IpGroupSmid, "IP_GROUP_SMID");
            DbParameters.Add(MySqlParamName.SubActivityCode, "IP_SUBACTIVITY_CODE");
            DbParameters.Add(MySqlParamName.ActivityCode, "IP_ACTIVITY_CODE");
            DbParameters.Add(MySqlParamName.IP_USER_UID, "IP_USER_UID");
            DbParameters.Add(MySqlParamName.IpSessionId, "IP_SESSION_ID");
            DbParameters.Add(MySqlParamName.OpClientBasicDetail, "OP_CLIENT_DTL");
            DbParameters.Add(MySqlParamName.IpComponentId, "ip_component_id");
            DbParameters.Add(MySqlParamName.IpComponentTypeId, "ip_component_type_id");
            DbParameters.Add(MySqlParamName.IpComponentConnString, "ip_component_con_string");
            DbParameters.Add(MySqlParamName.IpLanguageIdDuplicate, "ip_language_id");
            DbParameters.Add(MySqlParamName.IsWorkflow, "IP_IS_WORKFLOW");
            DbParameters.Add(MySqlParamName.IsAttachment, "IP_IS_ATTACHMENT");
            DbParameters.Add(MySqlParamName.Scope, "IP_IS_SCOPE");
            DbParameters.Add(MySqlParamName.FeatureId, "IP_IS_FEATUREID");
            DbParameters.Add(MySqlParamName.IsRelatedArticle, "IP_IS_RELATED_ART");
            DbParameters.Add(MySqlParamName.OPContentTypeCode, "OPContentTypeCode");
            DbParameters.Add(MySqlParamName.OpClientId, "op_client_id");
            DbParameters.Add(MySqlParamName.IpPasswordResetDaysDuplicate, "ip_pwd_reset_days");
            DbParameters.Add(MySqlParamName.OPQuickLinkInfo, "OP_QUICK_LINK_INFO");
            DbParameters.Add(MySqlParamName.ContentValue, "IP_CONTENT_VALUE");
            DbParameters.Add(MySqlParamName.ForceDeleteFlag, "IP_FORCE_DELETE_FLAG");
            DbParameters.Add(MySqlParamName.MapStatusName, "MAP_STATUSNAME");
            DbParameters.Add(MySqlParamName.IpQueCode, "IP_QUE_CODE");
            DbParameters.Add(MySqlParamName.AttributeId, "IP_ATTRIBUTE_ID");
            DbParameters.Add(MySqlParamName.OpArticleAttribute, "OP_ARTICLE_ATTR");
            DbParameters.Add(MySqlParamName.OpPortalArtState, "OP_PORTALARTSTATE");
            DbParameters.Add(MySqlParamName.OpPortalMapStatus, "OP_PORTALMAPSTATUS");
            DbParameters.Add(MySqlParamName.IpDescription, "IP_DESCRIPTION");
            DbParameters.Add(MySqlParamName.AttributeType, "IP_ATTR_TYPE");
            DbParameters.Add(MySqlParamName.OPArticles, "OP_ARTICLES");
            DbParameters.Add(MySqlParamName.IpGroupId, "IP_GROUP_ID");
            DbParameters.Add(MySqlParamName.OpWeightageProps, "OP_WEIGHTAGEPROPS");
            DbParameters.Add(MySqlParamName.OpIsportalMap, "OP_ISPORTAL_MAP");
            DbParameters.Add(MySqlParamName.IpArtMapId, "IP_ART_MAP_ID");
            DbParameters.Add(MySqlParamName.IpAvailInEs, "IP_AVAIL_IN_ES");
            DbParameters.Add(MySqlParamName.IpMapStatus, "IP_MAP_STATUS");
            DbParameters.Add(MySqlParamName.IpArtState, "IP_ART_STATE");
            DbParameters.Add(MySqlParamName.IpArticleId, "IP_ARTICLE_ID");
            DbParameters.Add(MySqlParamName.OpTopicData, "OP_TOPIC_DATA");
            DbParameters.Add(MySqlParamName.OPArtBrokenData, "OP_ART_BROKEN_DATA");
            DbParameters.Add(MySqlParamName.IpFromPortalId, "ip_from_portal_id");
            DbParameters.Add(MySqlParamName.IpToPortalId, "ip_to_portal_id");
            DbParameters.Add(MySqlParamName.IpFromTopicId, "ip_from_topic_id");
            DbParameters.Add(MySqlParamName.IpToTopicId, "ip_to_topic_id");
            DbParameters.Add(MySqlParamName.IpFromLevelId, "ip_from_level_id");
            DbParameters.Add(MySqlParamName.IpToLevelId, "ip_to_level_id");
            DbParameters.Add(MySqlParamName.IpFromLinkId, "ip_from_link_id");
            DbParameters.Add(MySqlParamName.IpToLinkId, "ip_to_link_id");
            DbParameters.Add(MySqlParamName.IpRequestId, "ip_req_id");
            DbParameters.Add(MySqlParamName.IpImgLinkedCode, "ip_img_linked_code");
            DbParameters.Add(MySqlParamName.IpMacLinkedCode, "ip_mac_linked_code");
            DbParameters.Add(MySqlParamName.IpLinkedCode, "IP_LINKED_CODE");
            DbParameters.Add(MySqlParamName.OpGetQueDtls, "op_get_que_dtls");
            DbParameters.Add(MySqlParamName.OpTotalData, "Op_Total_Data");
            DbParameters.Add(MySqlParamName.CircleCode, "IP_CIRCLE_CODE");
            DbParameters.Add(MySqlParamName.Version, "IP_VERSION");
            DbParameters.Add(MySqlParamName.OpTotalDataDuplicate, "OP_TOTALDATA");
            DbParameters.Add(MySqlParamName.OpErrorPropMes, "OP_ERRORPROP_MES");
            DbParameters.Add(MySqlParamName.IpCount, "IP_COUNT");
            DbParameters.Add(MySqlParamName.OPMapRoleLIst, "op_map_role_list");

            DbParameters.Add(MySqlParamName.IpRelatedArticleCode, "IP_RELATED_ARTICLE_CODE");
            DbParameters.Add(MySqlParamName.ArtSummary, "IP_ART_SUMMARY");
            DbParameters.Add(MySqlParamName.IpRelatedArticleType, "IP_RELATED_ARTICLE_TYPE");
            DbParameters.Add(MySqlParamName.IpStoretypeCode, "IP_STORETYPE_CODE");
            DbParameters.Add(MySqlParamName.OpAllCat, "OP_ALLCAT");
            DbParameters.Add(MySqlParamName.OputhArticleList, "OP_AUTH_ARTICLE_LIST");
            DbParameters.Add(MySqlParamName.IpTopicName, "IP_TOPIC_NAME");
            DbParameters.Add(MySqlParamName.IpBodyContent, "IP_BODY_CONTENT");
            DbParameters.Add(MySqlParamName.IpTitle, "IP_TITLE");
            DbParameters.Add(MySqlParamName.IpTag, "IP_TAG");
            DbParameters.Add(MySqlParamName.IpMetaTgs, "IP_METATAGS");
            DbParameters.Add(MySqlParamName.TopicId, "IP_TOPIC_ID");
            DbParameters.Add(MySqlParamName.ImageName, "ip_image_name");
            DbParameters.Add(MySqlParamName.ImagePath, "ip_image_path");
            DbParameters.Add(MySqlParamName.ImageExtType, "ip_image_ext_type");
            DbParameters.Add(MySqlParamName.ImageGroup, "ip_image_group");
            DbParameters.Add(MySqlParamName.OpImageCode, "OP_IMAGE_CODE");
            DbParameters.Add(MySqlParamName.IpImageCode, "Ip_imagecode");
            DbParameters.Add(MySqlParamName.OpTotalCode, "op_totalData");
            DbParameters.Add(MySqlParamName.GroupName, "ip_Group_Name");
            DbParameters.Add(MySqlParamName.OPGroupCode, "OP_Group_Code");
            DbParameters.Add(MySqlParamName.OPGroupCodeDuplicate, "op_GroupCode");
            DbParameters.Add(MySqlParamName.PortalId, "IP_PORTAL_ID");
            DbParameters.Add(MySqlParamName.OpTopicLink, "OP_TOPIC_LINK");
            DbParameters.Add(MySqlParamName.LinkId, "IP_LINK_ID");
            DbParameters.Add(MySqlParamName.ParentId, "IP_PARENT_ID");
            DbParameters.Add(MySqlParamName.ChildId, "IP_CHILD_ID");
            DbParameters.Add(MySqlParamName.TopicOrder, "IP_TOPIC_ORDER");
            DbParameters.Add(MySqlParamName.LevelId, "IP_LEVEL_ID");
            DbParameters.Add(MySqlParamName.OpGetQlGroup, "OP_GET_QL_GROUP");
            DbParameters.Add(MySqlParamName.Action, "IP_ACTION");
            DbParameters.Add(MySqlParamName.ActionFor, "IP_ACTION_FOR");
            DbParameters.Add(MySqlParamName.ActionRemark, "IP_ACTION_REMARK");
            DbParameters.Add(MySqlParamName.ActionRemarkDuplicat, "IP_ACTIONREMARK");
            DbParameters.Add(MySqlParamName.OPCatById, "OP_CAT_BYID");
            DbParameters.Add(MySqlParamName.OpCat, "Op_Cat");
            DbParameters.Add(MySqlParamName.ActionTypeDuplicate, "ip_Actiontype");
            DbParameters.Add(MySqlParamName.ActionType, "IP_ACTION_TYPE");
            DbParameters.Add(MySqlParamName.Activity, "IP_ACTIVITY");
            DbParameters.Add(MySqlParamName.ActivityDescription, "IP_ACTIVITY_DESCRIPTION");
            DbParameters.Add(MySqlParamName.ActivityName, "IP_ACTIVITY_NAME");
            DbParameters.Add(MySqlParamName.AnswerCode, "IP_ANSWER_CODE");
            DbParameters.Add(MySqlParamName.AnswerDescription, "IP_ANSWER_DESCRIPTION");
            DbParameters.Add(MySqlParamName.AreaServiceIncharge, "IP_AREA_SERVICE_INCHARGE");
            DbParameters.Add(MySqlParamName.ArtComments, "IP_ART_COMMENTS");
            DbParameters.Add(MySqlParamName.ArtCommentType, "IP_ART_COMMENT_TYPE");
            DbParameters.Add(MySqlParamName.ArtFrequency, "IP_ART_FREQUENCY");
            DbParameters.Add(MySqlParamName.ArticleCode, "IP_ARTICLE_CODE");
            DbParameters.Add(MySqlParamName.ArticleFbId, "IP_ARTICLE_FB_ID");
            DbParameters.Add(MySqlParamName.ArticleFeedbackId, "IP_ARTICLE_FEEDBACK_ID");
            DbParameters.Add(MySqlParamName.ArticleFrequency, "IP_ARTICLE_FREQUENCY");
            DbParameters.Add(MySqlParamName.ArticleMstCode, "IP_ARTICLE_MST_CODE");
            DbParameters.Add(MySqlParamName.ArticlePriority, "IP_ARTICLE_PRIORITY");
            DbParameters.Add(MySqlParamName.ArticleScope, "IP_ARTICLE_SCOPE");
            DbParameters.Add(MySqlParamName.ArticleSection, "IP_ARTICLE_SECTION");
            DbParameters.Add(MySqlParamName.ArticleSumm, "IP_ARTICLE_SUMM");
            DbParameters.Add(MySqlParamName.ArticleTitle, "IP_ARTICLE_TITLE");
            DbParameters.Add(MySqlParamName.ArticleTooltip, "IP_ARTICLE_TOOLTIP");
            DbParameters.Add(MySqlParamName.ArticleType, "IP_ARTICLE_TYPE");
            DbParameters.Add(MySqlParamName.ArticleTypeValue, "IP_ARTICLE_TYPE_VALUE");
            DbParameters.Add(MySqlParamName.ArticleVersion, "IP_ARTICLE_VERSION");
            DbParameters.Add(MySqlParamName.ArtMstCode, "IP_ART_MST_CODE");
            DbParameters.Add(MySqlParamName.AuthorRemark, "IP_AUTHOR_REMARK");
            DbParameters.Add(MySqlParamName.AuthorRemarkDuplicate, "ip_authorremark");

            DbParameters.Add(MySqlParamName.AuthPassword, "IP_AUTH_PASSWORD");
            DbParameters.Add(MySqlParamName.AuthUsername, "IP_AUTH_USERNAME");
            DbParameters.Add(MySqlParamName.BatchId, "IP_BATCH_ID");
            DbParameters.Add(MySqlParamName.BookmarkCode, "IP_BOOKMARK");
            DbParameters.Add(MySqlParamName.Browsable, "IP_BROWSABLE");
            DbParameters.Add(MySqlParamName.BusiCode, "IP_BUSI_CODE");
            DbParameters.Add(MySqlParamName.BusinessCode, "IP_BUSINESS_CODE");
            DbParameters.Add(MySqlParamName.CallJioId, "IP_CALL_JIO_ID");
            DbParameters.Add(MySqlParamName.CallType, "IP_CALL_TYPE");
            DbParameters.Add(MySqlParamName.CanExpire, "IP_CAN_EXPIRE");
            DbParameters.Add(MySqlParamName.CategoryCode, "IP_CATAGORY_CODE");
            DbParameters.Add(MySqlParamName.IPCategoryCode, "ip_cat_code");
            DbParameters.Add(MySqlParamName.CatTypeCode, "IP_CAT_TYPE_CODE");
            DbParameters.Add(MySqlParamName.CityName, "IP_CITY_NAME");
            DbParameters.Add(MySqlParamName.ClientCode, "IP_CLIENT_CODE");
            DbParameters.Add(MySqlParamName.IpClientCode, "ip_client_code");
            //DbParameters.Add(MySqlParamName.ClientId, "CLIENT_ID");
            DbParameters.Add(MySqlParamName.ClientId, "IP_CLIENT_CODE"); // this is used at active session list 
            DbParameters.Add(MySqlParamName.ClientName, "CLIENT_NAME");
            DbParameters.Add(MySqlParamName.CloneScenarioCode, "IP_CLONE_SCENARIO_CODE");
            DbParameters.Add(MySqlParamName.Comment, "IP_COMMENT");
            DbParameters.Add(MySqlParamName.CommentType, "IP_COMMENT_TYPE");
            DbParameters.Add(MySqlParamName.Content, "IP_CONTENT");
            DbParameters.Add(MySqlParamName.ContentCode, "IP_CONTENT_CODE");
            DbParameters.Add(MySqlParamName.ContentName, "IP_CONTENT_NAME");
            DbParameters.Add(MySqlParamName.ContentType, "IP_CONTENT_TYPE");
            DbParameters.Add(MySqlParamName.ContentTypeCode, "IP_CONTENT_TYPE_CODE");
            DbParameters.Add(MySqlParamName.ContentTypeValue, "IP_CONTENT_TYPE_VALUE");
            DbParameters.Add(MySqlParamName.CopyUser, "IP_COPY_USER");
            DbParameters.Add(MySqlParamName.CreatedBy, "IP_CREATED_BY");
            DbParameters.Add(MySqlParamName.CurrStatus, "IP_CURR_STATUS");
            DbParameters.Add(MySqlParamName.CurrUserPassword, "IP_CURR_USER_PASSWORD");
            DbParameters.Add(MySqlParamName.CustomerId, "IP_CUSTOMER_ID");
            DbParameters.Add(MySqlParamName.DefEsclToLead, "IP_DEF_ESCL_TO_LEAD_NHQ");
            DbParameters.Add(MySqlParamName.DesignationCode, "IP_DESIGNATION_CODE");
            DbParameters.Add(MySqlParamName.DeviceMobilityLead, "IP_DEVICE_MOBILITY_LEAD");
            DbParameters.Add(MySqlParamName.DeviceStateHead, "IP_DEVICE_STATE_HEAD");
            DbParameters.Add(MySqlParamName.DisplayName, "IP_DISPLAY_NAME");
            DbParameters.Add(MySqlParamName.DisplayOrder, "IP_DISPLAY_ORDER");
            DbParameters.Add(MySqlParamName.Domain, "ip_domain");
            DbParameters.Add(MySqlParamName.EmailId, "IP_EMAIL_ID");
            DbParameters.Add(MySqlParamName.IpEmailId, "IP_EMAILID");
            DbParameters.Add(MySqlParamName.EndIndexDuplicate, "IP_ENDINDEX");
            DbParameters.Add(MySqlParamName.EndDate, "IP_END_DATE");
            DbParameters.Add(MySqlParamName.EndIndex, "IP_END_INDEX");
            DbParameters.Add(MySqlParamName.IpEndIndex, "ip_endindex");
            DbParameters.Add(MySqlParamName.FaqAttachmentCode, "IP_FAQ_ATTACHMENT_CODE");
            DbParameters.Add(MySqlParamName.FaqBusiCode, "IP_FAQ_BUSI_CODE");
            DbParameters.Add(MySqlParamName.FaqBusiCont, "IP_FAQ_BUSI_CONT");
            DbParameters.Add(MySqlParamName.FaqBusiScope, "IP_FAQ_BUSI_SCOPE");
            DbParameters.Add(MySqlParamName.FaqBusiStatus, "IP_FAQ_BUSI_STATUS");
            DbParameters.Add(MySqlParamName.FaqVersion, "IP_FAQ_VERSION");
            DbParameters.Add(MySqlParamName.FbStatus, "IP_FB_STATUS");
            DbParameters.Add(MySqlParamName.FeedbackId, "IP_FEEDBACKID");
            DbParameters.Add(MySqlParamName.FeedbackIdDuplicate, "IP_FEEDBACKID");
            DbParameters.Add(MySqlParamName.FeedbackType, "IP_FEEDBACK_TYPE");
            DbParameters.Add(MySqlParamName.FilePath, "IP_FILE_PATH");
            DbParameters.Add(MySqlParamName.FirstName, "IP_FIRST_NAME");
            DbParameters.Add(MySqlParamName.IpFirstName, "IP_FNAME");
            DbParameters.Add(MySqlParamName.Flag, "IP_FLAG");
            DbParameters.Add(MySqlParamName.FrmCategoryCode, "IP_FRM_CATEGORY_CODE");
            DbParameters.Add(MySqlParamName.FromSubCategoryCode, "IP_FRM_SUB_CATEGORY_CODE");
            DbParameters.Add(MySqlParamName.GroupCode, "IP_GROUP_CODE");
            DbParameters.Add(MySqlParamName.HintAns, "IP_HINT_ANS");
            DbParameters.Add(MySqlParamName.HintQues, "IP_HINT_QUES");
            DbParameters.Add(MySqlParamName.HintQue, "IP_HINT_QUE");
            DbParameters.Add(MySqlParamName.Identifier, "IP_IDENTIFIER");
            DbParameters.Add(MySqlParamName.IOAttempts, "IOP_ATTEMPTS");
            DbParameters.Add(MySqlParamName.IOErrorDesc, "IO_ERROR_DESC");
            DbParameters.Add(MySqlParamName.IOPLanguageCode, "IOP_LANGUAGE_CODE");
            DbParameters.Add(MySqlParamName.IOPSessionId, "IOP_SESSION_ID");
            DbParameters.Add(MySqlParamName.IOPUserUid, "IOP_USER_UID");
            DbParameters.Add(MySqlParamName.IORequestNo, "IOP_REQUEST_NO");
            DbParameters.Add(MySqlParamName.IOUserUid, "IO_USER_UID");


            DbParameters.Add(MySqlParamName.IpAddRequestNo, "IP_ADD_REQUEST_NO");
            DbParameters.Add(MySqlParamName.IpAddress, "IP_IPADDRESS");
            DbParameters.Add(MySqlParamName.IpArticleCodes, "IP_ARTICLE_CODE");
            DbParameters.Add(MySqlParamName.IpBookmark, "IP_BOOKMARK");
            DbParameters.Add(MySqlParamName.IpCached, "IP_CACHED");
            DbParameters.Add(MySqlParamName.IpCacheId, "IP_CACHE_ID");
            DbParameters.Add(MySqlParamName.IpClientComponent, "ip_client_component");
            DbParameters.Add(MySqlParamName.IpClientDetail, "ip_client_dtl");
            DbParameters.Add(MySqlParamName.IpClientName, "ip_client_name");
            DbParameters.Add(MySqlParamName.IpClientUserSession, "ip_clt_usr_session");
            DbParameters.Add(MySqlParamName.IpClientUserSessionDuplicate, "ip_clt_usr_session");

            DbParameters.Add(MySqlParamName.IpDefaultPassword, "ip_default_password");
            DbParameters.Add(MySqlParamName.IpDefaultUsername, "ip_default_username");
            DbParameters.Add(MySqlParamName.IpDetailId, "Ip_DETAILID");
            DbParameters.Add(MySqlParamName.IpFeatureCode, "ip_feature_code");
            DbParameters.Add(MySqlParamName.IpFeatureCodeDuplicate, "ip_feature_code");
            DbParameters.Add(MySqlParamName.IpFromCategoryCode, "IP_FRM_CATEGORY_CODE");
            DbParameters.Add(MySqlParamName.IpFromSubCategoryCode, "IP_FRM_SUB_CATEGORY_CODE");
            DbParameters.Add(MySqlParamName.IpFromSubSubCategoryCode, "IP_FRM_SUB_SUB_CATEGORY_CODE");
            DbParameters.Add(MySqlParamName.IpHostedOnOc, "ip_hosted_on_oc");
            DbParameters.Add(MySqlParamName.IpIsMainCategory, "IP_IS_MAIN_CATEGEGORY");
            DbParameters.Add(MySqlParamName.IpLanguageId, "ip_language_id");
            DbParameters.Add(MySqlParamName.IpLicenseKey, "ip_license_key");
            DbParameters.Add(MySqlParamName.IpPasswordResetDays, "ip_pwd_reset_days");
            DbParameters.Add(MySqlParamName.IpPortal, "IP_PORTAL");
            DbParameters.Add(MySqlParamName.IpReqDtlId, "IP_REQ_DTL_ID");
            DbParameters.Add(MySqlParamName.IpResponseMessage, "IP_RESPONSE_MESSAGE");
            DbParameters.Add(MySqlParamName.IpClientShortCode, "ip_short_code");
            DbParameters.Add(MySqlParamName.IpSubDomain, "ip_sub_domain");
            DbParameters.Add(MySqlParamName.IpTheme, "ip_theme");
            DbParameters.Add(MySqlParamName.IpToCategoryCode, "IP_TO_PORTAL_CODE");
            DbParameters.Add(MySqlParamName.IpToPortalCode, "IP_TO_PORTAL_CODE");
            DbParameters.Add(MySqlParamName.IpFormStatus, "IP_FORM_STATUS");
            DbParameters.Add(MySqlParamName.IpFormName, "ip_form_name");
            DbParameters.Add(MySqlParamName.IpValueType, "ip_value_type");
            DbParameters.Add(MySqlParamName.IpFormId, "ip_form_id");
            DbParameters.Add(MySqlParamName.ip_keydtl_code, "ip_keydtl_code");
            DbParameters.Add(MySqlParamName.Ip_Keydtl_Option, "ip_keydtl_option");
            DbParameters.Add(MySqlParamName.Ip_Key_Type, "ip_key_type");
            DbParameters.Add(MySqlParamName.ip_operator, "ip_operator");
            DbParameters.Add(MySqlParamName.ip_option_code, "ip_option_code");

            DbParameters.Add(MySqlParamName.ip_formname, "ip_formname");
            DbParameters.Add(MySqlParamName.ip_form_key, "ip_form_key");            
            DbParameters.Add(MySqlParamName.ip_ApiId, "ip_ApiId");
            DbParameters.Add(MySqlParamName.ip_method_type, "ip_method_type");
            DbParameters.Add(MySqlParamName.ip_content_type, "ip_content_type");            

            DbParameters.Add(MySqlParamName.IpToSubCategoryCode, "IP_TO_SUB_CATEGORY_CODE");
            DbParameters.Add(MySqlParamName.IpToSubSubCategoryCode, "IP_TO_SUB_SUB_CATEGORY_CODE");
            DbParameters.Add(MySqlParamName.IpValidUpto, "ip_validupto");
            DbParameters.Add(MySqlParamName.IsAllPortal, "IP_IS_ALL_PORTAL");
            DbParameters.Add(MySqlParamName.IsCategory, "IP_IS_CATEGORY");
            DbParameters.Add(MySqlParamName.IsCharacter, "IP_IS_CHARACTER");
            DbParameters.Add(MySqlParamName.IsCoverType, "IP_IS_COVER_ART");
            DbParameters.Add(MySqlParamName.IsstartQuestion, "IP_ISSTART_QUESTION");
            DbParameters.Add(MySqlParamName.Jcm, "IP_JCM");
            DbParameters.Add(MySqlParamName.Jiostate, "IP_JIOSTATE");
            DbParameters.Add(MySqlParamName.KeyCode, "IP_KEY_CODE");
            DbParameters.Add(MySqlParamName.KeyName, "IP_KEY_NAME");
            DbParameters.Add(MySqlParamName.Keytext, "IP_KEYTEXT");
            DbParameters.Add(MySqlParamName.Landmark, "IP_LANDMARK");
            DbParameters.Add(MySqlParamName.LanguageCode, "IP_LANGUAGE_CODE");
            DbParameters.Add(MySqlParamName.LastName, "IP_LAST_NAME");
            DbParameters.Add(MySqlParamName.IpLastName, "IP_LNAME");
            DbParameters.Add(MySqlParamName.LinkedCode, "LINKED_CODE");
            DbParameters.Add(MySqlParamName.LinkedMacroCode, "IP_LINKED_MACRO_CODE");
            DbParameters.Add(MySqlParamName.LinkType, "IP_LINK_TYPE");
            DbParameters.Add(MySqlParamName.LinkUrl, "IP_LINK_URL");
            DbParameters.Add(MySqlParamName.Locality, "IP_LOCALITY");
            DbParameters.Add(MySqlParamName.LocationCode, "IP_LOCATION_CODE");
            DbParameters.Add(MySqlParamName.LocationName, "IP_LOCATION_NAME");
            DbParameters.Add(MySqlParamName.LoginUserUid, "IP_LOGIN_USER_UID");
            DbParameters.Add(MySqlParamName.MacroDesc, "IP_MACRO_DESC");
            DbParameters.Add(MySqlParamName.MacroId, "IP_MACRO_ID");
            DbParameters.Add(MySqlParamName.OpMacroId, "OP_MACRO_ID");
            DbParameters.Add(MySqlParamName.IpKeyType, "ip_key_type");
            DbParameters.Add(MySqlParamName.IpKeyDisplayName, "ip_key_displayname");

            DbParameters.Add(MySqlParamName.IpPrimary, "ip_primary");

            DbParameters.Add(MySqlParamName.IpMandatory, "ip_mandatory");


            DbParameters.Add(MySqlParamName.MacroName, "IP_MACRO_NAME");
            DbParameters.Add(MySqlParamName.MacroType, "IP_MACRO_TYPE");
            DbParameters.Add(MySqlParamName.MacroTypeCode, "IP_MACRO_TYPE_CODE");
            DbParameters.Add(MySqlParamName.MacroTypeName, "IP_MACRO_TYPE_NAME");
            DbParameters.Add(MySqlParamName.MapId, "IP_MAP_ID");
            DbParameters.Add(MySqlParamName.MenuCode, "IP_MENU_CODE");
            DbParameters.Add(MySqlParamName.ModuleCode, "IP_MODULE_CODE");
            DbParameters.Add(MySqlParamName.NewPassword, "IP_NEW_PASSWORD");
            DbParameters.Add(MySqlParamName.NewQuestionCode, "IP_NEW_QUESTION_CODE");
            DbParameters.Add(MySqlParamName.NewsDesc, "IP_NEWS_DESC");
            DbParameters.Add(MySqlParamName.NewsFlag, "IP_NEWS_FLAG");
            DbParameters.Add(MySqlParamName.NewUserPassword, "IP_NEW_USER_PASSWORD");
            DbParameters.Add(MySqlParamName.NextQuestionCode, "IP_NEXT_QUESTION_CODE");
            DbParameters.Add(MySqlParamName.NhqCoordinator, "IP_NHQ_COORDINATOR");
            DbParameters.Add(MySqlParamName.NoPortal, "IP_NO_PORTAL");
            DbParameters.Add(MySqlParamName.NoUsers, "IP_NO_USERS");
            DbParameters.Add(MySqlParamName.OPAccessoriesProps, "OP_ACCESSORIES_PROPS");
            DbParameters.Add(MySqlParamName.OpAccessoriesrPropsGh, "OPACCCESSORIES_PROP_GH");
            //DbParameters.Add(MySqlParamName.OPActivesessions, "OP_ACTIVESESSIONS");
            DbParameters.Add(MySqlParamName.OPActivesessions, "OP_ACTIVE_SESSION");//This is filed is used at active session list
            DbParameters.Add(MySqlParamName.OPActivesessionsDuplicate, "OP_ACTIVE_SESSIONS"); //op_active_session
            DbParameters.Add(MySqlParamName.OPActivePortalList, "OP_ACTIVE_PORTALLIST");
            DbParameters.Add(MySqlParamName.OP_Def_Portal, "op_def_portal");
            DbParameters.Add(MySqlParamName.OPStartQuestion, "OP_START_QUESTION");
            DbParameters.Add(MySqlParamName.OpAllClient, "OP_ALL_CLIENT");
            DbParameters.Add(MySqlParamName.OPAnswerData, "OP_ANSWER_DATA");
            DbParameters.Add(MySqlParamName.OPNewAnswerCode, "OP_NEW_ANSWER_CODE");

            DbParameters.Add(MySqlParamName.OPAnswerMapping, "OP_ANSWER_MAPPING");
            DbParameters.Add(MySqlParamName.OPAnswerProps, "OP_ANSWER_PROPS");
            DbParameters.Add(MySqlParamName.OpAnswerPropsGh, "OP_ANSWERPROP_GH");
            DbParameters.Add(MySqlParamName.OPArtAttachment, "OP_ART_ATTACHMENT");
            DbParameters.Add(MySqlParamName.OPArtComments, "OP_ART_COMMENTS");
            DbParameters.Add(MySqlParamName.OPArtCommentsData, "OP_ART_COMMENTS_DATA");
            DbParameters.Add(MySqlParamName.OpFormId, "op_form_id");
            DbParameters.Add(MySqlParamName.OpkeyDtlCode, "op_keydtl_code");
            DbParameters.Add(MySqlParamName.OpKeydtlOption, "op_keydtl_option");





            DbParameters.Add(MySqlParamName.OPArtData, "OP_ART_DATA");
            DbParameters.Add(MySqlParamName.OpToLinkId, "op_to_link_id");
            DbParameters.Add(MySqlParamName.OPArtDtls, "OP_ART_DTLS");
            DbParameters.Add(MySqlParamName.OPArticleFeedbackId, "OP_ARTICLE_FEEDBACK_ID");
            DbParameters.Add(MySqlParamName.OPGetStoreLoct, "OP_GET_STORE_LOCT");
            DbParameters.Add(MySqlParamName.OPArticleLink, "OP_ARTICLE_Link");
            DbParameters.Add(MySqlParamName.OPArticleList, "OP_ARTICLE_LIST");
            DbParameters.Add(MySqlParamName.OPArticleMacro, "OP_ARTICLE_MACRO");
            DbParameters.Add(MySqlParamName.OPArticleMstCode, "OP_ARTICLE_MST_CODE");
            DbParameters.Add(MySqlParamName.OPArtRating, "OP_ART_RATING");
            DbParameters.Add(MySqlParamName.OPArtRelArticles, "OP_ART_REL_ARTICLES");
            DbParameters.Add(MySqlParamName.OPAttachGhName, "OP_ATTACH_GH_NAME");
            DbParameters.Add(MySqlParamName.OPAttachment, "OP_ATTACHMENT");
            DbParameters.Add(MySqlParamName.OPBatchCode, "OP_BATCH_CODE");


            DbParameters.Add(MySqlParamName.OPBookmarkData, "OP_BOOKMARK_DATA");
            DbParameters.Add(MySqlParamName.OPBrokenData, "OP_BROKEN_DATA");
            DbParameters.Add(MySqlParamName.OPBusinessArtData, "OP_BUSINESS_ART_DATA");
            DbParameters.Add(MySqlParamName.OPBusinessArtData1, "OP_BUSINESS_ART_DATA");
            DbParameters.Add(MySqlParamName.OPCacheId, "OP_CACHE_ID");
            DbParameters.Add(MySqlParamName.OPCategoryType, "OP_CATEGORY_TYPE");
            DbParameters.Add(MySqlParamName.OPCatPortal, "OP_CAT_PORTAL");
            DbParameters.Add(MySqlParamName.OPCatPortalSum, "OP_CAT_PORTAL_SUMM");
            DbParameters.Add(MySqlParamName.OPClientCode, "OP_CLIENT_CODE");
            DbParameters.Add(MySqlParamName.OpClientDtl, "OP_CLIENT_DTL");
            DbParameters.Add(MySqlParamName.OPClientDtls, "OP_CLIENT_DTLS");
            DbParameters.Add(MySqlParamName.OpClientInfo, "OP_CLIENT_INFO");
            DbParameters.Add(MySqlParamName.OpComponentData, "OP_COMPONENT_DATA");
            DbParameters.Add(MySqlParamName.OpComponentTypeData, "OP_COMPONENT_TYPE_DATA");
            DbParameters.Add(MySqlParamName.OPContent, "OP_CONTENT");
            DbParameters.Add(MySqlParamName.OPCoverArt, "OP_COVER_ART");
            DbParameters.Add(MySqlParamName.OPData, "OP_DATA");
            DbParameters.Add(MySqlParamName.OPData1, "OP_DATA1");
            DbParameters.Add(MySqlParamName.OPData2, "OP_DATA2");
            DbParameters.Add(MySqlParamName.OPData3, "OP_DATA3");
            DbParameters.Add(MySqlParamName.OPDataBrokenLinks, "OP_DATA_BROKENLINKS");
            DbParameters.Add(MySqlParamName.OPDataList, "OP_DATA_LIST");
            DbParameters.Add(MySqlParamName.OPDesignationName, "OP_DESIGNATION_NAME");
            DbParameters.Add(MySqlParamName.OPDesignations, "OP_DESIGNATIONS");
            DbParameters.Add(MySqlParamName.OPDetails, "OP_DETAILS");
            DbParameters.Add(MySqlParamName.OPDisplayName, "OP_DISPALY_NAME");
            DbParameters.Add(MySqlParamName.OpeningDays, "IP_OPENING_DAYS");
            DbParameters.Add(MySqlParamName.OpeningTimings, "IP_OPENING_TIMINGS");
            DbParameters.Add(MySqlParamName.OPErrorCode, "OP_ERROR_CODE");
            DbParameters.Add(MySqlParamName.OPArtCount, "OP_ART_COUNT");

            DbParameters.Add(MySqlParamName.OPErrorDesc, "OP_ERROR_DESC");
            DbParameters.Add(MySqlParamName.OPErrorDetail, "OP_ERROR_DETAIL");
            DbParameters.Add(MySqlParamName.OPErrorMsg, "OP_ERROR_MSG");
            DbParameters.Add(MySqlParamName.OPErrorpropCode, "OP_ErrorProp_CODE");
            DbParameters.Add(MySqlParamName.OPFaqBusiCode, "OP_FAQ_BUSI_CODE");
            DbParameters.Add(MySqlParamName.OPFaqBusiCode1, "OP_FAQ_BUSI_CODE");
            DbParameters.Add(MySqlParamName.OPFaqBusiVer, "OP_FAQ_BUSI_VER");
            DbParameters.Add(MySqlParamName.OPFaqBusiVer1, "OP_FAQ_BUSI_VER");
            DbParameters.Add(MySqlParamName.OPFbHead, "OP_FB_HEAD");
            DbParameters.Add(MySqlParamName.OPFbRating, "OP_FB_RATING");
            DbParameters.Add(MySqlParamName.OPFbStatus, "OP_FB_STATUS");
            DbParameters.Add(MySqlParamName.OPFeatureData, "OP_FEATURE_DATA");//OutRoles
            DbParameters.Add(MySqlParamName.OPGetContent, "OP_GET_CONTENT");
            DbParameters.Add(MySqlParamName.OPGetData, "OP_GET_DATA");
            DbParameters.Add(MySqlParamName.OPGetKeys, "OP_GET_KEYS");
            DbParameters.Add(MySqlParamName.OPGetKeywords, "OP_GET_KEYWORDS");
            DbParameters.Add(MySqlParamName.OPGetPortalRating, "OP_GET_PORTAL_RATING");

            DbParameters.Add(MySqlParamName.OPGetQueDtl, "OP_GET_QUE_DTL");
            DbParameters.Add(MySqlParamName.OPGetRoles, "OP_GET_ROLES");
            DbParameters.Add(MySqlParamName.OPGHData, "OP_GH_DATA");
            DbParameters.Add(MySqlParamName.OPHeader, "OP_HEADER");
            DbParameters.Add(MySqlParamName.OPHighData, "OP_High_Data");
            DbParameters.Add(MySqlParamName.OPInterlinkedArt, "OP_INTERLINKED_ART");
            DbParameters.Add(MySqlParamName.OPKeywords, "OP_KEYWORD");
            DbParameters.Add(MySqlParamName.OPL1Data, "OP_L1_DATA");
            DbParameters.Add(MySqlParamName.OPLangData, "OP_LANG_DATA");
            DbParameters.Add(MySqlParamName.OPLocationList, "OP_LOCATION_LIST");
            DbParameters.Add(MySqlParamName.OpLowData, "OP_LOW_DATA");
            DbParameters.Add(MySqlParamName.OPMacroData, "OP_MACRO_DATA");
            DbParameters.Add(MySqlParamName.OPMacroId, "OP_MACRO_ID");
            DbParameters.Add(MySqlParamName.OPMacroType, "OP_MACRO_TYPE");
            DbParameters.Add(MySqlParamName.OpGetMacroType, "OP_GET_MACRO_TYPE");

            DbParameters.Add(MySqlParamName.OPMapData, "OP_MAP_DATA");
            DbParameters.Add(MySqlParamName.OPMapId, "OP_MAP_ID");
            DbParameters.Add(MySqlParamName.OPMappedList, "OP_MAPPED_LIST");
            DbParameters.Add(MySqlParamName.OPMenuData, "OP_MENU_DATA");
            DbParameters.Add(MySqlParamName.OPNewFaqBusiCode, "OP_NEW_FAQ_BUSI_CODE");
            DbParameters.Add(MySqlParamName.OPNewFaqBusiCode_1, "OP_NEW_FAQ_BUSI_CODE");
            DbParameters.Add(MySqlParamName.OPNewQuestionCode, "OP_NEW_QUESTION_CODE");
            DbParameters.Add(MySqlParamName.OPNewScenarioCode, "OP_NEW_SCENARIO_CODE");
            DbParameters.Add(MySqlParamName.OPNewsData, "OP_NEWS_DATA");
            DbParameters.Add(MySqlParamName.OPPORTAL, "PORTAL");
            DbParameters.Add(MySqlParamName.OPPortalCode, "OP_PORTAL_CODE");
            DbParameters.Add(MySqlParamName.OPPortalName, "op_portal_name");
            DbParameters.Add(MySqlParamName.OPPortalData, "op_portal_data");
            DbParameters.Add(MySqlParamName.OPPortalDtls, "OP_PORTAL_DTLS");
            DbParameters.Add(MySqlParamName.OPPortalList, "OP_PORTAL_LIST");
            DbParameters.Add(MySqlParamName.OPPortalSumm, "op_portal_summ");
            DbParameters.Add(MySqlParamName.OPQueAccessories, "OP_QUE_ACCESSORIES");
            DbParameters.Add(MySqlParamName.OPQuesAnsdata, "OP_QUES_ANSDATA");
            DbParameters.Add(MySqlParamName.OPQuestionBroken, "OP_QUESTION_BROKEN");
            DbParameters.Add(MySqlParamName.OPQuestionCode, "OP_QUESTION_CODE");
            DbParameters.Add(MySqlParamName.OPQuestionData, "OP_QUESTION_DATA");
            DbParameters.Add(MySqlParamName.OPQuestionProps, "OP_QUESTION_PROPS");
            DbParameters.Add(MySqlParamName.OpQuestionsProp_Gh, "OP_QUESTIONSPROP_GH");
            DbParameters.Add(MySqlParamName.OPQuickLink, "OP_QUICK_LINK");
            DbParameters.Add(MySqlParamName.OPQuickLinkData, "OP_QUICK_LINK_DATA");
            DbParameters.Add(MySqlParamName.OPRedisList, "OP_REDISH_LIST");
            DbParameters.Add(MySqlParamName.OPRelArticle, "OP_REL_ARTICLE");
            DbParameters.Add(MySqlParamName.OPRelatedArt, "OP_RELATED_ART");
            DbParameters.Add(MySqlParamName.OPRoles, "OP_ROLES");
            DbParameters.Add(MySqlParamName.OPRoleList, "OP_ROLE_LIST");
            DbParameters.Add(MySqlParamName.OPRoleActionList, "OP_ROLE_ACTION_LIST");




            DbParameters.Add(MySqlParamName.OPScenarioCode, "OP_SCENARIO_CODE");
            DbParameters.Add(MySqlParamName.OPScenarioProps, "OP_SCENARIO_PROPS");
            DbParameters.Add(MySqlParamName.OpScnearioPropsGh, "OP_SCENARIOPROPS_GH");
            DbParameters.Add(MySqlParamName.OPSearchFlag, "OP_SEARCH_FLAG");
            DbParameters.Add(MySqlParamName.OPSessionCode, "OP_SESSION_CODE");
            DbParameters.Add(MySqlParamName.OPStartDetail, "OP_START_DETAIL");
            DbParameters.Add(MySqlParamName.OPStatus, "OP_STATUS");
            DbParameters.Add(MySqlParamName.OPStoreCode, "OP_STORE_CODE");
            DbParameters.Add(MySqlParamName.OPStoreTypeCode, "OP_STORETYPE_CODE");
            DbParameters.Add(MySqlParamName.OPStoreTypeList, "OP_STORE_TYPE_LIST");
            DbParameters.Add(MySqlParamName.OPTopicCached, "OP_TOPIC_CACHEID");
            DbParameters.Add(MySqlParamName.OPTopicTreeCat, "OP_TOPIC_TREE_CAT");
            DbParameters.Add(MySqlParamName.OPTopicTreeSubcat, "OP_TOPIC_TREE_SUBCAT");
            DbParameters.Add(MySqlParamName.OPTopicTreeSubsubcat, "OP_TOPIC_TREE_SUBSUBCAT");
            DbParameters.Add(MySqlParamName.OPUsefulData, "OP_USEFUL_DATA");
            DbParameters.Add(MySqlParamName.OPUserData, "OP_USER_DATA");
            DbParameters.Add(MySqlParamName.OPUserDisplayName, "OP_USER_DISPLAY_NAME");
            DbParameters.Add(MySqlParamName.OPUserDisplayNameDuplicate, "OP_USER_DISPLAYNAME");
            DbParameters.Add(MySqlParamName.OpuserDisplaynameDuplicat, "OP_USER_DISPLAYNAME");
            DbParameters.Add(MySqlParamName.OPUserModules, "OP_USER_MODULES");
            DbParameters.Add(MySqlParamName.OPUserName, "OP_USER_NAME");
            DbParameters.Add(MySqlParamName.OPUserPortals, "OP_USER_PORTALS");
            DbParameters.Add(MySqlParamName.OPUserRoles, "OP_USER_ROLES");
            DbParameters.Add(MySqlParamName.OPUsers, "OP_USERS");
            DbParameters.Add(MySqlParamName.OPUserStatus, "OP_USER_STATUS");
            DbParameters.Add(MySqlParamName.OPUserUid, "OP_USER_UID");
            DbParameters.Add(MySqlParamName.OPWt, "OP_WT");
            DbParameters.Add(MySqlParamName.ParentMacroCode, "IP_PARENT_MACRO_CODE");
            DbParameters.Add(MySqlParamName.Password, "IP_PASSWORD");
            DbParameters.Add(MySqlParamName.Pincode, "IP_PINCODE");
            DbParameters.Add(MySqlParamName.PortalAuthDomain, "IP_PORTAL_AUTH_DOMAIN");
            DbParameters.Add(MySqlParamName.PortalCode, "IP_PORTAL_CODE");
            DbParameters.Add(MySqlParamName.PortalDomain, "IP_PORTAL_DOMAIN");
            DbParameters.Add(MySqlParamName.PortalList, "IP_PORTAL_LIST");
            DbParameters.Add(MySqlParamName.PortalName, "IP_PORTAL_NAME");
            DbParameters.Add(MySqlParamName.ProactiveInfo, "IP_PROACTIVE_INFO");
            DbParameters.Add(MySqlParamName.QuestionCode, "IP_QUESTION_CODE");
            DbParameters.Add(MySqlParamName.QuestionDescription, "IP_QUESTION_DESCRIPTION");
            DbParameters.Add(MySqlParamName.QuestionName, "IP_QUESTION_NAME");
            DbParameters.Add(MySqlParamName.QuestionType, "IP_QUESTION_TYPE");
            DbParameters.Add(MySqlParamName.QuickFlagLink, "IP_QUICK_FLAG_LINK");
            DbParameters.Add(MySqlParamName.QuickLinkFlag, "IP_QUICK_LINK_FLAG");
            DbParameters.Add(MySqlParamName.QuickLinkGroupCode, "IP_QUICK_LINK_GROUP_CODE");
            DbParameters.Add(MySqlParamName.QuickLinkText, "IP_QUICK_LINK_TEXT");
            DbParameters.Add(MySqlParamName.Rating, "IP_RATING");
            DbParameters.Add(MySqlParamName.RegionalSpoc, "IP_REGIONAL_SPOC");
            DbParameters.Add(MySqlParamName.Remark, "IP_REMARK");
            DbParameters.Add(MySqlParamName.ReportingTo, "IP_REPORTING_TO");
            DbParameters.Add(MySqlParamName.IpReportingTo, "IP_REPORTINGTO");//duplicate

            DbParameters.Add(MySqlParamName.RequestType, "IP_REQUEST_TYPE");
            DbParameters.Add(MySqlParamName.ResetBy, "IP_RESET_BY");
            DbParameters.Add(MySqlParamName.ResolutionText, "IP_RESOLUTION_TEXT");
            DbParameters.Add(MySqlParamName.ReviveStatus, "IP_REVIVE_STATUS");
            DbParameters.Add(MySqlParamName.Role, "IP_ROLE");
            DbParameters.Add(MySqlParamName.Rsm, "IP_RSM");
            DbParameters.Add(MySqlParamName.ScenarioCode, "IP_SCENARIO_CODE");
            DbParameters.Add(MySqlParamName.ScenarioPriority, "IP_SCENARIO_PRIORITY");
            DbParameters.Add(MySqlParamName.ScenarioScope, "IP_SCENARIO_SCOPE");
            DbParameters.Add(MySqlParamName.ScenarioTitle, "IP_SCENARIO_TITLE");
            DbParameters.Add(MySqlParamName.ScenarioTooltip, "IP_SCENARIO_TOOLTIP");
            DbParameters.Add(MySqlParamName.ScenarioVersion, "IP_SCENARIO_VERSION");
            DbParameters.Add(MySqlParamName.Searchable, "IP_SEARCHABLE");
            DbParameters.Add(MySqlParamName.SearchType, "IP_SEARCH_TYPE");
            DbParameters.Add(MySqlParamName.SearchCriteria, "IP_SEARCH_CRITERIA");
            DbParameters.Add(MySqlParamName.SearchText, "IP_SEARCH_TEXT");
            DbParameters.Add(MySqlParamName.SelfStatus, "IP_SELF_STATUS");
            DbParameters.Add(MySqlParamName.ServiceCenterName, "IP_SERVICE_CENTER_NAME");
            DbParameters.Add(MySqlParamName.SessionCode, "IP_SESSION_CODE");
            DbParameters.Add(MySqlParamName.SessionId, "IP_SESSION_ID");
            DbParameters.Add(MySqlParamName.IP_SESSIONID, "IP_SESSIONID");
            DbParameters.Add(MySqlParamName.Source, "IP_SOURCE");
            DbParameters.Add(MySqlParamName.SrchCrit, "IP_SRCH_CRIT");
            DbParameters.Add(MySqlParamName.StartDate, "IP_START_DATE");
            DbParameters.Add(MySqlParamName.StartIndex, "IP_START_INDEX");
            DbParameters.Add(MySqlParamName.StartIndexDuplicate, "IP_STARTINDEX");
            DbParameters.Add(MySqlParamName.IpStartIndex, "ip_startindex");
            DbParameters.Add(MySqlParamName.State, "IP_STATE");
            DbParameters.Add(MySqlParamName.StateName, "IP_STATE_NAME");
            DbParameters.Add(MySqlParamName.Status, "IP_STATUS");
            DbParameters.Add(MySqlParamName.StoreAddress, "IP_STORE_ADDRESS");
            DbParameters.Add(MySqlParamName.StoreCode, "IP_STORE_CODE");
            DbParameters.Add(MySqlParamName.StoreType, "IP_STORE_TYPE");
            DbParameters.Add(MySqlParamName.StoreTypeDuplicate, "IP_STORETYPE");
            DbParameters.Add(MySqlParamName.StoreTypeCode, "IP_STORE_TYPE_CODE");
            DbParameters.Add(MySqlParamName.StoretypeName, "IP_STORETYPE_NAME");
            DbParameters.Add(MySqlParamName.SubCatCode, "IP_SUBCAT_CODE");
            DbParameters.Add(MySqlParamName.SubcategoryCode, "IP_SUBCATEGORY_CODE");
            DbParameters.Add(MySqlParamName.SubSubCatCode, "IP_SUB_SUB_CAT_CODE");
            DbParameters.Add(MySqlParamName.SuggestionRemark, "IP_SUGGESTION_REMARK");
            DbParameters.Add(MySqlParamName.SupRemark, "IP_SUP_REMARK");
            DbParameters.Add(MySqlParamName.SystemTag, "IP_SYSTEM_TAG");
            DbParameters.Add(MySqlParamName.Tooltip, "IP_TOOLTIP");
            DbParameters.Add(MySqlParamName.UlDisplayName, "IP_UL_DISPLAY_NAME");
            DbParameters.Add(MySqlParamName.UlTooltip, "IP_UL_TOOLTIP");
            DbParameters.Add(MySqlParamName.UpdStatus, "IP_UPD_STATUS");
            DbParameters.Add(MySqlParamName.UsefulLinkCode, "IP_USEFUL_LINK_CODE");
            DbParameters.Add(MySqlParamName.UserActivity, "IP_USER_ACTIVITY");
            DbParameters.Add(MySqlParamName.UserCreatedBy, "IP_USER_CREATED_BY");
            //    DbParameters.Add(MySqlParamName.UserIPduplicate, "IP_USER_ID"); //this line not found in db IP_USERNAME has been change to IP_USER_NAME
            DbParameters.Add(MySqlParamName.UserId, "IP_USERID");
            DbParameters.Add(MySqlParamName.IpUserId, "ip_user_id");
            DbParameters.Add(MySqlParamName.JsonType, "IP_JSON_TYPE");
            DbParameters.Add(MySqlParamName.UserIdDuplicate, "IP_USER_ID");
            DbParameters.Add(MySqlParamName.IpUserPassword, "IP_USER_PASSWORD");

            DbParameters.Add(MySqlParamName.UserInput, "IP_USER_INPUT");
            // DbParameters.Add(MySqlParamName.UserName, "IP_USERNAME");   //this line not found in db IP_USERNAME has been change to IP_USER_NAME
            DbParameters.Add(MySqlParamName.UserName, "IP_USER_NAME");
            // DbParameters.Add(MySqlParamName.UserPassword, "IP_USER_PASSWORD");
            DbParameters.Add(MySqlParamName.UserPassword, "IP_PASSWORD");
            DbParameters.Add(MySqlParamName.UserType, "IP_USER_TYPE");
            DbParameters.Add(MySqlParamName.IpUserType, "IP_USERTYPE");

            DbParameters.Add(MySqlParamName.UserUid, "IP_USER_UID");
            DbParameters.Add(MySqlParamName.Weightage, "IP_WEIGHTAGE");
            DbParameters.Add(MySqlParamName.WhetherKill, "IP_WHETHER_KILL");
            DbParameters.Add(MySqlParamName.WhetherKillsession, "IP_WHETHER_KILLSESSION");
            DbParameters.Add(MySqlParamName.ArtRating, "IP_ART_RATING");
            DbParameters.Add(MySqlParamName.FBStatus, "IP_FB_STATUS");
            DbParameters.Add(MySqlParamName.FileName, "IP_FILE_NAME");
            DbParameters.Add(MySqlParamName.Extension, "IP_EXTENSION");
            DbParameters.Add(MySqlParamName.OPAttachCode, "OP_ATTACHCODE");
            DbParameters.Add(MySqlParamName.AttachmentCode, "IP_ATTACHMENT_CODE");
            DbParameters.Add(MySqlParamName.SearchKey, "IP_SEARCH_KEY");
            DbParameters.Add(MySqlParamName.SearchValue, "IP_SEARCH_VALUE");
            DbParameters.Add(MySqlParamName.OPNewsInfo, "OP_NEWS_INFO");
            DbParameters.Add(MySqlParamName.OPArticleWeightage, "OP_ARTICLE_WEIGHTAGE_INFO");

            DbParameters.Add(MySqlParamName.IsAutomationQuestion, "IP_ISAUTOMATION_QUESTION");
            DbParameters.Add(MySqlParamName.ip_valuetype, "ip_valuetype");

            DbParameters.Add(MySqlParamName.ApiId, "ip_ApiId");
            DbParameters.Add(MySqlParamName.ApiName, "ip_ApiName");
            DbParameters.Add(MySqlParamName.ApiUrl, "ip_ApiUrl");
            DbParameters.Add(MySqlParamName.ApiTypeCode, "ip_ApiType");
            DbParameters.Add(MySqlParamName.ApiMethodCode, "ip_ApiMethod");
            DbParameters.Add(MySqlParamName.EventCode, "ip_EventId");
            DbParameters.Add(MySqlParamName.OPApiID, "op_apiid");
            DbParameters.Add(MySqlParamName.ParameterType, "ip_parameter_type");
            DbParameters.Add(MySqlParamName.OurParameter, "ip_our_parameter");
            DbParameters.Add(MySqlParamName.ClientParameter, "ip_client_parameter");
            DbParameters.Add(MySqlParamName.ApiDtlId, "ip_api_dtlid");
            DbParameters.Add(MySqlParamName.OpApiDtlId, "op_api_dtlid");//
            DbParameters.Add(MySqlParamName.IPApiId, "ip_api_id");
            DbParameters.Add(MySqlParamName.IPApiName, "ip_api_name");

            DbParameters.Add(MySqlParamName.BrifingConfigCode, "ip_brifing_config_code");
            DbParameters.Add(MySqlParamName.NoOfDays, "ip_no_of_days");
            DbParameters.Add(MySqlParamName.NoOfAttempts, "ip_no_of_attempts");
            DbParameters.Add(MySqlParamName.NoOfQueInPool, "ip_no_of_ques_in_pool");
            DbParameters.Add(MySqlParamName.NoOfRandomQue, "ip_no_of_random_questions");
            DbParameters.Add(MySqlParamName.CanSkip, "ip_can_skip");
            DbParameters.Add(MySqlParamName.IpAssessmentName, "ip_assessment_name");

            DbParameters.Add(MySqlParamName.IpQuestionType, "ip_question_type");
            DbParameters.Add(MySqlParamName.IpAssessmentDuration, "ip_assessment_duration");
            DbParameters.Add(MySqlParamName.IpPassingCriteria, "ip_passing_criteria");
            DbParameters.Add(MySqlParamName.OpAssessmentCode, "op_assessment_code");
            DbParameters.Add(MySqlParamName.IpAssessmentCode, "ip_assessment_code");

            DbParameters.Add(MySqlParamName.ip_question_sr_no, "ip_question_sr_no");
            DbParameters.Add(MySqlParamName.ip_assessment_question_name, "ip_assessment_question_name");
            DbParameters.Add(MySqlParamName.ip_answer_type, "ip_answer_type");
            DbParameters.Add(MySqlParamName.ip_question_score, "ip_question_score");
            DbParameters.Add(MySqlParamName.ip_delete_flag, "ip_delete_flag");
            DbParameters.Add(MySqlParamName.op_assessment_question_code, "op_assessment_question_code");
            DbParameters.Add(MySqlParamName.op_assessment_answer_code, "op_assessment_answer_code");



            DbParameters.Add(MySqlParamName.ip_assessment_question_code, "ip_assessment_question_code");
            DbParameters.Add(MySqlParamName.ip_assessment_answer_description, "ip_assessment_answer_description");
            DbParameters.Add(MySqlParamName.ip_answer_score, "ip_answer_score");
            DbParameters.Add(MySqlParamName.ip_answer_is_correct, "ip_answer_is_correct");
            DbParameters.Add(MySqlParamName.ip_display_order, "ip_display_order");

            DbParameters.Add(MySqlParamName.ip_question_type, "ip_question_type");
            DbParameters.Add(MySqlParamName.ip_assessment_duration, "ip_assessment_duration");
            DbParameters.Add(MySqlParamName.ip_passing_criteria, "ip_passing_criteria");
            DbParameters.Add(MySqlParamName.ip_assessment_code, "ip_assessment_code");
            DbParameters.Add(MySqlParamName.ip_assessment_answer_code, "ip_assessment_answer_code");
            


























        }
        public static MySqlParameter MySqlParameterInstance(MySqlParamName enumParamName)
        {
            var MySqlParameter = new MySqlParameter();
            MySqlParameter.ParameterName = GetParameterName(enumParamName);
            MySqlParameter.MySqlDbType = GetParameterType(enumParamName);
            MySqlParameter.Size = GetParameterSize(enumParamName);
            return MySqlParameter;
        }

        public static MySqlParameter MySqlParameterInstance(MySqlParamName enumParamName, char value)
        {
            var MySqlParameter = MySqlParameterInstance(enumParamName);
            MySqlParameter.Value = value;
            return MySqlParameter;
        }

        public static MySqlParameter MySqlParameterInstance(MySqlParamName enumParamName, string value)
        {
            var MySqlParameter = MySqlParameterInstance(enumParamName);
            MySqlParameter.Value = value;
            return MySqlParameter;
        }
        public static MySqlParameter MySqlParameterInstance(MySqlParamName enumParamName, int value)
        {
            var MySqlParameter = MySqlParameterInstance(enumParamName);
            MySqlParameter.Value = value;
            return MySqlParameter;
        }

        public static MySqlParameter MySqlParameterInstance(MySqlParamName enumParamName, object value)
        {
            var MySqlParameter = MySqlParameterInstance(enumParamName);
            MySqlParameter.Value = value;
            return MySqlParameter;
        }
        public static string GetParameterName(MySqlParamName enumParamName)
        {
            return DbParameters[enumParamName];
        }
        private static MySqlDbType GetParameterType(MySqlParamName enumParamName)
        {
            MySqlDbType dbType;
            switch (enumParamName)
            {
                case MySqlParamName.IpPasswordResetDaysDuplicate:
                    dbType = MySqlDbType.Int16;
                    break;


                case MySqlParamName.IpTag:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.IpTitle:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.LocationName:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.FirstName:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.IpFirstName:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.MacroDesc:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.HintQue:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.IOPUserUid:  //add jaspreet
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.IpReportingTo:  //add jaspreet
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.OpMacroId:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.ClientId:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.DisplayOrder:
                    dbType = MySqlDbType.Int16;
                    break;

                //case MySqlParamName.PortalId:
                //    dbType = MySqlDbType.Int32;
                //    break;
                case MySqlParamName.AttributeId:
                    dbType = MySqlDbType.Int32;
                    break;
                case MySqlParamName.ParentId:
                    dbType = MySqlDbType.Int64;
                    break;

                case MySqlParamName.ChildId:
                    dbType = MySqlDbType.Int64;
                    break;

                case MySqlParamName.OpProductCatalogId:
                    dbType = MySqlDbType.Blob;
                    break;

                case MySqlParamName.UserIdDuplicate:
                    dbType = MySqlDbType.VarChar;
                    break;



                //case MySqlParamName.OPContentTypeCode:
                //    dbType = MySqlDbType.JSON;
                //    break;
                case MySqlParamName.TopicId:
                    dbType = MySqlDbType.Int64;
                    break;
                case MySqlParamName.TopicOrder:
                    dbType = MySqlDbType.Int32;
                    break;

                case MySqlParamName.Domain:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.OpImageCode:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.IpClientShortCode:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.IpLicenseKey:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.StartIndex:
                    dbType = MySqlDbType.Int32;
                    break;
                case MySqlParamName.IpValidUpto:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.IpSubDomain:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.IpClientUserSessionDuplicate:
                    dbType = MySqlDbType.Int32;
                    break;
                case MySqlParamName.IpFormStatus:
                    dbType = MySqlDbType.VarChar;
                    break;


                case MySqlParamName.IpHostedOnOc:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.WhetherKillsession:
                    dbType = MySqlDbType.Int32;
                    break;

                case MySqlParamName.Password:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.IpStartIndex:
                    dbType = MySqlDbType.Int32;
                    break;


                case MySqlParamName.IpFromPortalId:
                    dbType = MySqlDbType.Int64;
                    break;

                case MySqlParamName.IpToPortalId:
                    dbType = MySqlDbType.Int64;
                    break;
                case MySqlParamName.OPBatchCode:
                    dbType = MySqlDbType.Double;
                    break;

                case MySqlParamName.IpFromTopicId:
                    dbType = MySqlDbType.Int64;
                    break;

                case MySqlParamName.LinkId:
                    dbType = MySqlDbType.Int64;
                    break;

                case MySqlParamName.IpToTopicId:
                    dbType = MySqlDbType.Int64;
                    break;

                case MySqlParamName.IpFromLevelId:
                    dbType = MySqlDbType.VarChar;
                    break;

                case MySqlParamName.IpToLevelId:
                    dbType = MySqlDbType.VarChar;
                    break;

                case MySqlParamName.IpFromLinkId:
                    dbType = MySqlDbType.Int64;
                    break;
                case MySqlParamName.IpToLinkId:
                    dbType = MySqlDbType.Int64;
                    break;

                case MySqlParamName.IpRequestId:
                    dbType = MySqlDbType.Int64;
                    break;


                case MySqlParamName.ClientUserSession:
                    dbType = MySqlDbType.Int32;
                    break;



                case MySqlParamName.Weightage:
                    dbType = MySqlDbType.Int32;
                    break;


                case MySqlParamName.IpDefaultUsername:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.IpClientDetail:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.IpUserPassword:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.LastName:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.IpLastName:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.PortalList:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.IpTopicName:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.OpGetQueDtls:
                    dbType = MySqlDbType.JSON;
                    break;
                case MySqlParamName.OPInterlinkedArt:
                    dbType = MySqlDbType.JSON;
                    break;

                case MySqlParamName.HintAns:
                    dbType = MySqlDbType.VarChar;
                    break;

                case MySqlParamName.IpClientComponent:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.IOPSessionId:
                    dbType = MySqlDbType.Int32;
                    break;
                case MySqlParamName.IOAttempts:
                    dbType = MySqlDbType.Double;
                    break;
                //case MySqlParamName.HintQues:
                //    dbType = MySqlDbType.Int32;
                //    break;
                ////  case MySqlParamName.Weightage:
                //      dbType = MySqlDbType.Int32;
                //        case MySqlParamName.OPData:  //add jaspreet

                case MySqlParamName.IpFeatureCode:
                    dbType = MySqlDbType.Int32;
                    break;


                case MySqlParamName.IpFeatureCodeDuplicate:
                    dbType = MySqlDbType.VarChar;
                    break;
                case MySqlParamName.IpLanguageId:
                    dbType = MySqlDbType.Int32;
                    break;
                case MySqlParamName.IpSessionId:
                    dbType = MySqlDbType.Int32;
                    break;
                case MySqlParamName.IpLanguageIdDuplicate:
                    dbType = MySqlDbType.VarChar;
                    break;

                case MySqlParamName.FeedbackIdDuplicate:
                    dbType = MySqlDbType.Int32;
                    break;

                case MySqlParamName.ContentTypeCode:
                    dbType = MySqlDbType.Int32;
                    break;

                case MySqlParamName.Content:  //add jaspreet
                    dbType = MySqlDbType.LongBlob;
                    break;


                case MySqlParamName.OpuserDisplaynameDuplicat:  //add jaspreet
                    dbType = MySqlDbType.VarChar;
                    break;

                case MySqlParamName.OPArticleFeedbackId:
                    dbType = MySqlDbType.Int32;
                    break;

                case MySqlParamName.IpCount:
                    dbType = MySqlDbType.Int32;
                    break;
                case MySqlParamName.IsCoverPageFlag:
                    dbType = MySqlDbType.VarChar;
                    break;

                default:
                    dbType = MySqlDbType.VarChar;
                    break;


            }
            return dbType;
        }
        private static int GetParameterSize(MySqlParamName enumParamName)
        {
            int size = 0;
            switch (enumParamName)
            {
                case MySqlParamName.IsCoverPageFlag:
                    size = 1;
                    break;
                case MySqlParamName.WhetherKillsession:
                    break;

                case MySqlParamName.IOAttempts:
                    break;
                case MySqlParamName.OpImageCode:
                    size = 20;
                    break;
                case MySqlParamName.IpTag:
                    size = 5;
                    break;
                case MySqlParamName.IpTitle:
                    size = 5;
                    break;
                case MySqlParamName.IpAddress:
                    size = 20;
                    break;

                case MySqlParamName.ModuleCode:
                    size = 20;
                    break;

                case MySqlParamName.OPUserStatus:
                    size = 500;
                    break;
                case MySqlParamName.Password:
                    size = 500;
                    break;
                case MySqlParamName.IpUserPassword:
                    size = 4000;
                    break;
                case MySqlParamName.HintAns:
                    size = 200;
                    break;
                case MySqlParamName.MacroDesc:
                    size = 50000;
                    break;
                case MySqlParamName.IpArtState:
                    size = 10;
                    break;
                case MySqlParamName.LanguageCode:
                    size = 10;
                    break;
                case MySqlParamName.UserName:
                    size = 50;
                    break;
                case MySqlParamName.AuthorRemark:
                    size = 200;
                    break;
                case MySqlParamName.HintQue:
                    size = 200;
                    break;
                case MySqlParamName.PortalList:
                    size = 5000;
                    break;
                case MySqlParamName.IpTopicName:
                    size = 200;
                    break;
                case MySqlParamName.IpLinkedCode:
                    size = 4000;
                    break;
                case MySqlParamName.IpMacLinkedCode:
                    size = 4000;
                    break;
                case MySqlParamName.IpImgLinkedCode:
                    size = 4000;
                    break;
                case MySqlParamName.UserPassword:
                    size = 500;
                    break;
                case MySqlParamName.ClientName: //add jaspreet
                    size = 20;
                    break;
                case MySqlParamName.IpFormStatus: //add jaspreet
                    size = 1;
                    break;
                default:
                    size = 200;
                    break;
            }
            return size;
        }


    }
}
