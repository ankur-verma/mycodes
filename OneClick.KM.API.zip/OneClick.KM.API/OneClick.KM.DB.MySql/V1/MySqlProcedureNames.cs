﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.DB.MySql
{

    public static class MySqlProcedureNames
    {
        //public const string AgentLogin = "sampleProc";

        #region Article
        public const string GetArticles = "PROC_GET_MOST_USED_ARTS";
        public const string GetArticleDetails = "proc_get_art_dtls_by_artcode";
        public const string GetArticleByMenu = "PROC_GET_ARTICLE_BY_MENU";
        public const string GetArticleAttachment = "proc_get_art_attach_by_id";  //proc_get_art_attach_by_id
        //   public const string GetArticleAttachmentData = "pkg_auth_faq_busi_v1.proc_get_article_attachment";

        public const string GetArticleGroupContents = "proc_get_art_by_ql_code";
        // public const string GetBreadCrumbLinks = "proc_get_Bread_Crumb";
        public const string GetBreadCrumbLinksV1 = "PROC_GET_BREAD_CRUMB_V1";
        public const string InsertFaqBusinessV5 = "PROC_INS_FAQ_BUSI";          //"PKG_AUTH_ARTC_MGMT.proc_ins_faq_busi_v5";
        public const string ReviveArtsV2 = "proc_revive_arts_v2";
        public const string GetArticleSummary = "PROC_GET_DET_FOR_ART_SUMM_M";
        public const string CheckArticleAccessOfUser = "proc_Get_Data_RightWise";

        #endregion Article

        #region [Auth Article ArticleLogic]

        public const string PreviewArticleData = "proc_get_faq_busi_header_m";
        public const string CreateNewVersion = "proc_crt_new_ver_art_v1"; //"PKG_AUTH_ARTC_MGMT.proc_crt_new_ver_art_v1";

        //public const string DeletePublishedArticle = "PKG_AUTH_ARTCAT_MAP.PROC_DELETE_PUB_ARTICLE";
        public const string DeletePublishedArticle = "PROC_VALIDATE_DELETE_PUB_ARTICLE";
        public const string CheckArticleReviveVersion = "PROC_EDIT_ARTICLE_ART";
        public const string PreviewArticleContent = "proc_get_contents_by_art_cir";
        public const string PreviewArticleAttachments = "proc_get_article_attachment";
        public const string PreviewRelatedArticle = "PROC_GET_RELATED_ARTICLE_V1";

        public const string ArticleContentForEdit = "PROC_AUTH_GET_CONTENT";//"proc_get_content";
        public const string EditContentType = "proc_update_edit_content_v1";
        public const string UploadContent = "proc_ins_faq_content_v2";//proc_ins_faq_content_v1"; by ankur vishnoi
        public const string ArticleCreationAttachment = "proc_save_faq_attachment";
        public const string ArticlePreviewInfo = "proc_art_dtl_info_v3";
        public const string DeleteArticleAttachment = "proc_delete_faq_attachment";
        public const string GetArticlePreviewData = "proc_get_faq_busi_header_m";
        public const string GetArticleBasicForEdit = "proc_get_edit_article_v1";
        public const string ArticleEditBasic_V1 = "PROC_EDIT_ARTICLE";
        public const string GetSearchedPublishedArticles = "proc_art_published_srchlst_wcv";// "proc_art_published_srchlst_V2";
        public const string SearchArticleLinkData = "PROC_GET_PUB_ART_LINK";
        public const string DeleteArticle = "proc_delete_arts";
        public const string UpdateArticleComment = "PROC_INS_ART_COMMENTS";
        public const string GetSOlutionRKM = "PROC_GET_SOLUTION_RKM";
        public const string SearchAccessoriesList = "PROC_GET_SOLUTION_ARTICLE_V2";

        public const string CheckArticleMap = "proc_check_ArticleMap";
        public const string CheckCurrentMapping = "proc_check_currentmap";
        public const string GetSolutionAricleV1 = "PROC_GET_SOLUTION_ARTICLE_V1";
        public const string AuthArticleEditBasic = "PROC_EDIT_ARTICLE";

        public const string AuthsearchRelatedArticle = "PROC_SEARCH_ARTICLE_V1";
        public const string MacroContent = "PROC_GET_ARTICLEMACROLST_BYID";
        public const string DownloadAttachment = "PROC_GET_ART_ATTACH_BY_ID_FAQBUSIV1";//proc_get_art_attach_by_id
        public const string GetBrokenListForArticle = " PROC_DELETE_PUB_ARTICLE_BSR";
        public const string SearchArticleList = "proc_Get_All_Search_Article_v1";
        public const string AuthAllArchiveArticlelist = "proc_get_del_arch_arts_wcv_v1";//"proc_get_del_arch_arts_wcv";//"proc_get_del_arch_arts_v2";
        public const string ArticleContent = "proc_get_contents_by_art_cir";
        public const string GetArticleRelatedData = "PROC_GETCONTENTS_BY_ART_REL";
        public const string GetArticleAttachmentData = "proc_get_article_attachment";
        public const string ProcArtPubdashboardV1 = "proc_art_pub_Dashboard_V1";
        public const string GetArticleRelatedLinkDtlDal = "PROC_GET_ARTICLERELATEDLINKDTL";
        public const string GetArticlelinkDtl = "PROC_GET_ARTICLElINK_DTL";
        public const string ProcArticleLocator = "PROC_ARTICLE_LOCATOR";

        #endregion [Auth Article ArticleLogic]

        #region [Auth ArticleStatusLogic]

        public const string UpdateArticlePortalMapping = "proc_ins_artportal_map";
        public const string GetArticleMappedPortaList = "proc_get_art_curr_portal";
        public const string UpdateArticleStatus = "proc_change_status_v1";
        public const string GetArticleDetailsForElasticSearch_New = "proc_art_dtl_for_search_v3";

        #endregion [Auth ArticleStatusLogic]


        #region [Auth RelatedArticleLogic]

        public const string GetArticleBasicDtl = "PROC_GET_ARTICLE_BASIC_DTL_V1";
        public const string GetRelatedArticle = "PROC_GET_RELATED_ARTICLE_V1"; //"pkg_auth_rel_article.PROC_GET_RELATED_ARTICLE_V1";
        public const string SearchRelatedArticle_V1 = "PROC_SEARCH_ARTICLE_V1";

        #endregion [Auth RelatedArticleLogic]

        public const string UserRights = "proc_get_user_roles";
        public const string DeleteRelatedArticle = "PROC_DEL_REL_ARTICLE_MAP";
        public const string GetUserRights = "proc_chk_user_rights";

        #region Guided Help
        public const string ScenarioDetails = "proc_get_l1_dtls_by_artcode";  // related to guidedhelp for application
        public const string GetGHQuestionAnsDetail = "proc_get_que_dtls_by_quecode";  // related to guidedhelpQuestionAns for application
        public const string GHArticleDetail = "proc_get_GHart_dtls_by_artcode";  //
        #endregion Guided Help

        #region [AuthKeyword ]
        public const string AuthGetArticleKeyList = "proc_get_keys_by_art_v1";
        public const string AuthGetSearchKeyword = "proc_get_keywords_v2";
        public const string AuthAddInsKeyword = "PROC_INS_KEYWORD_DTL_V2";
        public const string AuthDeleteKeyword = "proc_del_keyword_dtl_rkm";
        public const string AuthDeleteKeywordDtlV1 = "proc_del_keyword_dtl_v1";

        #endregion

        #region [ Client ]
        public const string AuthGetPortalConfig = "proc_get_seo_parameters";
        public const string AuthCheckPortalName = "proc_chk_portal_name  ";
        public const string AuthInsertPortal = "PROC_INSERT_PORTAL";
        public const string AuthDeletePortalLogic = "proc_delete_portal";
        public const string GetPortalDetails = "proc_get_seo_parameters";

        #endregion

        #region [ Login ]
        public const string AgentLogin = "proc_user_login_km";  //Login the application
        public const string GetUserActiveSessions = "proc_get_active_sessionslist";  //Get User Active Session List
        public const string UpdatePortal = "proc_update_portal_code";
        public const string ValidatePortalDLogin = "proc_common_login";
        public const string AgentLogout = "PROC_LOGOUT";  //Logout the application
        public const string MultipleSession = "PROC_MULTIPLE_SESSION";  // Kill or Continue Session
        public const string SSOLogin = " proc_sso_user_login";  //  SSOLogin for application   
        public const string SaveResetPassword = "proc_change_profile";  // save reset Password  for Application 
        #endregion

        #region [ Login ]
        public const string AuthLogin = "proc_user_login_v5";
        public const string AuthLogout = "proc_auth_logout";
        //  public const string AuthForgotPassword = "pkg_authoring_login.PROC_FORGOT_PASSWORD";
        public const string AuthInsertForgotPassword = "PROC_FORGOT_PASSWORD";
        public const string AuthNewUserChangePassword = "proc_first_user_login";
        public const string AuthChangeExpirePassword = "proc_user_expire_login";
        public const string AuthResetPassword = "proc_reset_user_pwd";
        public const string AuthUpdateUserResetPassword = "proc_user_reset_pwd";

        #endregion

        #region [BookMark]

        public const string SaveBookmark = "proc_ins_user_bookmark";
        public const string GetUserBookmark = "proc_get_user_bookmark";
        public const string DeleteBookmark = "proc_del_user_bookmark";

        #endregion

        #region [ Suggestion ]

        public const string GetSuggestion = "proc_get_my_suggestions_v1";
        public const string DeleteSuggestion = "proc_del_my_suggestions_v1";
        public const string PendingSuggestion = "proc_app_rej_supervisor";

        #endregion


        #region [AuthActivity ]

        public const string AuthGetActivities = "proc_get_act_SubAct";

        #endregion

        #region ImageBank
        public const string AuthInsertImage = "PROC_INS_IMAGE";
        public const string AuthDeleteImage = "PRC_DELETE_IMAGE";
        public const string GetImageBankDataByClientID = "proc_get_image_by_clientid_V1";
        public const string GetImageBankDataByScenario = "PROC_GET_IMAGE_BY_SCENARIO_v1";
        public const string GetGroupDetail = "proc_GROUP_DTL";
        public const string UpdateImage = "proc_update_img";
        public const string ImageLocateInfo = "PRC_LOCATE_IMAGEINFO";
        public const string AddGroup = "PROC_INS_GROUPMST";
        public const string UpdateGroup = "PROC_UPDATE_GROUPMST";
        #endregion ImageBank

        #region [Auth SopScenario]

        public const string AuthSopScenario = "proc_ins_guided_help";
        public const string AuthGHQuesAnsList = "proc_get_sop_inbox_search_V1";
        public const string AuthSopDetailByScenarioCode = "proc_get_guid_help_edit";
        public const string AuthEditScenario = "PROC_UPDATE_GUID_HELP_V2";
        public const string AuthReviveGHUpdate = "proc_update_guid_revive_v1";
        public const string AuthReviveGHQuestion = "proc_revive_question";
        public const string AuthReviveGHQuestionV1 = "proc_revive_question_v1";
        public const string GetAllPublishedGuidedHelpDal = "proc_get_publish_sop_v1";




        public const string AuthGuidedHelpSummary = "PROC_GET_DET_FOR_GH_SUMM_V4";
        public const string AuthUpdateGuidedHelpStatusNew = "proc_gh_change_status_wcv";//"proc_gh_change_status_v1";
        public const string AuthDeleteGH = "proc_del_gh_fresh_edt_wcv";//"proc_delete_guided_help";
        public const string AuthDeletePublishedGH = "proc_delete_gh_wcv"; //"proc_delete_guided_help_v1";
        public const string AuthGHInfo = "proc_get_gh_info_v1";
        public const string AuthCloneAnswer = "proc_revive_answer";
        public const string AuthCloneAnswerV1 = "proc_revive_answer_v1";
        #region same Proc Used two time
        public const string AuthScenarioDetails = "proc_isscenario_published";
        public const string AuthScenarioStatus = "PROC_AUTH_GET_L1_DTLS_BY_ARTCODE";

        public const string AuthGHQuesAns = "proc_isscenario_published";
        public const string AuthQuesAnsStatus = "proc_get_que_dtls_by_quecode";
        public const string AuthQuesAnsStatusMySql = "PROC_AUTH_GET_QUE_DTLS_BY_QUECODE";

        #endregion
        public const string AuthSearchedPublishedGH = "proc_get_sop_publish_search_srch_v1";  //proc_get_sop_publish_search
        public const string AuthPublishedGuidedQuesAnsList = "PROC_GH_PUB_QUE_ANS_DTL_BSR";
        public const string AuthReviveGuidedQuesAnsList = "proc_gh_que_ans_revive_dtl_v1 ";//"proc_gh_que_ans_revive_dtl";
        public const string AuthAllGuidedInboxSearchedList = "proc_get_sop_publish_search_gh";//PROC_GET_SOP_PUBLISH_SEARCH_SRCH
        public const string AuthAllGuidedHelpQuesAnsList = "proc_gh_pub_que_ans_dtl_gh";  //PROC_GH_PUB_QUE_ANS_DTL
        public const string AuthGetSearchedInboxGuidedHelps = "proc_get_sop_inbox_search";
        public const string AuthGetSearchedInboxGuidedHelps_V1 = "proc_get_sop_inbox_search_wcv_v1";//"proc_get_sop_inbox_search_v1";
        public const string AuthCheckAllGuidedHelpAccess = "proc_get_sop_auth_new ";
        public const string AuthGetDeletedGHv1 = "proc_get_del_arch_ghs_v2";//"proc_get_del_arch_ghs_v1";

        public const string AuthGetSelectedAnswer = "PROC_GET_SOP_SELECTED_ANSWERS";
        public const string AuthDeleteSelectedAnswer = "PROC_DELETE_SOP_SELECTED_ANS";
        public const string AuthSaveGuidedHelpLink = "proc_ins_que_accessories";
        public const string AUthGetQuesDetails = "proc_get_ques_dtls";
        public const string AuthCloneAns = "proc_clone_answer_v1";
        public const string AuthCloneAnsV2 = "proc_clone_answer_v2";
        public const string AuthCloneQue = "proc_clone_question_v1";
        public const string AuthCloneQueV1 = "proc_clone_question_v2";
        public const string AuthGuidedHelpVersioning = "proc_gh_versoning";


        #region GHQuesAnsDetail
        public const string AuthGuidedHelpData = "proc_get_gh_header_V1";//  "proc_get_gh_header";
        public const string AuthGetGuidedHelpQuestionData = "proc_get_ques_dtl_v1"; //"proc_get_ques_dtl";
        public const string AuthCreateQuestion = "proc_create_question_V2";// "proc_create_question_V1";//"PROC_CREATE_QUESTION ";
        public const string AuthDeleteQuestionAnswerDal = "proc_guid_help_que_del_v3";//"PROC_GUID_HELP_QUE_DEL_V2";
        public const string AuthDeleteAnswerDal = "PROC_GUID_HELP_ANS_DEL_V2";
        public const string AuthGetQuestionByScenario = "proc_get_quest_byscenques_V2";//"proc_get_quest_byscenques_V1";//"PROC_GET_QUEST_BYSCENQUES";
        public const string AuthUpdateQuestion = "proc_update_question_v3";// "proc_update_question_v2";//"PROC_UPDATE_QUESTION_v1";
        public const string AuthGetSearchedQuestionData = "proc_srch_gh_ques_list";
        public const string AuthAnswerDetail = "proc_get_ans_dtls";
        public const string AuthAddAnswer = "proc_create_answer_V1";//"PROC_CREATE_ANSWER";
        public const string AuthUpdateAnswer = "PROC_UPDATE_ANSWER_V1";//"PROC_UPDATE_ANSWER";
        public const string AuthAnswerDtl = "proc_get_ans_dtl_V1";//"proc_get_ans_dtl";



        #endregion

        #region [Auth Comment]
        public const string AuthComment = " PROC_GET_ART_COMMENTS";
        public const string AuthArtComment = "PROC_INS_ART_COMMENTS";
        #endregion

        #region Feedback
        public const string GetFeedBackQuestion = "proc_get_fb_que";
        public const string SaveFeedbackAndDetails = "PROC_INSERT_FEEDBACK";
        public const string SaveFeedbackInMaster = "PROC_INSERT_FEEDBACK_MST";
        public const string InsertFeedbackRating = "PROC_INSERT_RATING";
        public const string EditFeedbackRating = "PROC_EDIT_RATING";
        public const string DeleteFeedbackRating = "PROC_DEL_RATING";
        public const string GetFeedbackRating = "PROC_GET_RATING";
        #endregion Feedback

        #region [Authoring Feedback]
        public const string GetFeedbackType = "PROC_GET_FB_TYPE";
        public const string FeedbackQuestionType = "PROC_AUTH_GET_FB_QUE_V1";
        public const string FeedbackRating = "proc_get_fb_rating";
        public const string FeedbackFreshList = "PROC_GET_FB_LIST_v1";
        public const string GetListWithFeedbackType = "PROC_GET_FB_LIST_v1";
        public const string InsertFeedbackResponse = "proc_close_fb";
        public const string GetFeedbackResponse = "proc_get_fb_header";
        public const string FeedbackReportListDal = "PROC_GET_FB_REPORT";
        public const string FeedbackStatusListDal = "proc_get_fb_status";
        public const string UpdateFeedbackStatusLogic = "proc_insert_fb_remark";
        #endregion [Authoring Feedback]

        public const string ProcInsertFeedbackmst = " PROC_INSERT_FEEDBACK_MST";
        public const string ProcInsertFeedback = "PROC_INSERT_FEEDBACK";
        public const string ProcGetFbQue = "proc_get_fb_que";





        #endregion Feedback

        #region StoreLocator

        public const string GetStoreLocationList = "proc_search_store_loct";

        public const string GetJioStateList = "proc_get_jiostate";

        public const string GetCities = "proc_get_cities";

        public const string GetLocality = "proc_get_locality";




        #region [Authoring StoreLocator]

        public const string StoreDelete = "proc_delete_store_loct";

        public const string GetCityList = "proc_get_jiocity";

        public const string StoreTypeList = "proc_get_store_byportal";

        public const string AddStoretype = "proc_check_store_type_name";

        public const string AddStoreType = "PROC_INS_STORE_TYPE";


        public const string AuthStoreDetail = "proc_get_store_loct_byid";
        public const string AuthAddStoreLocator = "proc_ins_store";
        public const string AuthGetStateList = "PROC_AUTH_GET_JIOSTATE";/// "proc_get_jiostate";
        public const string AuthStoreTypeByPortal = "PROC_GET_STORE_TYPE_LOCATER";
        public const string AuthRetreiveStoreList = "proc_get_store_loct_portal";
        public const string AuthEditStoreType = "proc_update_store_type_name";
        public const string AuthDeleteStoreType = "proc_delete_store_type";
        public const string AuthEditStore = "proc_edit_store";
        public const string AuthProcInsStoreType = "PROC_INS_STORE_TYPE";
        public const string AuthGetStoreLocation = "proc_get_store_loct";
        public const string AuthGetStoreLocationByid = "proc_get_store_loct_byid";




        #endregion [Authoring StoreLocator]

        #endregion StoreLocator    




        #region TopicTree

        public const string GetTopicTree = "PROC_GET_TOPIC_TREE";
        public const string InsTopicLinking = "PROC_INS_TOPIC_LINKING";
        public const string EditOrDeleteInTopicCategory = "PROC_EDIT_TOPIC_CATEGORY";
        public const string EditOrDeleteInTopicLinking = "PROC_EDIT_TOPIC_LINKING";
        public const string ArticleMappwithCatCount = "proc_cat_exist_count";
        public const string ArticleMappwithCatCountV1 = "proc_cat_exist_count_v1";

        public const string AddTopicArtMap = "proc_add_topic_art_map";
        public const string ProcGetCatExistArt = "proc_Get_cat_exist_art";
        public const string ProcGetCatExistArtV1 = "proc_Get_cat_exist_art_V1";
        public const string ProcTopicCatMappedSingleart = "proc_topic_cat_mapped_singleart";
        #endregion TopicTree

        #region Menu

        public const string GetMenuList = "proc_get_active_menu";


        #endregion Menu



        #region News
        public const string GetPortal = "PROC_GET_Portal";
        public const string GetNews = "proc_get_news";
        #endregion News

        #region [Authoring Procedures]

        public const string GetMacroListDal = "PROC_GET_ART_MACRO";

        public const string CreateMacroDal = "PROC_INS_ART_MACRO";

        public const string GetEditMacroDal = "PROC_GET_EDIT_ART_MACRO";

        public const string EditMacroDal = "PROC_AUTH_UPDATE_MACRO";

        public const string DeleteMacroDal = "PROC_DEL_MACRO";

        public const string GetMacroTypeList = "PROC_GET_MACRO";
        public const string CheckMacroName = "PROC_CHK_MACRO_NAME";

        #endregion [Authoring Procedures]  

        #region[ClientMangement]
        public const string GetClientDetails = "PROC_GET_ALLCLIENT";
        public const string GetAllClientDetails = "PRC_CONFIG_LANG_DTL";

        public const string GetAllClient = "PROC_GET_ALLCLIENT";
        public const string ClientDetailWithContactPerson = "PROC_GET_CLIENT_INFO";
        public const string GetAllClientDetail = "PRC_CLIENT_MGMT";
        public const string InsertAllClientDetail = "PROC_INS_CLIENT_MST";
        public const string InsertFeatureDetails = "PROC_INS_CLIENT_FEATURE_MAP";
        public const string InsertComponentDetails = "PROC_INS_CLIENT_COMPONENT_MAP";
        public const string InsertLanguageDetails = "PROC_INS_CLIENT_LANG_MAP";


        #endregion[ClientManagement]






        #region Cachemanagement

        public const string GetSopPublishSearch = "proc_get_sop_publish_search";

        public const string ProcArtPublishedSearchListV3 = "proc_art_published_srchlst_V3";

        public const string ProcGetElasticFullCtlV2 = "PROC_GET_ELASTIC_FUL_CTL_V2";

        public const string ProcGetElasticArticleV2 = "proc_get_elastic_article_v2";


        public const string ProcUpdateCacheDTL = "proc_update_cache_dtl";

        public const string ProcUpdateCacheMS = "proc_update_cache_ms";

        public const string ProcGetCacheMstDTL = "proc_get_cache_mst_dtl";

        public const string ProcGetCacheDTL = "proc_get_cache_dtl";
        public const string ProcGetRedisFulCTLV1 = "PROC_GET_REDISH_FUL_CTL_V1";
        public const string ProcRollBackRedisFulCTLV1 = "PROC_GET_REDISH_FUL_CTL_V1";
        public const string ProcGetRedisARTICLELV1 = "PROC_GET_REDIS_ARTICLE_V1";

        public const string ProcGetRedisGHV1 = "PROC_GET_REDIS_GH_V1";

        public const string ProcGetRedisTPTree = " proc_get_redish_tp_tree";

        #endregion

        #region [Weightage]

        public const string Weightagelist = "PROC_GET_ALL_ARTICLE";

        public const string CreateNewWeightage = "proc_ins_article_wt";

        public const string WeightageListComm = "proc_get_weightage_article";

        public const string DeleteWeightage = "PROC_DELETE_WEIGHTAGE";
        public const string SaveWeightage = "proc_dragdrop_weightage";
        #endregion [Weightage]


        #region [ArticlePortalMapLogic]

        public const string ProcGetPubArtListV1 = "proc_get_pub_art_list_v1";

        public const string ProcGetPubArtListCheckV1 = "proc_get_pub_art_list_check_v1";

        public const string ArticleLocateInfo = "proc_get_locate_article_list";// "PKG_AUTH_ARTCAT_MAP.proc_get_locate_article_list";
        public const string UpdateArticleBookmarkForUnmapping = "PROC_UPDATE_USER_BOOKMARK";
        public const string CheckArticlePortalMappingExists = "proc_chk_art_portal_map";
        public const string SubmitArticlePortalMapping = "proc_ins_art_portal_map";
        public const string EditCurrentArticleMapping = "proc_get_edit_curt_mapV1";
        public const string CheckArticlePortalMappingDeletable = "proc_chk_master_art_portal_map";
        //public const string UpdateArticlePortalMapping = "PKG_AUTH_SRCH_ART.proc_ins_artportal_map";
        // public const string GetArticleMappedPortaList = "pkg_auth_art_portal_mapping.proc_get_art_curr_portal";
        public const string MappedSubSubCategoryList_v1 = "proc_get_sub_subcategory";
        public const string MappedSubCategoryList_v1 = "proc_get_sub_category";

        #endregion [ArticlePortalMapLogic]

        #region [For mongo Db] By Mubin
        public const string GetGuidedHelpLogsForMongoDb = "PROC_GET_ARTICLE_DETAILS";
        public const string GetArticleDetailsForMongoDb = "PROC_GET_ARTICLE_DETAILS";
        #endregion [For mongo Db]

        #region Agent [UserManage]

        public const string UpdateUserPortal = "PROC_UPDATE_DEF_PORTAL";
        #endregion



        #region [AuthUserManagement ]


        public const string AuthGetUserLocation = "proc_get_location";
        public const string AuthGetDesignationList = "proc_get_designations";
        public const string AuthGetRolesListFromUserType = "proc_get_roles_by_utype ";
        public const string AuthGetReportingToUserList = "proc_get_reporting_to";
        public const string AuthCreateUser = "proc_create_user_v2";
        public const string AuthUserInsertPortal = "proc_auth_ins_user_portals";
        public const string AuthCreationBulkBatch = "CREATE_BATCH_PORTAL";
        public const string AuthUserAddBatch = "ADD_BATCH_USERS_V1";
        public const string AuthUserBatchList = "GET_BATCH_DTL";
        public const string AuthUpdateUserRoles = "proc_user_group_mapping";
        public const string AuthUserBatchDetail = "SP_USER_BATCH_DTL_v1";
        public const string AuthRetreiveLocationList = "proc_get_location_list";
        public const string AuthAddNewUserLocation = "proc_ins_location_mst";
        public const string AuthEditLocationDetail = "proc_edit_location_mst";
        public const string AuthUserRecord = "PROC_GET_ALL_USER";
        public const string AuthActiveUserList = "proc_get_alluser_dtls_v1";  // user list for bulk upload source user, with all active user list
        public const string AuthUserList = "proc_get_user_list_v1"; // user list for user list in manage user profile , with all status type user except deleted user
        public const string AuthUserDetail = "proc_get_usr_dtls_by_uid";
        public const string AuthUpdateUser = "proc_edit_user_v5";
        public const string AuthUpdateUserModule = "proc_user_module_mapping";
        public const string AuthUpdateUserPortal = "proc_ins_user_portals";

        #endregion



        #region PortalCategoryMapping
        public const string AuthGetPortalName = "PROC_GET_PORTAL_NAME";

        public const string AuthGEtCategoryName = "proc_get_category";

        public const string AuthPortalGetSubCategory = "proc_get_sub_category ";

        public const string AuthPortalGetSubSubCategory = "proc_get_sub_subcategory ";


        public const string AuthUtilityGetCategory = "proc_get_category";

        public const string AuthUtilityGetSubCategory = "proc_get_sub_category";

        public const string AuthUtilityGetSubSubCategory = "proc_get_sub_subcategory";

        public const string AuthCatPortalGetMappedList = "proc_get_mapped_list";

        public const string AuthArtCatInsPortMapping = "proc_ins_cat_portal_mapping";

        public const string AuthArtCatPortMappingUpdate = "proc_cat_portal_map_update";

        public const string AuthArtCatPortMappingUpdateRollBack = "proc_cat_portal_map_rollback"; //Need to be implemented

        public const string AuthCatPortMapTree = "proc_cat_portal_map_tree";

        public const string AuthARTCatPortMappingData = "cat_portal_mapping_data";

        public const string AuthARTCatPortMapList = "proc_get_map_art_list";

        public const string AuthARTCatGetUnMapArtList = "proc_get_un_map_art_list";

        public const string AuthARTCatGetInsArtMapForCat = "proc_ins_art_map_for_cat";


        public const string AuthARTCatPortalUnMap = "cat_portal_un_map";


        public const string AuthARTCatCheckMasterMap = "proc_chk_master_map";

        public const string AuthARMapGetRedisData = "proc_get_redish_data";

        public const string AuthCatGetPortalCode = "proc_get_portal_code";

        public const string CatPortalMapRequest = "cat_portal_map_req_mst_v1";
        public const string CatPortalMapRequestDtlV1 = "cat_portal_map_req_dtl_v1";

        public const string ProcInsCAtPortalMappingV1 = "proc_ins_cat_portal_mapping_v1";

        public const string ProcInsCAtPortalMappingV1Data = "cat_portal_map_req_dtl_v1_data";

        public const string InsertPortalCategories = "PROC_INS_CAT_MAP";




        #endregion


        #region for Link
        public const string GetQuickLinks = "proc_get_quick_links";

        public const string GetQuickLInkGroup = "proc_get_quick_link_group";
        public const string GetUsefullLinks = "PROC_GET_USEFUL_LINK";
        #region for Auth
        public const string AuthAddUsefulLink = "proc_ins_useful_link_v1";
        public const string AuthDeleteUsefulLink = "proc_delete_useful_link ";
        public const string AuthUsefulLinkList = "PROC_AUTH_GET_USEFUL_LINK";
        public const string AuthCheckDuplicateUseful = "proc_chk_useful_link_name";
        public const string AuthUpdateUsefulLinkOrder = "proc_update_useful_link_order";
        #endregion for Auth
        #endregion for Link
        public const string ArticleMacroListDal = "PROC_GET_ARTICLEMACROLST";
        public const string CreateMacroType = "PROC_INSERT_MACRO";
        public const string EditMacroType = "proc_update_macro";
        public const string RemoveMacroType = "proc_del_macro_type";

        #region [Auth Utility]

        public const string AuthCheckSession = "proc_check_session";
        public const string AuthGetAllPortal = "proc_get_portal_byuser_v1";
        public const string AuthGetBasicEntry = "proc_auth_get_identifier_dtls";
        public const string AuthGetAllCategoryType = "proc_get_category_type";
        public const string AuthGetAllCategory = "proc_get_category";
        public const string AuthGetAllSubCategory = "proc_get_sub_category";
        public const string AuthSubSubCategory = "proc_get_sub_subcategory";
        public const string AuthScopePriority = "proc_get_identifier_dtls";
        public const string AutharticleSection = "proc_get_article_section";
        public const string AuthGetAllCategoryType_V1 = "PRC_GET_CONTENT_DETAILS";

        #endregion


        #region [ClientManagement ]

        public const string CheckClientName = "PROC_CHECK_CLIENT_NAME";
        public const string CheckClientShortCode = "PROC_CHECK_CLIENT_SHORT_CODE";
        public const string AuthGetDetails = "proc_get_client_det";
        public const string AuthUpdateClientDetails = "proc_update_client_sess";


        #endregion

        #region [CommonClient ]

        public const string GetModuleList = "PROC_GET_FEATURE_LIST";
        public const string GetLanguages = "PROC_GET_LANGAUAGES_LIST";
        public const string GetConfigrationList = "PROC_GET_CONFIGURATION_LIST";


        #endregion

        #region[Article Outage]

        public const string GetSearchedInboxArticles = "proc_art_inbox_search_v2";// "proc_art_inbox_search_v1";// "PKG_AUTH_SEARCH_OUTAGE.PROC_OUTAGE_INBOX";
        public const string ArticleOutageGetSearchedInboxArticles = "PROC_OUTAGE_INBOX";

        public const string ArticlePublishedSearchList = "PROC_ART_PUBLISHED_SRCHLST";
        public const string AllArchiveArticlelist = "PROC_GET_DEL_ARCH_ARTS_V2";

        public const string InsTopicCategory = "PROC_INS_TOPIC_CATEGORY";
        public const string GetTopicCategory = "PROC_GET_ALL_TOPIC_CAT";
        public const string GetTopicCatById = "PROC_GET_TOPIC_CAT_BYID";
        public const string AuthGetPortalCategories = "PROC_GET_TOPIC_LINKS";
        public const string AuthCreateTopicLinking = "PROC_INS_TOPIC_LINKING";
        public const string AuthEditTopicLinking = "PROC_EDIT_TOPIC_LINKING";
        public const string GetArticlePortalTopicMapByArtStatusAndUserID = "PROC_GET_ART_BY_STATUS";

        #endregion

        #region Attachment
        public const string AuthSaveAttachment = "proc_save_attachment";
        public const string AuthGetAttachments = "proc_get_attach_by_clientid";
        public const string AuthDeleteAttachment = "proc_delete_attach_by_id";
        public const string AuthSearchAttachment = "proc_get_attach_by_name";
        public const string AuthUpdateAttachment = "proc_update_attach";
        public const string AuthContentChange = "PRC_GET_CONT_DETAILS";
        public const string AuthGetFaqDocAttachment = " proc_get_article_attachment_art";
        public const string AuthRemoveFaqDocAttachment = "PROC_DELETE_ART_DOCATTACHMENT";
        public const string AuthFaqDocAttachmentCreation = "proc_insert_article_attach";

        public const string AttachmentLocateInfo = "PROC_LOCATE_ATTACHMENT_INFO";




        #endregion

        #region[Search Configurtaion]

        public const string GetSearchTopicList = " proc_get_active_topic";
        public const string UnPublishArticle = "proc_change_status_v1";
        public const string RemoveBrokenLink = "PROC_DEL_REL_ART_WITH_ACCESS";
        public const string GetArticleBasicDtl_V1 = "PROC_GET_ARTICLE_BASIC_DTL_V1";
        public const string GetRelatedArticle_V1 = "PROC_GET_RELATED_ARTICLE_V1";

        public const string InsertArticlePortalMapping = "PROC_INS_ART_PORTAL_TOPIC_MAP";

        public const string GetArticlePortalMapping = "PROC_GET_ARTICLE_MAPPED_PORTALS";


        #endregion[Search Configurtaion]

        public const string testproc = "testproc";

        public const string ArticlePortalTopicPublished = "PROC_UPD_ART_PORTAL_TOPIC_MAP";
        public const string ArticlePortalTopicPublishedIfSave = "proc_upd_article_mst_v2";//"proc_upd_article_mst_v1";//"PROC_UPD_ARTICLE_MST";
        public const string GHArticlePortalTopicPublishedIfSave = "proc_publish_gh_wcv";

        #region[ManagedOrdering]

        public const string ToGetMappedAndNotMappedArticles = "proc_get_attr_articles_v1";//"PROC_GET_ATTR_ARTICLES";

        public const string InsertNewArticleInOrdering = "proc_ins_article_attr_mapping_v1";//"proc_ins_article_attr_mapping";

        public const string GetAllPublishedArticleWithOrder = "proc_get_article_attr_mapping_v1";// "PROC_GET_ARTICLE_ATTR_MAPPING";
        public const string DeleteOrdering = "proc_delete_article_attribute_v1";//"proc_delete_article_attribute";

        public const string UpdateArticleAttributes = "proc_update_article_attribute_v1";//"proc_update_article_attribute";
        #endregion  [ManagedOrdering]

        #region [Buisnesscode]
        public const string ProcCheckBusinessCode = "proc_chk_unq_busi_code_v3";
        #endregion


        #region [Role Management]

        public const string ProcDeleterole = "PROC_DELETE_ROLE";
        public const string ProcGetrole = "PROC_GET_ROLE_INFO";
        public const string ProcGetModules = "proc_get_modules";
        public const string ProcGetRoleActions = "PROC_GET_ROLE_ACTION_INFO";
        public const string ProcCreateContentActions = "PROC_CREATE_CONTENT_ACTION";
        public const string ProcCreateGroupRole = "PROC_CREATE_GROUP_ROLE";
        public const string ProcCreateRoleActions = "PROC_CREATE_ROLE_ACTION";
        public const string ProcCheckRole = "PROC_CHECK_ROLE";

        public const string ProcCreateNewRole = "PROC_CREATE_NEWROLE";
        public const string ProcGetActivitiesByUID = "proc_get_role_action_info2_v1";//"PROC_GET_ROLE_ACTION_INFO2";
        public const string ProcGetGrouInfoById = "PROC_GET_ROLE_ACTION_INFO1";//proc_get_role_action_info_V1
        public const string ProcGetGrouInfoById1 = "proc_get_role_action_info_V1";
        public const string ProcGetModulesByrole = "proc_get_modules_byrole";
        #endregion
        #region content type
        public const string AddContentType = "proc_insert_content_v1";
        public const string GetContentForEdit = "proc_get_edit_content_v1";
        public const string GetContentList = "proc_get_content";
        public const string CheckContentType = "proc_chk_content";
        public const string ContentDelete = "proc_del_content";


        public const string ContentLocateInfo = "proc_get_content_locate_info";

        public const string ArticlePortaltree = "TEST_ARTICLE_PORTAL_TREE";

        public const string CheckArticlePortalTopicPublished = "proc_chk_art_portal_map";

        public const string ProcCreateGuidedHelp = "Proc_Crt_Guided_Help_wcv";
        public const string ProcGetGhWcv = "proc_get_gh_wcv";
        public const string ProcUpdGuidedHelpWcv = "PROC_UPD_GUIDED_HELP_WCV";



        #endregion
        #region[ProductCatalog]
        public const string proc_ins_prod_catalog = "proc_ins_prod_catalog";
        public const string proc_get_all_poral_catalogs = "proc_get_all_poral_catalogs";
        public const string proc_edt_prod_catalog = "proc_edt_prod_catalog";
        public const string proc_get_catalog_dtls = "proc_get_catalog_dtls";
        public const string proc_del_prod_catalog = "proc_del_prod_catalog";
        public const string proc_upd_disp_ord_prod_cat = "proc_upd_disp_ord_prod_cat";


        #endregion[ProductCatalog]
        #region
        public const string GetSearchedInboxArticlesGhw = "proc_art_inbox_search_v1_ghw";
        public const string AuthAllArchiveArticlelist_ghw = "proc_get_del_arch_arts_v2_ghw";
        public const string GetSearchedPublishedArticles_ghw = "proc_art_published_srchlst_V2_ghw";
        #endregion
        #region ProfileMangement

        public const string ProcInsProfileMst = "proc_auth_ins_profile_mst";
        public const string ProcInsProfileDetails = "proc_auth_ins_upd_profile_dtl";
        public const string ProcInsProfileDetailsOpt = "proc_auth_ins_upd_profile_dtl_opt";
        public const string ProcGetCustomerKeyDetails = "proc_get_customer_key_details";
        public const string ProcGetProfileDetail = "proc_auth_get_profile_dtl";
        public const string CheckAttachedGuidedHelp = "proc_auth_delpram_profile_mgmt";
        public const string ProcInsProfileMst1 = "proc_auth_ins_profile_mst1";
        public const string ProcInsProfileDetails1 = "proc_auth_ins_upd_profile_dtl1";
        public const string ProcGetProfileDetail_v1 = "proc_auth_get_profile_dtl_v1";

        public const string ProcAuthIinsApiconfiguration = "proc_auth_ins_apiconfiguration";
        public const string ProcAuthInsApiDetail = "PROC_AUTH_INS_API_DETAIL";
        public const string ProcGetApiMst = "proc_get_api_mst";
        public const string ProcGetApiDetails = "proc_get_api_details";
        public const string ProcCheckApiName = "proc_check_api_name";
        public const string ProcUpdateApiDisplay = "proc_update_api_display";

        #endregion

        #region DtAutoAnswer
        public const string proc_auth_get_decision_tree = "proc_auth_get_decision_tree";
        public const string proc_auth_get_decision_tree1 = "proc_auth_get_decision_tree1";
        public const string proc_get_apilist = "proc_get_apilist";
        #endregion

        #region[Create user]
        public const string CreateUserProc = "proc_api_crt_user";
        public const string EditUserProc = "proc_api_edt_user";
        public const string ProcMapUserPortal = "proc_api_map_user_portal";
        public const string ProcDeleteUser = "proc_api_delete_user";
        public const string ProcBlockUser = "proc_api_block_user";
        public const string ProcUnBlockUser = "proc_api_unblock_user";
        public const string AuthUpdateGuidedHelpStatusNewWithandWithoutCover = "proc_get_published_gh_data";

        public const string ProcResetUser = "proc_api_reset_user";
        public const string ProcGetUserPortals = "proc_api_get_user_portals";
        public const string ProcEditUserPortals = "proc_api_edt_user_portals";

        #endregion

        public const string ProcGetBrokenLinkAutoAnswer = "proc_get_brokenlink_autoanswer";
        public const string ProcGetProdcatalogueList = "proc_get_prodcatalogue_list_v1";//"proc_get_prodcatalogue_list"; Changed by Ankur Verma
        public const string ProcAuthUpdArtProdCatMap = "proc_auth_upd_art_prod_cat_map_v1";// "proc_auth_upd_art_prod_cat_map";
        public const string PorcGetQueAccessories = "porc_get_que_accessories";
        public const string GHCreateNewVersion = "proc_gh_versoning_wcv";
        public const string ProcReviveGuidedUpdateWvc = "proc_revive_gh_wcv";
        public const string ProcGHCreateNewVersion = "proc_gh_versoning_wcv";
        public const string ProcArticleAndGHSummery = "proc_get_det_for_gh_summ_wcv";

        #region Simulation
        public const string ProcAddSimulation = "proc_ins_qa_simu_accessories";
        public const string ProcGetSimulation = "proc_get_qa_simu_accessories";
        public const string ProcDeleteSimulation = "proc_del_qa_simu_accessories";
        #endregion

        #region [Briefing]
        public const string proc_ins_briefing_config = "proc_ins_briefing_config";
        public const string proc_get_brief_config_byportal = "proc_get_brief_config_byportal";
        public const string proc_upd_briefing_config = "proc_upd_briefing_config";
        public const string proc_art_published_srchlst_briefing = "proc_art_published_srchlst_briefing";
        public const string proc_ins_briefing_assessment = "proc_ins_briefing_assessment";
        public const string proc_get_assessment_bycode = "proc_get_assessment_bycode";
        public const string proc_ins_assessment_question = "proc_ins_assessment_question";
        public const string proc_ins_assessment_answer = "proc_ins_assessment_answer";
        public const string proc_upd_briefing_assessment = "proc_upd_briefing_assessment";
        public const string proc_upd_assessment_question = "proc_upd_assessment_question";
        public const string proc_upd_assessment_answer = "proc_upd_assessment_answer";
        public const string proc_del_briefing_assessment = "proc_del_briefing_assessment";
        public const string proc_del_assessment_question = "proc_del_assessment_question";
        public const string proc_del_assessment_answer = "proc_del_assessment_answer";
        public const string proc_get_assessments_byportal = "proc_get_assessments_byportal";
        public const string proc_get_question = "proc_get_question";
        public const string proc_briefing_chk_assessment_title = "proc_briefing_chk_assessment_title";
        public const string proc_map_briefing_assessment = "proc_map_briefing_assessment";
        public const string proc_get_answer = "proc_get_answer";


        #endregion
        #region Agent Briefing
        public const string proc_briefing_user_validate = "proc_briefing_user_validate";
        public const string proc_get_brifing_info = "proc_get_brifing_info";
        public const string proc_log_assessment_summary = "proc_log_assessment_summary";
        public const string proc_log_user_assessment = "proc_log_user_assessment";
        #endregion

    }
}
