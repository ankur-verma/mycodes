﻿using OneClick.KM.Caching;
using OneClick.KM.Core;
using OneClick.KM.Model.Client;
using System;
using System.Linq;

namespace OneClick.KM.Factory
{
	public static class ClientConfigHelper
	{
		public static string KnowledgeDb(string ClientId)
		{
			var con = Convert.ToString(CacheHelper.GetFromCache(ClientId+AppKeys.DbConnectionPrefix));
			return con;
		}
		public static string LogDb(string ClientId)
		{
			ClientConfigurations clientCon = new ClientConfigurations();
			clientCon = (ClientConfigurations)CacheHelper.ClientDetailFromCache(ClientId);
			var retVal = (from cl in clientCon.LogDb select cl).ToString();
			return retVal;
		}
		public static string SearchType(string Client)
		{
			return "Oracle";
		}
		public static string CachingType(string Client)
		{
			return "Oracle";
		}

	}
}
