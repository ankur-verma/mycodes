﻿using OneClick.KM.Caching;
using OneClick.KM.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.Factory
{
    public static class ConfigurationCalling
    {
        public static string GetClientConfig(string Client)
        {
            string DbType = string.Empty;
            DbType = Convert.ToString(CacheHelper.GetFromCache(Client + AppKeys.DbType));
            if(string.IsNullOrEmpty(DbType))
            {
                CacheHelper.AddClientDetailToCache(Client);
                DbType = Convert.ToString(CacheHelper.GetFromCache(Client + AppKeys.DbType));
            }
            return DbType;          
        }

        public static string GetClientShortCode(string Client)
        {
            string shortcode = string.Empty;            
            shortcode = Convert.ToString(CacheHelper.GetFromCache(Client + AppKeys.ClientShortCode));
            if (string.IsNullOrEmpty(shortcode))
            {
                CacheHelper.AddClientDetailToCache(Client);
                shortcode = Convert.ToString(CacheHelper.GetFromCache(Client + AppKeys.ClientShortCode));
            }
            return shortcode;
        }

        public static string GetClientLogConfig(string Client)
        {
            string LogPrefix = string.Empty;
            LogPrefix = Convert.ToString(CacheHelper.GetFromCache(Client + AppKeys.LogDb));
            if (string.IsNullOrEmpty(LogPrefix))
            {
                CacheHelper.AddClientDetailToCache(Client);
                LogPrefix = Convert.ToString(CacheHelper.GetFromCache(Client + AppKeys.LogDb));
            }
            return LogPrefix;
           
        }

    }
}
