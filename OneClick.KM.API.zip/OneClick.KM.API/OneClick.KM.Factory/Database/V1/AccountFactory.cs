﻿
using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{
    public class AccountFactory
    {
        IAccount account;
        public AccountFactory(String clientId)
        {
            string dbName = ConfigurationCalling.GetClientConfig(clientId);
            switch (dbName)
            {
                case "Oracle":
                    account = new DB.Oracle.V1.Account.ImpAccount(clientId);
                    break;
                case "MySql":
                    account = new OneClick.KM.DB.MySql.V1.Account.ImpAccount(clientId);
                    break;
                default:
                    account = new DB.Oracle.V1.Account.ImpAccount(clientId);
                    break;
            }
        }
        public IAccount AccountInstance()
        {
            return account;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
               return "Oracle";

        }
        #endregion

    }
}
