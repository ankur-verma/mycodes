﻿using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{
    public class ActivityFactory
    {

        IActivity activity;
        public ActivityFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);           
            switch (dbName)
            {
                case "Oracle":
                    activity = new DB.Oracle.V1.Activity.ImpActivity(Client);
                    break;
                case "MySql":
                    activity = new DB.MySql.V1.Activity.ImpActivity(Client);
                    break;
            }
        }
        public IActivity ActivityInstance()
        {
            return activity;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";
        }
        #endregion
    }
}
