﻿
using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{
    public class ArticleFactory
    {
        IArticles article;
        public ArticleFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    article = new DB.Oracle.Article.ImpArticle(Client);
                    break;
                case "MySql":
                    article = new DB.V1.MySql.Article.ImpArticle(Client);
                    break;
            }
        }
        public IArticles ArticleInstance()
        {
            return article;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";
        }
        #endregion
    }

}
