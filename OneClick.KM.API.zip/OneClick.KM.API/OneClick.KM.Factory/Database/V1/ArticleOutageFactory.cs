﻿using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{
    public class ArticleOutageFactory
    {
        IArticleOutage _articleOutage;
        public ArticleOutageFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    _articleOutage = new OneClick.KM.DB.Oracle.V1.Article.ArticleOutage(Client);
                    break;

                case "MySql":
                    _articleOutage = new OneClick.KM.DB.MySql.V1.Article.ArticleOutage(Client);
                    break;
            }
        }
        public IArticleOutage RelatedArticleInstance()
        {
            return _articleOutage;
        }
        #region need to be implemented latter
       
        #endregion
    }
}
