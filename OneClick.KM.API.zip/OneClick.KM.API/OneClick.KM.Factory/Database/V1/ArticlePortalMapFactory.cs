﻿using OneClick.KM.Core;
using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{

    public class ArticlePortalMapFactory
    {
        public bool IsValid { get; set;}

        IArticlePortalMap articlePortalMap;
        public ArticlePortalMapFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
          // var licenseInfo = Caching.CacheHelper.GetConnetionStringByClient(Client, AppKeys.LicenseInfo);
          
            switch (dbName) 
            {
                case "Oracle":                    
                    articlePortalMap = new DB.Oracle.V1.ArticlePortalMap.ArticlePortalMapLogic(Client);
                    break;
                case "MySql":
                    articlePortalMap = new DB.MySql.V1.ArticlePortalMap.ArticlePortalMapLogic(Client);
                    break;
            }
        }      

        public IArticlePortalMap ArticlePortalMapInstance()
        {
           
            return articlePortalMap;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";
        }
        #endregion
    }
}
