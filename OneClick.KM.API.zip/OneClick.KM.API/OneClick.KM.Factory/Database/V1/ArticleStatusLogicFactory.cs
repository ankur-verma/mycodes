﻿using OneClick.KM.Interfaces.Database.V1;
using System;
namespace OneClick.KM.Factory.Database.V1
{


    // ImpArticleStatusLogic : DBHelper , IArticleStatusLogic
    public class ArticleStatusLogicFactory
    {
        IArticleStatusLogic articleStatusLogic;
        public ArticleStatusLogicFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    articleStatusLogic = new DB.Oracle.V1.Article.ImpArticleStatusLogic(Client);
                    break;
                case "MySql":
                    articleStatusLogic = new DB.MySql.V1.Article.ImpArticleStatusLogic(Client);
                    break;
            }
        }
        public IArticleStatusLogic ArticleStatusLogicFactoryInstance()
        {
            return articleStatusLogic;
        }
      
    }
}
