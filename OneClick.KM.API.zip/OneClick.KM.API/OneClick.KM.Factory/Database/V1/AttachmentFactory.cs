﻿using OneClick.KM.DB.Oracle.V1.Attachment;
using OneClick.KM.Interfaces.Database.V1;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.Factory.Logs.V1
{
    public class AttachmentFactory
    {
        IAttachment attach;
        public AttachmentFactory(String clientId)
        {
            string dbName = ConfigurationCalling.GetClientConfig(clientId);
            switch (dbName)  //switch (DBName(dbName))
            {
                case "Oracle":
                    attach = new DB.Oracle.V1.Attachment.ImpAttachement(clientId);
                    break;
                case "MySql":
                    attach = new DB.MySql.V1.Attachment.ImpAttachement(clientId);
                    break;
                //case "MongoDB":
                //    attach = new DB.Oracle.V1.Attachment.ImpAttachement(clientId);
                //    break;
                    //case "MySql":
                    //	account = new DB.MySql.V1.Account.ImpAccount();
                    //	break;
                    //case "Postgres":
                    //	account = new DB.Postgres.V1.Account.ImpAccount();
                    //	break;
            }
        }
        public IAttachment AttachmentInstance()
        {
            return attach;
        }
       
    }
}