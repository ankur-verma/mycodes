﻿using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{
    public class BookmarkFactory
    {

        IBookmark bookmark;
        public BookmarkFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
            
                case "Oracle":
                    bookmark = new DB.Oracle.V1.BookMark.ImpBookMarkDetail(Client);
                    break;
                case "MySql":
                    bookmark = new DB.MySql.V1.BookMark.ImpBookMarkDetail(Client);
                    break;
            }
        }
        public IBookmark BookmarkInstance()
        {
            return bookmark;
        }
        #region need to be implemented latter

        #endregion
    }

}
