﻿using System;
using System.Collections.Generic;
using System.Text;
using OneClick.KM.Interfaces.Database.V1;

namespace OneClick.KM.Factory.Database.V1
{
   public class BriefingFactory
    {
        IBriefing _Briefing;
        public BriefingFactory(String clientId)
        {
            string dbName = ConfigurationCalling.GetClientConfig(clientId);
            switch (dbName)
            {

                case "MySql":
                    _Briefing = new DB.MySql.V1.Briefing.ImpBriefing(clientId);
                    break;
                default:
                    // _ProductCatalog = new DB.Oracle.V1.ProductCatalog.ImpAccount(clientId);
                    break;
            }
        }
        public IBriefing BriefingInstance()
        {
            return _Briefing;
        }
        #region need to be implemented later
        public string DBName(string Client)
        {
            return "Oracle";

        }
        #endregion


    }
}
