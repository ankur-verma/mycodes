﻿using OneClick.KM.Interfaces.Database.V1;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.Factory.Database.V1
{
   public class ClientConfigurationsFactory
    {
        IClientConfigurations clientManagement;
        public ClientConfigurationsFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    clientManagement = new DB.Oracle.V1.ClientRestriction.ImpClientConfigurations(Client);
                    break;
            }
        }
        public IClientConfigurations ClientManagementInstance()
        {
            return clientManagement;
        }

        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";
        }
        #endregion
    }
}
