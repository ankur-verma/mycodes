﻿using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{
    public class ClientFactory
    {
        IClient client;
        public ClientFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    client = new DB.Oracle.V1.Client.ImpClientConfig(Client);
                    break;
                case "MySql":
                    client = new DB.MySql.V1.Client.ImpClientConfig(Client);
                    break;
            }
        }
        public IClient ClientInstance()
        {
            return client;
        }
       
    }
}
