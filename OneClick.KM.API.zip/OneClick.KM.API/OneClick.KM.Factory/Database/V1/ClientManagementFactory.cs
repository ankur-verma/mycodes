﻿using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{
    public class ClientManagementFactory
    {

        IClientManagement clientManagement;
        public ClientManagementFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    clientManagement = new DB.Oracle.V1.ClientManagement.ImpClientManagement(Client);
                    break;
            }
        }
        public IClientManagement ClientManagementInstance()
        {
            return clientManagement;
        }

        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";
        }
        #endregion
    }
}
