﻿using OneClick.KM.Interfaces.Database.V1;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.Factory.Database.V1
{ 
    public class CommentFactory
    {
        IComment comment;
        public CommentFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    comment = new DB.Oracle.V1.CommentLogic.ImpCommentLogic(Client);
                    break;
                case "MySql":
                    comment = new DB.MySql.V1.CommentLogic.ImpCommentLogic(Client);
                    break;
            }
        }
        public IComment CommentInstance()
        {
            return comment;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";
        }
        #endregion
    }

}
