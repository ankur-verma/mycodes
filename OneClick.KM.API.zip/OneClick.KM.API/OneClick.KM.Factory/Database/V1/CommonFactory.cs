﻿using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{
    public class CommonFactory
    {
        ICommon common;
        public CommonFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    common = new DB.Oracle.V1.Common.ImpCommonClient(Client);
                    break;
                case "MySql":
                    common = new DB.MySql.V1.Common.ImpCommonClient(Client);
                    break;
            }
        }
        public ICommon CommonInstance()
        {
            return common;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";
        }
        #endregion
    }
}
