﻿using System;
using System.Collections.Generic;
using System.Text;
using OneClick.KM.DB.Oracle.V1.CreateClient;
using OneClick.KM.Interfaces.Database.V1;

namespace OneClick.KM.Factory.Database.V1
{
   public class CreateUserFactory
    {
        ICreateUser createClient;
        public CreateUserFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    createClient = new CreateUserImp(Client);
                    break;
                case "MySql":
                    createClient = new OneClick.KM.DB.MySql.V1.UserInbound.CreateUserImp(Client);
                    break;
            }
        }
        public ICreateUser CreateUserInstance()
        {
            return createClient;
        }
        #region need to be implemented latter

        #endregion
    }
}
