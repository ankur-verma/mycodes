﻿using OneClick.KM.DB.Oracle.V1.Feedback;
using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{
    public class FeedbackFactory
    {
        IFeedback feedback;
        public FeedbackFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    feedback = new DB.Oracle.V1.Feedback.ImpFeedback(Client);
                    break;
                case "MySql":
                    feedback = new DB.MySql.V1.Feedback.ImpFeedback(Client);
                    break;
            }
        }
        public IFeedback FeedbackInstance()
        {
            return feedback;
        }

        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";
        }
        #endregion
    }
}
