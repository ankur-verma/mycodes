﻿using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{
    public class GuidedHelpFactory
    {
        IGuidedHelp guidedHelp;
        public GuidedHelpFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    guidedHelp = new DB.Oracle.V1.GuidedHelp.ImpGuidedHelp(Client);
                    break;
                case "MySql":
                    guidedHelp = new DB.MySql.V1.GuidedHelp.ImpGuidedHelp(Client);
                    break;
            }
        }
        public IGuidedHelp GuidedHelpInstance()
        {
            return guidedHelp;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";
        }
        #endregion
    }
}
