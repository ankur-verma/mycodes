﻿using OneClick.KM.Interfaces.Database.V1;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.Factory.Database.V1
{
  
    public class GuidedHelpWithCoverPageFactory
    {
        IGuidedHelpWorkFlow guidedHelpWithCoverPage;
        public GuidedHelpWithCoverPageFactory(string clientId)
        {
            string dbName = ConfigurationCalling.GetClientConfig(clientId);
            switch (dbName)
            {
                //case "Oracle":
                //    guidedHelpWithCoverPage = new DB.Oracle.V1.GuidedHelpWithoutCoverPage.ImpGuidedHelpWithCoverPage(clientId);
                //    break;
                case "MySql":
                    guidedHelpWithCoverPage = new OneClick.KM.DB.MySql.V1.GuidedHelpWorkFlow.ImpGuidedHelpWorkFlow(clientId);
                    break;
                //default:
                //    guidedHelpWithCoverPage = new DB.Oracle.V1.Account.ImpGuidedHelpWithCoverPage(clientId);
                //    break;
            }
        }
        public IGuidedHelpWorkFlow GuidedHelpWithCoverPageInstance()
        {
            return guidedHelpWithCoverPage;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";

        }
        #endregion

    }
}
