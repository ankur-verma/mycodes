﻿using OneClick.KM.Interfaces.Database.V1;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.Factory.Database.V1
{
    public class ImageFactory
    {
        IImageBank image;
        public ImageFactory(String client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(client);
            switch (dbName)  //switch (DBName(dbName))
            {
                case "Oracle":
                    image = new DB.Oracle.V1.ImageBank.ImpImageBank(client);
                    break;
                case "MySql":
                    image = new DB.MySql.V1.ImageBank.ImpImageBank(client);
                    break;

                    //case "Postgres":
                    //	account = new DB.Postgres.V1.Account.ImpAccount();
                    //	break;
            }
        }
        public IImageBank ImageBankInstance()
        {
            return image;
        }
        #region need to be implemented latter
        //public string DBName(string Client)
        //{
        //    return "Oracle";

        //}
        #endregion

    }
}

