﻿using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{
    public class KeywordFactory
    {
        IKeyword keyword;
        public KeywordFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    keyword = new DB.Oracle.V1.Keyword.ImpKeyword(Client);
                    break;
                case "MySql":
                    keyword = new DB.MySql.V1.Keyword.ImpKeyword(Client);
                    break;
            }
        }
        public IKeyword KeywordInstance()
        {
            return keyword;
        }
       
    }

}
