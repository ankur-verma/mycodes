﻿using OneClick.KM.Interfaces.Database.V1;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.Factory.Database.V1
{
   public  class LinkFactory
    {
        ILinks link;
        public LinkFactory(String Client)
        {
            switch (DBName(Client))
            {
                case "Oracle":
                    link = new DB.Oracle.V1.Links.ImpLink(Client);
                    break;
                case "MySql":
                    link = new DB.MySql.V1.Links.ImpLink(Client);
                    break;
            }
        }
        public ILinks LinkInstance()
        {
            return link;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";
        }
        #endregion

    }
}

