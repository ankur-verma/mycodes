﻿using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{

    public class LinksMapFactory
    {
        ILinks link;
        public LinksMapFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    link = new OneClick.KM.DB.Oracle.V1.Links.ImpLink(Client);
                    break;
                case "MySql":
                    link = new OneClick.KM.DB.MySql.V1.Links.ImpLink(Client);
                    break;

            }
        }
        public ILinks LinksInstance()
        {
            return link;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";
        }
        #endregion
    }
}
