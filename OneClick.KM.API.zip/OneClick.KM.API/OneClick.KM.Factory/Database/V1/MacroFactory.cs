﻿using OneClick.KM.Interfaces.Database.V1;

namespace OneClick.KM.Factory.Database.V1
{
    public class MacroFactory
    {
        IMacro macro;

        public MacroFactory(string Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    macro = new DB.Oracle.V1.Macro.ImpMacro(Client);
                    break;
                case "MySql":
                    macro = new DB.MySql.V1.Macro.ImpMacro(Client);
                    break;
            }
        }
        public IMacro MacroInstance()
        {
            return macro;
        }
       
    }
}
