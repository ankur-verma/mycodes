﻿using OneClick.KM.DB.Oracle.V1.ManageOrdering;
using OneClick.KM.Interfaces.Database.V1;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.Factory.Database.V1
{
   public class ManageOrderingFactory
    {

        IManageOrdering ordering;

        public ManageOrderingFactory(string Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    ordering = new DB.Oracle.V1.ManageOrdering.ImpManageOrdering(Client);
                    break;
                case "MySql":
                    ordering = new DB.MySql.V1.ManageOrdering.ImpManageOrdering(Client);
                    break;
            }
        }
        public IManageOrdering ManageOrderingInstance()
        {
            return ordering;
        }
        #region need to be implemented latter
        

        #endregion 
    }
}
