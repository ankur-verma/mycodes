﻿using OneClick.KM.Interfaces.Database.V1;

namespace OneClick.KM.Factory.Database.V1
{
    public class MenuFactory
    {
        IMenu menu;

        public MenuFactory(string Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    menu = new DB.Oracle.V1.Menu.ImpMenu(Client);
                    break;
                case "MySql":
                    menu = new DB.MySql.V1.Menu.ImpMenu(Client);
                    break;
            }

        }
        public IMenu MenuInstance()
        {
            return menu;
        }
        #region need to be implemented latter
       
        #endregion
    }
}
