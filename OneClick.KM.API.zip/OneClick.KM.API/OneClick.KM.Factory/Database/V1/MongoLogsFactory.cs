﻿using OneClick.KM.DB.Oracle.V1;
using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{
    public class MongoLogsFactory
    {
        IMongoDBLogs mongoDBLogs;
        public MongoLogsFactory(String Client)
        {

            switch (DBName(Client))
            {
                case "Oracle":
                    mongoDBLogs = new ImpLogHelper(Client);
                    break;
            }
        }
        public IMongoDBLogs MongoLogInstance()
        {
            return mongoDBLogs;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";
        }
        #endregion
    }
}
