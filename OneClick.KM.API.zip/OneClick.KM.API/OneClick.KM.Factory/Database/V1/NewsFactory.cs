﻿using OneClick.KM.Interfaces.Database.V1;

namespace OneClick.KM.Factory.Database.V1
{
    public class NewsFactory
    {

        INews news;

        public NewsFactory(string Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    news = new DB.Oracle.V1.News.ImpNews(Client);
                    break;
                case "MySql":
                    news = new DB.MySql.V1.News.ImpNews(Client);
                    break;
            }
        }
        public INews NewsInstance()
        {
            return news;
        }       
    }
}
