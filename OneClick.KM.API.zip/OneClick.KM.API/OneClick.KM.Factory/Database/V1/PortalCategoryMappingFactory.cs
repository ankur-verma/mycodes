﻿using OneClick.KM.DB.Oracle.V1.PortalCategory;
using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{
    public class PortalCategoryMappingFactory
    {
        IPortalCategoryMapping _IPortalCategoryMapping;
        public PortalCategoryMappingFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    _IPortalCategoryMapping = new DB.Oracle.V1.PortalCategory.ImpPortalCategoryMapping(Client);
                    break;
                case "MySql":
                    _IPortalCategoryMapping = new DB.MySql.V1.PortalCategory.ImpPortalCategoryMapping(Client);
                    break;
            }
        }
        public IPortalCategoryMapping PortalMappingInstance()
        {
            return _IPortalCategoryMapping;
        }
        #region need to be implemented latter
       
        #endregion
    }
}
