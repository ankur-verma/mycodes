﻿
using OneClick.KM.Interfaces.Database.V1;

namespace OneClick.KM.Factory.Database.V1
{
    public class PortalFactory
    {
        IPortal portal;

        public PortalFactory(string Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    portal = new DB.Oracle.V1.PortalImp.ImpPortal(Client);
                    break;
                case "Mysql":
                    portal = new DB.MySql.V1.PortalImp.ImpPortal(Client);
                    break;
            }
        }
        public IPortal PortalInstance()
        {
            return portal;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";
        }
        #endregion
    }
}
