﻿using OneClick.KM.Interfaces.Database.V1;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.Factory.Database.V1
{
   public class ProductCatalogFactory
    {
        IProductCatalog _ProductCatalog;
        public ProductCatalogFactory(String clientId)
        {
            string dbName = ConfigurationCalling.GetClientConfig(clientId);
            switch (dbName)
            {
                
                case "MySql":
                    _ProductCatalog = new DB.MySql.V1.ProductCatalog.ImpProductCatalog(clientId);
                    break;
                default:
                   // _ProductCatalog = new DB.Oracle.V1.ProductCatalog.ImpAccount(clientId);
                    break;
            }
        }
        public IProductCatalog ProductCatalogInstance()
        {
            return _ProductCatalog;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";

        }
        #endregion


    }
}
