﻿using OneClick.KM.Interfaces.Database.V1;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.Factory.Database.V1
{
    public class ProfileManagementFactory
    { 
    IProfileManagement _IProfileManagement;
    public ProfileManagementFactory(String Client)
    {
        string dbName = ConfigurationCalling.GetClientConfig(Client);
        switch (dbName)
        {
            case "Oracle":
                _IProfileManagement = new DB.Oracle.V1.ProfileMangement.ImpProfileMangement(Client);
                break;
            case "MySql":
                _IProfileManagement = new DB.MySql.V1.ProfileManagement.ImpProfileMangement(Client);
                break;
        }
    }
    public IProfileManagement ProfileManagemenInstance()
    {
        return _IProfileManagement;
    }
    }
}
