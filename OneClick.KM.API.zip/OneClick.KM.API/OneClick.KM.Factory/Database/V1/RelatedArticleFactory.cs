﻿using OneClick.KM.Interfaces.Database.V1;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.Factory.Database.V1
{
  public   class RelatedArticleFactory
    {

        IRelatedArticle  relArticle;
        public RelatedArticleFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    relArticle = new DB.Oracle.V1.Article.ImpRelatedArticleImp(Client);
                    break;
                case "MySql":
                    relArticle = new DB.MySql.V1.Article.ImpRelatedArticleImp(Client);
                    break;
            }
        }
        public IRelatedArticle RelatedArticleInstance()
        {
            return relArticle;
        }
        
    }
}
