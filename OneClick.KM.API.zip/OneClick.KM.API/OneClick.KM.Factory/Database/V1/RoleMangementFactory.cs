﻿using OneClick.KM.DB.Oracle.V1.RoleManagement;
using OneClick.KM.Interfaces.Database.V1;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.Factory.Database.V1
{
  public class RoleMangementFactory
    {
        IRoleManagement rolemanagement;
        public RoleMangementFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    rolemanagement = new DB.Oracle.V1.RoleManagement.ImpRoleManagement(Client);
                    break;
                case "MySql":
                    rolemanagement = new DB.MySql.V1.RoleManagement.ImpRoleManagement(Client);
                    break;
            }
        }
        public IRoleManagement RoleManagementInstance()
        {
            return rolemanagement;
        }
        #region need to be implemented latter
        
        #endregion
    }
}
