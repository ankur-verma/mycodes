﻿ using OneClick.KM.Interfaces.Database.V1;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.Factory.Database.V1
{
   public class SaveFeedbackMasterFactory
    {
        ISaveFeedbackMaster _ISaveFeedbackMaster;
        public SaveFeedbackMasterFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    _ISaveFeedbackMaster = new DB.Oracle.V1.Feedback.ImpSaveFeedbakMaster(Client);
                    break;
                case "MySql":
                    _ISaveFeedbackMaster = new DB.MySql.V1.Feedback.ImpSaveFeedbakMaster(Client);
                    break;
            }
        }
        public ISaveFeedbackMaster FeedbackInstance()
        {
            return _ISaveFeedbackMaster;
        }

       
    }
}
