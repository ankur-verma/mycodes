﻿using OneClick.KM.Interfaces.Database.V1;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.Factory.Database.V1
{
   public class SearchConfigurationFactory
    {
        ISeachConfiguration search;
        public SearchConfigurationFactory(String clientId)
        {
            string dbName = ConfigurationCalling.GetClientConfig(clientId);
            switch (dbName)  //switch (DBName(dbName))
            {
                case "Oracle":
                    search = new DB.Oracle.V1.SearchConfiguration.ImpSearchConfiguration(clientId);
                    break;
                case "MySql":
                    search = new DB.MySql.V1.SearchConfiguration.ImpSearchConfiguration(clientId);
                    break;
               
            }
        }
        public ISeachConfiguration SearchConfigurationInstance()
        {
            return search;
        }
        #region need to be implemented latter
       
        #endregion

    }
}
