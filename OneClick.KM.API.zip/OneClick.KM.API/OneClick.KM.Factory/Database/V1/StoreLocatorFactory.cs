﻿using OneClick.KM.DB.Oracle.V1.StoreLocator;
using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{
    public class StoreLocatorFactory 
    {
        IStoreLocator _IStoreLocator;
        public StoreLocatorFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    _IStoreLocator = new DB.Oracle.V1.StoreLocator.ImpStoreLocator(Client);
                    break;
                case "MySql":
                    _IStoreLocator = new DB.MySql.V1.StoreLocator.ImpStoreLocator(Client);
                    break;
            }
        }
        public IStoreLocator GetStoreLocatorInstance()
        {
            return _IStoreLocator;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";
        }
        #endregion
    }
}
