﻿using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{
    public class SuggestionFactory
    {
        ISuggestion suggestion;
        public SuggestionFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    suggestion = new DB.Oracle.V1.Suggestion.ImpSuggestion(Client);
                    break;
                case "MySql":
                    suggestion = new DB.MySql.V1.Suggestion.ImpSuggestion(Client);
                    break;
            }
        }
        public ISuggestion SuggestionInstance()
        {
            return suggestion;
        }
        #region need to be implemented latter
       
        #endregion

    }
}
