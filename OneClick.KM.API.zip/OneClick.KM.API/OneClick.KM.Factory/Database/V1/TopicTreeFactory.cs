﻿using OneClick.KM.Interfaces.Database.V1;

namespace OneClick.KM.Factory.Database.V1
{
    public class TopicTreeFactory
    {

        ITopicTree topictree;

        public TopicTreeFactory(string Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    topictree = new DB.Oracle.V1.TopicTree.ImpTopicTree(Client);
                    break;
                case "MySql":
                    topictree = new DB.MySql.V1.TopicTree.ImpTopicTree(Client);
                    break;
            }
        }
        public ITopicTree TopicTreeInstance()
        {
            return topictree;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";
        }
    }
}
#endregion
