﻿using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{

    public class UserManageFactory
    {
        IUserManage userManage;
        public UserManageFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    userManage = new OneClick.KM.DB.Oracle.V1.UserManagement.UserManagement(Client);
                    break;
                case "MySql":
                    userManage = new OneClick.KM.DB.MySql.V1.UserManagement.UserManagement(Client);
                    break;
            }
        }


        public IUserManage UserManageInstance()
        {
            return userManage;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";
        }
        #endregion
    }
}
