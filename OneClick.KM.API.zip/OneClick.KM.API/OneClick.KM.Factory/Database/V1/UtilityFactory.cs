﻿using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{
    public class UtilityFactory
    {
        IUtility utility;
        public UtilityFactory(String Client)
        {
            string dbName = ConfigurationCalling.GetClientConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    utility = new DB.Oracle.V1.Utility.ImpUtility(Client);
                    break;
                case "MySql":
                    utility = new DB.MySql.V1.Utility.ImpUtility(Client);
                    break;
            }
        }
        public IUtility UtilityInstance()
        {
            return utility;
        }
        #region need to be implemented latter
       
        #endregion

    }
}
