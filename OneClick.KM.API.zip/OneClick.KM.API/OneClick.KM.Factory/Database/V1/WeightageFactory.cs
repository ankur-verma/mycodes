﻿using OneClick.KM.DB.Oracle.V1.Weightage;
using OneClick.KM.Interfaces.Database.V1;
using System;

namespace OneClick.KM.Factory.Database.V1
{
    public class WeightageFactory
    {

        IWeightage _IWeightage;
        public WeightageFactory(String clientId)
        {
            string dbName = ConfigurationCalling.GetClientConfig(clientId);
            switch (dbName)
            {
                case "Oracle":
                    _IWeightage = new DB.Oracle.V1.Weightage.ImpWeightage(clientId);
                    break;
                case "MySql":
                    _IWeightage = new OneClick.KM.DB.MySql.V1.Weightage.ImpWeightage(clientId);
                    break;
            }
        }
        public IWeightage WeightageInstance()
        {
            return _IWeightage;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";
        }
        #endregion
    }
}
