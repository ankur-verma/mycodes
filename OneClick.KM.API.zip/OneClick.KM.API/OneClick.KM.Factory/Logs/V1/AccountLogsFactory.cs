﻿using OneClick.KM.Log.MongoDB.Interfaces;
using OneClick.KM.Log.MongoDB.V1.Account;
using System;

namespace OneClick.KM.Factory.Logs.V1
{
    public class AccountLogsFactory
    {

        IAccountLog account;
        public AccountLogsFactory(string Client)
        {
            string dbName = ConfigurationCalling.GetClientLogConfig(Client);
            switch (dbName)
            {
                case "Oracle":
                    account = new Account(Client);
                    break;
                case "MySql":
                    account = new Account(Client);
                    break;
                case "MongoDB":
                    account = new Log.MongoDB.V1.Account.Account(Client);
                    break;

            }
        }

        public IAccountLog GetAccountLogsInstance()
        {
            return account;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";

        }
        #endregion

    }
}
