﻿using OneClick.KM.Interfaces.Logs.V1;
using OneClick.KM.Log.MongoDB.V1.Article;
using OneClick.KM.Model.Mongo;
using System;

namespace OneClick.KM.Factory.Logs.V1
{
    public class ArticleLogsFactory
    {


        IArtticleLog article;
        public ArticleLogsFactory(String Client)
        {
            switch (Client)
            {
                case "Oracle":
                    article = new ImpArticleLog(Client);
                    break;
                case "MongoDB":
                    article = new ImpArticleLog(Client);
                    break;

            }
        }

        public IArtticleLog GetArticlesLogsInstance()
        {
            return article;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "MongoDB";

        }
        #endregion
    }


}
