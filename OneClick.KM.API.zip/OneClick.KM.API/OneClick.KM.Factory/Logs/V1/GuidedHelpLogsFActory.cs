﻿using OneClick.KM.Interfaces.Logs.V1;
using OneClick.KM.Log.MongoDB.V1.GuidedHelp;

namespace OneClick.KM.Factory.Logs.V1
{
    public  class GuidedHelpLogsFActory
    {
        IGuidedHelpLog _MongoGuidedHelp;
        public GuidedHelpLogsFActory(string Client)
        {
            switch (Client)
            {
                case "Oracle":
                    _MongoGuidedHelp = new MongoGuidedHelp(Client);
                    break;
                case "MongoDB":
                    _MongoGuidedHelp = new MongoGuidedHelp(Client);
                    break;

            }
        }

        public IGuidedHelpLog GetGuidedHelpLogsInstance()
        {
            return _MongoGuidedHelp;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "MongoDB";

        }
        #endregion
    }
}
