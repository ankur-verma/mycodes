﻿using OneClick.KM.Interfaces.Logs.V1;
using OneClick.KM.Log.MongoDB.V1.InsertError;
using System;

namespace OneClick.KM.Factory.Logs.V1
{
    public class InsertErrorLogsFactory
    {

        IInsertErrorLog _InsertError;
        public InsertErrorLogsFactory(String Client)
        {
            switch (Client)
            {
                case "Oracle":
                    _InsertError = new InsertError(Client);
                    break;
                case "MongoDB":
                    _InsertError = new InsertError(Client);
                    break;
            }
        }

        public IInsertErrorLog ErrorIntance()
        {
            return _InsertError;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";

        }
        #endregion
    }
}
