﻿using OneClick.KM.Interfaces.Logs.V1;
using OneClick.KM.Log.MongoDB.V1.Search;
using System;

namespace OneClick.KM.Factory.Logs.V1
{
    public class SearchLogsFactory
    {
        ISearchLog _Search;
        public SearchLogsFactory(String Client)
        {
            switch (Client)
            {
                case "Oracle":
                    _Search = new Search(Client);
                    break;
                case "MongoDB":
                    _Search = new Search(Client);
                    break;
            }
        }

        public ISearchLog GetSearchLog()
        {
            return _Search;
        }

        public ISearchLog GetGuidedHelpLogsInstance()
        {
            throw new NotImplementedException();
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";

        }
        #endregion
    }
}
