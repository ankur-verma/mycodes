﻿using OneClick.KM.Interfaces.Logs.V1;
using OneClick.KM.Log.MongoDB.V1.UserService;
using System;

namespace OneClick.KM.Factory.Logs.V1
{
    public class UserServicesLogsFactory
    {
        IUserRepositoryServiceLog _UserRepositoryService;
        public UserServicesLogsFactory(String Client)
        {
            switch (Client)
            {
                case "Oracle":
                    _UserRepositoryService = new UserRepositoryService(Client);
                    break;

                case "MongoDB":
                    _UserRepositoryService = new UserRepositoryService(Client);
                    break;
            }
        }

        public IUserRepositoryServiceLog GetUserServiceLogsInstance()
        {
            return _UserRepositoryService;
        }
        #region need to be implemented latter
        public string DBName(string Client)
        {
            return "Oracle";

        }
        #endregion
    }
}
