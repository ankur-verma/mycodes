﻿using OneClick.KM.Model;
using OneClick.KM.Model.Account;
using OneClick.KM.Model.ClientManagement;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IAccount
    {
        #region[Agent]
        Task<UserData> ValidateLogin(Login login);
        Task<APIResponseMessage>LogoutSession(BaseModel login);
        Task<UserData> ContinueSession(ActiveUserSessionDet login);
        Task<UserData> ValidatePortalDLogin(PortalDLogin login);
        Task<UserData> SSOValidateLogin(SSOLogin login);
      //  Task<List<HintQuestion>> GetHintQuestion(HintQuestion mHintQuestion);
        Task<APIResponseMessage> SaveResetPassword(ResetPassword objuser);
        Task<APIResponseMessage> UpdatePortal(BaseModel portal);
        #endregion
        #region[Authorng]
        //Task<LoginProp> Login(LoginProp UserLogin, bool pWhetherKillSession);
        Task<LoginProp> Login(LoginProp pLogin, bool pWhetherKillSession);
        
        Task<string> Logout(LogoutProp UserLogin);
        Task<ErrorProp> ChangeExpirePasswordLogic(ChangePassword userdetail);
        Task<ErrorPropForAsync> InsertForgotPassword(InsertForgetPassword ForgotPassword);

        Task<ErrorProp> NewUserChangePassLogic(ChangePassword userdetail);
        Task<ErrorProp> ResetPassword(UserBasic objuser);

        Task<UserData> GetActiveSessionList(ClientBaseModel clientBaseModel);

        Task<ErrorProp> UpdateUserResetPassword(ChangePassword Userdetail);


       // Task<ErrorProp> GetAllClientInfo(String ShortCode);
        #endregion
    }
}
