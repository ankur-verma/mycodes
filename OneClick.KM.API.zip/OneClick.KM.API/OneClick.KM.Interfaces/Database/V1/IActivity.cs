﻿using OneClick.KM.Model;
using OneClick.KM.Model.Activity;
using OneClick.KM.Model.DynamicLayout;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IActivity
    {
        Task<ErrorPropForAsync> GetActivities(String strModuleCode, String strUserId, string domainname, List<ActivityProp> Activity);

        Task<ErrorPropForAsync> GetActivities_V2(String strModuleCode, String strUserId, List<ActivityProp> Activity);
        Task<ErrorPropForAsync> AppLayout(LayotRequest layotRequest);
    }

}
