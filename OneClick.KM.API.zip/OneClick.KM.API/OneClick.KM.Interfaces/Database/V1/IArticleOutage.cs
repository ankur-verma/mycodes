﻿using OneClick.KM.Model;
using OneClick.KM.Model.Articles;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{

    public interface IArticleOutage
    {
        Task<ErrorPropForAsync> GetSearchedInboxArticles(string userid, string domain, string portal, string searchCriteria, string searchText, string startIdx, string endIdx, List<ArticleLstCls> listarticle);
        Task<ErrorPropForAsync> GetSearchedPublishedArticles(string userid, string domain, string portal, string searchCriteria, string searchText, string startIdx, string endIdx, List<ArticleLstCls> listarticle);
        Task<ErrorPropForAsync> AllArchiveArticlelist(Dictionary<string, string> dict, List<ArticleLstCls> objArclist);
    }
}
