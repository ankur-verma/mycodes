﻿using OneClick.KM.Model;
using OneClick.KM.Model.ArticlePortalCategoryMapping;
using OneClick.KM.Model.Menu;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IArticlePortalCategoryMapping
    {
        Task<ErrorProp> CreateTopicCategory(ArticlePortalCategoryMapping postParam);
        Task<ErrorPropForAsync> GetAllTopicCategories(ArticlePortalCategoryMapping pContent);
        Task<ErrorPropForAsync> GetTopicCatById(TopicCategories cat);
        Task<ErrorPropForAsync> GetPortalCategories(TopicCategories cat);
        Task<ErrorProp> CreateTopicLinking(TopicCategories cat);
        Task<ErrorProp> SavePortalCategoryChanges(SavePortalCategoryChanges cat);
       // Task<ErrorPropForAsync> GetPortalMapCategories(TopicCategories cat);
       //Task<ErrorProp> InsertArticlePortal(MenuRecursiveObject menu);
    }
}
