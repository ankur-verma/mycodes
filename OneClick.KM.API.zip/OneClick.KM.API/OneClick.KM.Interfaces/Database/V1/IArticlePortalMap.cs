﻿using OneClick.KM.Model;
using OneClick.KM.Model.ArticlePortalMap;
using OneClick.KM.Model.Articles;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IArticlePortalMap
    {
      
        Task<ErrorPropForAsync> ArticleListForPortalMapping(ArticlePortalMapRequest ObjArt, List<ArticleListPortalMapping> ListArticle);
        Task<ErrorPropForAsync> GetProductlogueListForElasticSearch_New(string userid, string articleCode, string faqbusicode);
        Task<ErrorPropForAsync> ArticleLocateInfo(ArticlePortalMapRequest ObjArt, ArticleLocateInfo ObjArtInfo);

        Task<ErrorPropForAsync> CurrentArticleMapping(ArticlePortalMapRequest ObjArt, CurrentArticleMapping ObjCurrentMap);

        Task<ErrorPropForAsync> EditCurrentArticleMapping(ArticlePortalMapRequest ObjArt, List<ArticleListPortalMapping> ObjCurrentMap);
        Task<ErrorPropForAsync> GetArticelLocator(ArticlePortalMapRequest pdata);
        Task<ErrorProp> SubmitArticlePortalMapping(string UserID, string SessionId, List<ArticleListPortalMapping> ListArticle);



        Task<ErrorPropForAsync> CheckArticlePortalMappingExists(string UserID, List<ArticleListPortalMapping> ObjList,
            string PortalCode, string CatCode, string SubCatCode, string SubSubCatCode,
             List<ArticleListPortalMapping> DuplicateArtList);

        Task<ErrorPropForAsync> CheckArticlePortalMappingDeletable(ArticlePortalMapRequest ObjArt);

        Task<ErrorProp> CheckPublishedArticle(CheckPublishArticleMapping ObjArt);

        #region  for new KM
        // Task<ErrorPropForAsync> ArticlePortalMapping(ArticlePortalTopicMap ObjArt);
        Task<ErrorPropForAsync> GetArticlePortalMapping(ArticlePortalTopicMapList pdata);
        Task<ErrorPropForAsync> GetArticlePortalProductMapping(ArticlePortalTopicMapList pdata);
        Task<ErrorPropForAsync> InsertArticlePortalMapping(ArticlePortalTopicMap ObjArt);
        Task<ErrorPropForAsync> GetArticlePortalTopicMapByArtStatusAndUserID(ArticlePortalTopicMapByArtStatusAndUser objArt);
        Task<ErrorPropForAsync> GetArticlePortalProductMapByArtStatusAndUserID(ArticlePortalTopicMapByArtStatusAndUser objArt);
        Task<ErrorPropForAsync> ArticlePortalTopicPublished(ArticlePortalTopicPublish objArt);
        Task<ErrorPropForAsync> ProductCatalogueUpdate(ArticlePortalTopicPublish objArt);
        Task<ErrorPropForAsync> GetArticleDetailsForElasticSearch_New(string userid, string articleCode, string faqbusicode);
        Task<ErrorPropForAsync> ArticlePortalTopicPublishedIfSave(string UserId, string FaqBusiCode, string ArticleId,
            string Comment, string EndDate, string StartDate, string Scenariocode);

        Task<ErrorPropForAsync> InsertArticleProductCatLogMapping(ArticleProductCatlogMap ObjArt);
        Task<ErrorPropForAsync> GuidedHelpArticlePortalTopicPublished(GHArticlePortalTopicPublish objArt);
        Task<ErrorPropForAsync> ProductCatalogueUpdate(GHArticlePortalTopicPublish objArt);
      
        #endregion
    }
}
