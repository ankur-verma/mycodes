﻿using OneClick.KM.Model;
using OneClick.KM.Model.ElasticCache;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IArticleStatusLogic
    {
        Task<ErrorProp> ChangeStatus(string userid, string portal, string articleCode, string articleType, string faqbusicode, string version, string status,
           string commentText, string commentType, string ClientId);
        Task<ErrorProp> UpdateArticleStatus(string userid, string portal, string articleCode, string faqbusicode, string version, string status);
        Task<ErrorPropForAsync> GetArticleSummary(string userid, string portalcode, string articlecode, string faqbusicode);
        Task<List<ArticleAttachmentData>> GetArticleAttachments(string ArticleCode, string PortalCode, string FaqBusiCode);
        //Task<ErrorPropForAsync> GetArticleDetailsForElasticSearch_New(string userid, string articleCode, string faqbusicode, ElasticCacheViewModel redElsData);
        //Task<ErrorPropForAsync> GetArticleDetailsForElasticSearch_New(string userid, string articleCode, string faqbusicode, ElasticCacheViewModel redElsData, OracleCommand Command)
        Task<ErrorProp> CheckUserRights(string UserId , string ActionId);
          }
}
