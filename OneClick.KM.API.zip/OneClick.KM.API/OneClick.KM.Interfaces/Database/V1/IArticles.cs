﻿using OneClick.KM.Model;
using OneClick.KM.Model.Articles;
using OneClick.KM.Model.Attachment;
using OneClick.KM.Model.Menu;
using System.Collections.Generic;
using System.Threading.Tasks;
using static OneClick.KM.Model.Feedback.Feedback;
using static OneClick.KM.Model.GuidedHelpModel.GuidedHelp;
using static OneClick.KM.Model.Macro.Macro;

namespace OneClick.KM.Interfaces.Database.V1
{

    public interface IArticles
    {
        #region[Agent Application]
        #region[Get Article list from Topic tree in agent portal]
        Task<ErrorPropForAsync> GetArticle(ArticleDetail articleModel);
        #endregion[Get Article list from Topic tree in agent portal]

        #region [Get Article details with attachmemnt list and related article list based on article code in Agent application]
        Task<ErrorPropForAsync> GetArticleDetail(ArticleDetail articleDetail);
        #endregion [Get Article details with attachmemnt list and related article list basedon article code]

        Task<ErrorPropForAsync> GetArticleByMenu(MenuDetail menu);

        Task<ErrorPropForAsync> CreateArticleBasic(ArticleBasicViewModel objArticleBasicViewMaodel);
        Task<ArticleAttach> GetArtAttachment(ArticleAttach articleAttach);
        Task<ErrorPropForAsync> GetArticleGroupContent(LinkGroup linkGroup);

        Task<ErrorPropForAsync> GetBreadCrumbLink(BreadcrumbLink mbreadcrumbLink);
        Task<ErrorProp> checkArticleMap(ArticleContent pdata);

        Task<ErrorPropForAsync> GetManagedPublishedArticle(ArticleContent objart,  List<ArticleLstCls> listarticle);

        Task<ErrorPropForAsync> GetArchiveStatuslist(Dictionary<string, string> dict, List<IdText> objArcStatus);
        #endregion[Agent Application]

        #region[Authoring Article Logic]
        Task<ArticleViewModelPartial> PreviewArticleData(string ArticleCode, string UserId, string FaqBusiCode);
        Task<ErrorPropForAsync> PreviewArticleContent(ArticleViewModelPartial objArticleViewMaodelParial);
        Task<List<ArticleAttachmentData>> PreviewArticleAttachments(string ArticleCode, string PortalCode, string FaqBusiCode);
        Task<List<RelatedArticleModel>> PreviewRelatedArticle(string pArticleCode, string pArticleType,
             string pFaqBusiCode);
        Task<ErrorPropForAsync> CreateNewVersion(ArticleContent pdata);
        Task<ErrorPropForAsync> DeletePublishedArticle(string ArticleCode, string PortalCode, string FaqBusiCode, string UserID, string SessionId, string CommentText, string CommentType, string ArticleType, string ForceDeleteFlag);
        Task<ErrorProp> CheckArticleReviveVersion(ArticleContent articleContent);
        Task<ErrorPropForAsync> ArticleContentForEdit(ArticleContent pdata);
        Task<ErrorProp> EditContentType(ContentTypeList pdata);
        Task<ErrorProp> UploadContent(ArticleContent pContent);
        Task<ErrorProp> ArticleCreationAttachment(ArticleAttachmentData objArticleAttachmentData, string msg);

        Task<ErrorPropForAsync> SearchAccessoriesList(ArticleContent objart, List<ArticleLstCls> listarticle);
        int ArticleAttachmentUpload(string FileBase64, string FileName, string FileExtension, string FilePath);
        Task<ErrorPropForAsync> ArticlePreviewinfo(ArticleContent objPreviewArticle);
        Task<ErrorProp> DeleteArticleAttachment(string UserId, string ArticleCode, string PortalCode, string FaqBusiCode, string AttachmentCode, string msg);
        Task<ArticleViewModelPartial> GetArticlePreviewData(string ArticleCode, string UserId, string FaqBusiCode, string PortalCode);
        Task<ErrorPropForAsync> GetArticleBasicForEdit_V1(ArticleBasicViewModel objArticleBasicViewModel);
        Task<ErrorPropForAsync> GetSearchedPublishedArticles(string UserId, string domain, string Portal, string SearchCriteria, string SearchText, string StartIndex, string EndIndex, List<ArticleLstCls> listarticle);
        Task<ErrorPropForAsync> SearchArticleLinkData(ArticleContent objart, List<ArticleLstCls> listarticle);
        Task<ErrorProp> DeleteArticle(string ArticleCode, string PortalCode, string FaqBusiCode, string UserID, string SessionId, string CommentText, string CommentType, string ArticleType, string ClientId);
        Task<ErrorPropForAsync> ReviveArticle(ArticleBasicViewModel objArticleBasicViewMaodel, List<GuidedHelpQuestionDetail> errGuidedHelp);

        void BaseCommitTrans();

        void BaseRollbackTrans();


        Task<ErrorProp> UpdateGroupOrder(GroupListModel GroupList);

        Task<ErrorProp> DeleteGroupRecord(DeleteGroupModel dict);

        Task<ErrorProp> EditGroup(EditGroupModel dict);
        Task<ErrorPropForAsync> InsertNewGroup(InsertGroupModel  dict,  string GroupCode);

        Task<ErrorPropForAsync> GetGroupList(GetGroupList getGroupList, List<GroupList> objGrouplist);
        //ErrorProp InsNewgroup(Dictionary<string, string> dict, out string GroupCode);        

        //ErrorProp GetGroupList(Dictionary<string, string> dict, ref List<GroupList> objGrouplist);
        Task<ErrorPropForAsync> ArticleEditBasic_V1(ArticleBasicViewMaodel objArticleBasicViewMaodel, List<GuidedHelpQuestionDetail> errGuidedHelp);
        Task<ErrorPropForAsync> ContentChange(ContentDetail content);

        Task<ErrorProp> GetFaqDocAttachment(ArticleAttchViewModal objFaqAttch);
        Task<ErrorProp> RemoveFaqDocAttachment(ArticleAttchViewModal objFaqAttch);
        Task<ErrorProp> FaqDocAttachmentCreation(ArticleAttchViewModal objFaqAttch);
        #endregion
        Task<List<RelatedArticleModel>> GetRelatedArticle(string pArticleCode, string pArticleType, string pPortalCode, string pFaqBusiCode);

        Task<ErrorProp> editContent(ArticleContent pContent);
        Task<ErrorPropForAsync> searchRelatedArticle(string pArticleType, string pArticleCode,
           string pSearchKey, string pSearchValue, string pUserID, string pPortalCode, string pFaqBusiCode, string pContentType, List<RelatedArticleModel> relatedArticleList);
        Task<ErrorPropForAsync> GetSearchedInboxArticles(string userid, string domain, string portal, string searchCriteria, string searchText, string startIdx, string endIdx, List<ArticleLstCls> listarticle);
        #region OneClick
        Task<ErrorProp> CheckExistMacro(MacroProp macProp);
        Task<ErrorPropForAsync> SearchArticleLinkTitle(ArticleContent objart, ArticleLstCls objarticle);
        Task<ErrorPropForAsync> ArticleCreationBasic_V1(ArticleBasicViewMaodel objArticleBasicViewMaodel);
        Task<ErrorPropForAsync> GetArticleBasicForEdit_V1(string userid, string articleCode, string faqBusiCode, ArticleBasicViewMaodel objArticleBasicViewMaodel);
        Task<ErrorPropForAsync> ArticlePublishTemp(ArticlePublishTemp objart);
        Task<ErrorPropForAsync> ReviveArticle_V1(ArticleBasicViewModel objArticleBasicViewMaodel, List<GuidedHelpQuestionDetail> errGuidedHelp);
        Task<ErrorPropForAsync> MacroContent(MacroView objmacro);
        Task<ErrorPropForAsync> ArticleAttachmentDownloadContent(ArticleAttachmentData attachmentContent, string DbAttachment);
      //Task<ErrorPropForAsync> ArticleAttachmentDownloadContent(string attachmentCode, ArticleAttachmentData attachmentContent);
        Task<ErrorPropForAsync> GetBrokenListForArticle(string userid, string articleCode, List<RelatedArticleModel> ListArticle);
        Task<ErrorPropForAsync> AllArchiveArticlelist(Dictionary<string, string> dict, List<ArticleLstCls> objArclist);
        Task<ArticleViewModelPartial> GetArticleRelatedData(string articleCode);
        Task<ErrorPropForAsync> ArticleContent(ArticleViewModelPartial objArticleViewMaodelParial);
        Task<List<ArticleAttachmentData>> GetArticleAttachments(string ArticleCode, string PortalCode, string FaqBusiCode);
        Task<ErrorPropForAsync> SearchArticleList(string userid, string contentType, string portal, string status, string searchCriteria, string searchText, string startIdx, string endIdx, List<ArticleLstCls> listarticle);
        Task<ErrorProp> GetArticleRelatedLinkDtlDal(ArticleViewModelPartial pdata);
        Task<ErrorProp> GetArticlelinkDtl(ArticleViewModelPartial pdata);

        Task<ErrorPropForAsync> GetArticelLocator(ArticleData pdata);

        Task<ErrorPropForAsync> CheckUniqueBusinessCode(ArticleRequest req);

		Task<ErrorPropForAsync> CheckUserAccess(ArticleRequest pdata);

		Task<ErrorPropForAsync> PublishedArticleListwithDate(string userid, string domain, string portal, string Fromdate, string Todate, string startIdx, string endIdx);		
		#endregion Oneclick

		#region content Type
		Task<ErrorPropForAsync> AddContentType(ArticleContentList objcontent);
        Task<ErrorPropForAsync> GetContentForEdit(ContentTypeList objcontent);
        Task<ErrorPropForAsync> GetContentList(string UserID, List<ContentTypeList> objcontent);
        Task<ErrorPropForAsync> CheckContentType(ContentTypeList objcontent);
        Task<ErrorPropForAsync> ContentDelete(ContentTypeList objcontent);
        Task<ErrorPropForAsync> ContentLocateInfo(ContentTypeList info);
        #endregion

    }
}
  