﻿using OneClick.KM.Model;
using OneClick.KM.Model.Attachment;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IAttachment
    {
        #region Article Attachments
        //Task <ErrorProp> ClientCreationAttachment(ClientAttachmentData objArticleAttachmentData,string DbAttachment);
        Task<ErrorPropForAsync> ClientCreationAttachment(ClientAttachmentData objAttach, string isAttachFrmDB);
       Task<List<ClientAttachmentData>> GetAttachments(ClientAttachmentViewData objAttach, string isAttachFrmDB);
        //List<ClientAttachmentData> GetAttachments(ClientAttachmentViewData objClientAttachmentViewData);

        Task<ErrorProp> DeleteAttachment(ClientAttachmentViewData objAttach, string isAttachFrmDB);

        Task<List<ClientAttachmentData>> SearchAttachment(ClientAttachmentViewData objClientAttachmentViewData, string isAttachFrmDB);


        Task<ErrorPropForAsync> UpdateAttachment(ClientAttachmentViewData objClientAttachmentViewData, string isAttachFrmDB);

        Task<ErrorProp> AttachmentLocateInfo(ClientAttachmentViewData info);
        #endregion
    }
   
}
