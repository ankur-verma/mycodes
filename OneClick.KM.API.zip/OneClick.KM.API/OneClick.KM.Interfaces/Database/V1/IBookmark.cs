﻿using OneClick.KM.Model;
using OneClick.KM.Model.Articles;
using OneClick.KM.Model.Bookmark;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IBookmark
    {

        Task<APIResponseMessage> SaveBookMarks(Bookmark baseModel);
        Task<ErrorPropForAsync> GetBookMarkList(BaseModel baseModel);
        Task<List<ArticleData>> DeleteBookMark(DeleteBookmark delete);
    }
}
