﻿using System;
using OneClick.KM.Model;
using System.Collections.Generic;
using System.Text;
using OneClick.KM.Model.Briefing;
using System.Threading.Tasks;
using OneClick.KM.Model.Account;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IBriefing
    {
        Task<ErrorPropForAsync> SaveConfig(BriefingConfig objconfig);
        Task<ErrorPropForAsync> BriefingConfig(BriefingConfig objconfig);
        Task<ErrorPropForAsync> ConfigUpdate(BriefingConfig objconfig);
        Task<ErrorPropForAsync> GetSearchedPublishedArticles(ArticleRequest pdata);
       

        #region assessment
        Task<ErrorPropForAsync> CreateAssesment(AssesmentModel _Assesment);
        Task<ErrorPropForAsync> UpdateAssesment(AssesmentModel _Assesment);
        Task<ErrorPropForAsync> DeleteAssesment(AssesmentModel _Assesment);
        Task<ErrorPropForAsync> DeleteQuestion(AssesmentModel _Assesment);
        Task<ErrorPropForAsync> DeleteAnswer(AssesmentModel _Assesment);

        Task<ErrorPropForAsync> GetAssesmentById(AssesmentModel _INAssesment);
        Task<ErrorPropForAsync> GetAssesmentlist(AssesmentModel _Assesment);
        Task<ErrorPropForAsync> CheckAssesmentTitle(AssesmentModel _Assesment);
        #endregion
        #region AgentApi
        Task<ErrorPropForAsync> BriefingUserLoginValidation(UserData objconfig);
        Task<ErrorPropForAsync> BriefingInfoById(BriefingDetail objconfig);
        Task<ErrorPropForAsync> InsertAttemptMstData(BriefingDetail objconfig);
        Task<ErrorPropForAsync> InsertAttemptLogs(List<AttemptLog> objconfig);
   

        #endregion
    }
}
