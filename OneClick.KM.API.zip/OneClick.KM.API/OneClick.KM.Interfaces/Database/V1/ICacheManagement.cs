﻿using OneClick.KM.Model;
using OneClick.KM.Model.Articles;
using OneClick.KM.Model.CacheManagement;
using OneClick.KM.Model.Client;
using OneClick.KM.Model.ElasticCache;
using System.Collections.Generic;
using System.Threading.Tasks;
using static OneClick.KM.Model.GuidedHelpModel.GuidedHelp;
using static OneClick.KM.Model.Macro.Macro;

namespace OneClick.KM.Interfaces.Database.V1
{

    public interface ICacheManagement
    {
        #region GuidedHelpList
        Task<ErrorPropForAsync> GetSearchedPublishedGuidedHelps(string userid, string domain, string portal, string searchCriteria, string searchText, string startIdx, string endIdx, List<Scenario> lstGuidedhelp);
        #endregion

        #region ArticleList
        Task<ErrorPropForAsync> GetSearchedPublishedArticles(string userid, string domain, string portal, string searchCriteria, string searchText, string startIdx, string endIdx, List<ArticleLstCls> listarticle);
        #endregion

        #region Rebuild - Elastic cache
        ErrorPropForAsync RebuildElasticSearchForFullControlPortalwise(string userid, string session, string portal);
        ErrorPropForAsync RebuildElasticSearchArticlewise(string userid, string portal, string session, List<ArticleIdBasic> SearchableArticleCodes);
        #endregion

        #region Rebuild - Redis Cache
        Task<ErrorPropForAsync> RebuildRedisCacheFullControlPortalwise(string userid, string portal);
        Task<ErrorPropForAsync> RollBackRebuildRedisCacheFullControlPortalwise(string userid, string portal);
        ErrorPropForAsync RebuildRedisCacheArticlewise(string userid, string portal, List<ArticleIdBasic> articleCodes);
        ErrorPropForAsync RebuildRedisCacheGHwise(string userid, string portal, List<ArticleIdBasic> articleCodes);
        Task<ErrorPropForAsync> RebuildRedisCacheTopicTree(string userid, string portal);
        #endregion

        #region Async Task
        void InitiateElasticSearchUpdateForFullControlPortalWise(string userid, string session, string portal);
        void InitiateElasticSearchUpdateArticlewise(string userid, string portal, string session, List<ArticleIdBasic> articleCodes);
        void InitiateRedisCacheUpdateForFullControlPortalwise(string userid, string portal);
        void InitiateRedisCacheUpdateArticlewise(string userid, string portal, List<ArticleIdBasic> articleCodes);
        void InitiateRedisCacheUpdateGuidedHelpWise(string userid, string portal, List<ArticleIdBasic> articleCodes);
        void InitiateRedisCacheUpdateForTopicTree(string userid, string portal);
        #endregion

        #region Elastic Search Process
        Task<ErrorPropForAsync> UpdateElasticSearchForFullControlPortalwise(string userid, string session, string portal);
        void UpdateElasticSearchArticlewise(string userid, string portal, string session, List<ArticleIdBasic> targetArticles);
        void InitiateElasticSearchPushForArticles(string userid, string session, List<ArticleIdBasic> articleToPush, ref int SuccessfulProcessCount, ref int FailedProcessCount);
        
        #endregion

        #region Redis Cache Process
        Task<ErrorPropForAsync> UpdateRedisCacheForFullControlPortalwise(string userid, string portal);
        void UpdateRedisCacheArticlewise(string userid, string portal, List<ArticleIdBasic> targetArticles);
        void UpdateRedisCacheGuidedHelpWise(string userid, string portal, List<ArticleIdBasic> targetArticles);
        void UpdateRedisCacheForTopicTree(string userid, string portal);
        Task<ErrorPropForAsync> InitiateRedisCachePushForArticles(string userid, List<ArticleIdBasic> articleToPush, int SuccessfulProcessCount, int FailedProcessCount);
        Task<ErrorPropForAsync> InitiateRedisCachePushForGH(string userid, List<ArticleIdBasic> ghToPush, int SuccessfulProcessCount, int FailedProcessCount);
        Task<ErrorPropForAsync> InitiateRedisCachePushForPortalConfig(string userid, PortalSeoConfig portalToPush, int SuccessfulProcessCount, int FailedProcessCount);
        Task<ErrorPropForAsync> InitiateRedisCachePushForTopicTree(string userid, string portal, string topicCacheDetailId, int SuccessfulProcessCount, int FailedProcessCount);
        Task<ErrorPropForAsync> InitiateRedisCachePushForMacro(string userid, List<MacroProp> macroToPush, int SuccessfulProcessCount, int FailedProcessCount);




        Task<ErrorPropForAsync> RollBackRedisCachePushForArticles(string userid, List<ArticleIdBasic> articleToPush, int SuccessfulProcessCount, int FailedProcessCount);
        Task<ErrorPropForAsync> RollBackRedisCachePushForGH(string userid, List<ArticleIdBasic> ghToPush, int SuccessfulProcessCount, int FailedProcessCount);
        Task<ErrorPropForAsync> RollBAckRedisCachePushForPortalConfig(string userid, PortalSeoConfig portalToPush, int SuccessfulProcessCount, int FailedProcessCount);
        Task<ErrorPropForAsync> RollBackRedisCachePushForTopicTree(string userid, string portal, string topicCacheDetailId, int SuccessfulProcessCount, int FailedProcessCount);
        Task<ErrorPropForAsync> RollBackRedisCachePushForMacro(string userid, List<MacroProp> macroToPush, int SuccessfulProcessCount, int FailedProcessCount);
        #endregion

        #region Database - Elastic Search
        Task<ErrorPropForAsync> RegisterCacheBatchForElasticSearchFullControlPortalwise(string userid, string portal, string cacheId, List<ArticleIdBasic> articlesToPush);
        Task<ErrorPropForAsync> RegisterCacheBatchForElasticSearchArticlewise(string userid, string targetArticlecodes, string portal, string cacheId, List<ArticleIdBasic> articlesToPush);
        #endregion

        #region Database - Redis cache
        ErrorPropForAsync RegisterCacheBatchForRedisCaheFullControlPortalwise(string userid, string portal, ref string cacheId, ref string topicCacheDetailId, ref List<ArticleIdBasic> articlesToPush, ref List<ArticleIdBasic> ghToPush, ref PortalSeoConfig portalToPush, ref List<MacroProp> macroToPush);
        ErrorPropForAsync RegisterCacheBatchForRedisCacheArticlewise(string userid, string targetArticlecodes, string portal, ref string cacheId, ref List<ArticleIdBasic> articlesToPush);
        ErrorPropForAsync RegisterCacheBatchForRedisCacheGuidedHelpWise(string userid, string targetArticlecodes, string portal, ref string cacheId, ref List<ArticleIdBasic> ghToPush);
        Task<ErrorPropForAsync> RegisterCacheBatchForRedisCaheTopicTree(string userid, string portal, string cacheId, string topicCacheDetailId);
        #endregion

        #region Database - Ref cursors
       // void BuildArticleDataModelList(List<Portal> portalList, List<ElasticCacheViewModel> artElasticRedisList, List<KeywordSearchContent> artKeywordList, List<CArticleAttach> artAttachList, List<CRelatedArticle> artRelatedArtList, List<PortalWeightageMapping> artPortalWeightageMappingList, ref List<ArticleIdBasic> articleToPush);
       // ElasticCacheViewModel BuildElasticRedisModel(string articleCode, List<Portal> portalList, List<ElasticCacheViewModel> artElasticRedisList, List<KeywordSearchContent> artKeywordList, List<CArticleAttach> artAttachList, List<CRelatedArticle> artRelatedArtList, List<PortalWeightageMapping> artPortalWeightageMappingList);
        void BuildGuidedHelpModelList(List<ScenarioProps> ghDetailList, List<QuestionProps> ghQuesList, List<AnswerProps> ghAnsList, List<AccessoriesProps> ghAccessoryList, ref List<ArticleIdBasic> ghToPush);
        ElasticCacheViewModel BuildGuidedHelpModelList(string articleCode, string scenarioCode, List<ScenarioProps> ghDetailList, List<QuestionProps> ghQuesList, List<AnswerProps> ghAnsList, List<AccessoriesProps> ghAccessoryList);
        #endregion

        #region MISC
        Task<ErrorPropForAsync> PushArticleIntoElasticSearch(string userid, string session, ArticleIdBasic objArticle);
        Task<ErrorPropForAsync> PushArticleIntoRedisCache(ElasticCacheViewModel objArticle);
        Task<ErrorPropForAsync> PushGHIntoRedisCache(RedisGuidedHelp redisGHData);
        Task<ErrorPropForAsync> PushMacroIntoRedisCache(string userid, MacroProp macro);
        void CheckAndUpdateCacheDetailStatus(string userid, string cacheDetailId, string errorCode, string errorDetail, ref int failedProcess, ref int successProcess);
        //Task<ErrorPropForAsync> UpdateCacheDetailStatus(string userid, string cacheDetailId, string errorCode, string errorDetail);
        Task<ErrorPropForAsync> UpdateCacheBatchStatus(string userid, string cacheId, ErrorProp status, int failedCount, int successCount);
        Task<ErrorPropForAsync> AnalyseCacheRequestStatus(ErrorProp originalStatus, int failedCount, int successCount);
        string formatElasticData(string input);
       // List<PortalWeightageMapping> PopulatePortalWeightageMappingList(string weightage, List<Portal> PortalList);
       // List<PortalHitCountMapping> PopulatePortalHitCountMappingList(string hitCount, List<Portal> PortalList);
        #endregion

        #region CacheReport
        Task<ErrorPropForAsync> CacheReportlist(string userid, List<CacheReportList> CacheReportlist);
        Task<ErrorPropForAsync> CacheReportByCacheId(string userid, string CacheId, List<CacheReportDetail> CachedtlById);
        #endregion
    }
}
