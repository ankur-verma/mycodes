﻿using OneClick.KM.Model;
using OneClick.KM.Model.Client;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IClient
    {
        #region Portal List
        Task<ErrorProp> GetPortalDetails(string ClientCode, string UserID);
        #endregion

        #region Portal creation

        Task<ErrorProp> CheckPortalNameAvailability(string userId, string portalName);

        Task<ErrorProp> AddNewPortal(PortalSeoConfig obj);

        Task<ErrorProp> DeletePortal(PortalSeoConfig obj);
        Task<ErrorProp> UpdatePortalConfig(PortalSeoConfig obj);
        #endregion
    }
}
