﻿using OneClick.KM.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using static OneClick.KM.Model.ClientConfigurations.ClientConfiguration;
using static OneClick.KM.Model.ClientManagement.ClientBasicDetails;

namespace OneClick.KM.Interfaces.Database.V1
{
   public interface IClientConfigurations
    {
        Task<ErrorPropForAsync> GetAllClientConfig(ClientRequest req);
        Task<ErrorProp> AddOrUpdateClientConfig(ClientConfigUpdateModel req);
        Task<ErrorPropForAsync> GetAllClientConfigByClientId(ClientRequest req);


    }
}
