﻿using OneClick.KM.Model;
using OneClick.KM.Model.ClientManagement;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IClientManagement
    {
        Task<ErrorProp> GetAllClientList(ClientBaseModel response);
        //Task<ErrorProp> GetClientDetailWithContactPerson(BaseModel response);
        //Task<ErrorProp> GetClientLanguageList(BaseModel response);
        //Task<ErrorProp> GetFeatureList(BaseModel baseModel);
        Task<ErrorProp> GetAllClientData(ClientBaseModel clientBaseModel);
        Task<ErrorProp> InsertClientDetail(ClientDetail clientBaseModel);
        Task<ErrorProp> CheckClientName(ClientDetail client);
        Task<ErrorProp> CheckClientShortCode(ClientDetail clientshortcode);

        //Task<ErrorProp> GetAllClientInfo(String ShortCode);
        Task<ErrorProp> GetClientDetails(string UserId, ClientBasicDetails objclient);
        Task<ErrorProp> UpdateClientDetail(ClientDetail clientBaseModel);

        Task<ErrorProp> GetClientDetails(GetClientInfo clientBaseModel);
        Task<ErrorPropForAsync> GetThemeDetails(ThemeDetail detail);
        Task<ErrorPropForAsync> InsertThemeDetail(ThemeDetail detail);
        Task<ErrorPropForAsync> ClientLogin(ClientLogin login);
        Task<ErrorPropForAsync> GetCheckListDetails(CheckLinkListDetail detail);
        Task<ErrorPropForAsync> SaveCheckListDetails(CheckListpost detail);
        Task<ErrorPropForAsync> GetClientDatabaseSetting(DatabaseSetting detail);
        Task<ErrorPropForAsync> SaveDatabaseSetting(SaveDataBaseSetting detail);
            Task<ErrorProp> UserLoginDetails(UserLoginDetails _UserLoginDetails);
        Task<ErrorProp> CheckSession(string SessionId);
        

        Task<ErrorPropForAsync> GenerateKey(GetClientInfo detail);
        Task<ErrorProp> UpdateClientStatus(ClientDetail _UserLoginDetails);

        Task<ErrorPropForAsync> GetActivityList(ClientDetail _UserLoginDetails);
    }
}



    