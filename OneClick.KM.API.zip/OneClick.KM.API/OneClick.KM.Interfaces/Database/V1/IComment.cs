﻿using OneClick.KM.Model;
using OneClick.KM.Model.Comment;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IComment
    {
        Task<ErrorPropForAsync> Comment(CommentDetail objcomment, List<CommentDetail> objcommentList);

        Task<ErrorProp> UpdateArticleComment(string userid,
           string portal, string articleCode, string faqbusicode, string articleType,
           string commentText, string commentType);

    }
}
