﻿using OneClick.KM.Model;
using OneClick.KM.Model.ClientManagement;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public  interface ICommon
    {
        Task<ErrorProp> GetFeatureList(FeatureDetail list);
        Task<ErrorProp> GetLanguagesList(LanguageDetail list);
        Task<ErrorProp> GetConfigrationList(ComponentTypeDetail list);
        Task<ErrorPropForAsync> GetUserRights(string User_id);
    }
}
