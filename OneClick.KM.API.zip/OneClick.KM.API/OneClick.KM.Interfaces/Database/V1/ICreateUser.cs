﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using OneClick.KM.Model;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface ICreateUser
    {
        Task<ErrorPropForAsync> CreateUser(List<Dictionary<string, dynamic>> values , string ReqUsername , string ReqPassword);
        Task<ErrorProp> ImpDeleteUser(List<Dictionary<string, dynamic>> values, string ReqUsername, string ReqPassword);
        Task<ErrorProp> ImpBlockUser(List<Dictionary<string, dynamic>> values, string ReqUsername, string ReqPassword);
        Task<ErrorProp> ImpUnBlockUser(List<Dictionary<string, dynamic>> values, string ReqUsername, string ReqPassword);
        Task<ErrorPropForAsync> ImpResetkUser(List<Dictionary<string, dynamic>> values, string ReqUsername, string ReqPassword);
        Task<ErrorPropForAsync> EditUser(List<Dictionary<string, dynamic>> values, string ReqUsername, string ReqPassword);
    }
}
