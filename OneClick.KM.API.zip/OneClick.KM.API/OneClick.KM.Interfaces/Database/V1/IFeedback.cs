﻿using OneClick.KM.Model;
using System.Collections.Generic;
using System.Threading.Tasks;
using static OneClick.KM.Model.Feedback.Feedback;

namespace OneClick.KM.Interfaces.Database.V1
{

    public interface IFeedback
    {
        #region[Feedback in Application]
        #region[Get feedback question list in agent application]
        Task<ErrorPropForAsync> GetFeedBackQuestionList(FeedBack feedBack);
        #endregion
        Task<ErrorPropForAsync> SaveFeedBackInMasterAndDetails(FeedBackDetails feedBackdetail);
        Task<ErrorPropForAsync> SaveFeedBackMaster(FeedBackMst feedBack);
        //Task<ErrorPropForAsync> SaveFeedBackInMasterAndDetails(FeedBackDetails feedBackdetail);
        //Task<FeedBackMst> SaveFeedBackMaster(FeedBackMst feedBack);
        #endregion

        #region [Authoring Feedback]
        Task<List<IdText>> GetFeedbackType(FeedbackPostdata pdata);
        Task<ErrorPropForAsync> FeedbackQuestionType(FeedbackPostdata pdata, List<IdText> Questionlist);
        Task<ErrorPropForAsync> FeedbackRating(FeedbackPostdata fbdata, List<IdText> objArticleRating);
        Task<ErrorPropForAsync> FeedbackFreshList(FeedbackPostdata pdata);
        Task<ErrorPropForAsync> GetListWithFeedbackType(FeedbackPostdata pdata);
       Task<ErrorPropForAsync> GetFeedbackResponse(FeedbackPostdata pdata);
        Task<ErrorProp> InsertFeedbackResponse(InsertFeedbackResponse Fdata);
        Task<ErrorProp> FeedbackStatusListDal(FeedbackPostdata Fdata);
        Task<ErrorProp> FeedbackReportListDal(FeedbackPostdata pdata);
        Task<ErrorProp> UpdateFeedbackStatusLogic(FeedbackPostdata Fdata);
        Task<ErrorProp> SaveDisplayOrder(string UserID, List<ArticleStarRating> objArtStarRating);
        #endregion

        #region Article Star Rating
        Task<ErrorProp> CreateArticleStarRating(ArticleStarRating objArtStarRating);
        Task<ErrorProp> EditArticleStarRatingQuestion(ArticleStarRating objArtStarRating);
        Task<ErrorProp> RemoveArticleStarRatingQuestion(ArticleStarRating objArtStarRating);
        Task<ErrorPropForAsync> GetArticleStarRatingByPortalRating(string UserID, string PortalCode, string Rating, List<ArticleStarRating> objArtStarRating);
        #endregion



      
    }
}
