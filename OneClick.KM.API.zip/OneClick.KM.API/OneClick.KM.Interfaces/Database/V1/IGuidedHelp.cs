﻿using OneClick.KM.Model;
using OneClick.KM.Model.ArticlePortalMap;
using OneClick.KM.Model.Articles;
using OneClick.KM.Model.CacheManagement;
using System.Collections.Generic;
using System.Threading.Tasks;
using static OneClick.KM.Model.GuidedHelpModel.GuidedHelp;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IGuidedHelp
    {
        #region Agent
        Task<ScenarioProps> GetScenarioDetails(ScenarioProps request);
        Task<QuestionProps> GetQuesAnswerDetails(QuestionProps QuesProps);
        Task<ArticleContentDetail> GetGHArticleDtl(ArticleDetail articleModel);

        #endregion

        #region Authoring
        Task<ErrorPropForAsync> CreateSopScenario_V1(ScenarioViewDetail lobjScenario);

        // Task<ErrorPropForAsync> GetAuthScenarioDetails(ScenarioProps objscenario);

        Task<ErrorPropForAsync> AddComment(string Client, string userid,
           string portalcode, string articlecode, string articleType, string scenariocode,
           string curstatus, string nxtstatus, string commentText, string commentType);
        Task<ErrorPropForAsync> CreateSopScenarioDal(ScenarioViewDetail lobjScenario);
        ErrorProp GuidedhelpSetOrder(AddLinkViewModel addLinkView);
        Task<ErrorPropForAsync> AllArchiveGuidedlist(ArchiveGuidedlist lobjScenario, List<Scenario> objscenariolist);
        Task<ErrorPropForAsync> EditScenarioDal(ScenarioViewDetail lobjScenario);
        Task<ErrorProp> Delete_Article_From_SOP_Question(string articlecode, string userid);
        Task<ErrorPropForAsync> GetGuidedHelpQuestionAnswerData(string userid, string articleCode, string scenarioCode, string quesCode, List<L1_AnswerProps> ghQuesAnsDetails);

        Task<ErrorPropForAsync> GetQuestionDetail(string userid, string quesCode, L1_QuestionsProps result);
        Task<ErrorPropForAsync> InboxGuidedQuesAnsList(string userid, string domain, string portal, string searchCriteria, string searchText, string startIdx, string endIdx, List<Scenario> lstGuidedhelp);
        Task<ErrorProp> saveGuidedHelpLink(string userid,
           string portalCode,
           string scenariocode,
           string quesCode,
           string selArticleType,
           string selArticleCode);


        ErrorProp getGuidedHelpLinkData(string userid,
            string portalCode,
            string articleId,
            string quesCode,
             AddLinkViewModel data);
        Task<ErrorProp> getMappedArticleListbyQuestion(string userid, string quesCode, string scenariocode);

        Task<ErrorPropForAsync> GetAuthScenarioDetails(ScenarioProps objscenario);



        Task<ErrorPropForAsync> EditScenario(ScenarioViewDetail lobjScenario);
        Task<ErrorPropForAsync> ReviveGuidedUpdate(ScenarioViewDetail lobjScenario);

        ErrorProp CreateNewSOPVersion(string userid, string articleCode, string Version, string scenerioCode, string PortalCode, string ArticleType, string commentType, string commentText);
        Task<ErrorPropForAsync> GetGuidedHelpSummary(string userid, string portalcode, string articlecode, string scenariocode, ContentDetailSummary summary);
        Task<ErrorProp> DeleteGuidedHelp(string Client, string UserId, string ScenerioCode, string ArticleCode, string PortalCode, string SessionId, string CommentText, string CommentType, string ArticleType, string FaqBusiCode);
        Task<ErrorPropForAsync> DeletePublishedGuidedHelp(string ClientId, string UserId, string ScenerioCode, string ArticleCode, string PortalCode, string SessionId, string CommentText, string CommentType, string ArticleType, List<AnswerPropsDetail> brokenAnswers, string FaqBusiCode);
        Task<ErrorPropForAsync> Guidedhelpinfo(Scenario obj, ScenarioQuesAnsViewModel objGHinfo);
        Task<ErrorPropForAsync> GetAuthQuesAnswerDetails(QuestionProps QuesProps);
        Task<ErrorPropForAsync> GetSearchedPublishedGuidedHelps(string userid, string domain, string portal, string searchCriteria, string searchText, string startIdx, string endIdx, List<Scenario> lstGuidedhelp);
        Task<ErrorPropForAsync> PublishedGuidedQuesAnsList(string userid, string domain, string portal, string searchCriteria, string searchText, string startIdx, string endIdx, List<Scenario> lstGuidedhelp);
        Task<ErrorPropForAsync> ReviveGuidedQuesAnsList(string userid, string domain, string portal, string searchCriteria, string searchText, string startIdx, string endIdx, string ReviveStatus, List<Scenario> lstGuidedhelp);
        Task<ErrorPropForAsync> AllGuidedHelpInboxSearchedList(string userid, string domain, string portal, string searchCriteria, string searchText, string startIdx, string endIdx, string Status, List<Scenario> lstGuidedhelp);
        Task<ErrorPropForAsync> AllGuidedHelpQuesAnsList(string userid, string domain, string portal, string searchCriteria, string searchText, string startIdx, string endIdx, string Status, List<Scenario> lstGuidedhelp);
        Task<ErrorPropForAsync> GetSearchedInboxGuidedHelps(string userid, string domain, string portal, string searchCriteria, string searchText, string startIdx, string endIdx, List<Scenario> lstGuidedhelp);
        Task<ErrorProp> CheckAllGuidedHelpAccess(Scenario ScenarioDtl);
        Task<ErrorPropForAsync> UpdateAnswer(AnswerPropsDetail ansObj, AnswerPropsDetail result);
        Task<ErrorPropForAsync> ChangeStatusGuidedHelp(string Client, string userid, string portalcode, string articlecode, string articleType, string scenariocode, string curstatus, string nxtstatus, string commentText, string commentType, string FaqBusiCode);
        Task<ErrorPropForAsync> GetAllPublishedGuidedHelpDal(Scenario obj, List<Scenario> lstGuidedhelp);
        Task<ErrorPropForAsync> ChangeStatusGuidedHelpRollBack(string ClientId, string userid, string portalcode, string articlecode, string articleType, string scenariocode, string curstatus, string nxtstatus, string commentText, string commentType);
        #region[GHQuesAnsDetail]
        //  Task<ArticleContent> GetGHArticleDtl(ArticleDetail articleModel);
        Task<ScenarioViewDetail> SOPDetailsByScenarioCode(ScenarioViewDetail ObjScenarioViewModel);
        Task<ErrorPropForAsync> GetGuidedHelpData(string userid, string articleCode, string scenarioCode, ScenarioDetail ghDetail);
        Task<ErrorPropForAsync> GetGuidedHelpQuestionData(string userid, string articleCode, string scenarioCode, List<QuestionsPropsDetail> ghQuesDetails);
        Task<ErrorProp> CreateQuestion(QuestionsPropsDetail objQues);
        Task<ErrorProp> DeleteQuestionAnswerDal(string articlecode, string KeyValue, string modetype, string userid, string scencode);
        Task<QuestionsPropsDetail> GetQuestionByScenario(string pScenarioCode, string pQuestionCode, string pArticleCode, string userid);
        Task<ErrorProp> UpdateQuestion(QuestionsPropsDetail objQues);
        Task<ErrorPropForAsync> GetSearchedQuestionData(string userid, string quesCode, string searchCriteria, string searchText, string startIdx, string endIdx, string scencode, List<QuestionsPropsDetail> ghQuesDetails);
        Task<ErrorPropForAsync> GetAnswerDetail(string userid, string answerCode, AnswerPropsDetail result);
        Task<ErrorPropForAsync> AddAnswer(AnswerPropsDetail ansObj, AnswerPropsDetail result);
        Task<ErrorPropForAsync> GetBrokenListForGH(string userid, string articleCode, List<RelatedArticleModel> ListArticle);
        Task<ErrorProp> GHCreateNewVersion(string userid, string articleCode, string Version, string scenerioCode, string PortalCode, string faq_busi_code);
        Task<ErrorPropForAsync> ReviveGuidedUpdateWvc(ScenarioViewDetail lobjScenario);
        Task<ErrorPropForAsync> ChangeStatusGuidedHelpWithAndWithouthCoverPage(string ClientId, string userid,
                  string articlecode, string scenariocode, string status);
        #endregion

        #region DtAutoAnswer
        Task<ErrorPropForAsync> AllDtAnswerKey(DtAutoAnswerKeys objDtKeys, List<DtAutoAnswerKeys> lstAutoAnsKey);
        Task<ErrorPropForAsync> AllDtAnswerOption(DtAutoAnswerKeys objDtKeys, List<DtAutoAnswerOptions> lstAutoAnsOption);
        Task<ErrorPropForAsync> ApiList(DtApi objDtKeys);
        #endregion
        Task<ErrorPropForAsync> AutomationBokenSummary(Scenario ObjScenario, List<L1_AnswerProps> ObjBrokenAutomationAnswer);

        void BaseCommitTrans();

        void BaseRollbackTrans();
        #endregion
        #region AddSimulation
        Task<ErrorProp> AddSimulation(SimulationGH ansObj);
        Task<ErrorPropForAsync> GetSimulationByCode(SimulationGH ansObj);

        Task<ErrorProp> DeleteSimulation(SimulationGH ansObj);
        #endregion
    }
}
