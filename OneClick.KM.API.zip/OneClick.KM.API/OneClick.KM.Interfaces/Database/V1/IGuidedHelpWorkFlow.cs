﻿using OneClick.KM.Model;
using OneClick.KM.Model.GuidedHelpWorkFlow;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IGuidedHelpWorkFlow
    {
        Task<ErrorPropForAsync> CreateCoverPage(CreateGuidedModel request);

        Task<ErrorPropForAsync> AllArchiveArticlelist(Dictionary<string, string> dict, List<ArticleLstCls> objArclist);
        Task<ErrorPropForAsync> GetSearchedPublishedArticles(string UserId, string domain, string Portal, string SearchCriteria, string SearchText, string StartIndex, string EndIndex, List<ArticleLstCls> listarticle);
        Task<ErrorPropForAsync> GetSearchedInboxArticles(string userid, string domain, string portal, string searchCriteria, string searchText, string startIdx, string endIdx, List<ArticleLstCls> listarticle);

        Task<ErrorPropForAsync> GetGuidedHelp(GetGuidedModel request);
        Task<ErrorPropForAsync> UpdateGuidedHelp(CreateGuidedModel request);
        Task<ErrorPropForAsync> GHCreateNewVersion(Model.GuidedHelpCoverPage.CreateNewVersionGH pdata);
        Task<ErrorPropForAsync> ArticleAndGHSummery(Model.GuidedHelpCoverPage.ArticleAndGHSummery pdata);
      //  Task<ErrorPropForAsync> CreateReviveCoverPageArticle(ReviveGuidedHelpData request);
      //  Task<ErrorPropForAsync> ReviveGuidedUpdate(Model.GuidedHelpModel.GuidedHelp.ScenarioViewDetail lobjScenario);
    }
}
