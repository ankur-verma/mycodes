﻿using OneClick.KM.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using static OneClick.KM.Model.ImageBank.ImageBankModel;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IImageBank
    {

        //Task<List<ImagebankViewModel>> GetImageBankDataByClientID(string clientID, string userID, string startIndex, string endIndex);
        //Task<List<ImagebankViewModel>> GetImageBankDataByScenario(string clientID, string userID, string groupID, string imageTag, string startIndex, string endIndex);
        //Task<ErrorProp> PostImageBankImage(ImagebankViewModel imageBankImages);

        //Task<ErrorProp> DeleteImage(string clientID, string userID, string imageCode, string imagePath);
        //Task<ErrorProp> UpdateImage(ImagebankViewModel objClientAttachmentViewData);
        //Task<List<ImagebankViewModel>> GetGroup();

        //Task<ErrorProp> ImageLocateInfo(string clientID, string userID, string imageCode);

        ////AddGroup
        //Task<ErrorProp> AddGroup(string userID, string groupName);
        //Task<ErrorProp> UpdateGroup(ImagebankViewModel objGroupData);

        Task<ErrorProp> ImageBankImgUpload(ImagebankViewModel ObjImage);
       // Task<ErrorProp> ArticleImgTaggingUpload(string imgBase64, string thumbnailBase64, string fileName, string filePath, string fileExt);
 
        Task<ErrorProp> DeleteImage(string clientID, string userID, string imageCode, string imagePath);
        Task<List<ImagebankViewModel>> GetImageBankDataByClientID(string clientID, string userID, string startIndex, string endIndex);

        Task<List<ImagebankViewModel>> GetImageBankDataByScenario(string clientID, string userID, string groupID, string imageTag, string startIndex, string endIndex);
        Task<ErrorPropForAsync> UpdateImage(ImagebankViewModel objattach);
        Task<List<ImagebankViewModel>> GetGroup(string UserId);

        Task<ErrorProp> AddGroup(string userID, string groupName);
        Task<ErrorProp> UpdateGroup(ImagebankViewModel objGroupData);
        Task<ErrorProp> ImageLocateInfoDal(string clientID, string userID, string imageCode);
        // Task<ErrorProp> ImageLocateInfoDal(ImagebankViewModel pdata);      

    }
}
