﻿using OneClick.KM.Model;
using OneClick.KM.Model.Keyword;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IKeyword
    {
        #region [Autoring]
        //  Task<KeyWordModel> CreateKeyword(KeyWordModel lobjUtil);
        Task<ErrorPropForAsync> CreateKeyword(KeyWordModel lobjUtil);

        Task<ErrorProp> DeleteKeyword(KeyWordModel obj);
        Task<List<KeyWordDtl>> GetArticleKeyList(KeyWordModel objdata);
        Task<ErrorPropForAsync> GetSearchkeyword(KeyWordDtl objdata, List<KeyWordDtl> lstKeydtl);
        #endregion
    }
}


