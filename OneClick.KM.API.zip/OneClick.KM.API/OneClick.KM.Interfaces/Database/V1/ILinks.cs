﻿
using OneClick.KM.Model;
using OneClick.KM.Model.Link;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface ILinks
    {
        Task<List<LinksModel>> GetQuickLinks(LinksModel Links);

        Task<List<UsefulLink>> GetUsefullLinks(BaseModel _Links);

        Task<List<LinkGroup>> GetQuickLInkGroup(BaseModel link);


        Task<ErrorProp> AddUsefulLink(UsefulLinkviewModel objLink);
        Task<ErrorProp> UsefulLinkDelete(UsefulLinkviewModel objLink);
        Task<ErrorPropForAsync> UsefulLinkList(List<UsefulLinkviewModel> objLinkList, UsefulLinkviewModel objlink);

        Task<ErrorProp> CheckDuplicateName(UsefulLinkviewModel objLink);

        Task<ErrorProp> UpdateUsefulLinkOrderDal(UsefulLinkModelOrder ObjLinkOrder);
    }
}
