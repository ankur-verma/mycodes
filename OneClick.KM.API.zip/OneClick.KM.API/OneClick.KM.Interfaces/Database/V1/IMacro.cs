﻿using OneClick.KM.Model;
using System.Collections.Generic;
using System.Threading.Tasks;
using static OneClick.KM.Model.Macro.Macro;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IMacro
    {

        Task<ErrorPropForAsync> MacroList(MacroView objMacro, List<MacroView> objMacrolist);

        Task<ErrorProp> CreateMacro(MacroView objMacro);

        Task<ErrorPropForAsync> GetEditMacro(MacroView objMacro, MacroView objMacrolist);

        Task<ErrorProp> EditMacro(MacroView objMacro);

        Task<ErrorPropForAsync> DeleteMacro(MacroView objMacro, List<MacroProp> objArtlist);

        // Task<ErrorPropForAsync> CheckMacroName(MacroView objMacro, List<MacroProp> objArtlist);
        Task<ErrorProp> CheckMacroName(MacroView objMacro);

        Task<ErrorPropForAsync> ArticleMacroList(MacroView objMacro, List<MacroView> objMacrolist);

        Task<ErrorProp> CreateMacroType(MacroTypeView objMacroType);
        Task<ErrorProp> EditMacroType(MacroTypeView objMacroType);
        Task<ErrorProp> RemoveMacroType(MacroTypeView objMacroType);
        //Task<ErrorPropForAsync> MacroTypeList(MacroTypeView Mdata, string UserID, List<MacroTypeView> objMacroTypeList);
        Task<ErrorPropForAsync> MacroTypeList(string UserId, List<MacroTypeView> objMacroTypeList);
    }
}
