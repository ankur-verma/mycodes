﻿using OneClick.KM.Model;
using OneClick.KM.Model.ManageOrdering;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using static OneClick.KM.Model.ManageOrdering.ManageOrdering;

namespace OneClick.KM.Interfaces.Database.V1
{
   public interface IManageOrdering
    {

       Task<ErrorPropForAsync> InsertNewArticleInOrding(OrderingData Objordering, List<OrderingDetail> orderlist);

        Task<ErrorPropForAsync> GetAllPublishArticle(OrderingData Objordering, List<OrderingDetail> orderlist);
        Task<ErrorPropForAsync> GetArticlelistwithOrder(OrderingData Objordering, List<OrderingDetail> orderlist);
        Task<ErrorPropForAsync> SetOrdering(OrderingData Objordering,List<OrderingDetail> orderlist);
        Task<ErrorPropForAsync> DeleteOrdering(OrderingData Objordering);
        Task<ErrorPropForAsync> GetArtProductalogDisplayOrder(string userid, string CatalogId, string PortalCode);
    }
}
