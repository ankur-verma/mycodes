﻿using OneClick.KM.Model;
using OneClick.KM.Model.Menu;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IMenu
    {
        Task<List<MenuDetail>> GetMenuList(BaseModel baseModel);
    }
}
