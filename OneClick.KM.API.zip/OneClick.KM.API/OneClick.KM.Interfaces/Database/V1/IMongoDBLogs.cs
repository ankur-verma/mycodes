﻿using OneClick.KM.Model.Mongo;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IMongoDBLogs
    {
        Task<MongoDBLogs> GetArticleDetailsForMongoDb(string ArticleCode, string faqbusicode);
        Task<MongoDBLogs> GetGuidedHelpLogsForMongoDb(string ArticleCode, string ScenarioCode);
    }
}
