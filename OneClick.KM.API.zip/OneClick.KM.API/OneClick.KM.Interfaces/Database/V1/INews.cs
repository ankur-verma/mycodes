﻿using OneClick.KM.Model;
using OneClick.KM.Model.Articles;
using OneClick.KM.Model.News;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface INews
    {
        Task<List<ArticleData>> GetNews(NewsDetail request);

    }
}
