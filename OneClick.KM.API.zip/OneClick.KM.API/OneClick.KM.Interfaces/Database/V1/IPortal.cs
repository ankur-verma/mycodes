﻿using OneClick.KM.Model;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IPortal
    {
        Task<string> UserPortal(BaseModel response);

    }
}
