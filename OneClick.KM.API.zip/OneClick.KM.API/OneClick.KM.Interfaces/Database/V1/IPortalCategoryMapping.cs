﻿using OneClick.KM.Model;
using OneClick.KM.Model.PortalCategoryMapping;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IPortalCategoryMapping
    {
        #region PortalCategoryMapping
        Task<ErrorPropForAsync> MappedPortalList(PortalCategoryMappingModel Portalcatdlt, List<DdlPortalCategoryMap> mappedPortal);
        Task<ErrorPropForAsync> MappedCategoryList(PortalCategoryMappingModel Portalcatdlt, List<DdlPortalCategoryMap> mappedCat);
        Task<ErrorPropForAsync> MappedSubCategoryList(PortalCategoryMappingModel Portalcatdlt, List<DdlPortalCategoryMap> mappedsubCat);
        Task<ErrorPropForAsync> MappedSubSubCategoryList(PortalCategoryMappingModel Portalcatdlt, List<DdlPortalCategoryMap> mappedsubsubCat);
        Task<ErrorPropForAsync> MappedList(PortalCategoryMappingModel Portalcatdlt, List<MappedListModel> maplist);
        Task<ErrorPropForAsync> InsertCategoryMapping(List<PortalCategoryMappingModel> Portalcatdlt, List<MappedListModel> maplist);
        Task<ErrorPropForAsync> UpdateStatusCategoryMapping(List<MappedListModel> Mapstatuslist, string SessionId);

        Task<ErrorProp> UpdateStatusCategoryMappingRollBack(List<MappedListModel> Mapstatuslist, string SessionId);
        
        Task<ErrorPropForAsync> TopictreePreview(MappedListModel Portalcatdlt, List<MappedListModel> maplist);
        Task<ErrorProp> CheckMappingIsDeletable(string userid, MappedListModel Portalcatdlt);

        Task<ErrorPropForAsync> InsertPortalCategories(PortalCategoryMapping Portalcatdlt, List<PortalCategoryMappingData> maplist);


        void BaseCommitTrans();
        void BaseRollbackTrans();
        #endregion
    }
}
