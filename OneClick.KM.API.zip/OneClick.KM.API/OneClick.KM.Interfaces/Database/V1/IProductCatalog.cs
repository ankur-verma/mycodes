﻿using OneClick.KM.Model;
using OneClick.KM.Model.ProductCatalog;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
  public interface IProductCatalog
    {
        Task<ErrorProp> InsertCreatedCatalogDetails(ProductCatalogModel Fdata);
        Task<ErrorPropForAsync> EditCatalogDetails(ProductCatalogModel Fdata);  
        Task<ErrorProp> DeleteCatalog(ProductCatalogModel Fdata);
        Task<ErrorProp> UpdateCatalogDetails(ProductCatalogModel Fdata);
        Task<ErrorPropForAsync> GetAllCatalogs(ProductCatalogModel Fdata);
        Task<ErrorProp> UpdateCatalogDisplayOrder(UpdateDisplayOrder Fdata);
    }
}
