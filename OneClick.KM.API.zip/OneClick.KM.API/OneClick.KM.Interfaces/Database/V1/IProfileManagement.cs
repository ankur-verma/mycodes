﻿using OneClick.KM.Model;
using OneClick.KM.Model.ProfileMangementModel;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
  public interface IProfileManagement
    {
        Task<ErrorProp> AddOrUpdateForm(ProfileManagementBaseModel login);
        Task<ErrorPropForAsync> GetKeyDetails(BaseModel req);

        Task<ErrorPropForAsync> GetProfileDetail(ProfileManagementBaseModel req);
        Task<ErrorPropForAsync> CheckAttachedGuidedHelp(ProfileManagementBaseModel req);
        
        #region ApiManageConfiguration
        Task<ErrorProp> ManageApiConfiguration(ApiConfiguration req);
        Task<ErrorPropForAsync> GetApiConfigurationList(ApiConfiguration req);//
        Task<ErrorPropForAsync> GetApiParameterDetailList(ApiConfiguration req);
        Task<ErrorPropForAsync> CheckApiName(ApiConfiguration req);
        Task<ErrorPropForAsync> SaveApiOrder(List<ApiConfiguration> req);
        #endregion
    }
}
