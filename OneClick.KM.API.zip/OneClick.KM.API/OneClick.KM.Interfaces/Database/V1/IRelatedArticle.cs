﻿using OneClick.KM.Model;
using OneClick.KM.Model.Articles;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IRelatedArticle
    {
        Task<RelatedArticleModel> GetArticleBasicDtl(string pArticleType, string pArticleID, string pUserID, string pPortalCode, string pFaqBusiCode);
        Task<List<RelatedArticleModel>> GetRelatedArticle_Old(string pArticleCode, string pArticleType, string pPortalCode, string pFaqBusiCode);
        Task<List<RelatedArticleModel>> GetRelatedArticle(string pArticleCode, string pArticleType, string pPortalCode, string pFaqBusiCode);
        Task<ErrorPropForAsync> SearchRelatedArticle_V1(string pArticleType, string pArticleCode,
         string pSearchKey, string pSearchValue, string pUserID, string pFaqBusiCode, string pContentType, List<RelatedArticleModel> relatedArticleList);
        Task<ErrorProp> UnPublishArticle(string userid, string sessionId, string portal, string articleCode, string faqbusicode, string version, string status);
        Task<ErrorProp> RelateArticle(SaveRelatedArticleModel pData);
        Task<ErrorPropForAsync> GetRelatedAccessories(string pArticleCode, string userId, List<RelatedArticleModel> relArtList);
        Task<ErrorPropForAsync> GetArticleBasicDtl_V1(string pArticleID, string pUserID, string pFaqBusiCode, string pArticleType);
        Task<ErrorPropForAsync> DeleteRelatedArticle(RelatedArticleDetail article);
        Task<ErrorPropForAsync> GetRelatedArticle_V1(string pArticleCode, string pFaqBusiCode, string pArticleType);
    
    }
}
