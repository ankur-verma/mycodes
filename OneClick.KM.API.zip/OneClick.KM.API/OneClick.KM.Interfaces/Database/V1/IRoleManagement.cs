﻿using OneClick.KM.Model;
using OneClick.KM.Model.Rolemanagement;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
   public interface IRoleManagement
    {
        Task<ErrorPropForAsync> GetRolelist(string userid, string groupcode);
        Task<ErrorPropForAsync> DeleteRole(string userid , string groupid);
        Task<ErrorPropForAsync> GetCatActions();
        Task<ErrorPropForAsync> AddOrUpdateRole(RoleManagementRequestModel request);
        Task<ErrorPropForAsync> GetGroupInfoById(RoleManagementRequestModel request);
    }
}
