﻿using OneClick.KM.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using static OneClick.KM.Model.Feedback.Feedback;

namespace OneClick.KM.Interfaces.Database.V1
{
   public interface ISaveFeedbackMaster
    {
        Task<List<FeedBackOpt>> GetFeedBackQuestionList(FeedBack feedBack);
        //Task<FeedBackMst> SaveFeedBackDetails(FeedBackDetails feedBack);
        Task<ErrorPropForAsync> SaveFeedBackMaster(FeedBackMst feedBack);
        Task<FeedBackMst> SaveFeedBackInMasterAndDetails(FeedBackDetails feedBack);
    }
}
