﻿using OneClick.KM.Model;
using OneClick.KM.Model.SearchConfiguration;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
   public interface ISeachConfiguration
    {
        Task<ErrorPropForAsync> GetSearchTopicList(BaseModel baseModel);
    }
}
