﻿using OneClick.KM.Model;
using OneClick.KM.Model.StoreLocator;
using System.Collections.Generic;
using System.Threading.Tasks;
using static OneClick.KM.Model.StoreLocator.StoreLocator;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IStoreLocator
    {
        Task<ErrorProp> AddNewStore(StoreLocatorView objstore);

        Task<ErrorPropForAsync> GetStateList(string UserID,  List<CityStateView> objcitystate);
        Task<ErrorPropForAsync> GetCityList(string UserID, string State,  List<CityStateView> objcitystate);

        Task<ErrorProp> EditStore(StoreLocatorView storeObj);
        Task<ErrorPropForAsync> getStoreList(string userid, string domain,  List<StoreLocatorView> storeList);
        Task<ErrorPropForAsync> RetreiveStoreList(string userid, string portal, string domain,  List<StoreLocatorView> storeList);
        Task<ErrorPropForAsync> getStoreDetail( StoreLocatorView storeDetail);
        Task<ErrorProp> StoreDelete(StoreLocatorView storeObj);
        
        #region StoretypeManagment

        Task<ErrorPropForAsync> Storetypelist(StoreLocatorView objStore,  List<StoreLocatorView> Storetypelist);
        Task<ErrorProp> AddStoretype(StoreLocatorView objStore,  string StroretypeCode);
        Task<ErrorProp> EditStoretype(StoreLocatorView objStore);

       // Task<ErrorProp> GetEditStoretype(StoreLocatorView objStore,  StoreLocatorView Storedtl);
        Task<ErrorProp> DeleteStoretype(StoreLocatorView objStore);
        Task<ErrorProp> CheckStoretypeName(StoreLocatorView objStore);

        #endregion
        Task<ErrorPropForAsync> StoretypebyPortal(StoreLocatorView objStore,  List<StoreTypeModel> Storetypelist);
        Task<ErrorPropForAsync> GetStoreLocationList(StoreLocationSearch Store);
        //Task<List<StoreLocatorDetail>> GetStoreLocationList(StoreLocationSearch storeLocator);
        Task<ErrorPropForAsync> GetJioStateList(BaseModel basemodel);
        Task<ErrorPropForAsync> GetCities(StoreLocationSearch storeLocationSearch);
        Task<ErrorPropForAsync> GetLocality(StoreLocationSearch sToreLocator);
    
        Task<ErrorPropForAsync> GetEditStoretype(StoreLocatorView objStore, StoreLocatorView Storedtl);
    }
}
