﻿using OneClick.KM.Model;
using OneClick.KM.Model.Suggestion;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface ISuggestion
    {
        Task<ErrorPropForAsync> SuggestionList(Suggestions SugsnModel);
        Task<ErrorPropForAsync> DeleteSuggestion(Suggestions sugg);
        Task<ErrorPropForAsync> PendingSuggestion(Suggestions suggestions);
    }
}
