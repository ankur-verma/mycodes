﻿using OneClick.KM.Model;
using OneClick.KM.Model.TopicTree;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface ITopicTree
    {
        Task<TopicTreeData> GetTopicTree(BaseModel baseModel);

        Task<ErrorPropForAsync> AddTopicTreee(AddTopicTree baseModel);

       // Task<ErrorPropForAsync> GetTopicLinks(string UserId, string Portald);
    }
}
