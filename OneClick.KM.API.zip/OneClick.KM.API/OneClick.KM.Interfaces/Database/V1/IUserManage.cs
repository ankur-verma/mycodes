﻿
using OneClick.KM.Model;
using OneClick.KM.Model.UserManagement;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IUserManage

    {
        Task<ErrorProp> UpdateUserPortalData(UserData objdata);
        Task<ErrorPropForAsync> GetDesignationList(string UserID, List<Designation> objDesignations);       
        Task<ErrorPropForAsync> GetRolesListFromUserType(string UserID, string domain, string userType, List<Roles> rolelist);
        Task<ErrorProp> CreateUser(UserCreateModal obj);
        Task<ErrorProp> UpdateUser(UserUpdateModal obj);
        Task<ErrorPropForAsync> GetReportingToUsersList(string UserID, string domain, string usertype, string group, List<LstPortal> AllPortal,  List<UserNamesByDesignation> userByDesignationlist);

        Task<ErrorPropForAsync> GetUserList(string UserID,  List<UserBasic> objUser,  List<Roles> objRoles,  List<Module> objModules);
        Task<ErrorPropForAsync> UserList(string UserID, string Searchby, string Searchtext,  List<UserBasic> userlist,  List<Roles> rolelist,  List<Module> modulelist);
        Task<ErrorPropForAsync> GetUserDetail(string loginUserid, string userid, string domain,  UserBasic obj);

        Task<ErrorPropForAsync> GetUserLocation(string UserID, List<UserLocation> objloc);
        Task<ErrorProp> CreationBulkBatch(UserCreateModal obj, string Portallist);
        Task<ErrorPropForAsync> AllUserBatchlist(UserCreateModal obj, List<UserCreateModal> Allbatch);

        Task<ErrorProp> UpdateUserPortal(string UserID, UserData objdata);
        Task<ErrorProp> CreationUserBatch(UserCreateModal obj, string Portallist);

        #region User location
        Task<ErrorPropForAsync> RetreiveLocationList(string userid, string domain, List<UserLocation> LocationList);
        Task<ErrorProp> AddNewLocation(string userid, string locationName);
        Task<ErrorProp> EditLocationDetail(string userid, string locationCode, string locationName);
        Task<ErrorPropForAsync> UserRecord(List<UserRecord> lstUser);
        Task<ErrorProp>  RemoveLocationData(string userid, string locationCode);

        Task<ErrorPropForAsync> Userbatchdtl(UserCreateModal obj, List<UserBasic> batchdtl);
        Task<ErrorProp> CreationBulkuser(UserCreateModal obj, UserCreateModal UserCreatelist);
        Task<ErrorProp> UpdateBulkUser(UserCreateModal obj, string Portallist, UserCreateModal UserCreatelist);
        Task<ErrorProp> updateUserRoles(UserUpdateModal obj);
        //ErrorProp UpdateUserPortalList(string UserID, UserData objuser);
        //ErrorPropForAsync GetUserPortalList(string UserID, List<UserData> objuser);
        //Task<ErrorPropForAsync> CheckCurrentPassword(string userid, string username, string password);
        //ErrorProp ResetPassword(UserBasic objuser);
        //ErrorProp CreateBulkUser(UserCreateModal obj);
        //ErrorProp BulkSourceUserlist(string UserID, List<UserBasic> objUser);
        //Task<ErrorProp> CreationBulkuser(UserCreateModal obj, UserCreateModal UserCreatelist);
        //ErrorProp UpdateBulkuser(UserCreateModal obj, string Portallist, UserCreateModal UserCreatelist);
        //ErrorProp Userbatchdtl(UserCreateModal obj, List<UserBasic> batchdtl);
        //ErrorProp GetUserRolesList(string UserID, List<Roles> roles);
        //ErrorProp GetModuleList(string UserID, List<Module> module);
        //ErrorProp GetUsersDesignationList(string UserID, string userDesignationhrch, List<LstPortal> AllPortal, List<UserNamesByDesignation> objUsersByDesignations);



        #endregion





    }
}
