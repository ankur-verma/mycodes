﻿using OneClick.KM.Model;
using OneClick.KM.Model.Client;
using OneClick.KM.Model.Utility;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using static OneClick.KM.Model.GuidedHelpModel.GuidedHelp;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IUtility
    {
        Task<List<BasicEntry>> GetBasicEntry(String Identifier);
        Task<ErrorProp> CheckSession(String SessionID);
        Task<ErrorPropForAsync> GetAllPortal(String userid, String clientcode, String domain, String IsAllPortal);
        Task<List<ScopeDetail>> GetAllScope(String identifier);
         
        //Task<ErrorPropForAsync> GetArticleSection(string userId, string portal, List<ArticleSection> lstData);
        Task<List<CategoryTypeDetail>> GetAllCategoryType();

        Task<List<CategoryDetail>> GetAllCategory(string Categorytypecode, string PriorityCode);

        Task<List<SubCategoryDetail>> GetAllSubCategory(string categoryCode);

        Task<List<SubSubCategoryDetail>> GetAllSubSubCategory(string categoryCode, string subCategoryCode);
        Task<List<CategoryTypeDetail>> GetAllCategoryType_V1(ContentTypeData data);
    }
}
