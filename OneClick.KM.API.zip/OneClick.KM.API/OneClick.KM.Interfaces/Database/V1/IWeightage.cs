﻿using OneClick.KM.Model;
using OneClick.KM.Model.Weightage;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Database.V1
{
    public interface IWeightage
    {
        Task<ErrorPropForAsync> GetSearchedPublishedArticles(WeightageData ObjWeitage,  List<WeightageDetail> Weitagelist);
        Task<ErrorProp> CreateNewWeightage(WeightageData ObjWeitage, string SessionId);
        Task<ErrorPropForAsync> WeightageList(WeightageData ObjWeightage,  List<WeightageDetail> Weitagelist);
        Task<ErrorProp> DeleteWeightage(WeightageData ObjWeitage, string SessionId);
        Task<ErrorProp> SaveWeightageOrder(WeightageData ObjWeitage, string SessionId);
        void BaseCommitTrans();
        void BaseRollbackTrans();
    }
}
