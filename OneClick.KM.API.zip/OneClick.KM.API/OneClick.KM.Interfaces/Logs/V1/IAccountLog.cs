﻿using OneClick.KM.Model;
using OneClick.KM.Model.Mongo;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.Log.MongoDB.Interfaces
{
   public interface IAccountLog
    {

        Task<UserLoginLogs> LoginDetailsData(UserLoginLogs mlogin);

        //MacroLog for Application
         Task<APIResponseMessage> InsertMacroLogs(MacroLogs macLogs);


        //Insert User related logs in MongoDb
         Task<APIResponseMessage> InsertUserInteraction(UserInteractions usr_int);


        //GetUser Interaction from MongoDb
         Task<List<UserInteractions>> GetUserInteractions(UserInteractions usr_int);


        // Get user related data   from mongo db  using id
         Task<UserInteractions> GetInteractionsById(UserInteractions usr_int);


        // get GuidedHelp detail by id from  mongo db
         Task<List<GHStepInteractions>> GetInteractionDetailById(GHStepInteractions mGHStepInteractions);


        //insert macro utility log into mongo Db 
         Task<APIResponseMessage> InsertMicroUtilVisit(MicroUtility objMicroUtil);


        //Update article log into mongo db
         Task<APIResponseMessage> UpdateArticleLog(UserInteractions usr_int);

        //ErrorLogs insert into mongo Db 
         Task<APIResponseMessage> InsertErrorLogs(ErrorLogs errLogs);
       
    }
}
