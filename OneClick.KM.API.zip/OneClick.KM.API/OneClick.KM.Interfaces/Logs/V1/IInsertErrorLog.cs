﻿using OneClick.KM.Model;
using OneClick.KM.Model.Mongo;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Logs.V1
{
  public  interface IInsertErrorLog
    {
        Task<APIResponseMessage> InsertErrorLogs(ErrorLogs errLogs);
    }
}
