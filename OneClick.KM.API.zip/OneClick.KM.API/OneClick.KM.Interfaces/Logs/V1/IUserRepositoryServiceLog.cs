﻿using OneClick.KM.Model;
using OneClick.KM.Model.Mongo;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.Interfaces.Logs.V1
{
   public interface IUserRepositoryServiceLog
    {
        Task<APIResponseMessage> InsertUserInteraction(UserInteractions usr_int);
        Task<List<UserInteractions>> GetUserInteractions(UserInteractions usr_int);
        Task<UserInteractions> GetInteractionsById(UserInteractions usr_int);
       // Task<List<GHStepInteractions>> GetInteractionDetailById(GHStepInteractions mGHStepInteractions);
        Task<APIResponseMessage> InsertMicroUtilVisit(MicroUtility objMicroUtil);
        Task<APIResponseMessage> UpdateArticleLog(UserInteractions usr_int);
    }
}
