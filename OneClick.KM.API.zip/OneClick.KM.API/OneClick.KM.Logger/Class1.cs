﻿using System;

namespace OneClick.KM.Logger
{
	public class Class1
	{
	}
}
