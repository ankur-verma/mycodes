﻿using System;

namespace OneClick.KM.Logger
{
    public static class LogHelper
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        public static void Info(string message, string clientId)
        {			
			logger.Info(message);
        }       
        public static void Warning(string message, string clientId)
        {
            logger.Warn(message);
        }
        public static void Debug(string message, string clientId)
        {
            logger.Debug(message);
        }
        public static void Error(string message,string clientId)
        {
            logger.Error(message);
        }

    }
}
