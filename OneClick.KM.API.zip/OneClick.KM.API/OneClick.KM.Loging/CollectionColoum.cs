﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.Loging
{
  public  class CollectionColoum
    {
      
            public class ColUserName
            {
                public const string Value = "UserName";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }

            public class ColUserId
            {
                public const string Value = "UserId";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }


            public class ColUserUid
            {
                public const string Value = "UserUid";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }


            public class ColPortalCode
            {
                public const string Value = "PortalCode";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }
            public class ColPortalName
            {
                public const string Value = "PortalName";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }


            public class ColSessionId
            {
                public const string Value = "SessionId";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }



            public class ColTabSessionId
            {
                public const string Value = "TabSessionId";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }

            public class ColLoginTime
            {
                public const string Value = "LoginTime";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }


            public class ColLogoutTime
            {
                public const string Value = "LogoutTime";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }

            public class ColCreationTime
            {
                public const string Value = "CreationTime";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }

            public class ColBPOCode
            {
                public const string Value = "BPOCode";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }

            public class ColBPOName
            {
                public const string Value = "BPOName";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }

            public class ColLoginType
            {
                public const string Value = "LoginType";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }


            public class ColLogoutType
            {
                public const string Value = "LogoutType";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }


            public class ColCallGUID
            {
                public const string Value = "CallGUID";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }



            public class ColUserType
            {
                public const string Value = "UserType";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }

            public class ColSearchInput
            {
                public const string Value = "SearchInput";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }

            public class ColSearchResponse
            {
                public const string Value = "SearchResponse";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }
            public class ColSearchFilter
            {
                public const string Value = "SearchFilter";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }
            public class ColCreationDate
            {
                public const string Value = "CreationDate";
                public const OracleDbType DBType = OracleDbType.Date;
                public const int Size = 50;
            }
            public class ColSearchType
            {
                public const string Value = "SearchType";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }

            public class ColInteractionId
            {
                public const string Value = "InteractionId";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }

            public class ColCategoryCode
            {
                public const string Value = "CategoryCode";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }


            public class ColCategoryName
            {
                public const string Value = "CategoryName";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }



            public class ColSubCategoryCode
            {
                public const string Value = "SubCategoryCode";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }





            public class ColSubCategoryName
            {
                public const string Value = "SubCategoryName";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }


            public class ColSubSubCategoryCode
            {
                public const string Value = "SubSubCategoryCode";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }
            public class ColSubSubCategoryName
            {
                public const string Value = "SubSubCategoryName";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }




            public class ColArticleCode
            {
                public const string Value = "ArticleCode";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }




            public class ColArticleType
            {
                public const string Value = "ArticleType";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }


            public class ColArticleTitle
            {
                public const string Value = "ArticleTitle";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }



            public class ColToolTip
            {
                public const string Value = "ToolTip";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }
            public class ColSource
            {
                public const string Value = "Source";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }



            public class ColStartDate
            {
                public const string Value = "StartDate";
                public const OracleDbType DBType = OracleDbType.Date;
                public const int Size = 50;
            }


            public class ColEndDate
            {
                public const string Value = "EndDate";
                public const OracleDbType DBType = OracleDbType.Date;
                public const int Size = 50;
            }


            public class ColLanguageCode
            {
                public const string Value = "LanguageCode";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }


            public class ColLanguageName
            {
                public const string Value = "LanguageName";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }



            public class ColAccessoryCode
            {
                public const string Value = "AccessoryCode";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }


            public class ColInteractionDetail
            {
                public const string Value = "InteractionDetail";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }


            public class ColTransactionDate
            {
                public const string Value = "TransactionDate";
                public const OracleDbType DBType = OracleDbType.Date;
                public const int Size = 50;
            }



            public class ColMacroName
            {
                public const string Value = "MacroName";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }

            public class ColMacroType
            {
                public const string Value = "MacroType";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }



            public class ColSourceCode
            {
                public const string Value = "SourceCode";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }


            public class ColOtherDetails
            {
                public const string Value = "OtherDetails";
                public const OracleDbType DBType = OracleDbType.Varchar2;
                public const int Size = 50;
            }


        #region[Authoring]
        public class ColScenarioCode
        {
            public const string Value = "ScenarioCode";
            public const OracleDbType DBType = OracleDbType.Varchar2;
            public const int Size = 50;
        }


        public class ColTitle
        {
            public const string Value = "Title";
            public const OracleDbType DBType = OracleDbType.Varchar2;
            public const int Size = 50;
        }


        public class ColVersion
        {
            public const string Value = "Version";
            public const OracleDbType DBType = OracleDbType.Varchar2;
            public const int Size = 50;
        }

        public class ColLangCode
        {
            public const string Value = "LangCode";
            public const OracleDbType DBType = OracleDbType.Varchar2;
            public const int Size = 50;
        }


        public class ColCreatedBy
        {
            public const string Value = "CreatedBy";
            public const OracleDbType DBType = OracleDbType.Varchar2;
            public const int Size = 50;
        }

        public class ColCreatedOn
        {
            public const string Value = "CreatedOn";
            public const OracleDbType DBType = OracleDbType.Varchar2;
            public const int Size = 50;
        }



        public class ColModifiedOn
        {
            public const string Value = "ModifiedOn";
            public const OracleDbType DBType = OracleDbType.Varchar2;
            public const int Size = 50;
        }


        public class ColModifiedBy
        {
            public const string Value = "ModifiedBy";
            public const OracleDbType DBType = OracleDbType.Varchar2;
            public const int Size = 50;
        }


        public class ColDeletedBy
        {
            public const string Value = "DeletedBy";
            public const OracleDbType DBType = OracleDbType.Varchar2;
            public const int Size = 50;
        }


        public class ColStatus
        {
            public const string Value = "Status";
            public const OracleDbType DBType = OracleDbType.Varchar2;
            public const int Size = 50;
        }



        public class ColFaqBusiCode
        {
            public const string Value = "FaqBusiCode";
            public const OracleDbType DBType = OracleDbType.Varchar2;
            public const int Size = 50;
        }



        public class ColFaqBusiVersion
        {
            public const string Value = "FaqBusiVersion";
            public const OracleDbType DBType = OracleDbType.Varchar2;
            public const int Size = 50;
        }


        public class ColContentType
        {
            public const string Value = "ContentType";
            public const OracleDbType DBType = OracleDbType.Varchar2;
            public const int Size = 50;
        }


        #endregion
    }
}
