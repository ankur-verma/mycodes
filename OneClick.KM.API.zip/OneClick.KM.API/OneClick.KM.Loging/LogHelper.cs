﻿
namespace OneClick.KM.Loging
{    
    public  static class LogHelper
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();     
        
        public static void Info(string message)
        {
            logger.Info(message);
        }
        public static void Warning(string message)
        {
            logger.Warn(message);
        }
        public static void Debug(string message)
        {
            logger.Debug(message);
        }

        public static void Error(string message)
        {
            logger.Error(message);
        }
    }
}
