﻿using MongoDB.Driver;
using OneClick.KM.Core.Security;

namespace OneClick.KM.Loging
{
    public class MDatabase
    {
        public IMongoDatabase OpenMongoConnection()
        {
            var objCEncryption = new Encryption();
            string _path = string.Empty;// objCEncryption.iGenDcrypt(ConfigurationManager.AppSettings["MongoDbCon"].ToString());
            var mongoUrl = new MongoUrl(_path);
            var dbname = mongoUrl.DatabaseName;
            var mongoClient = new MongoClient(_path);
            IMongoDatabase db = mongoClient.GetDatabase(dbname);
            return db;
        }
    }
}
