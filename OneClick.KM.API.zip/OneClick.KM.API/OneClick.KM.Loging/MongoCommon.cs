﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.Loging
{

   public class MongoCommon
    {
        public async Task<APIResponseMessage> InsertErrorLogs(ErrorLogs errLogs)
        {
            APIResponseMessage resMsg = new APIResponseMessage();
            MDatabase dbcls = new MDatabase();

            try
            {
                IMongoDatabase db = dbcls.OpenMongoConnection();
                var coll = db.GetCollection<BsonDocument>("ERROR_LOGS_AUTH");
                var objErr = new BsonDocument
                {
                  {"ErrorCode", (String.IsNullOrEmpty(errLogs.ErrorCode) ? BsonNull.Value : (BsonValue)errLogs.ErrorCode) },
                  {"Url", (String.IsNullOrEmpty(errLogs.Url) ? BsonNull.Value : (BsonValue)errLogs.Url)},
                  {"UserId", (String.IsNullOrEmpty(errLogs.UserId) ? BsonNull.Value : (BsonValue)errLogs.UserId)},
                  {"UserName", (String.IsNullOrEmpty(errLogs.UserName) ? BsonNull.Value : (BsonValue)errLogs.UserName)},
                  {"Message",(String.IsNullOrEmpty(errLogs.Message) ? BsonNull.Value : (BsonValue)errLogs.Message)},
                  {"InnerException",(String.IsNullOrEmpty(errLogs.InnerException) ? BsonNull.Value : (BsonValue)errLogs.InnerException) },
                  {"StackTrace", (String.IsNullOrEmpty(errLogs.StackTrace) ? BsonNull.Value : (BsonValue)errLogs.StackTrace) },
                  {"Source", (String.IsNullOrEmpty(errLogs.Source) ? BsonNull.Value : (BsonValue)errLogs.Source) },
                  {"ErrorDetails", (String.IsNullOrEmpty(errLogs.ErrorDetails) ? BsonNull.Value : (BsonValue)errLogs.ErrorDetails)},
                  {"ErrorDate", (BsonValue)errLogs.ErrorDate},
                  {"SourceIP", (String.IsNullOrEmpty(errLogs.SourceIP) ? BsonNull.Value : (BsonValue)errLogs.SourceIP) }
                };
                await coll.InsertOneAsync(objErr);
                resMsg.ErrorCode = "0";
                resMsg.Remarks = "Ok";

            }
            catch (Exception ex)
            {
                //resMsg.ErrorCode = "MD-1";ErrorDate
                resMsg.ErrorCode = "API_MD_ERR" + Convert.ToString(ex.HResult);
                resMsg.Remarks = ex.Message;
                //resMsg.ErrorCode = "1";
                //resMsg.Remarks = e.InnerException.ToString();
            }
            return resMsg;
        }
    }
   

    public class MongoDBLogs
    {
        public string PortalCode { get; set; }
        public string PortalName { get; set; }
        public string ArticleCode { get; set; }
        public string ScenarioCode { get; set; }
        public string Version { get; set; }
        public string FaqBusiCode { get; set; }
        public string Title { get; set; }
        public string FaqBusiVersion { get; set; }
        public string CREATEDBY { get; set; }
        public string ContentType { get; set; }
        public string LangCode { get; set; }
        public string CreatedBy { get; set; }




        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public Nullable<System.DateTime> CreatedOn { get; set; }


        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public Nullable<System.DateTime> ModifiedOn { get; set; }


        public string ModifiedBy { get; set; }
        public string DeletedBy { get; set; }
        public string UserId { get; set; }
        public string Status { get; set; }

        public string ArticleType { get; set; }

    }

    public class UserLoginLogs : APIResponseMessage            //used to insert logs in MongoDb for application
        {
            [BsonId]
            [BsonRepresentation(BsonType.ObjectId)]
            public string UserName { get; set; }
            public string UserId { get; set; }
            public string PortalCode { get; set; }
            public string PortalName { get; set; }
            public string SessionId { get; set; }
            public string TabSessionId { get; set; }

            [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
            public Nullable<System.DateTime> LoginTime { get; set; }

            [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
            public Nullable<System.DateTime> LogoutTime { get; set; }

            [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
            public Nullable<System.DateTime> CreationTime { get; set; }

            public string BpoCode { get; set; }
            public string BpoName { get; set; }
            public string LoginType { get; set; }

            public string LogoutType { get; set; }
            public string UserType { get; set; }

            public string CallGUID { get; set; }




        }


        [Serializable]
        [JsonObject]
        public class SearchDetail : APIResponseMessage
        {
            [BsonId]
            [BsonRepresentation(BsonType.ObjectId)]
            public string UserID { get; set; }
            public string UserName { get; set; }
            public string SessionId { get; set; }
            public string TabSessionId { get; set; }
            public string PortalCode { get; set; }
            public string PortalName { get; set; }
            public string BpoCode { get; set; }
            public string BpoName { get; set; }
            public string SearchInput { get; set; }
            public List<JsonArticleList> SearchResponse { get; set; }
            public List<JsonSearchTopic> searchFilter { get; set; }
            public string CallGUID { get; set; }
            public string LoginType { get; set; }
            public List<SearchCategory> SearchType { get; set; }


            [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
            public Nullable<System.DateTime> CreationDate { get; set; }

        }
        public class JsonSearchResponse
        {
            public List<JsonArticleList> JsonArticles { get; set; }
            public string NumberOfHigh { get; set; }
            public string NumberOfLow { get; set; }
        }
        public class JsonArticleList
        {
            public string ArticleId { get; set; }
            public string ArticleTitle { get; set; }
            public string BusinessCode { get; set; }
            public string ShortDescription { get; set; }
            public string Weightage { get; set; }
            public string HitCount { get; set; }
            public string ArticleTooltip { get; set; }
        }
        public class JsonSearchTopic
        {
            public string ArtTopicCode { get; set; }
            public string ArtTopicDesc { get; set; }
        }

        [Serializable]
        [JsonObject]
        public class MacroLogs
        {
            public string MacroCode { get; set; }

            public string MacroName { get; set; }

            public string MacroType { get; set; }

            public string PortalName { get; set; }

            public string PortalCode { get; set; }

            public string UserName { get; set; }

            public string UserUid { get; set; }

            public string SessionId { get; set; }

            public string TabSessionId { get; set; }

            public string Source { get; set; }

            public string SourceCode { get; set; }

            public string OtherDetails { get; set; }

            public string ArticleCode { get; set; }

            public string ArticleTitle { get; set; }
        }



        [Serializable]
        [JsonObject]
        public class UserInteractions
        {
            [BsonId]
            [BsonRepresentation(BsonType.ObjectId)]
            public string id;

            public string InteractionId { get; set; }
            public string CategoryCode { get; set; }

            public string CategoryName { get; set; }

            public string SubCategoryCode { get; set; }

            public string SubCategoryName { get; set; }

            public string SubSubCategoryCode { get; set; }

            public string SubSubCategoryName { get; set; }

            public string AccessoryCode { get; set; }
            public string ArticleCode { get; set; }

            public string ArticleType { get; set; }

            public string ArticleTitle { get; set; }

            public string ToolTip { get; set; }

            public string Source { get; set; }


            public string SearchInput { get; set; }

            public List<JsonArticleList> SearchResponse { get; set; }

            [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
            public Nullable<System.DateTime> StartDate { get; set; }

            public string UserId { get; set; }

            public string UserName { get; set; }

            public string SessionId { get; set; }

            public string TabSessionId { get; set; }

            public string PortalCode { get; set; }

            public string PortalName { get; set; }

            public string LanguageCode { get; set; }

            public string LanguageName { get; set; }

            public string CallGUID { get; set; }

            public string LoginType { get; set; }

            public string BpoCode { get; set; }

            public string BpoName { get; set; }

            public List<GHStepInteractions> InteractionDetail { get; set; }


            [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
            public Nullable<System.DateTime> TransactionDate { get; set; }

            public string LogStatus { get; set; }
            [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
            public Nullable<System.DateTime> EndDate { get; set; }

        }

      

        [Serializable]
        [JsonObject]
        public class MicroUtility
        {
            [BsonId]
            [BsonRepresentation(BsonType.ObjectId)]
            public string id;

            public string UserId { get; set; }

            public string UserName { get; set; }

            public string SessionId { get; set; }

            public string TabSessionId { get; set; }

            public string PortalCode { get; set; }

            public string PortalName { get; set; }

            public string BpoCode { get; set; }

            public string BpoName { get; set; }

            public string PageName { get; set; }

            public string Source { get; set; }

            [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
            public Nullable<System.DateTime> TransactionDate { get; set; }

        }


        public class ErrorLogs
        {
            public string ErrorCode { get; set; }

            public string Url { get; set; }

            public string UserId { get; set; }

            public string UserName { get; set; }

            public Nullable<System.DateTime> ErrorDate { get; set; }

            public string Message { get; set; }

            public string InnerException { get; set; }

            public string StackTrace { get; set; }

            public string Source { get; set; }

            public string ErrorDetails { get; set; }

            public string SourceIP { get; set; }
        }


    [Serializable]
  
    public class APIResponseMessage
    {
        public string ErrorCode { get; set; }
        public string Remarks { get; set; }


    }



    public class MongoDbLogs
    {
        public string PortalCode { get; set; }
        public string PortalName { get; set; }
        public string ArticleCode { get; set; }
        public string ScenarioCode { get; set; }
        public string Version { get; set; }
        public string FaqBusiCode { get; set; }
        public string Title { get; set; }
        public string FaqBusiVersion { get; set; }
        public string CREATEDBY { get; set; }
        public string ContentType { get; set; }
        public string LangCode { get; set; }
        public string CreatedBy { get; set; }




        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public Nullable<System.DateTime> CreatedOn { get; set; }


        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public Nullable<System.DateTime> ModifiedOn { get; set; }


        public string ModifiedBy { get; set; }
        public string DeletedBy { get; set; }
        public string UserId { get; set; }
        public string Status { get; set; }

        public string ArticleType { get; set; }


    }

    [Serializable]
    [JsonObject]
    public class SearchCategory
    {
        /// <summary>
        /// Get or set Category Id 
        /// </summary>

        public string CategoryId { get; set; }

        /// <summary>
        ///  Get or set Category name
        /// </summary>
        public string CategoryName { get; set; }


        public bool IsSelected { get; set; }

    }

    
    [Serializable]
    [JsonObject]
    public class GHStepInteractions
    {
        public string ScenarioCode { get; set; }
        public string QuestionCode { get; set; }
        public string InteractionId { get; set; }
        public string NextQuestionCode { get; set; }
        public string QuestionDescription { get; set; }
        public string QuestionType { get; set; }
        public string Status { get; set; }
        public string OptedAnsCode { get; set; }
        public string TabSessionId { get; set; }
        public string ActivityName { get; set; }
        public string SelectedOptionDesc { get; set; }
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public Nullable<System.DateTime> TransactionDate { get; set; }
        public string Source { get; set; }
    }
}
