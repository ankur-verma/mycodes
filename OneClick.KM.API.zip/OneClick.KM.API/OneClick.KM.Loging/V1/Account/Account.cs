﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
namespace OneClick.KM.Loging.V1.Account
{
    public class Account:MDatabase
    {
        public async Task<UserLoginLogs> LoginDetailsData(UserLoginLogs mlogin)
        {

            UserLoginLogs resMsg = new UserLoginLogs();
            try
            {
                IMongoDatabase db = OpenMongoConnection();
                var coll = db.GetCollection<BsonDocument>("USER_LOGINDETAILS");
                var user_intbson = new BsonDocument
                {
                  {"ColUserName", (String.IsNullOrEmpty(mlogin.UserName) ? BsonNull.Value : (BsonValue)mlogin.UserName) },
                  {"ColUserId", (String.IsNullOrEmpty(mlogin.UserId) ? BsonNull.Value : (BsonValue)mlogin.UserId)},
                  {"ColPortalCode", (String.IsNullOrEmpty(mlogin.PortalCode) ? BsonNull.Value : (BsonValue)mlogin.PortalCode)},
                  {"ColPortalName", (String.IsNullOrEmpty(mlogin.PortalName) ? BsonNull.Value : (BsonValue)mlogin.PortalName)},
                  {"ColSessionId",(String.IsNullOrEmpty(mlogin.SessionId) ? BsonNull.Value : (BsonValue)mlogin.SessionId)},
                  {"ColTabSessionId",(String.IsNullOrEmpty(mlogin.TabSessionId) ? BsonNull.Value : (BsonValue)mlogin.TabSessionId)},
                  {"ColLoginTime", mlogin.LoginTime},
                  {"ColLogoutTime", mlogin.LogoutTime},
                  {"ColCreationTime", (BsonValue)DateTime.Now},
                  {"ColBPOCode",(String.IsNullOrEmpty(mlogin.BpoCode) ? BsonNull.Value : (BsonValue)mlogin.BpoCode)},
                  {"ColBPOName",(String.IsNullOrEmpty(mlogin.BpoName) ? BsonNull.Value : (BsonValue)mlogin.BpoName)},
                  {"ColLoginType", (String.IsNullOrEmpty(mlogin.LoginType) ? BsonNull.Value : (BsonValue)mlogin.LoginType)},
                  {"ColLogoutType", (String.IsNullOrEmpty(mlogin.LogoutType) ? BsonNull.Value : (BsonValue)mlogin.LogoutType)},
                  {"ColCallGUID", (String.IsNullOrEmpty(mlogin.CallGUID) ? BsonNull.Value : (BsonValue)mlogin.CallGUID)},
                  {"ColUserType", (String.IsNullOrEmpty(mlogin.UserType) ? BsonNull.Value : (BsonValue)mlogin.UserType)},

                };
                await coll.InsertOneAsync(user_intbson);
                resMsg.ErrorCode = "0";
                resMsg.Remarks = "Ok";

            }
            catch (Exception ex)
            {
                resMsg.ErrorCode = "API_MD_ERR" + Convert.ToString(ex.HResult);

                resMsg.Remarks = ex.Message;
            }
            return resMsg;
        }

        //MacroLog for Application
        public async Task<APIResponseMessage> InsertMacroLogs(MacroLogs macLogs)
        {
            APIResponseMessage resMsg = new APIResponseMessage();
            try
            {
                IMongoDatabase db = OpenMongoConnection();
                var coll = db.GetCollection<BsonDocument>("MACRO_LOGS");
                var objMac = new BsonDocument
                {
                  {"ColMacroCode", (String.IsNullOrEmpty(macLogs.MacroCode) ? BsonNull.Value : (BsonValue)macLogs.MacroCode) },
                  {"ColMacroName", (String.IsNullOrEmpty(macLogs.MacroName) ? BsonNull.Value : (BsonValue)macLogs.MacroName)},
                  {"ColMacroType", (String.IsNullOrEmpty(macLogs.MacroType) ? BsonNull.Value : (BsonValue)macLogs.MacroType)},
                  {"ColPortalName", (String.IsNullOrEmpty(macLogs.PortalName) ? BsonNull.Value : (BsonValue)macLogs.PortalName)},
                  {"ColPortalCode", (String.IsNullOrEmpty(macLogs.PortalCode) ? BsonNull.Value : (BsonValue)macLogs.PortalCode)},
                  {"UserName",(String.IsNullOrEmpty(macLogs.UserName) ? BsonNull.Value : (BsonValue)macLogs.UserName)},
                  {"ColUserUid",(String.IsNullOrEmpty(macLogs.UserUid) ? BsonNull.Value : (BsonValue)macLogs.UserUid) },
                  {"ColSessionId", (String.IsNullOrEmpty(macLogs.SessionId) ? BsonNull.Value : (BsonValue)macLogs.SessionId) },
                  {"ColTabSessionId", (String.IsNullOrEmpty(macLogs.TabSessionId) ? BsonNull.Value : (BsonValue)macLogs.TabSessionId) },
                  {"ColSource", (String.IsNullOrEmpty(macLogs.Source) ? BsonNull.Value : (BsonValue)macLogs.Source)},
                  {"ColSourceCode", (String.IsNullOrEmpty(macLogs.SourceCode) ? BsonNull.Value : (BsonValue)macLogs.SourceCode)},
                  {"ColOtherDetails", (String.IsNullOrEmpty(macLogs.OtherDetails) ? BsonNull.Value : (BsonValue)macLogs.OtherDetails)},
                  {"ColArticleCode", (String.IsNullOrEmpty(macLogs.ArticleCode) ? BsonNull.Value : (BsonValue)macLogs.ArticleCode)},
                  {"ColArticleTitle", (String.IsNullOrEmpty(macLogs.ArticleTitle) ? BsonNull.Value : (BsonValue)macLogs.ArticleTitle)},
                  {"colTransactionDate", (BsonValue)DateTime.Now},
                };
                await coll.InsertOneAsync(objMac);
                resMsg.ErrorCode = "0";
                resMsg.Remarks = "Ok";

            }
            catch (Exception ex)
            {

                resMsg.ErrorCode = "API_MD_ERR" + Convert.ToString(ex.HResult);
                resMsg.Remarks = ex.Message;

            }
            return resMsg;
        }


        //Insert User related logs in MongoDb
        public async Task<APIResponseMessage> InsertUserInteraction(UserInteractions usr_int)
        {
            APIResponseMessage resMsg = new APIResponseMessage();
            try
            {
                IMongoDatabase db = OpenMongoConnection();
                var coll = db.GetCollection<BsonDocument>("USER_INTERACTIONS1");
                string jsonInterdtl = "";
                List<BsonDocument> InteractionDtlLst = new List<BsonDocument>();
                if (usr_int.InteractionDetail != null && usr_int.InteractionDetail.Count > 0)
                {
                    jsonInterdtl = JsonConvert.SerializeObject(usr_int.InteractionDetail);
                    InteractionDtlLst = BsonSerializer.Deserialize<BsonArray>(jsonInterdtl).Select(p => p.AsBsonDocument).ToList<BsonDocument>();
                }
                string jsonSearchRes = "";
                List<BsonDocument> SearchResLst = new List<BsonDocument>();
                if (usr_int.SearchResponse != null && usr_int.SearchResponse.Count > 0)
                {
                    jsonSearchRes = JsonConvert.SerializeObject(usr_int.SearchResponse);
                    SearchResLst = BsonSerializer.Deserialize<BsonArray>(jsonSearchRes).Select(p => p.AsBsonDocument).ToList<BsonDocument>();
                }
                var user_intbson = new BsonDocument
                {
                  {"ColInteractionId",(BsonValue)System.Guid.NewGuid().ToString()},
                  {"ColCategoryCode", (String.IsNullOrEmpty(usr_int.CategoryCode) ? BsonNull.Value : (BsonValue)usr_int.CategoryCode) },
                  {"ColCategoryName", (String.IsNullOrEmpty(usr_int.CategoryName) ? BsonNull.Value : (BsonValue)usr_int.CategoryName)},
                  {"ColSubCategoryCode", (String.IsNullOrEmpty(usr_int.SubCategoryCode) ? BsonNull.Value : (BsonValue)usr_int.SubCategoryCode)},
                  {"ColSubCategoryName", (String.IsNullOrEmpty(usr_int.SubCategoryName) ? BsonNull.Value : (BsonValue)usr_int.SubCategoryName)},
                  {"ColSubSubCategoryCode",(String.IsNullOrEmpty(usr_int.SubSubCategoryCode) ? BsonNull.Value : (BsonValue)usr_int.SubSubCategoryCode)},
                  {"ColSubSubCategoryName",(String.IsNullOrEmpty(usr_int.SubSubCategoryName) ? BsonNull.Value : (BsonValue)usr_int.SubSubCategoryName) },
                  {"ColArticleCode", (String.IsNullOrEmpty(usr_int.ArticleCode) ? BsonNull.Value : (BsonValue)usr_int.ArticleCode) },
                  {"ColArticleType", (String.IsNullOrEmpty(usr_int.ArticleType) ? BsonNull.Value : (BsonValue)usr_int.ArticleType) },
                  {"ColArticleTitle", (String.IsNullOrEmpty(usr_int.ArticleTitle) ? BsonNull.Value : (BsonValue)usr_int.ArticleTitle)},
                  {"ColToolTip", (String.IsNullOrEmpty(usr_int.ToolTip) ? BsonNull.Value : (BsonValue)usr_int.ToolTip)},
                  {"ColSource",(String.IsNullOrEmpty(usr_int.Source) ? BsonNull.Value : (BsonValue)usr_int.Source)},
                  {"ColSearchInput",(String.IsNullOrEmpty(usr_int.SearchInput) ? BsonNull.Value : (BsonValue)usr_int.SearchInput)},
                  {"ColSearchResponse",(String.IsNullOrEmpty(Convert.ToString(jsonSearchRes)) ? BsonNull.Value : (BsonValue) new BsonArray(SearchResLst))},
                  {"ColStartDate", usr_int.StartDate},
                  {"ColEndDate", ((BsonValue) DateTime.Now)},
                  {"ColUserId", (String.IsNullOrEmpty(usr_int.UserId) ? BsonNull.Value : (BsonValue)usr_int.UserId)},
                  {"ColUserName", (String.IsNullOrEmpty(usr_int.UserName) ? BsonNull.Value : (BsonValue)usr_int.UserName)},
                  {"colSessionId", (String.IsNullOrEmpty(usr_int.SessionId) ? BsonNull.Value : (BsonValue)usr_int.SessionId) },
                  {"ColTabSessionId", (String.IsNullOrEmpty(usr_int.TabSessionId) ? BsonNull.Value : (BsonValue)usr_int.TabSessionId) },
                  {"colPortalCode",(String.IsNullOrEmpty(usr_int.PortalCode) ? BsonNull.Value : (BsonValue)usr_int.PortalCode) },
                  {"ColPortalName",(String.IsNullOrEmpty(usr_int.PortalName) ? BsonNull.Value : (BsonValue)usr_int.PortalName) },
                  {"ColLanguageCode",(String.IsNullOrEmpty(usr_int.LanguageCode) ? BsonNull.Value : (BsonValue)usr_int.LanguageCode) },
                  {"ColLanguageName",(String.IsNullOrEmpty(usr_int.LanguageName) ? BsonNull.Value : (BsonValue)usr_int.LanguageName) },
                  {"ColCallGUID",(String.IsNullOrEmpty(usr_int.CallGUID) ? BsonNull.Value : (BsonValue)usr_int.CallGUID) },
                  {"ColLoginType",(String.IsNullOrEmpty(usr_int.LoginType) ? BsonNull.Value : (BsonValue)usr_int.LoginType) },
                  {"ColBPOCode",(String.IsNullOrEmpty(usr_int.BpoCode) ? BsonNull.Value : (BsonValue)usr_int.BpoCode) },
                  {"ColBPOName",(String.IsNullOrEmpty(usr_int.BpoName) ? BsonNull.Value : (BsonValue)usr_int.BpoName) },
                  {"ColAccessoryCode",(String.IsNullOrEmpty(usr_int.AccessoryCode) ? BsonNull.Value : (BsonValue)usr_int.AccessoryCode) },
                  { "ColInteractionDetail",(String.IsNullOrEmpty(Convert.ToString(jsonInterdtl)) ? BsonNull.Value : (BsonValue) new BsonArray(InteractionDtlLst))},

                  {"ColTransactionDate",((BsonValue) DateTime.Now) }
                };
                await coll.InsertOneAsync(user_intbson);
                resMsg.ErrorCode = "0";
                resMsg.Remarks = "Ok";

            }
            catch (Exception ex)
            {

                resMsg.ErrorCode = "API_MD_ERR" + Convert.ToString(ex.HResult);
                resMsg.Remarks = ex.Message;

            }
            return resMsg;
        }

        //GetUser Interaction from MongoDb
        public async Task<List<UserInteractions>> GetUserInteractions(UserInteractions usr_int)
        {
            List<UserInteractions> lstuser = new List<UserInteractions>();
            UserInteractions objuser1 = new UserInteractions();
            var builder = Builders<BsonDocument>.Filter;
            var filter = builder.Eq("UserId", usr_int.UserId) & builder.Eq("PortalCode", usr_int.PortalCode) & builder.Ne("ArticleCode", BsonNull.Value) & builder.Ne("ArticleType", BsonNull.Value) & builder.Ne("ArticleTitle", "NA");
            IMongoDatabase db = OpenMongoConnection();
            var coll = db.GetCollection<BsonDocument>("USER_INTERACTIONS1");
            //var list = await coll.Find(filter).ToListAsync();
            var list = await coll.Find(filter).Limit(30).SortByDescending(bson => bson["StartDate"]).ToListAsync();

            foreach (var item in list)
            {
                UserInteractions objuser = new UserInteractions();
                if (item.Contains("ColInteractionId"))
                    objuser.InteractionId = (item.GetValue("ColInteractionId") != BsonNull.Value ? item.GetValue("ColInteractionId").ToString() : null);
                if (item.Contains("ColAccessoryCode"))
                    objuser.AccessoryCode = (item.GetValue("ColAccessoryCode") != BsonNull.Value ? item.GetValue("ColAccessoryCode").ToString() : null);
                if (item.Contains("ColCategoryCode"))
                    objuser.CategoryCode = (item.GetValue("ColCategoryCode") != BsonNull.Value ? item.GetValue("ColCategoryCode").ToString() : null);
                if (item.Contains("ColCategoryName"))
                    objuser.CategoryName = (item.GetValue("ColCategoryName") != BsonNull.Value ? item.GetValue("ColCategoryName").ToString() : null);
                if (item.Contains("ColSubCategoryCode"))
                    objuser.SubCategoryCode = (item.GetValue("ColSubCategoryCode") != BsonNull.Value ? item.GetValue("ColSubCategoryCode").ToString() : null);
                if (item.Contains("ColSubCategoryName"))
                    objuser.SubCategoryName = (item.GetValue("ColSubCategoryName") != BsonNull.Value ? item.GetValue("ColSubCategoryName").ToString() : null);
                if (item.Contains("ColSubCategoryName"))
                    objuser.SubSubCategoryCode = (item.GetValue("ColSubSubCategoryCode") != BsonNull.Value ? item.GetValue("ColSubSubCategoryCode").ToString() : null);
                if (item.Contains("ColSubSubCategoryCode"))
                    objuser.SubSubCategoryName = (item.GetValue("ColSubSubCategoryName") != BsonNull.Value ? item.GetValue("ColSubSubCategoryName").ToString() : null);
                if (item.Contains("ColArticleCode"))
                    objuser.ArticleCode = (item.GetValue("ColArticleCode") != BsonNull.Value ? item.GetValue("ColArticleCode").ToString() : null);
                if (item.Contains("ColArticleType"))
                    objuser.ArticleType = (item.GetValue("ColArticleType") != BsonNull.Value ? item.GetValue("ColArticleType").ToString() : null);
                if (item.Contains("ColArticleTitle"))
                    objuser.ArticleTitle = (item.GetValue("ColArticleTitle") != BsonNull.Value ? item.GetValue("ColArticleTitle").ToString() : null);
                if (item.Contains("ColToolTip"))
                    objuser.ToolTip = (item.GetValue("ColToolTip") != BsonNull.Value ? item.GetValue("ColToolTip").ToString() : null);
                if (item.Contains("ColSource"))
                    objuser.Source = (item.GetValue("ColSource") != BsonNull.Value ? item.GetValue("ColSource").ToString() : null);
                if (item.Contains("ColSearchInput"))
                    objuser.SearchInput = (item.GetValue("ColSearchInput") != BsonNull.Value ? item.GetValue("ColSearchInput").ToString() : null);
                if (item.Contains("ColSearchResponse"))
                    objuser.SearchResponse = (item.GetValue("ColSearchResponse") != BsonNull.Value ? JsonConvert.DeserializeObject<List<JsonArticleList>>(item.GetValue("ColSearchResponse").ToJson()) : null);
                if (item.Contains("ColStartDate"))
                    objuser.StartDate = (item.GetValue("ColStartDate") != BsonNull.Value) ? Convert.ToDateTime(item.GetValue("ColStartDate")).ToLocalTime() : (DateTime?)null;
                if (item.Contains("ColUserId"))
                    objuser.UserId = (item.GetValue("ColUserId") != BsonNull.Value ? item.GetValue("ColUserId").ToString() : null);
                if (item.Contains("ColSessionId"))
                    objuser.SessionId = (item.GetValue("ColSessionId") != BsonNull.Value ? item.GetValue("ColSessionId").ToString() : null);
                if (item.Contains("ColPortalCode"))
                    objuser.PortalCode = (item.GetValue("ColPortalCode") != BsonNull.Value ? item.GetValue("ColPortalCode").ToString() : null);
                if (item.Contains("ColInteractionDetail"))
                    objuser.InteractionDetail = (item.GetValue("ColInteractionDetail") != BsonNull.Value ? JsonConvert.DeserializeObject<List<GHStepInteractions>>(item.GetValue("ColInteractionDetail").ToJson()) : null);
                lstuser.Add(objuser);
            }

            return lstuser.ToList();
        }



        // Get user related data   from mongo db  using id
        public async Task<UserInteractions> GetInteractionsById(UserInteractions usr_int)
        {
            UserInteractions objuser = new UserInteractions();
            var builder = Builders<BsonDocument>.Filter;
            var filter = builder.Eq("UserId", usr_int.UserId) & builder.Eq("PortalCode", usr_int.PortalCode) & builder.Eq("InteractionId", usr_int.InteractionId) & builder.Ne("ArticleCode", BsonNull.Value) & builder.Ne("ArticleType", BsonNull.Value) & builder.Ne("ArticleTitle", "NA");
            IMongoDatabase db = OpenMongoConnection();
            var coll = db.GetCollection<BsonDocument>("USER_INTERACTIONS1");
            var list = await coll.Find(filter).ToListAsync();

            foreach (var item in list)
            {

                if (item.Contains("ColInteractionId"))
                    objuser.InteractionId = (item.GetValue("ColInteractionId") != BsonNull.Value ? item.GetValue("ColInteractionId").ToString() : null);
                if (item.Contains("ColCategoryCode"))
                    objuser.CategoryCode = (item.GetValue("ColCategoryCode") != BsonNull.Value ? item.GetValue("ColCategoryCode").ToString() : null);
                if (item.Contains("ColCategoryName"))
                    objuser.CategoryName = (item.GetValue("ColCategoryName") != BsonNull.Value ? item.GetValue("ColCategoryName").ToString() : null);
                if (item.Contains("ColSubCategoryCode"))
                    objuser.SubCategoryCode = (item.GetValue("ColSubCategoryCode") != BsonNull.Value ? item.GetValue("ColSubCategoryCode").ToString() : null);
                if (item.Contains("ColSubCategoryName"))
                    objuser.SubCategoryName = (item.GetValue("ColSubCategoryName") != BsonNull.Value ? item.GetValue("ColSubCategoryName").ToString() : null);
                if (item.Contains("ColSubSubCategoryCode"))
                    objuser.SubSubCategoryCode = (item.GetValue("ColSubSubCategoryCode") != BsonNull.Value ? item.GetValue("ColSubSubCategoryCode").ToString() : null);
                if (item.Contains("ColSubSubCategoryName"))
                    objuser.SubSubCategoryName = (item.GetValue("ColSubSubCategoryName") != BsonNull.Value ? item.GetValue("ColSubSubCategoryName").ToString() : null);
                if (item.Contains("ColArticleCode"))
                    objuser.ArticleCode = (item.GetValue("ColArticleCode") != BsonNull.Value ? item.GetValue("ColArticleCode").ToString() : null);
                if (item.Contains("ColArticleType"))
                    objuser.ArticleType = (item.GetValue("ColArticleType") != BsonNull.Value ? item.GetValue("ColArticleType").ToString() : null);
                if (item.Contains("ColArticleTitle"))
                    objuser.ArticleTitle = (item.GetValue("ColArticleTitle") != BsonNull.Value ? item.GetValue("ColArticleTitle").ToString() : null);
                if (item.Contains("ColToolTip"))
                    objuser.ToolTip = (item.GetValue("ColToolTip") != BsonNull.Value ? item.GetValue("ColToolTip").ToString() : null);
                if (item.Contains("ColSource"))
                    objuser.Source = (item.GetValue("ColSource") != BsonNull.Value ? item.GetValue("ColSource").ToString() : null);
                if (item.Contains("ColSearchInput"))
                    objuser.SearchInput = (item.GetValue("ColSearchInput") != BsonNull.Value ? item.GetValue("ColSearchInput").ToString() : null);
                if (item.Contains("ColSearchResponse"))
                    objuser.SearchResponse = (item.GetValue("ColSearchResponse") != BsonNull.Value ? JsonConvert.DeserializeObject<List<JsonArticleList>>(item.GetValue("ColSearchResponse").ToJson()) : null);
                if (item.Contains("c"))
                    objuser.StartDate = (item.GetValue("ColStartDate") != BsonNull.Value) ? Convert.ToDateTime(item.GetValue("ColStartDate")).ToLocalTime() : (DateTime?)null;

                if (item.Contains("ColUserId"))
                    objuser.UserId = (item.GetValue("ColUserId") != BsonNull.Value ? item.GetValue("ColUserId").ToString() : null);
                if (item.Contains("ColSessionId"))
                    objuser.SessionId = (item.GetValue("ColSessionId") != BsonNull.Value ? item.GetValue("ColSessionId").ToString() : null);
                if (item.Contains("ColPortalCode"))
                    objuser.PortalCode = (item.GetValue("ColPortalCode") != BsonNull.Value ? item.GetValue("ColPortalCode").ToString() : null);
                if (item.Contains("ColInteractionDetail"))
                    objuser.InteractionDetail = (item.GetValue("ColInteractionDetail") != BsonNull.Value ? JsonConvert.DeserializeObject<List<GHStepInteractions>>(item.GetValue("ColInteractionDetail").ToJson()) : null);
            }
            return objuser;
        }

        // get GuidedHelp detail by id from  mongo db
        public async Task<List<GHStepInteractions>> GetInteractionDetailById(GHStepInteractions mGHStepInteractions)
        {
            UserInteractions objuser = new UserInteractions();
            var builder = Builders<BsonDocument>.Filter;
            var filter = builder.Eq("InteractionId", mGHStepInteractions.InteractionId) & builder.Ne("ArticleCode", BsonNull.Value) & builder.Ne("ArticleType", BsonNull.Value) & builder.Ne("ArticleTitle", "NA");
            IMongoDatabase db = OpenMongoConnection();
            var coll = db.GetCollection<BsonDocument>("USER_INTERACTIONS1");
            var list = await coll.Find(filter).ToListAsync();
            foreach (var item in list)
            {
                if (item.Contains("InteractionDetail"))
                    objuser.InteractionDetail = (item.GetValue("InteractionDetail") != BsonNull.Value ? JsonConvert.DeserializeObject<List<GHStepInteractions>>(item.GetValue("InteractionDetail").ToJson()) : null);
            }
            return objuser.InteractionDetail;
        }


        //insert macro utility log into mongo Db 
        public async Task<APIResponseMessage> InsertMicroUtilVisit(MicroUtility objMicroUtil)
        {
            APIResponseMessage resMsg = new APIResponseMessage();
            try
            {
                IMongoDatabase db = OpenMongoConnection();
                var coll = db.GetCollection<BsonDocument>("MICRO_UTILITYVISIT");
                var microUtil = new BsonDocument
                {
                  {"ColUserId", (String.IsNullOrEmpty(objMicroUtil.UserId) ? BsonNull.Value : (BsonValue)objMicroUtil.UserId)},
                  {"ColUserName", (String.IsNullOrEmpty(objMicroUtil.UserName) ? BsonNull.Value : (BsonValue)objMicroUtil.UserName)},
                  {"ColSessionId", (String.IsNullOrEmpty(objMicroUtil.SessionId) ? BsonNull.Value : (BsonValue)objMicroUtil.SessionId) },
                  {"ColTabSessionId", (String.IsNullOrEmpty(objMicroUtil.TabSessionId) ? BsonNull.Value : (BsonValue)objMicroUtil.TabSessionId) },
                  {"ColPortalCode",(String.IsNullOrEmpty(objMicroUtil.PortalCode) ? BsonNull.Value : (BsonValue)objMicroUtil.PortalCode) },
                  {"ColPortalName",(String.IsNullOrEmpty(objMicroUtil.PortalName) ? BsonNull.Value : (BsonValue)objMicroUtil.PortalName) },
                  {"ColBPOCode",(String.IsNullOrEmpty(objMicroUtil.BpoCode) ? BsonNull.Value : (BsonValue)objMicroUtil.BpoCode) },
                  {"ColBPOName",(String.IsNullOrEmpty(objMicroUtil.BpoName) ? BsonNull.Value : (BsonValue)objMicroUtil.BpoName) },
                  {"ColPageName", (String.IsNullOrEmpty(objMicroUtil.PageName) ? BsonNull.Value : (BsonValue)objMicroUtil.PageName) },
                  {"ColSource",(String.IsNullOrEmpty(objMicroUtil.Source) ? BsonNull.Value : (BsonValue)objMicroUtil.Source)},
                  {"ColTransactionDate",((BsonValue) DateTime.Now) }
                };
                await coll.InsertOneAsync(microUtil);
                resMsg.ErrorCode = "0";
                resMsg.Remarks = "Ok";

            }
            catch (Exception ex)
            {

                resMsg.ErrorCode = "API_MD_ERR" + Convert.ToString(ex.HResult);
                resMsg.Remarks = ex.Message;
            }
            return resMsg;
        }

        //Update article log into mongo db
        public async Task<APIResponseMessage> UpdateArticleLog(UserInteractions usr_int)
        {
            APIResponseMessage resMsg = new APIResponseMessage();
            try
            {
                IMongoDatabase db = OpenMongoConnection();
                var coll = db.GetCollection<BsonDocument>("UPDATE_ARTICLELOG");
                var objArticle = new BsonDocument
                {
                  {"ColUserId", (String.IsNullOrEmpty(usr_int.UserId) ? BsonNull.Value : (BsonValue)usr_int.UserId)},
                  {"ColUserName", (String.IsNullOrEmpty(usr_int.UserName) ? BsonNull.Value : (BsonValue)usr_int.UserName)},
                  {"ColSessionId", (String.IsNullOrEmpty(usr_int.SessionId) ? BsonNull.Value : (BsonValue)usr_int.SessionId) },
                  {"ColCategoryCode", (String.IsNullOrEmpty(usr_int.CategoryCode) ? BsonNull.Value : (BsonValue)usr_int.CategoryCode) },
                  {"ColCategoryName", (String.IsNullOrEmpty(usr_int.CategoryName) ? BsonNull.Value : (BsonValue)usr_int.CategoryName)},
                  {"ColSubCategoryCode", (String.IsNullOrEmpty(usr_int.SubCategoryCode) ? BsonNull.Value : (BsonValue)usr_int.SubCategoryCode)},
                  {"ColSubCategoryName", (String.IsNullOrEmpty(usr_int.SubCategoryName) ? BsonNull.Value : (BsonValue)usr_int.SubCategoryName)},
                  {"ColSubSubCategoryCode",(String.IsNullOrEmpty(usr_int.SubSubCategoryCode) ? BsonNull.Value : (BsonValue)usr_int.SubSubCategoryCode)},
                  {"ColSubSubCategoryName",(String.IsNullOrEmpty(usr_int.SubSubCategoryName) ? BsonNull.Value : (BsonValue)usr_int.SubSubCategoryName) },
                  {"ColArticleCode", (String.IsNullOrEmpty(usr_int.ArticleCode) ? BsonNull.Value : (BsonValue)usr_int.ArticleCode) },
                  {"ColArticleTitle", (String.IsNullOrEmpty(usr_int.ArticleTitle) ? BsonNull.Value : (BsonValue)usr_int.ArticleTitle)},
                  {"ColTransactionDate",((BsonValue) DateTime.Now) }
                };
                await coll.InsertOneAsync(objArticle);
                resMsg.ErrorCode = "0";
                resMsg.Remarks = "Ok";

            }
            catch (Exception ex)
            {

                resMsg.ErrorCode = "API_MD_ERR" + Convert.ToString(ex.HResult);
                resMsg.Remarks = ex.Message;

            }
            return resMsg;
        }

        //ErrorLogs insert into mongo Db 
        public async Task<APIResponseMessage> InsertErrorLogs(ErrorLogs errLogs)
        {
            APIResponseMessage resMsg = new APIResponseMessage();
            try
            {
                IMongoDatabase db = OpenMongoConnection();
                var coll = db.GetCollection<BsonDocument>("ERROR_LOGS");
                var objErr = new BsonDocument
                {
                  {"ErrorCode", (String.IsNullOrEmpty(errLogs.ErrorCode) ? BsonNull.Value : (BsonValue)errLogs.ErrorCode) },
                  {"Url", (String.IsNullOrEmpty(errLogs.Url) ? BsonNull.Value : (BsonValue)errLogs.Url)},
                  {"UserId", (String.IsNullOrEmpty(errLogs.UserId) ? BsonNull.Value : (BsonValue)errLogs.UserId)},
                  {"UserName", (String.IsNullOrEmpty(errLogs.UserName) ? BsonNull.Value : (BsonValue)errLogs.UserName)},
                  {"Message",(String.IsNullOrEmpty(errLogs.Message) ? BsonNull.Value : (BsonValue)errLogs.Message)},
                  {"InnerException",(String.IsNullOrEmpty(errLogs.InnerException) ? BsonNull.Value : (BsonValue)errLogs.InnerException) },
                  {"StackTrace", (String.IsNullOrEmpty(errLogs.StackTrace) ? BsonNull.Value : (BsonValue)errLogs.StackTrace) },
                  {"Source", (String.IsNullOrEmpty(errLogs.Source) ? BsonNull.Value : (BsonValue)errLogs.Source) },
                  {"ErrorDetails", (String.IsNullOrEmpty(errLogs.ErrorDetails) ? BsonNull.Value : (BsonValue)errLogs.ErrorDetails)},
                  {"ErrorDate", (BsonValue)errLogs.ErrorDate},
                  {"SourceIP", (BsonValue)errLogs.SourceIP},
                };
                await coll.InsertOneAsync(objErr);
                resMsg.ErrorCode = "0";
                resMsg.Remarks = "Ok";

            }
            catch (Exception ex)
            {
                //resMsg.ErrorCode = "MD-1";
                resMsg.ErrorCode = "API_MD_ERR" + Convert.ToString(ex.HResult);
                resMsg.Remarks = ex.Message;
                //resMsg.ErrorCode = "1";
                //resMsg.Remarks = e.InnerException.ToString();
            }
            return resMsg;
        }

    }
}
