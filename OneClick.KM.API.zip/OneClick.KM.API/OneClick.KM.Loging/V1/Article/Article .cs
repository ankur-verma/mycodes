﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.Loging.V1.Article
{
    public class Article : MDatabase
    {
        //  public async Task<MongoDBLogs> PostArticleLogDal(Model.Articles.ArticleContent mongoDBModel)
        public async Task<MongoDBLogs> PostArticleLogDal(MongoDBLogs obj)
        {

            return await Task.Run(async () =>
            {

                MDatabase dbcls = new MDatabase();
                // obj = GetArticleDetailsForMongoDb(mongoDBModel.ArticleCode, mongoDBModel.FaqBusiCode);
                try
                {
                    IMongoDatabase db = dbcls.OpenMongoConnection();
                    var coll = db.GetCollection<BsonDocument>("ARTICLE_MANAGE_LOGS");
                    var user_intbson = new BsonDocument()
                   {
                        {"PortalCode", (String.IsNullOrEmpty(obj.PortalCode) ? BsonNull.Value : (BsonValue)obj.PortalCode)},
                        {"PortalName", (String.IsNullOrEmpty(obj.PortalName) ? BsonNull.Value : (BsonValue)obj.PortalName)},
                        {"ArticleCode",(String.IsNullOrEmpty(obj.ArticleCode) ? BsonNull.Value : (BsonValue)obj.ArticleCode)},
                        {"FaqBusiCode",(String.IsNullOrEmpty(obj.FaqBusiCode) ? BsonNull.Value : (BsonValue)obj.FaqBusiCode)},
                        {"Title",(String.IsNullOrEmpty(obj.Title) ? BsonNull.Value : (BsonValue)obj.Title)},
                        {"FaqBusiVersion",(String.IsNullOrEmpty(obj.FaqBusiVersion) ? BsonNull.Value : (BsonValue)obj.FaqBusiVersion)},
                        { "UserId", (String.IsNullOrEmpty(obj.UserId ) ? BsonNull.Value : (BsonValue)obj.UserId)},
                        {"ContentType", (String.IsNullOrEmpty(obj.ContentType) ? BsonNull.Value : (BsonValue)obj.ContentType)},
                        {"LangCode", (String.IsNullOrEmpty(obj.LangCode) ? BsonNull.Value : (BsonValue)obj.LangCode)},
                        { "CreatedBy", (String.IsNullOrEmpty(obj.CreatedBy) ? BsonNull.Value : (BsonValue)obj.CreatedBy)},
                         {"CreatedOn",  (BsonValue)obj.CreatedOn},
                         {"ModifiedOn",  (BsonValue)obj.ModifiedOn},
                       // {"ModifiedOn", (String.IsNullOrEmpty(obj.ModifiedOn) ? BsonNull.Value : (BsonValue)obj.ModifiedOn)},
                        { "ModifiedBy", (String.IsNullOrEmpty(obj.ModifiedBy) ? BsonNull.Value : (BsonValue)obj.ModifiedBy)},
                        {"DeletedBy", (String.IsNullOrEmpty(obj.DeletedBy) ? BsonNull.Value : (BsonValue)obj.DeletedBy)},
                         {"Status", (String.IsNullOrEmpty(obj.Status) ? BsonNull.Value : (BsonValue)obj.Status)},
                        {"ArticleType", (String.IsNullOrEmpty(obj.ArticleType) ? BsonNull.Value : (BsonValue)obj.ArticleType)}

                    };
                    await coll.InsertOneAsync(user_intbson);
                    //resMsg.ErrorCode = "0";
                    //resMsg.ErrorDetail = "Ok";

                }
                catch (Exception ex)
                {
                    //resMsg.ErrorCode = "1";
                    //resMsg.ErrorDetail = "error";
                }
                return obj;
            });
        }

    }
}
