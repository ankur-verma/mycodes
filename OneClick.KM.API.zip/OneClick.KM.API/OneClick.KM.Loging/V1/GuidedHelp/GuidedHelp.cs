﻿using MongoDB.Bson;
using MongoDB.Driver;

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.Loging.V1.GuidedHelp
{
  public   class MongoGuidedHelp: MDatabase
    {

        //public async Task<MongoDBLogs> PostGuidedHelpLog(Model.Articles.ArticleContent mongoDBModel)
        public async Task<MongoDBLogs> PostGuidedHelpLog(MongoDBLogs obj)
        {
            return await Task.Run(async () =>
            {
                
                MDatabase dbcls = new MDatabase();

               // MongoDBLogs obj = GetGuidedHelpLogsForMongoDb(mongoDBModel.ArticleCode, mongoDBModel.ScenarioCode);

                try
                {
                    IMongoDatabase db = dbcls.OpenMongoConnection();
                    var coll = db.GetCollection<BsonDocument>("GUIDED_HELP_LOGS");
                    var user_intbson = new BsonDocument
                {

                    {"PortalCode", (String.IsNullOrEmpty(obj.PortalCode) ? BsonNull.Value : (BsonValue)obj.PortalCode)},
                    {"PortalName", (String.IsNullOrEmpty(obj.PortalName) ? BsonNull.Value : (BsonValue)obj.PortalName)},
                    {"ArticleCode",(String.IsNullOrEmpty(obj.ArticleCode) ? BsonNull.Value : (BsonValue)obj.ArticleCode)},
                    {"ScenarioCode",(String.IsNullOrEmpty(obj.ScenarioCode) ? BsonNull.Value : (BsonValue)obj.ScenarioCode)},
                    {"Title",(String.IsNullOrEmpty(obj.Title) ? BsonNull.Value : (BsonValue)obj.Title)},
                    {"Version",(String.IsNullOrEmpty(obj.Version) ? BsonNull.Value : (BsonValue)obj.Version)},
                    { "UserId", (String.IsNullOrEmpty(obj.UserId ) ? BsonNull.Value : (BsonValue)obj.UserId)},

                    {"LangCode", (String.IsNullOrEmpty(obj.LangCode) ? BsonNull.Value : (BsonValue)obj.LangCode)},
                    { "CreatedBy", (String.IsNullOrEmpty(obj.CreatedBy) ? BsonNull.Value : (BsonValue)obj.CreatedBy)},
                     {"CreatedOn",  (BsonValue)obj.CreatedOn},
                     {"ModifiedOn",  (BsonValue)obj.ModifiedOn},
                    { "ModifiedBy", (String.IsNullOrEmpty(obj.ModifiedBy) ? BsonNull.Value : (BsonValue)obj.ModifiedBy)},
                    {"DeletedBy", (String.IsNullOrEmpty(obj.DeletedBy) ? BsonNull.Value : (BsonValue)obj.DeletedBy)},
                     {"Status", (String.IsNullOrEmpty(obj.Status) ? BsonNull.Value : (BsonValue)obj.Status)},
                   // {"ArticleType", (String.IsNullOrEmpty(obj.ArticleType) ? BsonNull.Value : (BsonValue)obj.ArticleType)}

                };
                    await coll.InsertOneAsync(user_intbson);
                    //resMsg.ErrorCode = "0";
                    //resMsg.ErrorDetail = "Ok";

                }
                catch (Exception ex)
                {
                    //resMsg.ErrorCode = "1";
                    //resMsg.ErrorDetail = "error";
                }
                return obj;
            });
        }


        public async Task<APIResponseMessage> InsertErrorLogs(ErrorLogs errLogs)
        {
            APIResponseMessage resMsg = new APIResponseMessage();
            MDatabase dbcls = new MDatabase();

            try
            {
                IMongoDatabase db = dbcls.OpenMongoConnection();
                var coll = db.GetCollection<BsonDocument>("ERROR_LOGS_AUTH");
                var objErr = new BsonDocument
                {
                  {"ErrorCode", (String.IsNullOrEmpty(errLogs.ErrorCode) ? BsonNull.Value : (BsonValue)errLogs.ErrorCode) },
                  {"Url", (String.IsNullOrEmpty(errLogs.Url) ? BsonNull.Value : (BsonValue)errLogs.Url)},
                  {"UserId", (String.IsNullOrEmpty(errLogs.UserId) ? BsonNull.Value : (BsonValue)errLogs.UserId)},
                  {"UserName", (String.IsNullOrEmpty(errLogs.UserName) ? BsonNull.Value : (BsonValue)errLogs.UserName)},
                  {"Message",(String.IsNullOrEmpty(errLogs.Message) ? BsonNull.Value : (BsonValue)errLogs.Message)},
                  {"InnerException",(String.IsNullOrEmpty(errLogs.InnerException) ? BsonNull.Value : (BsonValue)errLogs.InnerException) },
                  {"StackTrace", (String.IsNullOrEmpty(errLogs.StackTrace) ? BsonNull.Value : (BsonValue)errLogs.StackTrace) },
                  {"Source", (String.IsNullOrEmpty(errLogs.Source) ? BsonNull.Value : (BsonValue)errLogs.Source) },
                  {"ErrorDetails", (String.IsNullOrEmpty(errLogs.ErrorDetails) ? BsonNull.Value : (BsonValue)errLogs.ErrorDetails)},
                  {"ErrorDate", (BsonValue)errLogs.ErrorDate},
                  {"SourceIP", (String.IsNullOrEmpty(errLogs.SourceIP) ? BsonNull.Value : (BsonValue)errLogs.SourceIP) }
                };
                await coll.InsertOneAsync(objErr);
                resMsg.ErrorCode = "0";
                resMsg.Remarks = "Ok";

            }
            catch (Exception ex)
            {
                //resMsg.ErrorCode = "MD-1";ErrorDate
                resMsg.ErrorCode = "API_MD_ERR" + Convert.ToString(ex.HResult);
                resMsg.Remarks = ex.Message;
                //resMsg.ErrorCode = "1";
                //resMsg.Remarks = e.InnerException.ToString();
            }
            return resMsg;
        }


       
    }
}
