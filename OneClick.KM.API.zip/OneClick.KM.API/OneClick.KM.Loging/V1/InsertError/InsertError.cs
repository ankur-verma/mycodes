﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Threading.Tasks;

namespace OneClick.KM.Loging.V1.InsertError
{
    public   class InsertError:MDatabase
    {

        public async Task<APIResponseMessage> InsertErrorLogs(ErrorLogs errLogs)
        {
            APIResponseMessage resMsg = new APIResponseMessage();
            MDatabase dbcls = new MDatabase();

            try
            {
                IMongoDatabase db = dbcls.OpenMongoConnection();
                var coll = db.GetCollection<BsonDocument>("ERROR_LOGS_AUTH");
                var objErr = new BsonDocument
                {
                  {"ColErrorCode", (String.IsNullOrEmpty(errLogs.ErrorCode) ? BsonNull.Value : (BsonValue)errLogs.ErrorCode) },
                  {"ColUrl", (String.IsNullOrEmpty(errLogs.Url) ? BsonNull.Value : (BsonValue)errLogs.Url)},
                  {"ColUserId", (String.IsNullOrEmpty(errLogs.UserId) ? BsonNull.Value : (BsonValue)errLogs.UserId)},
                  {"ColUserName", (String.IsNullOrEmpty(errLogs.UserName) ? BsonNull.Value : (BsonValue)errLogs.UserName)},
                  {"ColMessage",(String.IsNullOrEmpty(errLogs.Message) ? BsonNull.Value : (BsonValue)errLogs.Message)},
                  {"ColInnerException",(String.IsNullOrEmpty(errLogs.InnerException) ? BsonNull.Value : (BsonValue)errLogs.InnerException) },
                  {"ColStackTrace", (String.IsNullOrEmpty(errLogs.StackTrace) ? BsonNull.Value : (BsonValue)errLogs.StackTrace) },
                  {"ColSource", (String.IsNullOrEmpty(errLogs.Source) ? BsonNull.Value : (BsonValue)errLogs.Source) },
                  {"ColErrorDetails", (String.IsNullOrEmpty(errLogs.ErrorDetails) ? BsonNull.Value : (BsonValue)errLogs.ErrorDetails)},
                  {"ColErrorDate", (BsonValue)errLogs.ErrorDate},
                  {"ColSourceIP", (String.IsNullOrEmpty(errLogs.SourceIP) ? BsonNull.Value : (BsonValue)errLogs.SourceIP) }
                };
                await coll.InsertOneAsync(objErr);
                resMsg.ErrorCode = "0";
                resMsg.Remarks = "Ok";

            }
            catch (Exception ex)
            {
                //resMsg.ErrorCode = "MD-1";ErrorDate
                resMsg.ErrorCode = "API_MD_ERR" + Convert.ToString(ex.HResult);
                resMsg.Remarks = ex.Message;
                //resMsg.ErrorCode = "1";
                //resMsg.Remarks = e.InnerException.ToString();
            }
            return resMsg;
        }

    }
}
