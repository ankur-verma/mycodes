﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using MongoDB.Driver;

namespace OneClick.KM.Loging.V1.Search
{
  public  class Search:MDatabase
    {

        //search Log for application
        public async Task<SearchDetail> SearchData(SearchDetail search)
        {

            SearchDetail resMsg = new SearchDetail();
            try
            {
                IMongoDatabase db = OpenMongoConnection();
                var coll = db.GetCollection<BsonDocument>("USER_SEARCHDETAILS");
                string jsonInterdtl = "", jsonInterTopic = "", jsonSearchType = "";
                List<BsonDocument> InteractionDtllst = new List<BsonDocument>();
                if (search.SearchResponse != null && search.SearchResponse.Count > 0)
                {
                    jsonInterdtl = JsonConvert.SerializeObject(search.SearchResponse);
                    InteractionDtllst = BsonSerializer.Deserialize<BsonArray>(jsonInterdtl).Select(p => p.AsBsonDocument).ToList<BsonDocument>();
                }

                List<BsonDocument> TopicList = new List<BsonDocument>();
                if (search.searchFilter != null && search.searchFilter.Count > 0)
                {
                    jsonInterTopic = JsonConvert.SerializeObject(search.searchFilter);
                    TopicList = BsonSerializer.Deserialize<BsonArray>(jsonInterTopic).Select(p => p.AsBsonDocument).ToList<BsonDocument>();
                }

                List<BsonDocument> SearchTypeList = new List<BsonDocument>();
                if (search.SearchType != null && search.SearchType.Count > 0)
                {
                    jsonSearchType = JsonConvert.SerializeObject(search.SearchType);
                    SearchTypeList = BsonSerializer.Deserialize<BsonArray>(jsonSearchType).Select(p => p.AsBsonDocument).ToList<BsonDocument>();
                }

                var user_intbson = new BsonDocument
                {
                  {"ColUserID", (String.IsNullOrEmpty(search.UserID) ? BsonNull.Value : (BsonValue)search.UserID) },
                  {"ColUserName", (String.IsNullOrEmpty(search.UserName) ? BsonNull.Value : (BsonValue)search.UserName)},
                  {"ColSessionId", (String.IsNullOrEmpty(search.SessionId) ? BsonNull.Value : (BsonValue)search.SessionId)},
                  {"ColTabSessionId", (String.IsNullOrEmpty(search.TabSessionId) ? BsonNull.Value : (BsonValue)search.TabSessionId)},
                  {"ColPortalCode",(String.IsNullOrEmpty(search.PortalCode) ? BsonNull.Value : (BsonValue)search.PortalCode)},
                  {"ColPortalName",(String.IsNullOrEmpty(search.PortalName) ? BsonNull.Value : (BsonValue)search.PortalName) },
                  {"ColBPOCode",(String.IsNullOrEmpty(search.BpoCode) ? BsonNull.Value : (BsonValue)search.BpoCode)},
                  {"ColBPOName",(String.IsNullOrEmpty(search.BpoName) ? BsonNull.Value : (BsonValue)search.BpoName)},
                  {"ColSearchInput",(String.IsNullOrEmpty(search.SearchInput) ? BsonNull.Value : (BsonValue)search.SearchInput)},
                  {"ColSearchResponse",(String.IsNullOrEmpty(jsonInterdtl) ? BsonNull.Value : (BsonValue)new BsonArray(InteractionDtllst))},
                  {"ColSearchFilter",(String.IsNullOrEmpty(jsonInterTopic) ? BsonNull.Value : (BsonValue)new BsonArray(TopicList))},
                  {"ColLoginType", (String.IsNullOrEmpty(search.LoginType) ? BsonNull.Value : (BsonValue)search.LoginType)},
                  {"ColCallGUID", (String.IsNullOrEmpty(search.CallGUID) ? BsonNull.Value : (BsonValue)search.CallGUID)},
                  {"ColCreationDate", ((BsonValue) DateTime.Now)},
                  {"ColSearchType",(String.IsNullOrEmpty(jsonSearchType) ? BsonNull.Value : (BsonValue)new BsonArray(SearchTypeList))},

                };
                await coll.InsertOneAsync(user_intbson);
                resMsg.ErrorCode = "0";
                resMsg.Remarks = "Ok";

            }
            catch (Exception ex)
            {

                resMsg.ErrorCode = "API_MD_ERR" + Convert.ToString(ex.HResult);
                resMsg.Remarks = ex.Message;
            }
            return resMsg;
        }

    }
}
