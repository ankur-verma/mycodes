﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
namespace OneClick.KM.Loging.V1.UserService
{
    public class UserRepositoryService : MDatabase 
    {
        public async Task<APIResponseMessage> InsertUserInteraction(UserInteractions usr_int)
        {
            APIResponseMessage resMsg = new APIResponseMessage();
            try
            {
                IMongoDatabase db = OpenMongoConnection();
                var coll = db.GetCollection<BsonDocument>("UserInteractions1");
                string jsonInterdtl = "";
                List<BsonDocument> InteractionDtl_lst = new List<BsonDocument>();
                if (usr_int.InteractionDetail != null && usr_int.InteractionDetail.Count > 0)
                {
                    jsonInterdtl = JsonConvert.SerializeObject(usr_int.InteractionDetail);
                    InteractionDtl_lst = BsonSerializer.Deserialize<BsonArray>(jsonInterdtl).Select(p => p.AsBsonDocument).ToList<BsonDocument>();
                }
                string jsonSearchRes = "";
                List<BsonDocument> SearchRes_lst = new List<BsonDocument>();
                if (usr_int.SearchResponse != null && usr_int.SearchResponse.Count > 0)
                {
                    jsonSearchRes = JsonConvert.SerializeObject(usr_int.SearchResponse);
                    SearchRes_lst = BsonSerializer.Deserialize<BsonArray>(jsonSearchRes).Select(p => p.AsBsonDocument).ToList<BsonDocument>();
                }
                var user_intbson = new BsonDocument
                {
                  {"InteractionId",(BsonValue)System.Guid.NewGuid().ToString()},
                  {"CategoryCode", (String.IsNullOrEmpty(usr_int.CategoryCode) ? BsonNull.Value : (BsonValue)usr_int.CategoryCode) },
                  {"CategoryName", (String.IsNullOrEmpty(usr_int.CategoryName) ? BsonNull.Value : (BsonValue)usr_int.CategoryName)},
                  {"SubCategoryCode", (String.IsNullOrEmpty(usr_int.SubCategoryCode) ? BsonNull.Value : (BsonValue)usr_int.SubCategoryCode)},
                  {"SubCategoryName", (String.IsNullOrEmpty(usr_int.SubCategoryName) ? BsonNull.Value : (BsonValue)usr_int.SubCategoryName)},
                  {"SubSubCategoryCode",(String.IsNullOrEmpty(usr_int.SubSubCategoryCode) ? BsonNull.Value : (BsonValue)usr_int.SubSubCategoryCode)},
                  {"SubSubCategoryName",(String.IsNullOrEmpty(usr_int.SubSubCategoryName) ? BsonNull.Value : (BsonValue)usr_int.SubSubCategoryName) },
                  {"ArticleCode", (String.IsNullOrEmpty(usr_int.ArticleCode) ? BsonNull.Value : (BsonValue)usr_int.ArticleCode) },
                  {"ArticleType", (String.IsNullOrEmpty(usr_int.ArticleType) ? BsonNull.Value : (BsonValue)usr_int.ArticleType) },
                  {"ArticleTitle", (String.IsNullOrEmpty(usr_int.ArticleTitle) ? BsonNull.Value : (BsonValue)usr_int.ArticleTitle)},
                  {"ToolTip", (String.IsNullOrEmpty(usr_int.ToolTip) ? BsonNull.Value : (BsonValue)usr_int.ToolTip)},
                  {"Source",(String.IsNullOrEmpty(usr_int.Source) ? BsonNull.Value : (BsonValue)usr_int.Source)},
                  {"SearchInput",(String.IsNullOrEmpty(usr_int.SearchInput) ? BsonNull.Value : (BsonValue)usr_int.SearchInput)},
                  {"SearchResponse",(String.IsNullOrEmpty(Convert.ToString(jsonSearchRes)) ? BsonNull.Value : (BsonValue) new BsonArray(SearchRes_lst))},
                  {"StartDate", usr_int.StartDate},
                  {"EndDate", ((BsonValue) DateTime.Now)},
                  { "UserId", (String.IsNullOrEmpty(usr_int.UserId) ? BsonNull.Value : (BsonValue)usr_int.UserId)},
                  {"UserName", (String.IsNullOrEmpty(usr_int.UserName) ? BsonNull.Value : (BsonValue)usr_int.UserName)},
                  {"SessionId", (String.IsNullOrEmpty(usr_int.SessionId) ? BsonNull.Value : (BsonValue)usr_int.SessionId) },
                  {"TabSessionId", (String.IsNullOrEmpty(usr_int.TabSessionId) ? BsonNull.Value : (BsonValue)usr_int.TabSessionId) },
                  {"PortalCode",(String.IsNullOrEmpty(usr_int.PortalCode) ? BsonNull.Value : (BsonValue)usr_int.PortalCode) },
                  {"PortalName",(String.IsNullOrEmpty(usr_int.PortalName) ? BsonNull.Value : (BsonValue)usr_int.PortalName) },
                  {"LanguageCode",(String.IsNullOrEmpty(usr_int.LanguageCode) ? BsonNull.Value : (BsonValue)usr_int.LanguageCode) },
                  {"LanguageName",(String.IsNullOrEmpty(usr_int.LanguageName) ? BsonNull.Value : (BsonValue)usr_int.LanguageName) },
                  {"CallGUID",(String.IsNullOrEmpty(usr_int.CallGUID) ? BsonNull.Value : (BsonValue)usr_int.CallGUID) },
                  {"LoginType",(String.IsNullOrEmpty(usr_int.LoginType) ? BsonNull.Value : (BsonValue)usr_int.LoginType) },
                  {"BPOCode",(String.IsNullOrEmpty(usr_int.BpoCode) ? BsonNull.Value : (BsonValue)usr_int.BpoCode) },
                  {"BPOName",(String.IsNullOrEmpty(usr_int.BpoName) ? BsonNull.Value : (BsonValue)usr_int.BpoName) },
                  {"AccessoryCode",(String.IsNullOrEmpty(usr_int.AccessoryCode) ? BsonNull.Value : (BsonValue)usr_int.AccessoryCode) },
                  { "InteractionDetail",(String.IsNullOrEmpty(Convert.ToString(jsonInterdtl)) ? BsonNull.Value : (BsonValue) new BsonArray(InteractionDtl_lst))},
                  //{ "InteractionDetail",(String.IsNullOrEmpty(Convert.ToString(jsonInterdtl)) ? BsonNull.Value : (BsonValue)BsonDocument.Parse(Convert.ToString(jsonInterdtl)))},
                  //{"InteractionDetail",(BsonValue)BsonDocument.Parse(jsonInterdtl)},
                  {"TransactionDate",((BsonValue) DateTime.Now) }
                };
                await coll.InsertOneAsync(user_intbson);
                resMsg.ErrorCode = "0";
                resMsg.Remarks = "Ok";

            }
            catch (Exception ex)
            {
                //resMsg.ErrorCode = "MD-1";
                resMsg.ErrorCode = "API_MD_ERR" + Convert.ToString(ex.HResult);
                resMsg.Remarks = ex.Message;
                //resMsg.ErrorCode = "1";
                //resMsg.Remarks = e.InnerException.ToString();
            }
            return resMsg;
        }


        public async Task<List<UserInteractions>> GetUserInteractions(UserInteractions usr_int)
        {
            List<UserInteractions> lstuser = new List<UserInteractions>();
            UserInteractions objuser1 = new UserInteractions();
            var builder = Builders<BsonDocument>.Filter;
            var filter = builder.Eq("UserId", usr_int.UserId) & builder.Eq("PortalCode", usr_int.PortalCode) & builder.Ne("ArticleCode", BsonNull.Value) & builder.Ne("ArticleType", BsonNull.Value) & builder.Ne("ArticleTitle", "NA");
            IMongoDatabase db = OpenMongoConnection();
            var coll = db.GetCollection<BsonDocument>("UserInteractions1");
            //var list = await coll.Find(filter).ToListAsync();
            var list = await coll.Find(filter).Limit(30).SortByDescending(bson => bson["StartDate"]).ToListAsync();

            foreach (var item in list)
            {
                UserInteractions objuser = new UserInteractions();
                if (item.Contains("InteractionId"))
                    objuser.InteractionId = (item.GetValue("InteractionId") != BsonNull.Value ? item.GetValue("InteractionId").ToString() : null);
                if (item.Contains("AccessoryCode"))
                    objuser.AccessoryCode = (item.GetValue("AccessoryCode") != BsonNull.Value ? item.GetValue("AccessoryCode").ToString() : null);
                if (item.Contains("CategoryCode"))
                    objuser.CategoryCode = (item.GetValue("CategoryCode") != BsonNull.Value ? item.GetValue("CategoryCode").ToString() : null);
                if (item.Contains("CategoryName"))
                    objuser.CategoryName = (item.GetValue("CategoryName") != BsonNull.Value ? item.GetValue("CategoryName").ToString() : null);
                if (item.Contains("SubCategoryCode"))
                    objuser.SubCategoryCode = (item.GetValue("SubCategoryCode") != BsonNull.Value ? item.GetValue("SubCategoryCode").ToString() : null);
                if (item.Contains("SubCategoryName"))
                    objuser.SubCategoryName = (item.GetValue("SubCategoryName") != BsonNull.Value ? item.GetValue("SubCategoryName").ToString() : null);
                if (item.Contains("SubSubCategoryCode"))
                    objuser.SubSubCategoryCode = (item.GetValue("SubSubCategoryCode") != BsonNull.Value ? item.GetValue("SubSubCategoryCode").ToString() : null);
                if (item.Contains("SubSubCategoryName"))
                    objuser.SubSubCategoryName = (item.GetValue("SubSubCategoryName") != BsonNull.Value ? item.GetValue("SubSubCategoryName").ToString() : null);
                if (item.Contains("ArticleCode"))
                    objuser.ArticleCode = (item.GetValue("ArticleCode") != BsonNull.Value ? item.GetValue("ArticleCode").ToString() : null);
                if (item.Contains("ArticleType"))
                    objuser.ArticleType = (item.GetValue("ArticleType") != BsonNull.Value ? item.GetValue("ArticleType").ToString() : null);
                if (item.Contains("ArticleTitle"))
                    objuser.ArticleTitle = (item.GetValue("ArticleTitle") != BsonNull.Value ? item.GetValue("ArticleTitle").ToString() : null);
                if (item.Contains("ToolTip"))
                    objuser.ToolTip = (item.GetValue("ToolTip") != BsonNull.Value ? item.GetValue("ToolTip").ToString() : null);
                if (item.Contains("Source"))
                    objuser.Source = (item.GetValue("Source") != BsonNull.Value ? item.GetValue("Source").ToString() : null);
                if (item.Contains("SearchInput"))
                    objuser.SearchInput = (item.GetValue("SearchInput") != BsonNull.Value ? item.GetValue("SearchInput").ToString() : null);
                if (item.Contains("SearchResponse"))
                    objuser.SearchResponse = (item.GetValue("SearchResponse") != BsonNull.Value ? JsonConvert.DeserializeObject<List<JsonArticleList>>(item.GetValue("SearchResponse").ToJson()) : null);
                if (item.Contains("StartDate"))
                    objuser.StartDate = (item.GetValue("StartDate") != BsonNull.Value) ? Convert.ToDateTime(item.GetValue("StartDate")).ToLocalTime() : (DateTime?)null;
                // objuser.EndDate = (item.GetValue("EndDate") != BsonNull.Value) ? Convert.ToDateTime(item.GetValue("EndDate")).ToLocalTime() :(DateTime?)null;
                if (item.Contains("UserId"))
                    objuser.UserId = (item.GetValue("UserId") != BsonNull.Value ? item.GetValue("UserId").ToString() : null);
                if (item.Contains("SessionId"))
                    objuser.SessionId = (item.GetValue("SessionId") != BsonNull.Value ? item.GetValue("SessionId").ToString() : null);
                if (item.Contains("PortalCode"))
                    objuser.PortalCode = (item.GetValue("PortalCode") != BsonNull.Value ? item.GetValue("PortalCode").ToString() : null);
                if (item.Contains("InteractionDetail"))
                    objuser.InteractionDetail = (item.GetValue("InteractionDetail") != BsonNull.Value ? JsonConvert.DeserializeObject<List<GHStepInteractions>>(item.GetValue("InteractionDetail").ToJson()) : null);
                lstuser.Add(objuser);
            }
            //return lstuser.OrderByDescending(x => x.StartDate).Take(30).ToList();
            return lstuser.ToList();
        }

        public async Task<UserInteractions> GetInteractionsById(UserInteractions usr_int)
        {
            UserInteractions objuser = new UserInteractions();
            var builder = Builders<BsonDocument>.Filter;
            var filter = builder.Eq("UserId", usr_int.UserId) & builder.Eq("PortalCode", usr_int.PortalCode) & builder.Eq("InteractionId", usr_int.InteractionId) & builder.Ne("ArticleCode", BsonNull.Value) & builder.Ne("ArticleType", BsonNull.Value) & builder.Ne("ArticleTitle", "NA");
            IMongoDatabase db = OpenMongoConnection();
            var coll = db.GetCollection<BsonDocument>("UserInteractions1");
            var list = await coll.Find(filter).ToListAsync();

            foreach (var item in list)
            {
                //UserInteractions objuser = new UserInteractions();
                if (item.Contains("InteractionId"))
                    objuser.InteractionId = (item.GetValue("InteractionId") != BsonNull.Value ? item.GetValue("InteractionId").ToString() : null);
                if (item.Contains("CategoryCode"))
                    objuser.CategoryCode = (item.GetValue("CategoryCode") != BsonNull.Value ? item.GetValue("CategoryCode").ToString() : null);
                if (item.Contains("CategoryName"))
                    objuser.CategoryName = (item.GetValue("CategoryName") != BsonNull.Value ? item.GetValue("CategoryName").ToString() : null);
                if (item.Contains("SubCategoryCode"))
                    objuser.SubCategoryCode = (item.GetValue("SubCategoryCode") != BsonNull.Value ? item.GetValue("SubCategoryCode").ToString() : null);
                if (item.Contains("SubCategoryName"))
                    objuser.SubCategoryName = (item.GetValue("SubCategoryName") != BsonNull.Value ? item.GetValue("SubCategoryName").ToString() : null);
                if (item.Contains("SubSubCategoryCode"))
                    objuser.SubSubCategoryCode = (item.GetValue("SubSubCategoryCode") != BsonNull.Value ? item.GetValue("SubSubCategoryCode").ToString() : null);
                if (item.Contains("SubSubCategoryName"))
                    objuser.SubSubCategoryName = (item.GetValue("SubSubCategoryName") != BsonNull.Value ? item.GetValue("SubSubCategoryName").ToString() : null);
                if (item.Contains("ArticleCode"))
                    objuser.ArticleCode = (item.GetValue("ArticleCode") != BsonNull.Value ? item.GetValue("ArticleCode").ToString() : null);
                if (item.Contains("ArticleType"))
                    objuser.ArticleType = (item.GetValue("ArticleType") != BsonNull.Value ? item.GetValue("ArticleType").ToString() : null);
                if (item.Contains("ArticleTitle"))
                    objuser.ArticleTitle = (item.GetValue("ArticleTitle") != BsonNull.Value ? item.GetValue("ArticleTitle").ToString() : null);
                if (item.Contains("ToolTip"))
                    objuser.ToolTip = (item.GetValue("ToolTip") != BsonNull.Value ? item.GetValue("ToolTip").ToString() : null);
                if (item.Contains("Source"))
                    objuser.Source = (item.GetValue("Source") != BsonNull.Value ? item.GetValue("Source").ToString() : null);
                if (item.Contains("SearchInput"))
                    objuser.SearchInput = (item.GetValue("SearchInput") != BsonNull.Value ? item.GetValue("SearchInput").ToString() : null);
                if (item.Contains("SearchResponse"))
                    objuser.SearchResponse = (item.GetValue("SearchResponse") != BsonNull.Value ? JsonConvert.DeserializeObject<List<JsonArticleList>>(item.GetValue("SearchResponse").ToJson()) : null);
                if (item.Contains("StartDate"))
                    objuser.StartDate = (item.GetValue("StartDate") != BsonNull.Value) ? Convert.ToDateTime(item.GetValue("StartDate")).ToLocalTime() : (DateTime?)null;
                // objuser.EndDate = (item.GetValue("EndDate") != BsonNull.Value) ? Convert.ToDateTime(item.GetValue("EndDate")).ToLocalTime() :(DateTime?)null;
                if (item.Contains("UserId"))
                    objuser.UserId = (item.GetValue("UserId") != BsonNull.Value ? item.GetValue("UserId").ToString() : null);
                if (item.Contains("SessionId"))
                    objuser.SessionId = (item.GetValue("SessionId") != BsonNull.Value ? item.GetValue("SessionId").ToString() : null);
                if (item.Contains("PortalCode"))
                    objuser.PortalCode = (item.GetValue("PortalCode") != BsonNull.Value ? item.GetValue("PortalCode").ToString() : null);
                if (item.Contains("InteractionDetail"))
                    objuser.InteractionDetail = (item.GetValue("InteractionDetail") != BsonNull.Value ? JsonConvert.DeserializeObject<List<GHStepInteractions>>(item.GetValue("InteractionDetail").ToJson()) : null);
            }
            return objuser;
        }

        public async Task<List<GHStepInteractions>> GetInteractionDetailById(GHStepInteractions mGHStepInteractions)
        {
            UserInteractions objuser = new UserInteractions();
            var builder = Builders<BsonDocument>.Filter;
            var filter = builder.Eq("InteractionId", mGHStepInteractions.InteractionId) & builder.Ne("ArticleCode", BsonNull.Value) & builder.Ne("ArticleType", BsonNull.Value) & builder.Ne("ArticleTitle", "NA");
            IMongoDatabase db = OpenMongoConnection();
            var coll = db.GetCollection<BsonDocument>("UserInteractions1");
            var list = await coll.Find(filter).ToListAsync();
            foreach (var item in list)
            {
                if (item.Contains("InteractionDetail"))
                    objuser.InteractionDetail = (item.GetValue("InteractionDetail") != BsonNull.Value ? JsonConvert.DeserializeObject<List<GHStepInteractions>>(item.GetValue("InteractionDetail").ToJson()) : null);
            }
            return objuser.InteractionDetail;
        }
        public async Task<APIResponseMessage> InsertMicroUtilVisit(MicroUtility objMicroUtil)
        {
            APIResponseMessage resMsg = new APIResponseMessage();
            try
            {
                IMongoDatabase db = OpenMongoConnection();
                var coll = db.GetCollection<BsonDocument>("MICRO_UTILITYVISIT");
                var microUtil = new BsonDocument
                {
                  {"UserId", (String.IsNullOrEmpty(objMicroUtil.UserId) ? BsonNull.Value : (BsonValue)objMicroUtil.UserId)},
                  {"UserName", (String.IsNullOrEmpty(objMicroUtil.UserName) ? BsonNull.Value : (BsonValue)objMicroUtil.UserName)},
                  {"SessionId", (String.IsNullOrEmpty(objMicroUtil.SessionId) ? BsonNull.Value : (BsonValue)objMicroUtil.SessionId) },
                  {"TabSessionId", (String.IsNullOrEmpty(objMicroUtil.TabSessionId) ? BsonNull.Value : (BsonValue)objMicroUtil.TabSessionId) },
                  {"PortalCode",(String.IsNullOrEmpty(objMicroUtil.PortalCode) ? BsonNull.Value : (BsonValue)objMicroUtil.PortalCode) },
                  {"PortalName",(String.IsNullOrEmpty(objMicroUtil.PortalName) ? BsonNull.Value : (BsonValue)objMicroUtil.PortalName) },
                  {"BPOCode",(String.IsNullOrEmpty(objMicroUtil.BpoCode) ? BsonNull.Value : (BsonValue)objMicroUtil.BpoCode) },
                  {"BPOName",(String.IsNullOrEmpty(objMicroUtil.BpoName) ? BsonNull.Value : (BsonValue)objMicroUtil.BpoName) },
                  {"PageName", (String.IsNullOrEmpty(objMicroUtil.PageName) ? BsonNull.Value : (BsonValue)objMicroUtil.PageName) },
                  {"Source",(String.IsNullOrEmpty(objMicroUtil.Source) ? BsonNull.Value : (BsonValue)objMicroUtil.Source)},
                  {"TransactionDate",((BsonValue) DateTime.Now) }
                };
                await coll.InsertOneAsync(microUtil);
                resMsg.ErrorCode = "0";
                resMsg.Remarks = "Ok";

            }
            catch (Exception ex)
            {
                //resMsg.ErrorCode = "MD-1";
                resMsg.ErrorCode = "API_MD_ERR" + Convert.ToString(ex.HResult);
                resMsg.Remarks = ex.Message;
            }
            return resMsg;
        }

        public async Task<APIResponseMessage> UpdateArticleLog(UserInteractions usr_int)
        {
            APIResponseMessage resMsg = new APIResponseMessage();
            try
            {
                IMongoDatabase db = OpenMongoConnection();
                var coll = db.GetCollection<BsonDocument>("UPDATE_ARTICLELOG");
                var objArticle = new BsonDocument
                {
                  {"UserId", (String.IsNullOrEmpty(usr_int.UserId) ? BsonNull.Value : (BsonValue)usr_int.UserId)},
                  {"UserName", (String.IsNullOrEmpty(usr_int.UserName) ? BsonNull.Value : (BsonValue)usr_int.UserName)},
                  {"SessionId", (String.IsNullOrEmpty(usr_int.SessionId) ? BsonNull.Value : (BsonValue)usr_int.SessionId) },
                  {"CategoryCode", (String.IsNullOrEmpty(usr_int.CategoryCode) ? BsonNull.Value : (BsonValue)usr_int.CategoryCode) },
                  {"CategoryName", (String.IsNullOrEmpty(usr_int.CategoryName) ? BsonNull.Value : (BsonValue)usr_int.CategoryName)},
                  {"SubCategoryCode", (String.IsNullOrEmpty(usr_int.SubCategoryCode) ? BsonNull.Value : (BsonValue)usr_int.SubCategoryCode)},
                  {"SubCategoryName", (String.IsNullOrEmpty(usr_int.SubCategoryName) ? BsonNull.Value : (BsonValue)usr_int.SubCategoryName)},
                  {"SubSubCategoryCode",(String.IsNullOrEmpty(usr_int.SubSubCategoryCode) ? BsonNull.Value : (BsonValue)usr_int.SubSubCategoryCode)},
                  {"SubSubCategoryName",(String.IsNullOrEmpty(usr_int.SubSubCategoryName) ? BsonNull.Value : (BsonValue)usr_int.SubSubCategoryName) },
                  {"ArticleCode", (String.IsNullOrEmpty(usr_int.ArticleCode) ? BsonNull.Value : (BsonValue)usr_int.ArticleCode) },
                  {"ArticleTitle", (String.IsNullOrEmpty(usr_int.ArticleTitle) ? BsonNull.Value : (BsonValue)usr_int.ArticleTitle)},
                  {"TransactionDate",((BsonValue) DateTime.Now) }
                };
                await coll.InsertOneAsync(objArticle);
                resMsg.ErrorCode = "0";
                resMsg.Remarks = "Ok";

            }
            catch (Exception ex)
            {
                //resMsg.ErrorCode = "MD-1";
                resMsg.ErrorCode = "API_MD_ERR" + Convert.ToString(ex.HResult);
                resMsg.Remarks = ex.Message;
                //resMsg.ErrorCode = "1";
                //resMsg.Remarks = "error";
            }
            return resMsg;
        }
    }
}
