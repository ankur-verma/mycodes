﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace OneClick.KM.Model.Account
{
    [Serializable]

    #region[Agent Login]


    public class Login //application Login Model
    {

        [Required(ErrorMessage = "Please enter user name")]
        [StringLength(50, ErrorMessage = "User Name cannot be more than 50 characters")]
        [RegularExpression(@"[0-9A-Za-z._^]+", ErrorMessage = "Special characters not allowed.")]
        public string UserName { get; set; }
        [Required(ErrorMessage = "Please enter password")]
        [StringLength(500, ErrorMessage = "Password cannot be more than 50 characters")]
        [DataType(DataType.Password)]
        [RegularExpression(@"[0-9A-Za-z.@ _!#$%&*?~()^]+", ErrorMessage = "Special characters not allowed.")]
        public string UserPassword { get; set; }
        public string Domain { set; get; }
        public string IpAddress { set; get; }
        public string ModuleCode { set; get; }
        public int WhetherKillSession { set; get; }
     //   public int Attempts { set; get; }
        public string Attempts { set; get; }
        public string ReturnUrl { get; set; }
        public string ClientId { get; set; }
        public string ClientShortCode { get; set; }       
    }
    public class UserData : APIResponseMessage
    {
        public UserData()
        {
            ActiveSession = new List<ActiveUserSessionDet>();
            ActivePortalList = new List<ActivePortalList>();
            DefaultPortalList = new List<ActivePortalList>();
        }
        public string UserName { get; set; }
        public string SessionId { set; get; }
        public string UserId { set; get; }
        public string TabSessionId { get; set; }
        public string ClientCode { set; get; }
        public string DisplayName { set; get; }
        public string PortalCode { set; get; }
        public string PortalName { set; get; }
        public Int32 IopATTEMPTS { set; get; }
        public string UserRole { set; get; }
        public string LoginType { set; get; }
        public List<ActiveUserSessionDet> ActiveSession { get; set; }
        public List<ActivePortalList> ActivePortalList { get; set; }
        public List<ActivePortalList> DefaultPortalList { get; set; }
        // public string Remarks { get; set; }
        public string ClientShortCode { get; set; }
    }

    [Serializable]

    public class ActiveUserSessionDet : APIResponseMessage
    {
        public string UserName { get; set; }
        public string UserID { get; set; }
        public string ActiveSessionID { get; set; }
        public string PortalName { get; set; }
        public string PortalCode { get; set; }
        public DateTime LoginDate { get; set; }
        public string Action { get; set; }
        public string IpAddress { get; set; }
        public string ClientId { get; set; }
    }
    [Serializable]

    public class ActivePortalList
    {
        public string PortalCode{ get; set; }
        public string PortalName{ get; set; }
        public string DefaultPortal{ get; set; }
    }

    public class PortalDLogin
    {
        public string UserID { get; set; }
        public string PortalName { set; get; }
        public string UserType { get; set; }
        public int Attempts { set; get; }
        public string ClientId { get; set; }
    }

    public class SSOLogin
    {
        public string UserName { get; set; }
        public string ClientShortCode { get; set; }
        public string Salt { get; set; }
        public string Url { set; get; }
        public string ServiceId { get; set; }
        public string Attempts { set; get; } // add a parameter Attempts
        public string ClientId { get; set; }
    }

    public class ResetPassword
    {
        [Display(Name = "UserName")]
        public string UserName { get; set; }


        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "OldPassword")]
        public string OldPassword { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 8)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 8)]
        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The New Password and confirmation password should be same.")]
        public string ConfirmPassword { get; set; }
        public string Flage { get; set; }
        public IEnumerable<HintQuestion> mHintQuestion { get; set; }
        //[Required]
        //[Display(Name = "Hint Question")]
        //public string SelectedHintQus { get; set; }

        //[Required]
        //[Display(Name = "Hint Answer")]
        //public string HintAnswer { get; set; }

        public string PortalCode { set; get; }
        public string PortalName { set; get; }

        public bool IsChangeSuccess { get; set; }
        public string ClientId { get; set; }
        public string ClientShortCode { get; set; }
    }

    public class HintQuestion
    {
        public string Code { set; get; }
        public string Description { set; get; }
        public string Identifier { set; get; }
        public string DisplayOrder { set; get; }
        public string ClieintId { set; get; }
    }

    #endregion
    #region [Authoring Login ]

    public class LogoutProp
    {
        [Required(ErrorMessage = "SessionID Required ")]
        public string SessionID { get; set; }

        [Required(ErrorMessage = "SessionID Required ")]
        public string UserID { get; set; }
        [Required(ErrorMessage = "ClientId Required ")]
        public string ClientId { get; set; }
        
    }

    public class LoginProp
    {


        public LoginProp()
        {
           Error = new ErrorProp();

            GroupLst = new List<GroupProp>();

        }

        public string DomainName { get; set; }

        public string ClientCode { get; set; }



        public string IpAddress { get; set; }

        [Required(ErrorMessage = "Please enter User Name")]
        [StringLength(50, ErrorMessage = "User Name cannot be more than 50 characters")]
        [RegularExpression(@"^[0-9A-Za-z._]+", ErrorMessage = "Special characters not allowed.")]
        public string UserName { get; set; }


        [Required(ErrorMessage = "Please enter Password")]
        [StringLength(500, ErrorMessage = "User Name cannot be more than 50 characters")]
        [DataType(DataType.Password)]
        [RegularExpression(@"^[0-9A-Za-z.@!,#$%^&*?_~-£()]+", ErrorMessage = "Special characters not allowed.")]
        public string Password { get; set; }
        

        public string Attempts { get; set; }

        public string SessionId { get; set; }

        public string UserId { get; set; }

        public string DisplayName { get; set; }

        public bool CanExpire { get; set; }

        public ErrorProp Error { get; set; }
        public string Status { get; set; }

        public bool WhetherKillSession { get; set; }

        public List<GroupProp> GroupLst { get; set; }
        public string ClientId { get; set; }
        public string ClientShortCode { get; set; }
    }

    [Serializable]

    public class GroupProp
    {

        public string GroupCode { get; set; }
        public string GroupShortCode { get; set; }
        public string GroupName { get; set; }
        public string UserId { get; set; }
    }

    [Serializable]


     public class ForgetPassword
    {
        public string UserName { get; set; }

        public string Password { get; set; }
        public string HintQuesCode { get; set; }
        public string HintAns { get; set; }
        public string ClientId { get; set; }
        
        public string ClientShortCode { get; set;}
     }

    //public class ForgotPassword
    //{
    //    public string Domain { get; set; }
    //    [Required(ErrorMessage = "Please enter Hint Answer")]
    //    [StringLength(50, ErrorMessage = "Hint Answer cannot be more than 50 characters")]
    //    [DataType(DataType.Password)]
    //    public string HintAnswer { get; set; }

    //    public User User { get; set; }
    //    public BasicEntry HintQuestion { get; set; }
    //    public ErrorProp Error { get; set; }
    //    public ApplicationModule Module { get; set; }
    //    public string ClientId { get; set; }
        
    //    public string ClientShortCode { get; set; }
    //    public ForgotPassword()
    //    {
    //        User = new User();
    //        HintQuestion = new BasicEntry();
    //        Error = new ErrorProp();
    //        Module = new ApplicationModule();
    //    }
    //}
    [Serializable]

    public class User
    {
        public string UserID { get; set; }

        [Required(ErrorMessage = "Please enter User Name")]
        [StringLength(100, ErrorMessage = "User Name cannot be more than 100 characters")]
        [RegularExpression(@"^[0-9A-Za-z._]+", ErrorMessage = "Special characters not allowed.")]
        public string UserName { get; set; }
        public string DisplayName { get; set; }
        public BasicEntry Status { get; set; }
        public bool CanExpire { get; set; }
        public string ClientEncryptionMode { get; set; }
        public string UserEncryptionMode { get; set; }
        public string ClientCode { get; set; }
        public PasswordInfo Password { get; set; }
        public User()
        {
            Password = new PasswordInfo();
        }

    }
    [Serializable]


    public class BasicEntry
    {
        [Required(ErrorMessage = "Please enter Basic Entry Code")]
        [StringLength(10, ErrorMessage = "Basic Entry Code cannot be more than 10 characters")]
        public string Code { get; set; }
        [Required(ErrorMessage = "Please enter Description")]
        [StringLength(200, ErrorMessage = "Description cannot be more than 200 characters")]
        public string Description { get; set; }

        public string IsActive { get; set; }
        [StringLength(250, ErrorMessage = "PageURL cannot be more than 250 characters")]
        public string PageURL { get; set; }
        [RegularExpression(@"^[0-9]{0,2}$", ErrorMessage = "Display Order should contain only numbers from 0 to 99.")]
        public int? DisplayOrder { get; set; }
        public string IdentifierCode { get; set; }
        public string UserUID { get; set; }
        public string HintAns { get; set; }
        public ErrorProp Error { get; set; }
        //public Identifier Identifier { get; set; }

        public BasicEntry()
        {
            //Identifier = new Identifier();
            Error = new ErrorProp();
        }
    }

    [Serializable]


    public class ApplicationModule
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
    }

    [Serializable]

    public class PasswordInfo
    {
        [DataType(DataType.Password)]
        [Required(ErrorMessage = "Please enter Password")]
        public string Password { get; set; }
        /// <summary>
        /// Configuration setting in web.config
        /// </summary>
        public string ExpiryDays { get; set; }
        /// <summary>
        /// Possible values are Y or N
        /// </summary>
        public string CanExpire { get; set; }
    }

    public class ChangePassword
    {
        public string UserId { get; set; }
        public string UserName { get; set; }
        public string CurrentPassword { get; set; }
        public string NewPassword { get; set; }
        public string Hintque { get; set; }
        public string HintAns { get; set; }
        public string Domain { get; set; }
        public string Usertype { get; set; }
        public string ClientId { get; set; }

    }

    public class UserBasic
    {
        //objuser != null && objuser.UserName != null && objuser.Password != null && objuser.CurrentPassword != null
        public string SourceUser { get; set; }
        [Required(ErrorMessage = "User name can not be empty")]
        public string UserName { get; set; }
        public string UserNameIdentity { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        [Required(ErrorMessage = " Password can not be empty")]
        public string Password { get; set; }
        //based on copyfrom, if copyfrom is null then this fields are required otherwise fields data will copy from copyfrom user
        public string SelectDesignation { get; set; }
        public string ReportingTo { get; set; }
        public string ReportingToName { get; set; }
        public bool CanExpire { get; set; }
        public string Domain { get; set; }
        public string ClientCode { get; set; }
        public string CreatedBy { get; set; }
        public string UserId { get; set; }
        public string statusCode { get; set; }
        public string status { get; set; }
        public string HintQuestCode { get; set; }
        public string HintAnswer { get; set; }
        public string selectRole { get; set; }
        public List<Roles> UserRoles { get; set; }
        public List<Portal> UserPortalList { get; set; }
        public List<Module> UserModules { get; set; }
        public string UserCreateResponse { get; set; }
        public string UserRoleCode { get; set; }
        public string Rights { get; set; }
        public Boolean IsReportingtoSelf { get; set; }
        public Boolean Flag { get; set; }
        public string PortalLst { get; set; }
        [Required(ErrorMessage = "Current password can not be empty")]
        public string CurrentPassword { get; set; }
        [Compare("Password",ErrorMessage =" password not match")]
        public string ConfirmNewPassword { get; set; }
        public string HintQuestion { get; set; }
        public string DisplayName { get; set; }
        public string UserDetail { get; set; }
        public string ValidationMessage { get; set; }
        public string LocationCode { get; set; }
        public string Location { get; set; }
        public string ReturnStauts { get; set; }
        public string ReturnCode { get; set; }

        
        public string ClientId { get; set; }
    }


    [Serializable]

    public class Roles
    {
        public string UserID { get; set; }
        public string UserName { get; set; }
        public string RoleCode { get; set; }
        public string RoleName { get; set; }
        public bool IsChecked { get; set; }

    }

    [Serializable]

    public class Portal
    {
        public string PortalCode { get; set; }
        public string PortalName { get; set; }
        public bool IsChecked { get; set; }

    }

    [Serializable]
    public class Module
    {
        public string UserID { get; set; }
        public string UserName { get; set; }
        public string ModuleCode { get; set; }
        public string ModuleName { get; set; }
        public bool IsChecked { get; set; }

    }

    public class InsertForgetPassword

    {
        [Required(ErrorMessage = "Please enter UserName")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Please enter Domain")]
        public string Domain { get; set; }


        [Required(ErrorMessage = "Please enter Password")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Please enter HintQuesCode")]
        public string HintQuesCode { get; set; }
        [Required(ErrorMessage = "Please enter HintAns")]
        public string HintAns { get; set; }
      
        public string ClientId { get; set; } // use for returning Client Id Fetch from Client json file 

        [Required(ErrorMessage = "Please enter ClientShortCode")]
        public string ClientShortCode { get; set; }

    }

   

    #endregion
}
