﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OneClick.KM.Model
{
	public class AppSettings
	{
		public string DbConnection { get; set; }
		public string Email { get; set; }
		public string SMTPPort { get; set; }
	}
}
