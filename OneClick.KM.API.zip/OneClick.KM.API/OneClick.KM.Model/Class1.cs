﻿using System;

namespace OneClick.KM.Model
{
	public class Class1
	{
	}
}
