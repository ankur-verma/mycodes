﻿using Newtonsoft.Json;
using OneClick.KM.Core;
using OneClick.KM.Core.Utility;
using OneClick.KM.Model.ElasticCache;
using OneClick.KM.Model.UserManagement;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using static OneClick.KM.Model.GuidedHelpModel.GuidedHelp;

namespace OneClick.KM.Model
{
    public class BaseModel : APIResponseMessage
    {
        public string ClientId { get; set; }
        public string ClientCode { get; set; }
        public string CircleCode { get; set; }
        public string TabSessionId { get; set; }
        public string PortalCode { set; get; }
        public string SessionId { set; get; }
        public string UserId { set; get; }
        public string UserName { get; set; }
        public string LanguageCode { set; get; }
        public string Category { get; set; }
        public string SubCategory { get; set; }
        public string SubSubCategory { get; set; }
        public string CategoryCode { get; set; }
        public string SubCategoryCode { get; set; }
        public string SubSubCategoryCode { get; set; }
        public string Status { set; get; }
        public string ErrorMessage { get; set; }
        public string PortalHost { get; set; }
        public string IsByTopicTree { get; set; }
        public  string  Domain { get; set; }
        public string PortalName { get; set; }
        public string ActualError { get; set; }
	}

    [Serializable]
    [Newtonsoft.Json.JsonObject]
    public class ArticleRequest
    {
        public string UserId { get; set; }
        public string ClientCode { get; set; }
        public string BusinessCode { get; set; }
        public string Domain { get; set; }

        public string ArticleType { get; set; }
        public string ArticleCode { get; set; }
        public string ForceDeleteFlag { get; set; }
        public string PortalCode { get; set; }
        public string FaqBusiCode { get; set; }
        public string ScenarioCode { get; set; }
        public string QuesCode { get; set; }
        public string AnsCode { get; set; }
        public string ContentType { get; set; }
        public string Status { get; set; }

        public string SearchKey { get; set; }
        public string SearchValue { get; set; }

        public string StartIndex { get; set; }
        public string EndIndex { get; set; }

        public string CommentText { get; set; }
        public string CommentType { get; set; }
        public string FromDate { get; set; }
        public string Todate { get; set; }
        public string ReviveStatus { get; set; }
        public string CacheId { get; set; }
        public List<ArticleIdBasic> articles { get; set; }
        public string ClientId { get; set; }
        public string ActionId { get; set; }
    }

    public class ArticleRequest_V1
    {
       [Required]
        public string UserId { get; set; }
        public string ClientCode { get; set; }
        public string BusinessCode { get; set; }
        public string Domain { get; set; }
        [Required]
        public string ArticleType { get; set; }
        [Required]
        public string ArticleCode { get; set; }

        public string PortalCode { get; set; }
        [Required]
        public string FaqBusiCode { get; set; }
        public string ScenarioCode { get; set; }
        public string QuesCode { get; set; }
        public string AnsCode { get; set; }
        public string ContentType { get; set; }
        public string Status { get; set; }

        public string SearchKey { get; set; }
        public string SearchValue { get; set; }

        public string StartIndex { get; set; }
        public string EndIndex { get; set; }

        public string CommentText { get; set; }
        public string CommentType { get; set; }
        public string FromDate { get; set; }
        public string Todate { get; set; }
        public string ReviveStatus { get; set; }
        public string CacheId { get; set; }
        public List<ArticleIdBasic> articles { get; set; }

        [Required]
        public string ClientId { get; set; }
    }



    [Serializable]
    [Newtonsoft.Json.JsonObject]    
    public class SearchRelatedArticle
    {
        [Required]
        public string UserId { get; set; }
        public string ClientCode { get; set; }
        
        public string BusinessCode { get; set; }
        public string Domain { get; set; }

        [Required]
        public string ArticleType { get; set; }
        [Required]
        public string ArticleCode { get; set; }

        public string PortalCode { get; set; }
        [Required]
        public string FaqBusiCode { get; set; }
        public string ScenarioCode { get; set; }
        public string QuesCode { get; set; }
        public string AnsCode { get; set; }
        public string ContentType { get; set; }
        public string Status { get; set; }
        [Required]
        public string SearchKey { get; set; }
        [Required]
        public string SearchValue { get; set; }

        public string StartIndex { get; set; }
        public string EndIndex { get; set; }

        public string CommentText { get; set; }
        public string CommentType { get; set; }
        public string FromDate { get; set; }
        public string Todate { get; set; }
        public string ReviveStatus { get; set; }
        public string CacheId { get; set; }
        public List<ArticleIdBasic> articles { get; set; }
        [Required]
        public string ClientId { get; set; }
    }

    [Serializable]
    [Newtonsoft.Json.JsonObject]
    public class ReletedArticleAccessories
    {
        [Required]
        public string UserId { get; set; }
        public string ClientCode { get; set; }
        public string BusinessCode { get; set; }
        public string Domain { get; set; }

        public string ArticleType { get; set; }

        [Required]
        public string ArticleCode { get; set; }
        public string PortalCode { get; set; }
        public string FaqBusiCode { get; set; }
        public string ScenarioCode { get; set; }
        public string QuesCode { get; set; }
        public string AnsCode { get; set; }
        public string ContentType { get; set; }
        public string Status { get; set; }

        public string SearchKey { get; set; }
        public string SearchValue { get; set; }

        public string StartIndex { get; set; }
        public string EndIndex { get; set; }

        public string CommentText { get; set; }
        public string CommentType { get; set; }
        public string FromDate { get; set; }
        public string Todate { get; set; }
        public string ReviveStatus { get; set; }
        public string CacheId { get; set; }
        [Required]
        public string ClientId { get; set; }
    }





    [Serializable]
    [Newtonsoft.Json.JsonObject]
    public class ArticleIdBasic
    {
        public string ArticleCode { get; set; }
        public string FaqBusiCode { get; set; }
        public string ScenarioCode { get; set; }
        public string CacheDetailId { get; set; }
        public ElasticCacheViewModel ArtElasticRedisData { get; set; }
    }



     [Serializable]
    [JsonObject]
    public class AddLinkViewModel


    {
        public AddLinkViewModel()
        {
            LinkType=new List<lstScope>();
            Portallst = new List<LstPortal>();
            Ghorderinglist = new List<GhDragDrop>();

        }
        public string ScenarioQuestionCode { get; set; }
        public string ScenarioAnswerCode { get; set; }
        public List<lstScope> LinkType { get; set; }
        public string Link_Type { get; set; }
        public List<lstProduct> Product { get; set; }
        public string Productid { get; set; }
        public List<lstFAQType> FaqType { get; set; }
        public string FaqTypeCode { get; set; }
        public List<lstFAQ> FaqList { get; set; }
        public string FAQ { get; set; }
        public string FAQId { get; set; }
        public string Typedescription { get; set; }

        public CategoryTypeMap Source; // For add link pop over, tells whether add link pop over is opened (Sourced) from Guided help or article 

        public List<lstProvider> Provider { get; set; }
        public string ProviderCode { get; set; }
        public List<lstConnectionType> ConnectionType { get; set; }
        public string Connection_Type { get; set; }
        public List<lstSOP> SOP { get; set; }
        public string SOPid { get; set; }
        public List<lstFeature> Feature { get; set; }
        public string FeatureCode { get; set; }
        public List<lstTechnology> Technology { get; set; }
        public string TechnologyCode { get; set; }
        public string OwaText { get; set; }
        public string SmsText { get; set; }
        public List<lstFeatureGroup> FeatureGroup { get; set; }
        public string FeatureGroupCode { get; set; }
        public List<lstQuestion> Question { get; set; }
        public string QuestionCode { get; set; }
        public List<lstUserStory> UserStory { get; set; }
        public string ArticleId { get; set; }
        public List<lstArticle> Article { get; set; }
        public string ArticleCode { get; set; }
        public List<lstCategory> Category { get; set; }
        public string CategoryCode { get; set; }
        public List<lstSubCategory> SubCategory { get; set; }
        public string SubCategoryCode { get; set; }
        public List<lstSubSubCategory> SubSubCategory { get; set; }
        public string SubSubCategoryCode { get; set; }
        public string ScenarioCode { get; set; }

        public List<lstGroup> Group { get; set; }
        public string GroupCode { get; set; }

        public List<lstBookmark> Bookmark { get; set; }
        public string BookmarkId { get; set; }

        public string PortalCode { get; set; }
        public string Userid { get; set; }
        public List<LstPortal> Portallst { get; set; }

        public Boolean EditMode = false; // needed for Guided Help Add Link screen, to check whether link is already available for current ques code of Guided help and if it is then the screen will be in edit mode
        public List<GhDragDrop> Ghorderinglist { get; set; }
        public string ClientId { get; set; }
    }


    public class lstArticle
    {
        public string ArticleCode { get; set; }
        public string ArticleTitle { get; set; }
        public string Frequency { get; set; }
    }
    [Serializable]
    [JsonObject]
    public class lstPortal
    {
        public string PortalCode { get; set; }
        public string PortalName { get; set; }
    }
    [Serializable]
    [JsonObject]
    public class lstCategoryType
    {
        public string CategoryTypeCode { get; set; }
        public string CategoryTypeName { get; set; }
        public string Browsable { get; set; }
        public string Searchable { get; set; }
        public string IsCategory { get; set; }
    }
    [Serializable]
    [JsonObject]
    public class lstCategory
    {
        public string CategoryCode { get; set; }
        public string CategoryName { get; set; }
    }
    [Serializable]
    [JsonObject]
    public class lstSubCategory
    {
        public string SubCategoryCode { get; set; }
        public string SubCategoryName { get; set; }
    }
    [Serializable]
    [JsonObject]
    public class lstSubSubCategory
    {
        public string SubSubCategoryCode { get; set; }
        public string SubSubCategoryName { get; set; }
    }
    [Serializable]
    [JsonObject]
    public class lstScope
    {
        public string ScopeCode { get; set; }
        public string ScopeDesc { get; set; }
        public string ScopeIdentifier { get; set; }
        public string ScopeDisplayOrder { get; set; }
    }

    [Serializable]
    [JsonObject]
    public class lstProvider
    {
        public string ProviderCode { get; set; }
        public string ProviderName { get; set; }
    }
    [Serializable]
    [JsonObject]
    public class lstConnectionType
    {
        public string Identifier { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public string DisplayOrder { get; set; }
    }
    [Serializable]
    [JsonObject]
    public class lstSOP
    {
        public string ScenarioCode { get; set; }
        public string Description { get; set; }
    }
    [Serializable]
    [JsonObject]
    public class lstFeature
    {
        public string FeatureCode { get; set; }
        public string FeatureName { get; set; }
    }
    [Serializable]
    [JsonObject]
    public class lstTechnology
    {
        public string TechnologyCode { get; set; }
        public string TechnologyName { get; set; }
    }
    [Serializable]
    [JsonObject]
    public class lstFeatureGroup
    {
        public string FeatureCode { get; set; }
        public string FeatureName { get; set; }
    }
    [Serializable]
    [JsonObject]
    public class lstGroup
    {
        public string GroupCode { get; set; }
        public string GroupName { get; set; }
    }
    [Serializable]
    [JsonObject]
    public class lstBookmark
    {
        public string BookmarkCode { get; set; }
        public string BookmarkName { get; set; }
    }
    [Serializable]
    [JsonObject]
    public class lstQuestion
    {
        public string QuestionDesc { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public string FeatureCode { get; set; }
        public string FeatureName { get; set; }
        public string Orientation { get; set; }
        public string Status { get; set; }
        public string QuestionShortCode { get; set; }
    }
    [Serializable]
    [JsonObject]
    public class lstUserStory
    {
        public string ClientCode { get; set; }
        public string ClientName { get; set; }
        public string ArticleId { get; set; }
        public string ScenarioCode { get; set; }
        public string ScenarioType { get; set; }
        public string ProviderCode { get; set; }
        public string ProviderName { get; set; }
        public string CriteriaValue { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public string ScenarioTypeCode { get; set; }
    }

    [Serializable]
    [JsonObject]

    public class lstProduct
    {
        public string PRODUCTCODE { get; set; }
        public string PRODUCTNAME { get; set; }
        public string PRODUCTIMAGE { get; set; }
        public string STATUS { get; set; }
        public string PRODUCTSTATUS { get; set; }
        public string ACTIVEUSERID { get; set; }
        public string CREATOR { get; set; }
        public string ACTIVATIONDATE { get; set; }
        public string DEACTIVATIONDATE { get; set; }
        public string DEACTIVEUSERID { get; set; }
        public string DEACTIVATOR { get; set; }
    }
    [Serializable]
    [JsonObject]
    public class lstFAQType
    {
        public string TYPECODE { get; set; }
        public string TYPENAME { get; set; }
    }
    [Serializable]
    [JsonObject]
    public class lstFAQ
    {
        public string FaqCode { get; set; }
        public string FaqTitle { get; set; }
    }

}






