﻿using OneClick.KM.Model.UserManagement;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Text.RegularExpressions;

namespace OneClick.KM.Model
{
    public class CommonMethods
    {
        public const string portalCachePrefix = "ES_";
        public static ErrorProp GetError(string Code, string Message)
        {
            ErrorProp error = GetError(Code);
            if (Message != null &&
                Message != "")
            {
                error.ErrorDetail = Message;
            }
            return error;
        }
        public static ErrorProp GetError(string Code)
        {
            ErrorProp error = new ErrorProp();
            ResourceManager rm = new ResourceManager("OneClick.KM.Model.ErrorMsg", Assembly.GetExecutingAssembly());
            string errMsg = rm.GetString(Code);
            if (errMsg != null &&
                errMsg != "")
            {
                error.ErrorCode = Code;
                error.ErrorDetail = errMsg;
            }
            return error;
        }

        public static Response GetGenericMessage(string Code)
        {
            Response response = new Response();

            ErrorProp error = new ErrorProp();
            ResourceManager rm = new ResourceManager("OneClick.KM.Model.ErrorMsg", Assembly.GetExecutingAssembly());
            string errMsg = rm.GetString("ERR001");
            if (!string.IsNullOrEmpty(errMsg))
            {
                error.ErrorCode = Code;
                error.ErrorDetail = errMsg;
            }
            response.Error = error;
            return response;
        }

        public static async System.Threading.Tasks.Task<Response> CheckClient()
        {
            return await System.Threading.Tasks.Task.Run(() =>
            {
                Response response = new Response();
                ErrorProp error = new ErrorProp();
                error.ErrorCode = "-9999";
                error.ErrorDetail = "Please enter valid client id";
                response.Error = error;
                return response;
            });
        }


        public static string RandomDigits(int length)
        {
            var random = new Random();
            string s = string.Empty;
            for (int i = 0; i < length; i++)
                s = String.Concat(s, random.Next(10).ToString());
            return s;
        }

        public static string HTMLToText(string HTMLCode)
        {
            string retVal = string.Empty;
            try
            {
                // Remove new lines since they are not visible in HTML
                HTMLCode = HTMLCode.Replace("\n", " ");
                // Remove tab spaces
                HTMLCode = HTMLCode.Replace("\t", " ");
                // Remove multiple white spaces from HTML
                HTMLCode = Regex.Replace(HTMLCode, "\\s+", " ");
                // Remove HEAD tag
                HTMLCode = Regex.Replace(HTMLCode, "<head.*?</head>", ""
                                    , RegexOptions.IgnoreCase | RegexOptions.Singleline);
                // Remove any JavaScript
                HTMLCode = Regex.Replace(HTMLCode, "<script.*?</script>", ""
                  , RegexOptions.IgnoreCase | RegexOptions.Singleline);
                // Replace special characters like &, <, >, " etc.
                StringBuilder sbHTML = new StringBuilder(HTMLCode);
                // Note: There are many more special characters, these are just
                // most common. You can add new characters in this arrays if needed
                string[] OldWords = { "&nbsp;", "&amp;", "&quot;", "&lt;", "&gt;", "&reg;", "&copy;", "&bull;", "&trade;" };
                string[] NewWords = { " ", "&", "\"", "<", ">", "Â®", "Â©", "â€¢", "â„¢" };
                for (int i = 0; i < OldWords.Length; i++)
                {
                    sbHTML.Replace(OldWords[i], NewWords[i]);
                }
                // Check if there are line breaks (<br>) or paragraph (<p>)
                sbHTML.Replace("<br>", "\n<br>");
                sbHTML.Replace("<br ", "\n<br ");
                sbHTML.Replace("<p ", "\n<p ");
                // Finally, remove all HTML tags and return plain text
                string  sTr = System.Text.RegularExpressions.Regex.Replace(sbHTML.ToString(), "<[^>]*>", "");
                if (string.IsNullOrWhiteSpace(sTr))
                    return "NA";
                return sTr;
            }
            catch (Exception)
            {
                return HTMLCode;
                //throw;
            }
        }
        public static string CalculateTotalMinutesFromNow(DateTime futureDate)
        {
            if (futureDate != null)
            {
                return Convert.ToInt32(futureDate.Subtract(DateTime.Now).TotalMinutes).ToString();
            }
            else
            {
                return "";
            }
        }
    }
    public class APIResponseMessage
    {
        public string ErrorCode { get; set; }
        public string Remarks { get; set; }
    }

    #region Auth
    public class ErrorProp
    {
        public string ErrorCode { get; set; }
        public string ErrorDetail { get; set; }
        public string ReturnValue { get; set; }
        public string MessageType { get; set; }
        public string Redirect { get; set; }
        public Object ResponseData { get; set; }
        // public UserCreateModal ResponseData { get; set; }
        public string GetMessageInfo
        {
            get { return "Error Code (" + ErrorCode + ") : " + ErrorDetail; }
        }
        public string ActualError { get; set; }
    }
    public class ErrorPropForAsync
    {
        public ErrorPropForAsync()
        {
            ErrorClassObj = new ErrorProp();
            ErrorClassObj.ErrorCode = "1";
            ErrorClassObj.ErrorDetail = "No data found";
        }
        public ErrorProp ErrorClassObj { get; set; }
        public object Result { get; set; }
    }
    #endregion Auth
    public enum ModuleType
    {
        AUW,
        AUA,
        AUDB
    }
    public class ErrorCodeConstant
    {
        public static string AppendErrorCodePrefix(string ErrorCode)
        {
            try
            {
                if (ErrorCode != "0")
                {
                    ErrorCode = ErrorCode.Replace("AUDB", "");
                    if (ErrorCode.Length <= 2)
                    {
                        ErrorCode = "AUDB" + ErrorCode;
                    }
                }
            }
            catch
            {
                ErrorCode = "AUDB" + ErrorCode;
                //hrow ex;
            }
            return ErrorCode;
        }
        public static string CreateUseErrormessager(string Message)
        {
            return Message + CreateuserValidaionMessage;
        }

        public const string CreateuserValidaionMessage = " is missing!";
        public const string ValidationCode = "3";
        public const string AUD_106 = "AUD106";
        public const string GenericErrorMessage = "There is some issue occured, please contact to Application Administrator.";
        public const string AUA107 = "AUA-107";
        public const string AUA107Msg = "Article not mapping with the portal, there is no enty in article portal mapping table.";
        public const string AUA108 = "AUA-108";
        public const string AUA108Msg = "Article not found";
        public const string AUA109 = "AUA-109";
        public const string AUA109Msg = "New Article Code Can't be Empty";
        public const string AUA110 = "AUA-110";
        public const string AUA110Msg = "New Version Can't be Empty Or Wrong Version ";
        public const string AUA201 = "AUA-201";
        public const string AUA201Msg = "New Guided help code Can't be Empty";
        public const string AUA202 = "AUA-202";
        public const string AUA202Msg = "Question Code Can't be Empty for new version";
        public const string AUA203 = "AUA-203";
        public const string AUA203Msg = "There is no questions and answers in guided help ";
        /// <summary>
        /// This code indicate thats -Unable to connect Database 
        /// </summary>
        public const string AUDB600 = "AUDB-600";
        /// <summary>
        /// This code indicate thats -Unable to connect Web Api from Web Application
        /// </summary>
        public const string AUW600 = "AUW-600";
        public const string AUW601 = "AUW-601";
        public const string AUW601Msg = "Configuration Tag is missing in Web-Application web.config.";
        public const string AUW602 = "AUW-602";
        public const string AUW602Msg = "Configuration Tag value is missing in Web-Application web.config.";
        public const string AUW603 = "AUW-603";
        public const string AUW603Msg = "Api Timeout";
        //Web Application Try Catch Code
        public const string AUWTB = "AUWTB-600";//Common code for try catch for Web Application
        //API Try Catch Code
        public const string AUATB = "AUATB-600";//Common code for try catch for API
        //API Try Catch Code
        public const string AUAEP = "AUAEP-1";//Common Null parameter
        public const string IMGB101 = "IMGB-101";//
        public const string IMGB101Msg = "Uploading problem in image bank server, detail is ";

        public const string ATTB101 = "ATTB-101";//
        public const string ATTB101Msg = "Uploading problem in attachment bank server, detail is ";


        public static ErrorProp GetCustomeHttpErrorCode(HttpResponseMessage response, string prefix)
        {
            ErrorProp errorprop = new ErrorProp();
            int code = (int)response.StatusCode;
            if (code == (int)HttpStatusCode.GatewayTimeout)
            {
                errorprop.ErrorCode = prefix + "-" + code.ToString();
                errorprop.ErrorDetail = response.ReasonPhrase;
            }
            else if (code == (int)HttpStatusCode.InternalServerError)
            {
                errorprop.ErrorCode = prefix + "-" + code.ToString();
                errorprop.ErrorDetail = response.ReasonPhrase; //NotFound-
            }
            else if (code == (int)HttpStatusCode.NotFound)
            {
                errorprop.ErrorCode = prefix + "-" + code.ToString();
                errorprop.ErrorDetail = response.ReasonPhrase; //
            }
            else
            {
                errorprop.ErrorCode = prefix + "-" + code.ToString();
                errorprop.ErrorDetail = response.ReasonPhrase;
            }
            return errorprop;
        }
        /// <summary>
        /// Api Try catch issue
        /// </summary>
        /// <param name="ex"></param>
        /// <returns></returns>
        public static ErrorProp GetApiTryCatchErrorcode(Exception ex)
        {
            ErrorProp errorprop = new ErrorProp();
            try
            {
                if (ex != null)
                {
                    if (AUDB600 == ex.Message)
                    {
                        errorprop.ErrorCode = AUDB600;
                        errorprop.ErrorDetail = "Unable to connect Database " + ex.ToString();
                    }
                    else
                    {
                        errorprop.ErrorCode = AUATB;
                        errorprop.ErrorDetail = ex.ToString();
                    }
                }
                else
                {
                    errorprop.ErrorCode = AUATB;
                    errorprop.ErrorDetail = "error";
                }
            }
            catch (Exception ex1)
            {
                errorprop.ErrorCode = AUATB;
                errorprop.ErrorDetail = ex1.ToString();
            }
            return errorprop;
        }
        /// <summary>
        /// Web Authoring Try catch issue
        /// </summary>
        /// <param name="ex"></param>
        /// <returns></returns>
        public static ErrorProp GetWebTryCatchErrorcode(Exception ex)
        {
            ErrorProp errorprop = new ErrorProp();
            if (ex != null)
            {
                if (ex.InnerException != null
                    && ("Unable to connect to the remote server" == Convert.ToString(ex.InnerException.Message)
                    || ex.InnerException.Message.ToLower().IndexOf("the remote name could not be resolved") > 0
                   || ex.InnerException.Message.ToLower().IndexOf("connection refused") > 0)) //
                {
                    errorprop.ErrorCode = AUW600;  //Unable to connect to the remote server
                    errorprop.ErrorDetail = ex.ToString();//GenericErrorMessage;
                }
                else if ("A task was canceled." == ex.Message)
                {
                    errorprop.ErrorCode = AUW603;  //Unable to connect to the remote server
                    errorprop.ErrorDetail = AUW603Msg;//GenericErrorMessage;
                }
                else
                {
                    errorprop.ErrorCode = AUWTB;
                    errorprop.ErrorDetail = ex.ToString();//HttpStatusCode.InternalServerError
                }
            }
            else
            {
                errorprop.ErrorCode = AUWTB;
                errorprop.ErrorDetail = "error";
            }
            return errorprop;
        }
    }
    public class ErrorCodeRedisCache
    {
        #region Redis Cache Error Code and Messages
        #region Critcal Error
        public const string RC500 = "RC-500";//Unable to connect Redis Cache
        public const string RC500Msg = "Unable to connect Redis Cache.";
        public const string RC501 = "RC-501";//Common Code for Redis Cache
        public const string RC501Msg = "Unable to create context of Redis Server";//"Unable to connect Redis Cache.";
        public const string RC502 = "RC-502";//
        public const string RC502Msg = "IsRedisEnable configuration is disabled, please enable(Y) for insertion in redis cache ";
        public const string RC503 = "RC-503";//
        public const string RC503Msg = "IsRedisEnable Configuration Tag is missing in Api web.config.";
        public const string RC510 = "RC-510";//Configuration Tag is missing in Api web.config.
        public const string RC510Msg = "Configuration Tag is missing in Api web.config.";//Configuration Tag is missing in Api web.config.
        #endregion
        #region Error Message
        public const string RC1001 = "RC-1001";//
        public const string RC1001Msg = "Article not updated in cache";
        public const string RC1002 = "RC-1002";//
        public const string RC1002Msg = "Article not removed in cache";
        public const string RC1003 = "RC-1003";//
        public const string RC1004 = "RC-1004";//
        public const string RC1004Msg = "Portal Configuration not updated in Redis cache";
        public const string RC1005 = "RC-1005";//
        public const string RC1005Msg = "Portal Configuration data is empty";
        public const string RC1006 = "RC-1006";//
        public const string RC1006Msg = "Portal Configuration not removed in cache";
        public const string RC1007 = "RC-1007";//
        public const string RC1007Msg = "GuideHelp not updated in cache";
        public const string RC1008 = "RC-1008";//
        public const string RC1008Msg = "GuideHelp not updated in cache";
        public const string RC1009 = "RC-1009";//
        public const string RC1009Msg = "Guided Help not removed in cache";
        public const string RC1010 = "RC-1010";//
        public const string RC1010Msg = "GuideHelp Question not updated in cache";
        public const string RC1011 = "RC-1011";//
        public const string RC1011Msg = "Guided Help question not removed in cache";
        public const string RC1012 = "RC-1012";//
        public const string RC1012Msg = "Macro not updated in cache";
        public const string RC1013 = "RC-1013";//
        public const string RC1013Msg = "Macro data is empty";
        public const string RC1014 = "RC-1014";//
        public const string RC1014Msg = "Macro not removed in cache";
        public const string RC1015 = "RC-1015";//
        public const string RC1015Msg = "Portal topic tree data is empty";
        public const string RC1016 = "RC-1016";//
        public const string RC1016Msg = "Portal topic tree not removed in cache";
        public const string RC1017 = "RC-1017";//
        public const string RC1017Msg = "GuideHelp Question is not available in cache";
        public const string RC1018 = "RC-1018";//
        public const string RC1018Msg = "GuideHelp Scenario detail is not available in cache";
        #endregion
        public static ErrorProp RedisCacheMessagecode(Exception ex)
        {
            ErrorProp errorprop = new ErrorProp();
            if (RC510 == ex.Message)
            {
                errorprop.ErrorCode = RC510;
                errorprop.ErrorDetail = RC510Msg + " More Detail : " + ex.ToString();
            }
            else if (ex.Message.Contains("No connection is available to service this operation:"))
            {
                errorprop.ErrorCode = RC500;
                errorprop.ErrorDetail = RC500Msg + " More Detail : " + ex.ToString();
            }
            else
            {
                errorprop.ErrorCode = RC501;
                errorprop.ErrorDetail = ex.ToString();
            }
            return errorprop;
        }
        #endregion
    }
    public class ErrorCodeElasticSearch
    {
        public const string IsElasticEnable = "IsElasticEnable";
        public const string ElasticSearchInsertURL = "ElasticSearchInsertURL";
        public const string ElasticSearchDeleteURL = "ElasticSearchDeleteURL";
        public const string ElasticSearchUpdatePortalURL = "ElasticSearchUpdatePortalURL";
        public const string ElasticSearchUpdateWeightageURL = "ElasticSearchUpdateWeightageURL";
        #region Elastic Search Error Code and Messages
        public const string AUAES500 = "AUAES-500";//Unable to connect Elastic Search
        public const string AUAES500Msg = "Unable to connect Elastic Search Api.";
        public const string AUAES501 = "AUAES-501";//Common Code for Elastic Search
        public const string AUAES501Msg = "Unable to connect Elastic Search.";
        public const string AUAES502 = "AUAES-502";//
        public const string AUAES502Msg = "IsElasticEnable configuration is disabled, please enable(Y) for insertion in elastic search ";
        public const string AUAES503 = "AUAES-503";//
        public const string AUAES503Msg = "Configuration is not available in config file.";
        public const string AUAES510 = "AUAES-510";//Configuration Tag is missing in Api web.config.
        public const string AUAES510Msg = "Configuration Tag is missing in Api web.config.";//Configuration Tag is missing in Api web.config.
        // Only for Reference error messages which are declared in elastic serach api 
        /*
       public const string SampleConstant = "constant";
       public const string SUCCESS_ERRORCODE = "ES-01";
       public const string SUCCESS_ERRORMESSAGE = "Success.";
       public const string NOT_FOUND_ERRORCODE= "ES-02";
       public const string NOT_FOUND_ERRORMESSAGE = "Not found.";
       public const string HIT_COUNT_SUCCESSFULLY_UPDATE_ERRORCODE = "ES-03";
       public const string HIT_COUNT_SUCCESSFULLY_UPDATE_ERRORMESSAGE= "Hit count successfully update.";
       public const string DATE_SHOULD_NOT_BE_GREATER_THAN_TODAY_DATE_ERRORCODE = "ES-04";
       public const string DATE_SHOULD_NOT_BE_GREATER_THAN_TODAY_DATE_ERRORMESSAGE = "Date should not be greater than today date.";
       public const string LOGGER_DATE_LIST_SHOULD_BE_GREATER_THAN_1_AND_LESS_THAN_EERORCODE = "ES-05";
       public const string LOGGER_DATE_LIST_SHOULD_BE_GREATER_THAN_1_AND_LESS_THAN_ERRORMESSAGE = "Logger date list should be greater than 1 and less than 5";
       public const string YOU_ARE_UNAUTHORIZED_TO_ACCESS_THIS_RESOURCE_ERRORCODE = "ES-06";
       public const string YOU_ARE_UNAUTHORIZED_TO_ACCESS_THIS_RESOURCE_ERRORMESSAGE = "You are unauthorized to access this resource.";
       public const string API_SECURITY_KEY_IS_MISSING_ERRORCODE = "ES-07";
       public const string API_SECURITY_KEY_IS_MISSING_ERRORMESSAGE = "API security key is missing.";
       public const string USERID_HEADER_IS_MISSING_ERRORCODE = "ES-08";
       public const string USERID_HEADER_IS_MISSING_ERRORMESSAGE = "userId header is missing.";
       public const string SESSIONID_HEADER_IS_MISSING_ERRORCODE = "ES-09";
       public const string SESSIONID_HEADER_IS_MISSING_ERRORMESSAGE = "sessionId header is missing.";
       public const string AUTHORIZATION_HEADER_IS_MISSING_ERRORCODE = "ES-10";
       public const string AUTHORIZATION_HEADER_IS_MISSING_ERRORMESSAGE = "Authorization header is missing.";
       public const string AUTHENTICATIONFAILED_ERRORCODE = "ES-11";
       public const string AUTHENTICATIONFAILED_ERRORMESSAGE = "Authentication failed.";
       public const string INTERNAL_SERVER_ERROR_ERRORCODE = "ES-12";
       public const string INTERNAL_SERVER_ERROR_ERRORMESSAGE = "Internal server error.";
       public const string VALIDATION_ERRORCODE= "ES-13";
       public const string VALIDATION_ERRORMESSAGE = "Validation";
       public const string WEIGHTAGE_LIST_ERRORCODE = "ES-14";
       public const string WEIGHTAGE_LIST_ERRORMESSAGE = "Weightage list Can't be Empty";
       public const string ARTICLE_LIST_ERRORCODE = "ES-15";
       public const string ARTICLE_LIST_ERRORMESSAGE = "Article list Can't be Empty";
       public const string PORTAL_LIST_ERRORCODE = "ES-16";
       public const string PORTAL_LIST_ERRORMESSAGE = "Portal list Can't be Empty";
   */
        #endregion
        public static ErrorProp CheckElasticWebConfig(string keyname)
        {
            ErrorProp error = new ErrorProp();
            try
            {
                string iselastictag = "";// OneClick.KM.Core.Utility.AppSettings.GetConfigurationValue(keyname);
                if (iselastictag != null && iselastictag != "")
                {
                    error.ErrorCode = "0";
                    if (iselastictag == "N")
                    {
                        // elastic search feature is not enable                    
                        error.ErrorCode = ErrorCodeElasticSearch.AUAES502;
                        error.ErrorDetail = ErrorCodeElasticSearch.AUAES502Msg;
                        //Logger.ESLog.Info("Elastic Info : " + error.GetMessageInfo);
                    }
                }
                else
                {
                    // Tag is missing
                    error.ErrorCode = ErrorCodeElasticSearch.AUAES503;
                    error.ErrorDetail = ErrorCodeElasticSearch.AUAES503Msg;
                    //error = CommonMethods.GetError("AUA103", "IsElasticEnable configuration is not available in config file");
                }
            }
            catch (Exception ex)
            {
                error.ErrorCode = ErrorCodeConstant.AUATB;
                error.ErrorDetail = ex.ToString();
            }
            return error;
        }





    }
}
