﻿using OneClick.KM.Core;
using System;

namespace OneClick.KM.Model
{
    public class Response
    {
        public Response()
        {
            Error = new ErrorProp();
        }
        public ErrorProp Error { get; set; }
        public Object Result { get; set; }
    }
}
