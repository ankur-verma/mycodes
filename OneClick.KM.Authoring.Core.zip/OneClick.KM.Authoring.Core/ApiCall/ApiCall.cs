﻿
using Newtonsoft.Json;
using OneClick.KM.Authoring.Core.Utility;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Diagnostics;

namespace OneClick.KM.Authoring.Core.ApiCall
{
    public class ApiCall
    {

        private ErrorProp GetMultiUriConfigure(string apiurl,out string[] arrayValues)
        {
            ErrorProp errReturn = null;
            arrayValues = null;
           // string apiMultiUrl = uri;

            if (!string.IsNullOrEmpty(apiurl))
            {
                arrayValues = apiurl.Split(',');
                if (arrayValues.Length > 0)
                {
                    errReturn = new ErrorProp { ErrorCode = "0", ErrorDetail = "Success" };
                }
                else
                {
                    errReturn = new ErrorProp { ErrorCode = ErrorCodeConstant.AUW602, ErrorDetail = ErrorCodeConstant.AUW602Msg };
                    //Logger.AppLog.Error(" ErrorCode: " + errReturn.ErrorCode + " : " + errReturn.ErrorDetail);

                    errReturn.ErrorDetail = ErrorCodeConstant.GenericErrorMessage;

                }
                return errReturn;
            }
            else
            {

                errReturn = new ErrorProp { ErrorCode = ErrorCodeConstant.AUW601, ErrorDetail = ErrorCodeConstant.AUW601Msg };
                // Logger.AppLog.Error(" ErrorCode: " + errReturn.ErrorCode + " : " + errReturn.ErrorDetail);

                errReturn.ErrorDetail = ErrorCodeConstant.GenericErrorMessage;
                return errReturn;

            }
        }

        public ErrorProp CallWebApi_V1(ApiProp objprop)
        {
            string[] arrayValues = null;
            ErrorProp errReturn = GetMultiUriConfigure(objprop.ApiUri ,out arrayValues);
            if (errReturn.ErrorCode == "0")
            {
                bool isUriExist;

                for (int ival = 0; ival < arrayValues.Length; ival++)
                {
                    objprop.ApiUri = arrayValues[ival].ToString();

                    errReturn = InnerCallWebApi_V1(objprop, out isUriExist);

                    // This code is for multiple api, if one is down then checking for another active api url
                    if (isUriExist && errReturn.ErrorCode != ErrorCodeConstant.AUW600)
                    //if (isUriExist)
                    {
                        return errReturn;
                    }
                }
                return errReturn;

            }
            else
            {

                //Logger.AppLog.Error(" ErrorCode: " + errReturn.ErrorCode + " : " + errReturn.ErrorDetail);
                errReturn.ErrorDetail = ErrorCodeConstant.GenericErrorMessage;
                return errReturn;
            }
        }

        public ErrorProp InnerCallWebApi_V1(ApiProp objprop, out bool isApiExist)
        {
            isApiExist = true;
           
            string url = System.IO.Path.Combine(objprop.ApiUri, objprop.ApiName);
            //string url = System.IO.Path.Combine(objprop.ApiUri, objprop.ApiName);
            string username = objprop.Username;//Convert.ToString(HttpContext.Current.KMSSessionClass.UserName);
            string sessionId = objprop.SessionId;//Convert.ToString(KMSSessionClass.SessionId);
            string userId = objprop.UserId;//Convert.ToString(KMSSessionClass.UserId);
            ErrorProp errReturn = new ErrorProp();
            try
            {

                HttpResponseMessage response = null;

                using (HttpClient client = new HttpClient())
                {
                    var stopWatch = Stopwatch.StartNew();
                    var requestTime = DateTime.UtcNow;

                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(objprop.ContentType));
                    client.DefaultRequestHeaders.Add("SessionId", sessionId);
                    client.DefaultRequestHeaders.Add("UserId", userId);
                    client.DefaultRequestHeaders.Add("UserName", username);
                    client.DefaultRequestHeaders.Add("api-version", "2.0");
             
                    //client.DefaultRequestHeaders.ConnectionClose = true;

                    if (objprop.HeaderList.Count > 0)
                    {
                        foreach (var item in objprop.HeaderList)
                        {
                            client.DefaultRequestHeaders.Add(item.RequestHeader, item.RequestHeaderValue);
                        }
                    }
                    if (objprop.Method == APIMethodType.GET.ToString())
                    {
                        response = client.GetAsync(url).Result;

                    }
                    else if (objprop.Method == APIMethodType.POST.ToString())
                    {
                      
                        var postContent = new StringContent(objprop.DataForPost, System.Text.Encoding.UTF8, objprop.ContentType);
                        response = client.PostAsync(url, postContent).Result;
                        
                    }
                    else if (objprop.Method == APIMethodType.PUT.ToString())
                    {
                        var postContent = new StringContent(objprop.DataForPost, System.Text.Encoding.UTF8, objprop.ContentType);
                        response = client.PutAsync(url, postContent).Result;

                    }
                    else if (objprop.Method == APIMethodType.DELETE.ToString())
                    {
                        response = client.DeleteAsync(url).Result;

                    }
                    else if (objprop.Method.ToUpper() == APIMethodType.PATCH.ToString())
                    {
                        var postContent = new StringContent(objprop.DataForPost, System.Text.Encoding.UTF8, objprop.ContentType);
                        var method = new HttpMethod(objprop.Method);
                        var request = new HttpRequestMessage(method, url)
                        {
                            Content = postContent
                        };
                        response = client.SendAsync(request).Result;
                    }

                    var result = response.Content.ReadAsStringAsync().Result;
                    
                    if (response.IsSuccessStatusCode)
                    {
                        errReturn.ErrorCode = "0";
                        ApiResponse res = new ApiResponse();
                        if (objprop.CustomError != null)
                        {

                            ErrorProp  errPro= JsonConvert.DeserializeObject<ErrorProp>(result);
                            res.Error.ErrorCode = errPro.ErrorCode;
                            res.Error.ErrorDetail = errPro.ErrorDetail;
                            res.Result = errPro.Result;
                        }
                        else
                        {
                            res = JsonConvert.DeserializeObject<ApiResponse>(result);

                        }

                        if (res.Error.ErrorCode == "0")
                        {
                            errReturn.ErrorDetail = Convert.ToString(res.Error.ErrorDetail);////New added for Error msg fix
                        }
                        else
                        {
                            errReturn.ErrorCode = res.Error.ErrorCode;
                            errReturn.ErrorDetail = res.Error.ErrorDetail;                            
                        }

                        if (res.Error.ResponseData != null)
                        {
                            errReturn.ResponseData = res.Error.ResponseData;
                        }

                        if (res.Result != null)
                        {
                            errReturn.ReturnValue = Convert.ToString(res.Result);
                        }
                        Logger.APICallLog.Error(KMSAppSettings.LogFormatter(userId, username ,requestTime, stopWatch.ElapsedMilliseconds,url, JsonConvert.SerializeObject(objprop.DataForPost), Convert.ToString(res.Result)));
                    }
                    else
                    {
                        errReturn = ErrorCodeConstant.GetCustomeHttpErrorCode(response, ModuleType.AUW.ToString());
                        Logger.AppLog.Error("ÜserId: " + userId + " ÜserName: " + username + " ErrorCode: " + errReturn.ErrorCode + " : " + errReturn.ErrorDetail + " : URL- " + url);
                        //MongoMethods.InsertErrorLogsInMongoDB(userId, username, url, null, errReturn); this iscommented because api not working
                        errReturn.ErrorDetail = ErrorCodeConstant.GenericErrorMessage;

                        //errReturn.ReturnValue = "";
                        isApiExist = false;
                    }

                }

            }
          
            catch (AggregateException ex)
            {
                int ival = 0;
                foreach (var e in ex.Flatten().InnerExceptions)
                {
                    if (ival == 0)
                    {
                        errReturn = ErrorCodeConstant.GetWebTryCatchErrorcode(e);

                    }
                    ival++;
                    Logger.AppLog.Error("ÜserId: " + userId + " ÜserName: " + username + " ErrorCode: " + errReturn.ErrorCode + " : From Exceptions Block : Message- " + e.Message + " : InnerException- " + e.InnerException + " : URL- " + url);
                    //MongoMethods.InsertErrorLogsInMongoDB(userId, username, url, e, errReturn);

                }
                errReturn.ErrorDetail = ErrorCodeConstant.GenericErrorMessage;
            }
            catch (Exception ex)
            {

                errReturn = ErrorCodeConstant.GetWebTryCatchErrorcode(ex);
               Logger.AppLog.Error("ÜserId: " + userId + " ÜserName: " + username + " ErrorCode: " + errReturn.ErrorCode + " : From Exceptions Block : Message- " + ex.Message + " : InnerException- " + ex.InnerException + " : URL- " + url);
                //MongoMethods.InsertErrorLogsInMongoDB(userId, username, url, ex, errReturn);
                errReturn.ErrorDetail = ErrorCodeConstant.GenericErrorMessage;
            }
            return errReturn;

        }

       
        
    
    }
 

}
