﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OneClick.KM.Authoring.Core.Security;

namespace OneClick.KM.Authoring.Core.ApiCall
{
    public class ApiMethodNames
    {


        public const string Get_Cities = "Get_Cities";
        public const string Insert_User_Register = "Insert_User_Register";
        public const string Get_Customer_Validate_drReddy = "Get_Customer";

        public const string Get_Customer_Validate_RegisteredUsers = "Get_Customer_Validate_RegisteredUsers";


        public const string Get_RegisteredUsers = "Get_RegisteredUsers";

        #region Utility

        public const string Get_Clients = "api/Utility/ClientData";
        public const string Get_PortalData = "api/Utility/PortalData";
        public const string Get_CategoryData = "api/Utility/CategoryData";
        public const string Get_SubCategoryData = "api/Utility/SubCategoryData";
        public const string Get_SubSubCategoryData = "api/Utility/SubSubCategoryData";
        public const string Get_ScopePriorityData = "api/Utility/ScopePriorityData";//for new kms ScopePriorityData_V1



        // public const string Get_ScopePriorityData = "api/Utility/ScopePriorityData";
        public const string Post_ScenarioCreate = "api/SOPAPI/ScenarioCreate";
        public const string Get_ContentTypeData = "api/Utility/ContentTypeData";//for new kms

        public const string GetBasicEntry = "api/Utility/BasicEntry";
        public const string GetArticleSection = "api/Utility/ArticleSection";

        public const string ErrorLog = "api/Utility/ErrorLog";

        #endregion

        #region Keywords
        public const string KeywordList = "api/keyword/KeywordList";
        public const string savekey = "api/keyword/savekey";
        public const string ArticleKeywordList = "api/keyword/ArticleKeywords";
        public const string DeleteKeyword = "api/keyword/KeywordDelete";
        public const string GetSearchkeyword = "api/keyword/Searchkeyword";



        #endregion

        #region ArticleContent
        public const string Get_ArticleHeader = "api/Article/ArticleHeader";
        public const string UploadContent = "api/Article/AddArticlecontent";
        public const string ArticleContentForEdit = "api/Article/ArticleContentForEdit";

        public const string editContent = "api/Article/editContent";

        public const string ClientCapping = "api/Utility/GetClientConfiguration";

        #endregion


        #region LoginApi Methods Name

        //api/Account/login
        public const string CheckLogin = "api/Account/login";
        public const string ClientManagementLogin = "api/ClientManagement/UserLoginDetails";
        //public const string CheckLogin = "api/Login/login";

        public const string Logout = "api/Account/Logout";
        //public const string Logout = "api/Login/Logout";
        public const string CheckSessionId = "api/Utility/checksession";

        #endregion

        #region Article

        public const string Check_BusinessCode = "api/Article/CheckBusinessCode";
        public const string Post_NewArticle = "api/Article/CreateArticle_V1";//for new kms
        public const string Post_NewArticleClone = "api/Article/createarticleClone";
        public const string Get_ArticleList = "api/Article/ArticleList";
        // public const string Get_ManagedPublishedArticles = "api/Article/ManagedPublishedArticles";
        public const string Get_ManagedPublishedArticles = "api/Article/ManagedPublishedArticles";

        //public const string Get_GetSearchAccessoriesList = "api/Article/SearchAccessoriesList";
        public const string Get_GetSearchAccessoriesList = "api/Article/SearchAccessoriesList";

        public const string Get_SearchArticleLinkData = "api/Article/SearchArticleLinkData";
        public const string Get_SearchArticleLinkTitle = "api/Article/SearchArticleLinkTitle";
        public const string Get_ArticlePreviewData = "api/Article/ArticlePreview";
        public const string Get_ArchiveArticlePreveiw = "api/Article/ArchiveArticlePreveiw";
        public const string Publish_Article = "api/Article/ArticlePublishTemp";// new kms temp
        public const string Update_Article_Status = "api/Article/UpdateArticleStatus";
        public const string Get_AllArticles = "api/Article/AllArticles";
        public const string GetArticleBasicForEdit = "api/Article/ArticleBasicForEdit";
        public const string GetArticleBasicForEdit_V1 = "api/Article/ArticleBasicForEdit_V1";//new kms
        public const string ContentChange = "api/Article/ContentChange";//new kms
        public const string EditArticle = "api/Article/EditArticle";
        public const string EditArticle_V1 = "api/Article/EditArticle_V1";//new kms
        public const string Remove_Article = "api/Article/RemoveArticle";
        public const string Archive_Pub_Articles = "api/Article/ArchivePublishedArticle";
        public const string Get_PublishedArticleList = "api/Article/publishedArticleVisibilityList";
        public const string Get_SearchedInboxArticleList = "api/Article/SearchInboxArticleList";

        public const string Get_SearchPublishedArticleList = "api/Article/SearchPublishedArticleList";
        public const string UpdateArticleVisibility = "api/Article/HideUnhideArticle";

        public const string GetArticleListSrchBrws = "api/Article/ArticleListSrchBrws";
        public const string UpdateArticleListSrchBrws = "api/Article/UpdateArticleSrchBrws";
        public const string Get_ArticleSummary = "api/Article/ArticleSummary";


        public const string Get_InsGroupList = "api/Article/InsertGroup";
        //public const string Get_InsGroupList = "api/ArticleApi/InsertGroup";
        public const string Get_AllGroupList = "api/Article/AllGroupList";
        //public const string Get_AllGroupList = "api/ArticleApi/AllGroupList";
        public const string UpdateGroupList = "api/Article/UpdateGroupOrder";

        public const string DeleteGroup = "api/Article/DeleteGroup";
        //public const string DeleteGroup = "api/ArticleApi/DeleteGroup";

        public const string EditGroupName = "api/Article/EditGroupName";
        //public const string EditGroupName = "api/ArticleApi/EditGroupName";


        public const string ArticlePreviewinfo = "api/Article/ArticlePreviewinfo";


        public const string Get_MacroContent = "api/Article/MacroContent";

        public const string Revive_Article = "api/Article/ReviveArticleData";
        public const string Broken_Art_List = "api/Article/BrokenLArticleList";
        public const string Get_SearchedPublishedArticleListwithDate = "api/Article/PublishedArticleListwithDate";

        //public const string checkArticleMap = "api/Article/checkArticleMap";
        public const string checkArticleMap = "api/Article/checkArticleMap";

        // public const string CheckArticleReviveVersion = "api/Article/CheckArticleReviveVersion";
        public const string CheckArticleReviveVersion = "api/Article/CheckArticleReviveVersion";

        public const string CheckCategoryMapping = "api/Article/CheckCategoryMapping";

        #endregion

        #region Search Article Inbox
        public const string Get_Searched_Articles_List = "api/Article/ArticleSearchList";
        public const string Check_Access_For_Art = "api/Article/CheckUserAccessForArticle";
        #endregion

        #region ActivityApi Methods Name
        //public const string GetActivityList = "api/Activity/ActivityList";
        public const string GetClientActivityList = "api/ClientManagement/GetClientActivityList";

        public const string GetActivityList ="api/Activity/ActivityListV2";// "api/Activity/ActivityList";//



        #endregion

        #region Article Attachments
        public const string Get_Article_Attachment_Data = "api/Article/ArticleAttachmentDetails";
        public const string Post_Attachment_Files = "api/Article/ArticleCreationAttachment";
        public const string Delete_Attachment_Files = "api/Article/RemoveArticleAttachment";
        //public const string Attachment_Download_SubUrl = "api/Article/DownloadAttachment?attachmentcode=";

        public const string Attachment_Download = "api/Article/DownloadAttachment";

        public const string Attachment_Download_SubUrl = "DownloadAttachment?attachmentcode=";
        public const string GetFaqDocAttachment = "api/Article/GetFaqDocAttachment";
        public const string PostArticleAttchment = "api/Article/FaqDocAttachmentCreation";
        public const string DeleteFaqDocAttachment = "api/Article/RemoveFaqDocAttachment";
        public const string DownloadAttachmentFile = "api/Article/DownloadAttachFrmDBServer";






        #endregion

        #region Document Attachment

        public const string Client_Attachment_Files = "api/Attachment/ClientCreationAttachment";
        //public const string Client_Attachment_Files = "api/AttachmentApi/ClientCreationAttachment";
        public const string Get_Attachment_Files = "api/Attachment/Get_All_Attachment";
        //public const string Get_Attachment_Files = "api/AttachmentApi/Get_All_Attachment";
        public const string Delete_Attachment = "api/Attachment/RemoveAttachment";

        public const string AttachmentLocateInfo = "api/Attachment/AttachmentLocateInfo";

        //public const string Delete_Attachment = "api/AttachmentApi/RemoveAttachment";
        public const string Search_Attachment = "api/Attachment/SearchAttachment";
        //public const string Search_Attachment = "api/AttachmentApi/SearchAttachment";
        public const string Update_Attachment = "api/Attachment/UpdateAttachmentFileName";
        //public const string Update_Attachment = "api/AttachmentApi/UpdateAttachmentFileName";
        public const string UpdateAttchment = "api/Attachment/UpdateAttachment";
        //public const string UpdateAttchment= "api/AttachmentApi/UpdateAttachment";

        #endregion

        #region Related Articles
        public const string Search_Related_Articles = "api/Article/searchRelatedArticle";
        public const string Related_Articles_Data = "api/Article/RelatedArticleData";
        public const string Related_Articles_Data_V1 = "api/Article/RelatedArticleData_V1";
        public const string Relate_Articles = "api/Article/relateArticle";

        public const string RemoveRelatedArticle = "api/Article/RelatedArticleDelete";

        public const string Get_ArticleAccessory = "api/Article/RelatedAccessoryList";
        public const string RemoveBrokenAccessoryAndUnpublish = "api/Article/UnpublishBrokenLink";
        public const string Search_Related_Articles_V1 = "api/Article/searchRelatedArticle_V1";

        #endregion

        #region GuidedHelp

        //public const string ScenarioCreate = "api/SOPAPI/ScenarioCreateNew";
        //public const string ScenarioUpdate = "api/SOPAPI/ScenarioUpdateNew";
        //public const string GetScenarioDetails = "api/SOPAPI/SOPDetailsByScenrioCode";

        public const string ScenarioCreate = "api/GuidedHelp/ScenarioCreate";
        public const string ScenarioUpdate = "api/GuidedHelp/EditScenario";
        public const string GetScenarioDetails = "api/GuidedHelp/SOPDetailsByScenrioCode";

        //public const string Get_GuidedHelp_Details = "api/SOPAPI/GuidedHelpDetails";
        public const string Get_GuidedHelp_Details = "api/GuidedHelp/GuidedHelpDetails";
        //public const string Get_SearchInboxGuidedHelpList = "api/SOPAPI/SearchInboxGuidedHelpList";
        public const string Get_SearchInboxGuidedHelpList = "api/GuidedHelp/SearchInboxGuidedHelpList";


        public const string Get_SearchInboxGuidedHelpList_Notuse = "api/GuidedHelpWorkFlow/SearchInboxArticleList";







        public const string GetAllGuidedHelp = "api/GuidedHelp/AllGuidedHelp";
        //public const string GetAllGuidedHelp = "api/SOPAPI/AllGuidedHelp";

        public const string UpdateScenario = "api/SOPAPI/EditScenario";

        public const string Delete_GuidedHelp = "api/GuidedHelp/RemoveGuidedHelp";
        //public const string Delete_GuidedHelp = "api/SOPAPI/RemoveGuidedHelp";

        //public const string Delete_Published_GuidedHelp = "api/SOPAPI/RemovePublishedScenerio";
        public const string Delete_Published_GuidedHelp = "api/GuidedHelp/RemovePublishedScenerio";


        //public const string GetAllPublishedGuidedHelp = "api/SOPAPI/AllPublishedGuidedHelp";



        //public const string GetAllPublishedGuidedHelp = "api/SOPAPI/AllPublishedGuidedHelp";
        public const string GetAllPublishedGuidedHelp = "api/GuidedHelp/AllPublishedGuidedHelp";



        public const string Get_InboxQuesAnsList = "api/GuidedHelp/InboxGuidedQuesAnsList";

        //public const string Get_SearchPublishedGuidedHelpList = "api/SOPAPI/SearchPublishedGuidedHelpList";
        public const string Get_SearchPublishedGuidedHelpList = "api/GuidedHelp/SearchPublishedGuidedHelpList";

        // public const string Get_PublishedGuidedQuesAnsList = "api/SOPAPI/PublishedGuidedQuesAnsList";
        public const string Get_PublishedGuidedQuesAnsList = "api/GuidedHelp/PublishedGuidedQuesAnsList";

        public const string Get_GuidedHelpNextQuestion = "api/GuidedHelp/GuidedHelpNextQuestion";
        //public const string Get_GuidedHelpNextQuestion = "api/SOPAPI/GuidedHelpNextQuestion";

        public const string GetQuestionAndAnswer = "api/GuidedHelp/ManageQuesAns";
        //public const string GetQuestionAndAnswer = "api/SOPAPI/ManageQuesAns";

        //public const string GetQuestionByScenario = "api/SOPAPI/GetQuestionByScenario";
        public const string GetQuestionByScenario = "api/GuidedHelp/GetQuestionByScenario";

        // public const string UpdateQuestion = "api/SOPAPI/UpdateQuestion";
        public const string UpdateQuestion = "api/GuidedHelp/UpdateQuestion";

        // public const string CreateQuestion = "api/SOPAPI/CreateQuestion";
        public const string CreateQuestion = "api/GuidedHelp/CreateQuestion";



        public const string GetPortalTags = "api/GuidedHelp/GetPortalTags";
        //public const string GetPortalTags = "api/SOPAPI/GetPortalTags";

        public const string GetAnswerByQuesAns_Code = "api/GuidedHelp/GetAnswerByQuesAns_Code";
        //public const string GetAnswerByQuesAns_Code = "api/SOPAPI/GetAnswerByQuesAns_Code";

        //public const string UpdateAnswer = "api/SOPAPI/UpdateAnswer";
        public const string UpdateAnswer = "api/GuidedHelp/UpdateAnswer";


        //public const string AddAnswer = "api/SOPAPI/AddAnswer";
        public const string AddAnswer = "api/GuidedHelp/AddAnswer";

        public const string GetQuestionListInAns = "api/GuidedHelp/GetQuestionListInAns";
        //public const string GetQuestionListInAns = "api/SOPAPI/GetQuestionListInAns";

        //public const string GetMappedArticlesssListByQues = "api/SOPAPI/GetMappedArticlsListByQuestion";
        public const string GetMappedArticlesssListByQues = "api/GuidedHelp/GetMappedArticlsListByQuestion";

        public const string Broken_Gh_List = "api/GuidedHelp/BrokenGHList";
        //public const string Broken_Gh_List = "api/SOPAPI/BrokenGHList";



        // Delete Question or Answer in Guided Help
        //public const string DeleteQuesAnswer = "api/SOPAPI/DeleteQuesAnswer";
        public const string DeleteQuesAnswer = "api/GuidedHelp/DeleteQuesAnswer";

        //public const string DeleteArticleFromSopQuestion = "api/SOPAPI/DeleteArticleFromSopQuestion";
        public const string DeleteArticleFromSopQuestion = "api/GuidedHelp/DeleteArticleFromSopQuestion";


        //public const string Save_GuidedHelp_Add_Link = "api/SOPAPI/SaveGuidedHelpLink";
        public const string Save_GuidedHelp_Add_Link = "api/GuidedHelp/SaveGuidedHelpLink";

        public const string Get_GuidedHelp_Add_Link = "api/GuidedHelp/GuidedHelpLinkData";
        //public const string Get_GuidedHelp_Add_Link = "api/SOPAPI/GuidedHelpLinkData";


        //Preview  in Guided Help
        //public const string GuidedHelpPreview = "api/SOPAPI/GuidedHelpPreview";
        public const string GuidedHelpPreview = "api/GuidedHelp/GuidedHelpPreview";

        //public const string GuidedHelpQA = "api/SOPAPI/PreQAnsLit";
        public const string GuidedHelpQA = "api/GuidedHelp/PreQAnsLit";


        //public const string GHArticleDtl = "api/SOPAPI/GHArticleDtl";
        public const string GHArticleDtl = "api/GuidedHelp/GetGHArticleDtl";


        //public const string PreQAnsLit = "api/SOPAPI/PreQAnsLit";

        // public const string Guidedhelpinfo = "api/SOPAPI/Guidedhelpinfo";
        public const string Guidedhelpinfo = "api/GuidedHelp/Guidedhelpinfo";

        //Revive guide help from archived/deleted
        //public const string ReviveGuidedUpdate = "api/SOPAPI/ReviveGuidedUpdate";
        public const string ReviveGuidedUpdate = "api/GuidedHelp/ReviveGuidedUpdate";

        public const string GuidedhelpSetOrder = "api/GuidedHelp/GuidedhelpSetOrder";
        //public const string GuidedhelpSetOrder = "api/SOPAPI/GuidedhelpSetOrder";




        //public const string Get_GuidedHelp_Answer_Details = "api/SOPAPI/GuidedHelpQuesAnsDetails";
        public const string Get_GuidedHelp_Answer_Details = "api/GuidedHelp/GuidedHelpQuesAnsDetails";


        //public const string Search_GuidedHelp_Ques_Details = "api/SOPAPI/SearchGuidedHelpQuestion";
        public const string Search_GuidedHelp_Ques_Details = "api/GuidedHelp/SearchGuidedHelpQuestion";

        // public const string Guided_Help_Data = "api/SOPAPI/GuidedHelpData";
        public const string Guided_Help_Data = "api/GuidedHelp/GuidedHelpData";


        public const string Guided_Help_Ans_Data = "api/GuidedHelp/AnswerDetail";
        //public const string Guided_Help_Ans_Data = "api/SOPAPI/AnswerDetail";

        //public const string Guided_Help_Ques_Data = "api/SOPAPI/QuestionDetail";
        public const string Guided_Help_Ques_Data = "api/GuidedHelp/QuestionDetail";

        public const string Get_AllGuidedHelpInboxSearchedList = "api/GuidedHelp/AllGuidedHelpInboxSearchedList";
        //public const string Get_AllGuidedHelpInboxSearchedList = "api/SOPAPI/AllGuidedHelpInboxSearchedList";


        public const string CheckAllGuidedHelpAccess = "api/GuidedHelp/CheckAllGuidedHelpAccess";
        //public const string CheckAllGuidedHelpAccess = "api/SOPAPI/CheckAllGuidedHelpAccess";

        public const string AllGuidedHelpQuesAnsList = "api/GuidedHelp/AllGuidedHelpQuesAnsList";
        //public const string AllGuidedHelpQuesAnsList = "api/SOPAPI/AllGuidedHelpQuesAnsList";

        public const string GetDtAutomationKeys = "api/GuidedHelp/AllDtAnswerKey";
        public const string GetAllDtAnswerOption = "api/GuidedHelp/AllDtAnswerOption";
        public const string GetAutomationBokenSummary = "api/GuidedHelp/AutomationBokenSummary";
        public const string GetDtApiList = "api/GuidedHelp/ApiList";
        

        #region newGH
        public const string CreateGuidedHelp = "api/GuidedHelpWorkFlow/CreateGuidedHelp";
        public const string Get_GuidedHelpForEdit = "api/GuidedHelpWorkFlow/GetGuidedHelpGHW";
        public const string UpdateGuidedHelp = "api/GuidedHelpWorkFlow/UpdateGuidedHelp";
        public const string ReviveGuidedHelp = "api/GuidedHelpWorkFlow/CreateReviveCoverPageArticle";
        #endregion
        #endregion

        #region Publish-UnPublish Guided Help

        public const string ChangeStageGuidedHelp = "api/GuidedHelp/ChangeStageGuidedHelp";
        //public const string ChangeStageGuidedHelp = "api/SOPAPI/ChangeStageGuidedHelp";

        //public const string Get_GuidedHelp_Summary = "api/SOPAPI/GuidedHelpSummary";
        public const string Get_GuidedHelp_Summary = "api/GuidedHelp/GuidedHelpSummary";

        public const string Get_GHelp_Summary = "api/GuidedHelpWorkFlow/ArticleAndGHSummery";

        //public const string GuidedHelp_ChangeStatus = "api/SOPAPI/UpdateGuidedHelpStatus";
        public const string GuidedHelp_ChangeStatus = "api/GuidedHelp/UpdateGuidedHelpStatus";

        public const string PublishGuidedHelp = "api/GuidedHelp/PublishGuidedHelp";
        //public const string PublishGuidedHelp = "api/SOPAPI/PublishGuidedHelp";

        // Delete Question or Answer in Guided Help
        //public const string UnPublishGuidedHelp = "api/SOPAPI/UnPublishGuidedHelp";
        public const string UnPublishGuidedHelp = "api/GuidedHelp/UnPublishGuidedHelp";

        // new version 
        //public const string NewSOPVersion = "api/SOPAPI/NewSOPVersion";
        public const string NewSOPVersion = "api/GuidedHelp/NewSOPVersion";

        public const string GHNewVersion = "api/GuidedHelpWorkFlow/CreateNewVersionGh";
        public const string GHArticleGHInfo = "api/GuidedHelpWorkFlow/ArticleAndGHInfo";

        #region Image

        public const string Get_ArticleImages = "api/Article/GetArticleImage";
        public const string Post_ArticleImages = "api/Article/PostArticleImage";

        #endregion

        #endregion

        #region Article Circles

        public const string Get_AllCircles = "api/Article/GetAllCircles";
        public const string Post_AllCircles = "api/Article/PostArticleCircles";
        public const string Get_ArticleCircles = "api/Article/GetArticleCircles";
        public const string Post_ArticleCircles = "api/Article/PostArticleCircles";
        #endregion

        #region StoreLoc
        // public const string Get_CityStateList = "api/StoreLocApi/CityStateList";
        public const string Get_StoreDetail = "api/StoreLocatorApi/StoreDetail";
        //public const string Add_Store = "api/StoreLocApi/AddNewStore";
        public const string Add_Store = "api/StoreLocatorApi/AddNewStore";
        public const string Get_StoreList = "api/StoreLocatorApi/StoreList";
        public const string Update_Store = "api/StoreLocatorApi/EditStore";
        public const string Delete_Store = "api/StoreLocatorApi/StoreDelete";
        //public const string Get_StateList = "api/StoreLocApi/StateList";
        public const string Get_StateList = "api/StoreLocatorApi/StateList";
        public const string Get_CityList = "api/StoreLocatorApi/CityList";
        public const string StoretypebyPortal = "api/StoreLocatorApi/StoretypebyPortal";

        #endregion

        #region clientActivity
        //public const string Get_ClientDetails = "api/ClientActivityApi/clientDetails";
        public const string Get_ClientDetails = "api/ClientManagement/clientDetails";
        public const string Update_ClientDetails = "api/ClientManagement/UpdateClientDetail";


        #endregion

        #region User


        public const string Get_UserPortalDetails = "api/UserManage/UserPortalDetails";
        //public const string Get_UserPortalDetails = "api/UserManageApi/UserPortalDetails";
        public const string UpdatePortalDetails = "api/UserManage/UpdateUserPortals";
        //public const string UpdatePortalDetails = "api/UserManageApi/UpdatePortalDetails";

        public const string Get_Roles = "api/UserManage/GetUserRolesList";
        //public const string Get_Roles = "api/UserManageApi/GetUserRolesList";


        //api/UserManage/userrolesbyusertype

        public const string Get_Roles_By_UserType = "api/UserManage/UserRolesByUserType";
        //public const string Get_Roles_By_UserType = "api/UserManageApi/UserRolesByUserType";


        public const string Get_Designations = "api/UserManage/GetDesignations";
        //public const string Get_Designations = "api/UserManageApi/GetDesignations";

        public const string Get_UserByDesignations = "api/UserManageApi/GetUserByDesignations";


        public const string Get_Reporting_To_Users = "api/UserManage/ReportingToUserList";

        //public const string Get_Reporting_To_Users = "api/UserManageApi/ReportingToUserList";





        public const string Get_UserListToEdit = "api/UserManage/GetUserListToEdit";

        //public const string Get_UserListToEdit = "api/UserManageApi/GetUserListToEdit";


        public const string Get_UserList = "api/UserManage/UserList";
        //public const string Get_UserList = "api/UserManageApi/UserList";

        public const string CreateUsers = "api/UserManage/CreateUsers";
        //public const string CreateUsers = "api/UserManageApi/CreateUsers";

        public const string CreateBulkUser = "api/UserManageApi/CreateBulkUser";

        public const string Get_UserDetail = "api/UserManage/UserDetail";
        //public const string Get_UserDetail = "api/UserManageAPI/UserDetail";

        public const string UpdateUsers = "api/UserManage/UpdateUser";
        //public const string UpdateUsers = "api/UserManageApi/UpdateUser";

        public const string Get_Modules = "api/UserManage/GetUserModuleList";
        //public const string Get_Modules = "api/UserManageApi/GetUserModuleList";

        public const string CheckCurrentPassword = "api/UserManageApi/CheckCurrentPassword";


        //api/Utility/ResetPassword
        public const string ResetPassword = "api/Account/ResetPassword";
        //public const string ResetPassword = "api/UserManageApi/ResetPassword";

        public const string BulkSourceUserlist = "api/UserManage/BulkSourceUserlist";
        //public const string BulkSourceUserlist = "api/UserManageApi/BulkSourceUserlist";





        public const string Get_UserLocation = "api/UserManage/UserLocation";
        //public const string Get_UserLocation = "api/UserManageApi/UserLocation";
        public const string CreationBulkuser = "api/UserManage/CreationBulkuser";
        //public const string CreationBulkuser = "api/UserManageApi/CreationBulkuser";

        public const string AllUserBatchlist = "api/UserManage/AllUserBatchlist";
        //public const string AllUserBatchlist = "api/UserManageApi/AllUserBatchlist";

        public const string Userbatchdtl = "api/UserManage/Userbatchdtl";
        //public const string Userbatchdtl = "api/UserManageApi/Userbatchdtl";

        public const string Get_Location_List = "api/UserManage/LocationList";
        //public const string Get_Location_List = "api/UserManageApi/LocationList";
        public const string Add_Location = "api/UserManage/AddLocation";
        //public const string Add_Location = "api/UserManageApi/AddLocation";

        public const string Edit_location = "api/UserManage/EditLocation";
        //public const string Edit_location = "api/UserManageApi/EditLocation";

        public const string Delete_Location = "api/UserManage/RemoveLocation";
        //public const string Delete_Location = "api/UserManageApi/RemoveLocation";


        public const string Get_UserRecord = "api/UserManage/UserRecord";
        //public const string Get_UserRecord = "api/UserManageApi/UserRecord";
        // public const string RemoveLocation = "api/UserManageApi/RemoveLocation";
        #endregion

        #region portal Config
        //public const string Get_PortalConfig = "api/PortalConfigApi/SeoDetails";
        public const string Get_PortalConfig = "api/Client/SeoDetails";
        public const string Update_PortalConfig = "api/Client/UpdateSeoConfig";
        public const string Create_Portal = "api/Client/AddNewPortal";
        public const string Check_Portal = "api/Client/CheckPortalNameAvail";
        public const string Delete_Portal = "api/Client/DeletePortal";

        #endregion

        #region workflow
        public const string WorkflowList = "api/Article/WorkflowList";
        public const string UserRights = "api/CommonClient/UserRights";
        public const string CreateNewVersion = "api/Article/CreateNewVersion";
        #endregion

        #region Published Articles
        public const string PublishedList = "api/Article/PublishedList";

        #endregion

        #region Feedback


        public const string GET_FeedbackInboxlist = "api/Feedback/FeedbackInboxlist";
        //public const string GET_FeedbackInboxlist = "api/FeedbackApi/FeedbackInboxlist";

        public const string GET_Feedback = "api/Feedback/FeedbackDdlList";
        //public const string GET_Feedback = "api/FeedbackApi/FeedbackDdlList";\

        public const string GET_FeedbackResHeader = "api/Feedback/FeedbackResHeader";
        //public const string GET_FeedbackResHeader = "api/FeedbackApi/FeedbackResHeader";

        public const string GET_FeedbackData = "api/Feedback/FeedbackFreshList";
        //public const string GET_FeedbackData = "api/FeedbackApi/FeedbackFreshList";

        public const string UpdateFeedbackStatus = "api/Feedback/UpdateFeedbackStatus";
        //public const string UpdateFeedbackStatus = "api/FeedbackApi/UpdateFeedbackStatus";

        public const string InsFeedbackResponse = "api/Feedback/InsFeedbackResponse";
        //public const string InsFeedbackResponse = "api/FeedbackApi/InsFeedbackResponse";


        public const string FeedbackStatusList = "api/Feedback/FeedbackStatusList";
        //public const string FeedbackStatusList = "api/FeedbackApi/FeedbackStatusList";

        public const string FeedbackReportList = "api/Feedback/FeedbackReportList";
        //public const string FeedbackReportList = "api/FeedbackApi/FeedbackReportList";


        public const string CreateArticleStarRating = "api/Feedback/CreateArticleStarRating";
        //public const string CreateArticleStarRating = "api/FeedbackApi/CreateArticleStarRating";


        public const string EditArticleStarRatingQuestion = "api/Feedback/EditArticleStarRatingQuestion";
        //public const string EditArticleStarRatingQuestion = "api/FeedbackApi/EditArticleStarRatingQuestion";

        public const string RemoveArticleStarRatingQuestion = "api/Feedback/RemoveArticleStarRatingQuestion";
        //public const string RemoveArticleStarRatingQuestion = "api/FeedbackApi/RemoveArticleStarRatingQuestion";


        public const string Get_AllArticleStarRating = "api/Feedback/AllArticleStarRating";
        //public const string Get_AllArticleStarRating = "api/FeedbackApi/AllArticleStarRating";

        public const string Get_ArticleStarRatingByPortalRating = "api/Feedback/ArticleStarRatingByPortalRating";
        //public const string Get_ArticleStarRatingByPortalRating = "api/FeedbackApi/ArticleStarRatingByPortalRating";

        public const string SaveDisplayOrder = "api/Feedback/SaveDisplayOrder";
        //public const string SaveDisplayOrder = "api/FeedbackApi/SaveDisplayOrder";
        public const string FeedbackRating = "api/Feedback/FeedbackRating";
        //public const string FeedbackRating = "api/FeedbackApi/FeedbackRating";

        public const string GetQuestionType = "api/Feedback/FeedbackQuestionType";
        //public const string GetQuestionType = "api/FeedbackApi/FeedbackQuestionType";



        #endregion

        #region Category Management
        public const string CategoryList = "api/Article/CategoryList";
        public const string createcategory = "api/Article/createcategory";
        public const string CategoryListbyCat = "api/Article/CategoryListbyCat";
        public const string EditCategory = "api/Article/EditCategory";
        public const string CheckCategory = "api/Article/CheckCategory";

        #endregion

        #region Account

        public const string Get_HintAnsList = "api/Login/GetHintQuestion";


        public const string InsertForgotPassword = "api/Account/InsertForgotPassword";
        //public const string InsertForgotPassword = "api/Login/InsertForgotPassword";
        public const string NewUserChangePass = "api/Account/NewUserChangePass";
        //public const string NewUserChangePass = "api/Login/NewUserChangePass";
        public const string CheckPassword = "api/Account/CheckPassword";
        public const string ChangeExpirePassword = "api/Account/ChangeExpirePassword";

        //api/Account/UpdateUserResetPassword
        public const string Update_User_ResetPassword = "api/Account/UpdateUserResetPassword";
        //public const string Update_User_ResetPassword = "api/Login/UpdateUserResetPassword";
        #endregion

        #region SubCategory
        public const string CategoryListByPortal = "api/Article/CategoryListByPortal";
        public const string GetSubCategoryList = "api/Article/SubCategoryList";
        public const string CreateSubCategory = "api/Article/CreateSubCategory";
        public const string EditSubCategory = "api/Article/EditSubCategory";
        public const string GetEditSubCategory = "api/Article/GetEditSubCategory";
        public const string DeleteSubCategory = "api/Article/DeleteSubCategory";
        public const string CheckSubCategoryAvail = "api/Article/CheckSubCategoryAvail";
        #endregion

        #region SubSubCategory

        public const string SubCategoryListByCategory = "api/Article/SubCategoryListByCategory";
        public const string GetSubSubCategoryBySubCat = "api/Article/SubSubCategoryBySubCat";
        public const string GetSubSubCategoryList = "api/Article/SubSubCategoryList";
        public const string CreateSubSubCategory = "api/Article/CreateSubSubCategory";
        public const string EditSubSubCategory = "api/Article/EditSubSubCategory";
        public const string GetEditSubSubCategory = "api/Article/GetEditSubSubCategory";
        public const string DeleteSubSubCategory = "api/Article/DeleteSubSubCategory";
        public const string CheckSubSubCategoryAvail = "api/Article/CheckSubSubCategoryAvail";

        #endregion

        #region Content Management
        public const string AddContentType = "api/Article/AddContentType";
        public const string EditContentType = "api/Article/EditContentType";
        public const string GetContentForEdit = "api/Article/ContentForEdit";
        public const string GetContentTypeList = "api/Article/ContentTypeList";
        public const string ContentDelete = "api/Article/ContentDelete";
        public const string CheckContentType = "api/Article/CheckContentType";
        public const string ContentTypeLocateInfo = "api/Article/ContentLocateInfo";
        #endregion

        #region ArticleDeletion
        public const string ArticleListForDeletion = "api/Article/ArticleListForDeletion";

        public const string CatDelWithArticle = "api/Article/CatDelWithArticle";
        public const string CatUnSearchUnSearchWithArticle = "api/Article/CatUnSearchUnSearchWithArticle";

        #endregion

        #region MacroApi

        public const string Get_MacroList = "api/Macro/MacroList";
        //public const string Get_MacroList = "api/MacroApi/MacroList";
        public const string CreateMacro = "api/Macro/CreateMacro";
        //public const string CreateMacro = "api/MacroApi/CreateMacro";
        public const string Get_EditMacroData = "api/Macro/GetEditMacro";
        //public const string Get_EditMacroData = "api/MacroApi/GetEditMacro";

        public const string EditMacro = "api/Macro/EditMacro";
        //public const string EditMacro = "api/MacroApi/EditMacro";

        public const string DeleteMacro = "api/Macro/DeleteMacro";
        //public const string DeleteMacro = "api/MacroApi/DeleteMacro";

        public const string CheckMacroName = "api/Macro/CheckMacroName";
        //public const string CheckMacroName = "api/MacroApi/CheckMacroName";

        public const string ArticleMacroList = "api/Macro/ArticleMacroList";
        //public const string ArticleMacroList = "api/MacroApi/ArticleMacroList";

        public const string CreateMacroType = "api/Macro/CreateMacroType";
        //public const string CreateMacroType = "api/MacroApi/CreateMacroType";

        public const string EditMacroType = "api/Macro/EditMacroType";
        //public const string EditMacroType = "api/MacroApi/EditMacroType";

        public const string RemoveMacroType = "api/Macro/RemoveMacroType";
        //public const string RemoveMacroType = "api/MacroApi/RemoveMacroType";

        public const string MacroTypeList = "api/Macro/MacroTypeList";
        //public const string MacroTypeList = "api/MacroApi/MacroTypeList";

        public const string CheckExistMacro = "api/Article/CheckExistMacro";

        #endregion

        #region UsefulLink
        //public const string AddUsefulLink = "api/UsefulLinkApi/AddUsefulLink";
        //public const string DeleteUsefulLink = "api/UsefulLinkApi/UsefulLinkDelete";
        //public const string GetUsefulLinkList = "api/UsefulLinkApi/UsefulLinkList";
        //public const string CheckDuplicateName = "api/UsefulLinkApi/CheckDuplicateName";

        //public const string UpdateUsefullinkOrder = "api/UsefulLinkApi/UpdateUsefulLinkOrder";


        public const string AddUsefulLink = "api/Link/AddUsefulLink";
        public const string DeleteUsefulLink = "api/Link/UsefulLinkDelete";
        public const string GetUsefulLinkList = "api/Link/UsefulLinkList";
        public const string CheckDuplicateName = "api/Link/CheckDuplicateName";
        public const string UpdateUsefullinkOrder = "api/Link/UpdateUsefulLinkOrder";



        #endregion

        #region Comments
        //public const string Get_Comments = "api/CommentApi/Comment";
        public const string Get_Comments = "api/Comment/Comment";
        #endregion

        #region ArchiveList
        //public const string GetArchiveStatuslist = "api/Article/GetArchiveStatuslist";
        public const string GetArchiveStatuslist = "api/Article/GetArchiveStatuslist";

        //public const string AllArchiveArticlelist = "api/Article/AllArchiveArticlelist";
        public const string AllArchiveArticlelist = "api/Article/AllArchiveArticlelist";
        #endregion

        public const string GetArticlelinkDtl = "api/Article/GetArticlelinkDtl";
        public const string GetArticleRelatedLinkDtl = "api/Article/GetArticleRelatedLinkDtl";

        #region Deleted/Archived Guided help List
        // public const string AllArchiveGuidedlist = "api/SOPAPI/AllArchiveGuidedlist";
        public const string AllArchiveGuidedlist = "api/GuidedHelp/AllArchiveGuidedlist";
        // public const string ReviveGuidedQuesAnsList = "api/SOPAPI/ReviveGuidedQuesAnsList";
        public const string ReviveGuidedQuesAnsList = "api/GuidedHelp/ReviveGuidedQuesAnsList";

        #endregion

        public const string Artcle_Insert_In_MongoDb = "api/MongoLogs/PostArticleLog";

        public const string GuidedHelp_Insert_In_MongoDb = "api/MongoLogs/PostGuidedHelpLog";

        public const string InsertMongoErrorLog = "api/MongoLogs/InsertErrorLogs";

        #region Product Catalogue
        public const string Get_CatalogDetail = "api/ProductCatalog/GetCatalogDetailsForEdit";
        public const string Get_CatalogList = "api/ProductCatalog/GetAllCatalogList";
        public const string Delete_Catalog = "api/ProductCatalog/DeleteCatalog";
        public const string Update_Catalog = "api/ProductCatalog/UpdateCatalogDetails";
        public const string Add_Catalog = "api/ProductCatalog/CreateProductCatalog";
        public const string Update_Catalog_Order = "api/ProductCatalog/UpdateCatalogDisplayOrder";




        #endregion

        #region StoretypeManagment

        public const string Storetypelist = "api/StoreLocatorApi/Storetypelist";
        public const string AddStoretype = "api/StoreLocatorApi/AddStoretype";
        public const string EditStoretype = "api/StoreLocatorApi/EditStoretype";
        public const string GetEditStoretype = "api/StoreLocatorApi/GetEditStoretype";
        public const string DeleteStoretype = "api/StoreLocatorApi/DeleteStoretype";
        public const string CheckStoretypeName = "api/StoreLocatorApi/CheckStoretypeName";
        #endregion

        #region PortalCategoryMapping
        public const string MappedPortalList = "api/PortalCategoryMappingApi/MappedPortalList";
        public const string MappedCategoryList = "api/PortalCategoryMappingApi/MappedCategoryList";
        public const string MappedSubCategoryList = "api/PortalCategoryMappingApi/MappedSubCategoryList";
        public const string MappedSubSubCategoryList = "api/PortalCategoryMappingApi/MappedSubSubCategoryList";
        public const string MappedList = "api/PortalCategoryMappingApi/MappedList";
        public const string InsertCategoryMapping = "api/PortalCategoryMappingApi/InsertCategoryMapping";
        public const string UpdateStatusCategoryMapping = "api/PortalCategoryMappingApi/UpdateStatusCategoryMapping";
        public const string TopictreePreview = "api/PortalCategoryMappingApi/TopictreePreview";
        public const string CheckMapDeletion = "api/PortalCategoryMappingApi/CheckCategoryMappingDeletion";

        #endregion

        #region ArticlePortal Map

        public const string GetPortals_ArtPortMap = "api/PortalCategoryMappingApi/MappedPortalList";
        public const string GetCategory_ArtPortMap = "api/PortalCategoryMappingApi/MappedCategoryList";
        public const string GetSubCategory_ArtPortMap = "api/PortalCategoryMappingApi/MappedSubCategoryList";
        public const string GetSubSubCategory_ArtPortMap = "api/PortalCategoryMappingApi/MappedSubSubCategoryList";
        public const string GetArticle_By_Portal = "api/ArticlePortalMapApi/ArticleListForPortalMapping";
        public const string Get_CurrentArticle_Mapping = "api/ArticlePortalMapApi/CurrentArticleMapping";
        public const string Get_Article_LocateInfo = "api/ArticlePortalMap/ArticleLocateInfo";
        public const string Get_ArticleCat_MappingList = "api/ArticlePortalMapApi/EditCurrentArticleMapping";
        public const string Get_MapArticleTo_PortalCategory = "api/ArticlePortalMapApi/SubmitArticlePortalMapping";
        public const string Check_ArtPortMapping_Exists = "api/ArticlePortalMapApi/CheckArticlePortalMappingExists";
        public const string Check_ArtPortMapping_Deletable = "api/ArticlePortalMapApi/CheckArticlePortalMappingDeletable";

        #endregion

        #region  Weightage
        public const string WeightageList = "api/WeightageApi/WeightageList";
        public const string Get_PublishedArticleswithWeightage = "api/WeightageApi/PublishedArticleswithWeightage";
        public const string CreateNewWeightage = "api/WeightageApi/CreateNewWeightage";
        public const string DeleteWeightage = "api/WeightageApi/DeleteWeightage";
        public const string SaveWeightageOrder = "api/WeightageApi/SaveWeightageOrder";
        #endregion

        #region Cache management

        public const string Rebuild_ES_FC_Portalwise = "api/CacheManagement/RebuildElasticSearchForFullControlPortalwise";
        public const string Rebuild_ES_Articlewise = "api/CacheManagement/RebuildElasticSearchArticlewise";
        public const string Rebuild_RC_FC_Portalwise = "api/CacheManagement/RebuildRedisCacheForFullControlPortalwise";
        public const string Rebuild_RC_Articlewise = "api/CacheManagement/RebuildRedisCacheArticleswise";
        public const string Rebuild_RC_GHwise = "api/CacheManagement/RebuildRedisCacheGHwise";
        public const string Rebuild_RC_TT = "api/CacheManagement/RebuildRedisCacheForTopicTree";

        public const string PublishedArticleList = "api/CacheManagement/SearchPublishedArticleList";
        public const string PublishedGuidedHelpList = "api/CacheManagement/SearchPublishedGuidedHelpList";

        public const string CacheManagementReportList = "api/CacheManagement/CacheReportlist";
        public const string CacheReportByCacheId = "api/CacheManagement/CacheReportByCacheId";

        #endregion

        #region Article outage

        public const string Get_SearchedInboxOutageArticleList = "api/ArticleOutageApi/SearchInboxArticleList";
        public const string Get_SearchPublishedOutageArticleList = "api/ArticleOutageApi/SearchPublishedArticleList";
        public const string AllArchiveOutageArticlelist = "api/ArticleOutageApi/AllArchiveArticlelist";
        #endregion

        #region Post ImageBank added by naveen        
        public const string Post_Image_IamgeBank = "api/ImageBank/PostImageBankImage";
        //public const string Post_Image_IamgeBank = "api/ImageBankApi/PostImageBankImage";
        #endregion

        #region Get ImageBank by ClientID added naveen        
        public const string Get_Image_IamgeBank_ByClientID = "api/ImageBank/GetImageBankImageByClientID";
        //public const string Get_Image_IamgeBank_ByClientID = "api/ImageBankApi/GetImageBankImageByClientID";
        #endregion

        #region Get ImageBank by scenario added naveen        
        public const string Get_Image_IamgeBank_ByScenario = "api/ImageBank/GetImageBankImageByScenario";
        //public const string Get_Image_IamgeBank_ByScenario = "api/ImageBankApi/GetImageBankImageByScenario";
        #endregion

        #region Delete image by imagecode  added by naveen
        public const string Delete_Image = "api/ImageBank/DeleteImage";
        //public const string Delete_Image = "api/ImageBankApi/DeleteImage";
        #endregion

        #region Update image added by naveen
        public const string UpdateImage = "api/ImageBank/UpdateImage";
        //public const string UpdateImage = "api/ImageBankApi/UpdateImage";
        public const string ImageLocateInfo = "api/ImageBank/ImageLocateInfo";
        //public const string ImageLocateInfo = "api/ImageBankApi/ImageLocateInfo";
        #endregion

        #region get image group
        public const string GetGroup = "api/ImageBank/GetGroup";
        //public const string GetGroup = "api/ImageBankApi/GetGroup";
        #endregion

        #region Add group for imagebank
        public const string ImagebankAddGroup = "api/ImageBank/AddGroup";
        //public const string ImagebankAddGroup = "api/ImageBankApi/AddGroup";
        public const string ImagebankUpdateGroup = "api/ImageBank/UpdateGroup";
        //public const string ImagebankUpdateGroup = "api/ImageBankApi/UpdateGroup";
        #endregion

        #region Portal Category Mapping
        public const string GetPortalCategoryDetails = "api/ArticlePortalCategoryMapping/GetPortalCategories";
        public const string UpdatePortalCategoryDetails = "api/TopicTree/CategoryMapping";
        public const string GetCategroyPortalList = "api/Utility/PortalData";
        //public const string GetPortalCategories = "api/ArticlePortalCategoryMapping/GetPortalCategories";
        public const string InsertPortalCatMapping = "api/PortalCategoryMappingApi/InsertPortalCatMapping";

        #endregion

        //#region ClientManagement
        //public const string GetClientList = "api/Client/GetClientList";
        //#endregion

        #region Article Portal Mapping
        public const string ArticleTopicList = "api/ArticlePortalMap/GetArticlePortalMapping";
        public const string SaveArticleTopic = "api/ArticlePortalMap/InsertArticlePortalMapping";
        public const string GetArticlePortalMappingDtl = "api/ArticlePortalMap/GetArticlePortalMappingDtl";
        public const string UpdateArticleTopic = "api/ArticlePortalMap/UpdateArticleTopic";
        public const string UpdateArticleTopicversion = "api/ArticlePortalMap/UpdateArticleTopicversion";
        public const string CheckArtPortalMapping = "api/ArticlePortalMap/CheckArtPortalMapping";
        public const string GetProductCatelog = "api/ProductCatalog/GetAllCatalogList";
        public const string PublishGh = "api/GuidedHelp/GuidedHelpPublishArticle";
        #endregion

        #region ordering
        public const string GetAllPublishArticle = "api/ManageOrdering/GetAllPublishArticle";
        public const string InsertOrderingDetails = "api/ManageOrdering/InsertOrderingDetails";
        public const string GetArticlelistwithOrder = "api/ManageOrdering/GetArticlelistwithOrder";
        public const string SetOrdering = "api/ManageOrdering/SetOrdering";

        public const string DeleteOrdering = "api/ManageOrdering/DeleteOrdering";
        #endregion
        #region Role Management           
        public const string GetRoleList = "api/RoleManagement/GetRoleList";
        public const string DeleteRoleByClientId = "api/RoleManagement/DeleteRole";
        public const string GetRoleActionsByClientId = "api/RoleManagement/GetRoleActions";
        public const string AddRoleByClientId = "api/RoleManagement/AddOrUpdateRole";
        public const string EditRoleByClientId = "api/RoleManagement/GetGroupInfoById";

        #endregion

        #region ClientProfileCreation
        public const string GetClientMasterData = "api/ClientManagement/GetClientMasterData";
        public const string CreateAllClientData = "api/ClientManagement/InsertClientDetail";
        public const string UpdateAllClientData = "api/ClientManagement/UpdateClientDetail";
        public const string GetAllClientDataList = "api/ClientManagement/GetAllClientList";
        public const string GetClientDetailForEdit = "api/ClientManagement/GetClientDetailForEdit";
        public const string GetThemeDetails = "api/ClientManagement/GetThemeDetails";
        public const string GetClientManagementChecklist = "api/ClientManagement/GetCheckListDetails";
        public const string UpdateClientManagementChecklist = "api/ClientManagement/SaveCheckListDetails";
        public const string GetClientManagementDatabaseList = "api/ClientManagement/GetClientDatabaseSetting";
        public const string UpdateClientManagementDatabaseList = "api/ClientManagement/SaveDatabaseSetting";
        public const string GenerateLicenseKey = "api/ClientManagement/GenerateLicenseKey";
        public const string UpdateClientStatus = "api/ClientManagement/UpdateClientStatus";
        public const string GetAllConfiglist = "api/ClientConfigurations/GetAllConfiglist";
        public const string AddOrUpdateClientConfig = "api/ClientConfigurations/AddOrUpdateClientConfig";
        public const string GetConfiglistByClientId = "api/ClientConfigurations/GetConfiglistByClientId";
        public const string UpdateLicenseKey = "api/ClientManagement/SaveJsonFile";
        public const string CheckSession = "api/ClientManagement/CheckSession";
        #endregion

        #region ProfileManagement
        public const string ManageProfileForm = "api/ProfileManagement/AdddorUpdateForm";
        public const string GetProfileFormlList = "api/ProfileManagement/GetProfileDetail";
        public const string CheckAttachedGuidedHelp = "api/ProfileManagement/CheckAttachedGuidedHelp"; 
        public const string ManageApiConfiguration = "api/ProfileManagement/ManageApiConfiguration";//
        public const string GetApiConfigurationList = "api/ProfileManagement/GetApiConfigurationList";
        public const string GetApiParameterDetailList = "api/ProfileManagement/GetApiParameterDetailList";
        public const string CheckApiName = "api/ProfileManagement/CheckApiName";
        public const string SaveApiOrder = "api/ProfileManagement/SaveApiOrder";

        #endregion

        #region Simulation
        public const string AddSimulation = "api/GuidedHelp/AddSimulation";
        public const string GetSimulationByCode = "api/GuidedHelp/GetSimulationByCode";
        public const string DeleteSimulation = "api/GuidedHelp/DeleteSimulation";
        #endregion

        /// <summary>
        /// Generate Simulator Url for Iframe
        /// </summary>

        public const string SimulatorGetLink = "api/AddSimulation/GetLink";
        public const string SimulatorDeleteToken = "api/AddSimulation/GetLink";
        #region Briefing
        public const string SaveConfig = "api/Briefing/SaveConfig";
        public const string UpdateConfig = "api/Briefing/ConfigUpdate";
        public const string BriefingConfig = "api/Briefing/BriefingConfig";
        public const string Get_SearchPublishedBriefingArticleList = "api/Briefing/GetSearchedPublishedArticles";
        public const string CreateAssesment = "api/Briefing/CreateAssesment";
        public const string UpdateAssesment = "api/Briefing/UpdateAssesment";
        public const string GetAssesmentlist = "api/Briefing/GetAssesmentlist";
        public const string GetAssesmentById = "api/Briefing/GetAssesmentById";
        public const string DeleteAssesment = "api/Briefing/DeleteAssesment";
        public const string CheckAssesmentTitle = "api/Briefing/CheckAssesmentTitle";

        








        #endregion
    }

    public class VariableNames
    {
        public static string MaxAttachment = CAppSettings.GetConfigurationValue("Max_Attachment");
    }

   







}
