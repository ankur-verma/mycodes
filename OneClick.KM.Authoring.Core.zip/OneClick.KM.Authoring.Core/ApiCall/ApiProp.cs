﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using OneClick.KM.Authoring.Core.Utility;

namespace OneClick.KM.Authoring.Core.ApiCall
{
    public class ApiProp
    {
        public ApiProp()
        {
            HeaderList = new List<ApiHeader>();
            ContentType = "application/json";
            Method = APIMethodType.POST.ToString();           
        }
        public string ApiUri{ get; set; }

        public string ApiName { get; set; }
        public string ContentType { get; set; }
        public List<ApiHeader> HeaderList { get; set; }
        public String Method { get; set; }

        public string DataForPost { get; set; }

        public string Username { get; set; }
        public string SessionId { get; set; }
        public string UserId { get; set; }

        public ErrorProp CustomError { get; set; }
        //public string ClientId { get; set; }

    }

    public class ApiHeader
    {
        public string RequestHeader { get; set; }
        public string RequestHeaderValue { get; set; }

        public ErrorProp CustomError { get; set; }
    }

    [Serializable]
    [JsonObject]
    public class ErrorProp
    {
        public string ErrorCode { get; set; }
        public string ErrorDetail { get; set; }
        public string ReturnValue { get; set; }
        public string MessageType { get; set; }
        public string Redirect { get; set; }
        public Object ResponseData { get; set; }
        public string GetMessageInfo
        {
            get { return "Error Code (" + ErrorCode + ") : " + ErrorDetail; }
        }
        public string Result { get; set; }

    }
    
    public class ApiResponse
    {
        public ApiResponse()
        {
            Error = new ErrorProp();
        }
        public ErrorProp Error { get; set; }
        public Object Result { get; set; }
    }



}
