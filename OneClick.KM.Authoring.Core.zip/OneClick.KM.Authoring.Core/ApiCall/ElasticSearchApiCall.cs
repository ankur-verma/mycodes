﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

using System.Net.Http;
using System.Net.Http.Headers;
using OneClick.KM.Authoring.Core.Utility;

namespace OneClick.KM.Authoring.Core.ApiCall
{
   
    public class ElasticSearchApiCall
    {
        public ErrorProp CallWebApi(ApiProp objprop)
        {          
            ErrorProp errReturn = new ErrorProp();
            try
            {
                string url = System.IO.Path.Combine(objprop.ApiUri, objprop.ApiName); //objprop.ApiUri + "/" + objprop.ApiName;
               // Path.Combine(objprop.ApiUri, objprop.ApiName);

                HttpResponseMessage response = null;
                using (HttpClient client = new HttpClient())
                {
                   // client.DefaultRequestHeaders.

                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(objprop.ContentType));

                    if (objprop.HeaderList.Count > 0)
                    {
                        foreach (var item in objprop.HeaderList)
                        {
                            client.DefaultRequestHeaders.Add(item.RequestHeader, item.RequestHeaderValue);
                        }
                       // client.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "application/json; charset=utf-8");
                    }
                    if (objprop.Method  == APIMethodType.GET.ToString())
                    {
                        response = client.GetAsync(url).Result;

                    }
                    else if (objprop.Method == APIMethodType.POST.ToString())
                    {
                        var postContent = new StringContent(objprop.DataForPost, System.Text.Encoding.UTF8, objprop.ContentType);
                        response = client.PostAsync(url, postContent).Result;

                    }
                    else if (objprop.Method == APIMethodType.PUT.ToString())
                    {                       
                        var postContent = new StringContent(objprop.DataForPost, System.Text.Encoding.UTF8, objprop.ContentType);
                        response = client.PutAsync(url, postContent).Result;

                    }
                    else if (objprop.Method == APIMethodType.DELETE.ToString())
                    {
                        response = client.DeleteAsync(url).Result;

                    }
                    else if (objprop.Method.ToUpper() == APIMethodType.PATCH.ToString())
                    {
                        var postContent = new StringContent(objprop.DataForPost, System.Text.Encoding.UTF8, objprop.ContentType);
                        var method = new HttpMethod(objprop.Method);
                        var request = new HttpRequestMessage(method, url)
                        {
                            Content = postContent
                        };
                        response = client.SendAsync(request).Result;
                    }

                    var result = response.Content.ReadAsStringAsync().Result;                  
                    if (response.IsSuccessStatusCode)
                    {
                        errReturn.ErrorCode = "0";
                        errReturn.ErrorDetail = "Success";
                    }
                    else
                    {
                        int code = (int)response.StatusCode;                        
                    
                        errReturn.ErrorCode = ErrorCodeElasticSearch.AUAES500;
                        errReturn.ErrorDetail = ErrorCodeElasticSearch.AUAES500Msg;
                        errReturn.ErrorDetail = errReturn.ErrorDetail + " Elastic Search Api Response: " + code.ToString() + "-" + response.ReasonPhrase;
                    }                   

                    errReturn.ReturnValue = result;
                }
               
            }
            catch (Exception ex)
            {
                errReturn.ErrorCode = ErrorCodeConstant.AUATB;
                errReturn.ErrorDetail = ex.ToString();
                
            }
            return errReturn;

        }

        //public ErrorProp CallWebApi_V112(ApiProp objprop)
        //{

        //    ErrorProp errReturn = new ErrorProp();
        //    try
        //    {
        //        string url = System.IO.Path.Combine(objprop.ApiUri, objprop.ApiName); //objprop.ApiUri + "/" + objprop.ApiName;
        //        // Path.Combine(objprop.ApiUri, objprop.ApiName);

        //        HttpResponseMessage response = null;
        //        using (HttpClient client = new HttpClient())
        //        {
        //            client.DefaultRequestHeaders.Accept.Clear();
        //            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(objprop.ContentType));

        //            if (objprop.HeaderList.Count > 0)
        //            {
        //                foreach (var item in objprop.HeaderList)
        //                {
        //                    client.DefaultRequestHeaders.Add(item.RequestHeader, item.RequestHeaderValue);
        //                }
        //            }
        //            if (objprop.Method == APIMethodType.GET.ToString())
        //            {
        //                response = client.GetAsync(url).Result;

        //            }
        //            else if (objprop.Method == APIMethodType.POST.ToString())
        //            {
        //                var postContent = new StringContent(objprop.DataForPost, System.Text.Encoding.UTF8, objprop.ContentType);
        //                response = client.PostAsync(url, postContent).Result;

        //            }
        //            else if (objprop.Method == APIMethodType.PUT.ToString())
        //            {
        //                var postContent = new StringContent(objprop.DataForPost, System.Text.Encoding.UTF8, objprop.ContentType);
        //                response = client.PutAsync(url, postContent).Result;

        //            }
        //            else if (objprop.Method == APIMethodType.DELETE.ToString())
        //            {
        //                response = client.DeleteAsync(url).Result;

        //            }
        //            else if (objprop.Method.ToUpper() == APIMethodType.PATCH.ToString())
        //            {
        //                var postContent = new StringContent(objprop.DataForPost, System.Text.Encoding.UTF8, objprop.ContentType);
        //                var method = new HttpMethod(objprop.Method);
        //                var request = new HttpRequestMessage(method, url)
        //                {
        //                    Content = postContent
        //                };
        //                response = client.SendAsync(request).Result;
        //            }

        //            var result = response.Content.ReadAsStringAsync().Result;
        //            if (response.IsSuccessStatusCode)
        //            {
        //                errReturn.ErrorCode = "0";
        //                errReturn.ErrorDetail = "Success";

        //                var res = JsonConvert.DeserializeObject<Response_old>(result);
        //                if (res.Error.ErrorCode == "0")
        //                {
        //                    errReturn.ReturnValue = Convert.ToString(res.Result);                           
        //                }
        //                else
        //                {
        //                    errReturn.ErrorCode = res.Error.ErrorCode;
        //                    errReturn.ErrorDetail = res.Error.ErrorDetail;                        
        //                }


        //            }
        //            else
        //            {
        //                errReturn = CommonMethods.GetError("ES01");
        //                errReturn.ErrorDetail = response.StatusCode + "- " + response.ReasonPhrase;
        //                errReturn.ReturnValue = result;
        //            }
                   
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        errReturn.ErrorCode = "ES101";
        //        errReturn.ErrorDetail = ex.Message;
        //       // throw ex;
        //    }
        //    return errReturn;

        //}                
    
    }
 

}
