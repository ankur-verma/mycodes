﻿
using log4net;

namespace OneClick.KM.Authoring.Core
{
    public static class Logger
    {
        public static ILog AppLog = LogManager.GetLogger("ApplicationLog");
        public static ILog ESLog = LogManager.GetLogger("ESLog");
        public static ILog RedisLog = LogManager.GetLogger("RedisLog");
        public static ILog InfosecLog = LogManager.GetLogger("InfosecLog");
        public static ILog APICallLog = LogManager.GetLogger("APICallLog");
    }

  

}
