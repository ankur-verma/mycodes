﻿using System;
using System.Configuration;

namespace OneClick.KM.Authoring.Core.Security
{
    public static class CAppSettings
    {
        public const string ApiSecurityKey = "Value 0neC!licKJi0";
        /// <summary>
        /// to get value from the appSettings of web.config file 
        /// </summary>
        /// <param name="pstrKey">key</param>
        /// <returns>value of the key</returns>
        public static string GetConfigurationValue(string pstrKey, bool isNeedException = false)
        {
            var configurationValue = ConfigurationManager.AppSettings[pstrKey];
            if (configurationValue != null)
                return configurationValue;

            throw (new ApplicationException(
                "Configuration Tag is missing in web.config. It must contain <add key=\"" + pstrKey + "\" value=\"?\"/>"));

        }
    }
}
