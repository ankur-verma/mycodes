﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.Authoring.Core.Security
{
    public class PasswordEncrption
    {
        /// <summary>
        /// Generate SHA256 hash value for given string
        /// </summary>
        /// <param name="pstrStringToEncrypt">string to hash</param>
        /// <param name="pstrSalt">salt string</param>
        /// <returns>hashed string</returns>
        public static String GetSHA256Password(string pstrStringToEncrypt, string pstrSalt)
        {
            if (string.IsNullOrEmpty(pstrStringToEncrypt) || string.IsNullOrEmpty(pstrSalt))
                throw (new ApplicationException("Argument cann't be null in the function GetSHA256Password (KMS_Core_Security)"));

            var newSalt = AES256Encryption.ChangeString(pstrSalt.ToUpper());
            return ComputeHash(pstrStringToEncrypt, new SHA256CryptoServiceProvider(), Encoding.UTF8.GetBytes(newSalt.ToUpper()));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        /// <param name="algorithm"></param>
        /// <param name="salt"></param>
        /// <returns></returns>
        private static string ComputeHash(string input, HashAlgorithm algorithm, Byte[] salt)
        {
            StringBuilder Sb = new StringBuilder();
            Byte[] inputBytes = Encoding.UTF8.GetBytes(input);

            // Combine salt and input bytes
            Byte[] saltedInput = new Byte[salt.Length + inputBytes.Length];
            salt.CopyTo(saltedInput, 0);
            inputBytes.CopyTo(saltedInput, salt.Length);

            Byte[] hashedBytes = algorithm.ComputeHash(saltedInput);

            foreach (Byte b in hashedBytes)
                Sb.Append(b.ToString("x2", CultureInfo.InvariantCulture));

            return Sb.ToString();
        }
    }
}
