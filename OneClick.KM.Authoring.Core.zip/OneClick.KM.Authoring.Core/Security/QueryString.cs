﻿using System;
using System.Web;
using System.Collections;
using System.IO;
using System.Text;
using System.Security.Cryptography;
using System.Collections.Specialized;

namespace OneClick.KM.Authoring.Core.Security
{
    public class QueryString : NameValueCollection
    {
        //Initialized Key
        byte[] key = { };
        //Initilized Digest
        readonly private byte[] IV = { 0X12, 0X34, 0X56, 0X78, 0X90, 0XAB, 0XCD, 0XEF };
        //Define Encryption Key
        string mstrEncryptionKey = "1234567890";
        //If name of the documeny is Requied
        private string document;
        //Application Path Details



        #region Document
        public string Document
        {
            get
            {
                return document;
            }
        }
        #endregion
        #region Constructor QueryString
        //Constructor of the class
        public QueryString()
        {
        }
        #endregion
        #region Overloaded Constructor with Inherited base---> QueryString
        /// <summary>
        /// Constructor of Class with Name Value pair
        /// </summary>
        /// <param name="clone"></param>
        public QueryString(NameValueCollection clone)
            : base(clone)
        {

        }
        #endregion
        #region FromCurrent
        /// <summary>
        /// #pp:01092008 To get the Current Contexts URL
        /// </summary>
        /// <returns></returns>
        public static QueryString FromCurrent()
        {
            //#pp:01092008 Returns Absolute Content from url i.e. After "?"
            if (HttpContext.Current.Request.Url.AbsoluteUri.IndexOf("?") > -1)
            {
                String absoluteUrl = tuneMyUrl(HttpContext.Current.Request.Url.AbsoluteUri);
                return FromUrl(absoluteUrl);
            }
            return null;
        }
        public static QueryString FromCurrent(string url)
        {
            //#pp:01092008 Returns Absolute Content from url i.e. After "?"
            if (url.IndexOf("?") > -1)
            {
                String absoluteUrl = tuneMyUrl(url);
                return FromUrl(absoluteUrl);
            }
            return null;
        }
        #endregion
        #region FromUrl
        /// <summary>
        /// This part Basically reads the Querystring url and Split it on the basis of various criterias into parts and keys.
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static QueryString FromUrl(string url)
        {
            //#pp:01092008  Split on the basis of ?
            string[] parts = url.Split("?".ToCharArray());
            QueryString qs = new QueryString();
            //#pp:01092008 Store on prime spot for further use
            qs.document = parts[0];

            //#pp:01092008  if no ? is found querystring will not be encrypted
            if (parts.Length == 1)
                return qs;

            //#pp:01092008 fetch the multiple keys from the remaining parts
            string[] keys = parts[1].Split("&".ToCharArray());
            foreach (string key in keys)
            {
                string[] part = key.Split("=".ToCharArray());
                qs.Add(part[0], part.Length == 1 ? string.Empty : part[1]);
            }
            return qs;
        }
        #endregion
        #region ClearAllExcept
        /// <summary>
        /// #pp:01092008 To clear the contents of Querstring 
        /// </summary>
        /// <param name="except"></param>
        public void ClearAllExcept(string except)
        {
            //#pp:01092008 pass the preserved name
            ClearAllExcept(new string[] { except });
        }
        public void ClearAllExcept(string[] except)
        {
            ArrayList toRemove = new ArrayList();
            foreach (string s in this.AllKeys/*this part pics all the keys from name value collection*/)
            {
                foreach (string e in except)
                {
                    if (s.ToLower() == e.ToLower())
                        if (!toRemove.Contains(s))
                            toRemove.Add(s);
                }
            }

            //#pp:01092008 Removal part is done here
            foreach (string s in toRemove)
                this.Remove(s);
        }
        #endregion
        #region Add
        /// <summary>
        /// #pp:01092008 To add Name Value Pair Overriding is used to override .net ADD
        /// </summary>
        /// <param name="name"></param>
        /// <param name="value"></param>
        public override void Add(string name, string value)
        {
            if (this[name] != null)
            {

                this[name] = value;
            }
            else
            {
                base.Add(name, value);
            }
        }
        #endregion
        #region ToString
        /// <summary>
        /// #pp:01092008 To String Override
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {

            return ToString(false);
        }
        public string ToString(bool includeUrl)
        {
            //#pp:01092008 Form String array of length of Current context of Name Value
            string[] parts = new string[this.Count];
            //#pp:01092008 Form the key array of all keys
            string[] keys = this.AllKeys;

            //#pp:01092008 form the parts array from name and value with =
            // this thing is done to preserve = from encryption
            for (int i = 0; i < keys.Length; i++)
            {
                parts[i] = keys[i] + "=" + this[keys[i]];
            }
            //User the following if URL Encoding is required
            //parts[i] = keys[i] + "=" + HttpContext.Current.Server.UrlEncode(this[keys[i]]);

            //#pp:01092008 Reform the URL by concatinating the parts
            string url = String.Join("&", parts);

            //#pp:01092008 Append ? to the Start to get the complete feel of Querystring
            if ((url != null || url != String.Empty) && !url.StartsWith("?"))
            {
                url = "?" + url;
            }
            if (includeUrl)
            {
                //#pp:01092008 this decides wherr to include the document contaxt
                url = this.document + url;
            }
            return url;

        }
        #endregion
        #region Encrypt
        /// <summary>
        /// #pp:01092008 To Encrypt the Query String
        /// </summary>
        /// <param name="stringToEncrypt"></param>
        /// <param name="SEncryptionKey"></param>
        /// <returns></returns>
        public string Encrypt(string stringToEncrypt, string SEncryptionKey)
        {
            try
            {
                //#pp:01092008Form Key from the Encryption key characters
                key = System.Text.Encoding.UTF8.GetBytes(SEncryptionKey.Substring(0, 8));
                //#pp:01092008 Crypto Service Object
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                //#pp:01092008 form the byte stream of the Encrypting String
                byte[] inputByteArray = Encoding.UTF8.GetBytes(stringToEncrypt);
                MemoryStream ms = new MemoryStream();
                //#pp:01092008 Appry Encryption Algo
                CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(key, IV), CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();
                //Convert.ToBase64String(ms.ToArray()).Replace('=', '@');
                return Convert.ToBase64String(ms.ToArray()).Replace("=", "$@").Replace("/", "~@");

            }
            catch (Exception ex)
            {
                return ex.Message.ToString();
            }
            finally
            {
            }

        }
        #endregion

        public string Encrypt(string stringToEncrypt)
        {
            return Encrypt(stringToEncrypt, mstrEncryptionKey);
        }

        public string Decrypt(string stringToEncrypt)
        {
            return Decrypt(stringToEncrypt, mstrEncryptionKey);
        }

        #region Decrypt
        /// <summary>
        /// #pp:01092008 To Decrypt
        /// </summary>
        /// <param name="stringToDecrypt"></param>
        /// <param name="SEncryptionKey"></param>
        /// <returns></returns>
        public string Decrypt(string stringToDecrypt, string SEncryptionKey)
        {
            byte[] inputByteArray = new byte[stringToDecrypt.Length];
            // inputByteArray.Length = stringToDecrypt.Length;
            try
            {
                key = System.Text.Encoding.UTF8.GetBytes(SEncryptionKey.Substring(0, 8));
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                inputByteArray = Convert.FromBase64String(stringToDecrypt.Replace("$@", "=").Replace("~@", "/"));
                MemoryStream ms = new MemoryStream();
                CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(key, IV), CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();
                System.Text.Encoding encoding = System.Text.Encoding.UTF8;
                return encoding.GetString(ms.ToArray());
            }
            catch (Exception ex)
            {
                return ex.Message.ToString();
            }
            finally
            {
            }
        }
        #endregion
        #region EncryptQueryString
        /// <summary>
        /// #pp:01092008 Here the Main Functioning of Encryption is being Done
        /// </summary>
        /// <param name="queryString"></param>
        /// <returns></returns>
        public static QueryString EncryptQueryString(QueryString queryString)
        {

            QueryString newQueryString = new QueryString();
            string nm = String.Empty;
            string val = String.Empty;
            foreach (string name in queryString)
            {
                nm = name;
                val = queryString[name];
                //#pp:01092008 Encrypt the name and value pair
                newQueryString.Add(newQueryString.Encrypt(nm, newQueryString.mstrEncryptionKey), newQueryString.Encrypt(val, newQueryString.mstrEncryptionKey));
            }
            return newQueryString;
        }
        #endregion
        #region DecryptQueryString
        /// <summary>
        /// 
        /// </summary>
        /// <param name="queryString"></param>
        /// <returns></returns>
        public static QueryString DecryptQueryString(QueryString queryString)
        {
            QueryString newQueryString = new QueryString();

            string nm;
            string val;
            foreach (string name in queryString)
            {
                //#pp:01092008 Decrypt the Name 
                string nwName = tuneMyUrl(name);
                nm = newQueryString.Decrypt(nwName, newQueryString.mstrEncryptionKey);
                //#pp:01092008 Decrypt the Value
                val = newQueryString.Decrypt(queryString[nwName], newQueryString.mstrEncryptionKey);
                //#pp:01092008 form the namevalue pair again
                newQueryString.Add(nm, val);
            }

            return newQueryString;

        }
        #endregion
        #region formSecureQuery
        /// <summary>
        /// #pp:01092008 To form the Secure Query
        /// </summary>
        /// <param name="PageName"></param>
        /// <param name="qs"></param>
        /// <returns></returns>
        public static string formSecureQuery(String PageName, QueryString qs)
        {
            string _path = System.Configuration.ConfigurationManager.AppSettings["AppFolderName"].ToString();
            //#pp:01092008 To be called from the Page with Querystring as pass variable
            QueryString qsEncrypted = EncryptQueryString(qs);
            //#pp:01092008 Return the Encryped Url
            if (PageName.ToUpper().StartsWith("HTTP://") || PageName.ToUpper().StartsWith("HTTPS://"))
                _path = PageName;
            else
            _path = _path + "/" + PageName;
            return (_path += qsEncrypted.ToString());
        }
        #endregion
        #region readSecureQuery
        /// <summary>
        /// #pp:01092008 To read the Encryped Querystring as a whole
        /// </summary>
        /// <returns></returns>
        public static string readSecureQuery()
        {

            string decryptedQry = "";
            //#pp:01092008 This will get the Querystring from the Current Context
            QueryString qs = QueryString.FromCurrent();
            //#pp:01092008 Decrypt and Return the Querystring
            return (decryptedQry += ((QueryString)DecryptQueryString((qs))).ToString());
        }

        public static string readSecureQuery(QueryString qs)
        {

            string decryptedQry = "";
            return (decryptedQry += ((QueryString)DecryptQueryString((qs))).ToString());
        }

        #endregion

        #region getValueOf
        /// <summary>
        /// #pp:01092008  To Read the perticular value
        /// </summary>
        /// <param name="pstrName"></param>
        /// <returns></returns>
        public static string getValueOf(string pstrName)
        {
            QueryString qs = FromCurrent();

            return qs != null
                       ? ((DecryptQueryString((qs))).Get(pstrName) != null
                              ? ((DecryptQueryString((qs))).Get(pstrName))
                              : null)
                       : null;
        }
        public static string getValueOf(string pstrName, string url)
        {
            QueryString qs = FromCurrent(url);

            return qs != null
                       ? ((DecryptQueryString((qs))).Get(pstrName) != null
                              ? ((DecryptQueryString((qs))).Get(pstrName))
                              : null)
                       : null;
        }
        #endregion


        #region reDirectToSelf
        /// <summary>
        /// #pp:01092008  To Read the perticular value
        /// </summary>
        /// <param name="pstrName"></param>
        /// <returns></returns>
        public static string reDirectToSelf()
        {

            if (HttpContext.Current.Request.Url.AbsoluteUri.IndexOf("?") > -1)
            {
                String myUrl = tuneMyUrl(HttpContext.Current.Request.Url.OriginalString.ToString());
                return myUrl;
            }
            else
            {
                return null;
            }

        }
        #endregion

        #region tuneMyUrl
        protected static string tuneMyUrl(String absoluteUrl)
        {
            if (absoluteUrl.IndexOf("%24%40") > -1)
            {
                absoluteUrl = absoluteUrl.Replace("%24%40", "$@");
            }
            if (absoluteUrl.IndexOf("%2f") > -1)
            {
                absoluteUrl = absoluteUrl.Replace("%2f", "/");
            }
            if (absoluteUrl.IndexOf("%7e%40") > -1)
            {
                absoluteUrl = absoluteUrl.Replace("%7e%40", "~@");
            }
            return absoluteUrl;
        }
        #endregion


        #region TripleEncoding
        public string TripleDESEncode(string value)
        {
            string key = "a1B@c3D$";
            System.Security.Cryptography.TripleDESCryptoServiceProvider des = new System.Security.Cryptography.TripleDESCryptoServiceProvider();
            des.IV = new byte[8];
            System.Security.Cryptography.PasswordDeriveBytes pdb = new System.Security.Cryptography.PasswordDeriveBytes(key, new byte[-1 + 1]);
            des.Key = pdb.CryptDeriveKey("RC2", "MD5", 128, new byte[8]);
            System.IO.MemoryStream ms = new System.IO.MemoryStream((value.Length * 2) - 1);
            System.Security.Cryptography.CryptoStream encStream = new System.Security.Cryptography.CryptoStream(ms, des.CreateEncryptor(), System.Security.Cryptography.CryptoStreamMode.Write);
            byte[] plainBytes = System.Text.Encoding.UTF8.GetBytes(value);
            encStream.Write(plainBytes, 0, plainBytes.Length);
            encStream.FlushFinalBlock();
            byte[] encryptedBytes = new byte[(int)ms.Length - 1 + 1];
            ms.Position = 0;
            ms.Read(encryptedBytes, 0, (int)ms.Length);
            encStream.Close();
            return Convert.ToBase64String(encryptedBytes);
        }
        #endregion
        #region TripleDESDecode
        public string TripleDESDecode(string value)
        {

            string key = "a1B@c3D$";
            System.Security.Cryptography.TripleDESCryptoServiceProvider des = new System.Security.Cryptography.TripleDESCryptoServiceProvider();
            des.IV = new byte[8];
            System.Security.Cryptography.PasswordDeriveBytes pdb = new System.Security.Cryptography.PasswordDeriveBytes(key, new byte[-1 + 1]);
            des.Key = pdb.CryptDeriveKey("RC2", "MD5", 128, new byte[8]);
            byte[] encryptedBytes = Convert.FromBase64String(value);
            System.IO.MemoryStream ms = new System.IO.MemoryStream(value.Length);
            System.Security.Cryptography.CryptoStream decStream = new System.Security.Cryptography.CryptoStream(ms, des.CreateDecryptor(), System.Security.Cryptography.CryptoStreamMode.Write);
            decStream.Write(encryptedBytes, 0, encryptedBytes.Length);
            decStream.FlushFinalBlock();
            byte[] plainBytes = new byte[(int)ms.Length - 1 + 1];
            ms.Position = 0;
            ms.Read(plainBytes, 0, (int)ms.Length);
            decStream.Close();
            return System.Text.Encoding.UTF8.GetString(plainBytes);

        }
        #endregion
    }
}
