﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.Authoring.Core.Utility
{

    #region String Filter class
    /// <summary>
    /// This attribute is used to represent a string value
    /// for a value in an enum.
    /// </summary>
    public class StringValueAttribute : Attribute
    {
        /// <summary>
        /// Holds the stringvalue for a value in an enum.
        /// </summary>
        public string StringValue { get; protected set; }

        /// <summary>
        /// Constructor used to init a StringValue Attribute
        /// </summary>
        /// <param name="value"></param>
        public StringValueAttribute(string value)
        {
            this.StringValue = value;
        }
    }

    public static class StringEnums
    {
        /// <summary>
        /// Will get the string value for a given enums value, this will
        /// only work if you assign the StringValue attribute to
        /// the items in your enum.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string GetStringValue(this Enum value)
        {
            // Get the type
            Type type = value.GetType();

            // Get fieldinfo for this type
            System.Reflection.FieldInfo fieldInfo = type.GetField(value.ToString());

            // Get the stringvalue attributes
            StringValueAttribute[] attribs = fieldInfo.GetCustomAttributes(
                typeof(StringValueAttribute), false) as StringValueAttribute[];

            // Return the first if there was a match.
            return attribs.Length > 0 ? attribs[0].StringValue : null;
        }
    }

    #endregion 


    #region ENUMS

    public enum APIMethodType
    {
        GET,
        POST,
        DELETE,
        PATCH,
        PUT
    }

    // 
    public enum FlowModType
    {
        MOP
    }




    public enum CategoryTypeMap
    {
        FAQBUSI = 1, // Article
        L1 = 2, // Guided Help
        FAQ = 3 //  FAQ
    }

    public enum ContentType1
    {
        Article = 10001, // Article
        GuidedHelp = 10002, // Guided Help
        Faq = 10003,
        Outage=10004,
        RccBriefing=10005,
        SupportedDocument=10006,
        SolutionDocument=10007

    }


    public enum ContentType
    {
        [StringValue("FAQBUSI")]
        ARTICLE = 1,

        [StringValue("L1")]
        GUIDED_HELP = 2
    }

    public enum PriorityType
    {
        [StringValue("H")]
        HIGH, // H

        [StringValue("L")]
        LOW, // L

        [StringValue("HD")]
        HIDE //  HD
    }


    public enum ProcessType
    {
        [StringValue("F")]
        FRESH, 

        [StringValue("E")]
        EDIT, 

        [StringValue("M")]
        MODERATE ,

        [StringValue("BSP")]
        BUSINESS_SPOKE_PERSON_APPROVAL,

        [StringValue("BSPA")]
        BUSINESS_SPOKE_PERSON_APPROVED,

        [StringValue("P")]
        PUBLISHED,

        [StringValue("A")]
        ARCHIVED,

        [StringValue("D")]
        DELETED
    }


    public enum Groupights
    {
        [StringValue("AUTH")]
        AUTHOR,

        [StringValue("SAUTH")]
        SRAUTHOR,

        [StringValue("PUB")]
        BUS_SP,

        [StringValue("SYSADM")]
        SYS_ADM,

        [StringValue("ADM")]
        ADMIN,

        [StringValue("TECHSP")]
        TECHSUPPORT,

        [StringValue("BSP")]
        BUSSPOKE,
        [StringValue("OTAUTH")]
        Outage,
        [StringValue("RESETU")]
        ResetUser,
    };

    public enum UserActionType
    {
        [StringValue("SINGLE")]
        SINGLEUSER,
        [StringValue("BULK")]
        BULKUSER,


    }


    #endregion
}
