﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Reflection;
using System.Resources;
using System.Net.Sockets;
using OneClick.KM.Authoring.Core.ApiCall;
using OneClick.KM.Authoring.Core.Security;

namespace OneClick.KM.Authoring.Core.Utility
{
   public class CommonMethods
    {

       #region Configuration Methods

       public const string wrongUrl_incorrectData = "Incorrect Data or Wrong Url";

        public const string portalCachePrefix = "ES_";

        public static string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            throw new Exception("No network adapters with an IPv4 address in the system!");
        }


     

        #endregion

        #region ENUM Ops

        public static string GetCategoryTypeMapping(string catType)
        {
            if (catType == CategoryTypeMap.FAQBUSI.ToString())
            {
                return Convert.ToString((int)CategoryTypeMap.FAQBUSI);
            }
            else if (catType == CategoryTypeMap.L1.ToString())
            {
                return Convert.ToString((int)CategoryTypeMap.L1);
            }
            else if (catType == CategoryTypeMap.FAQ.ToString())
            {
                return Convert.ToString((int)CategoryTypeMap.FAQ);
            }
            return "";
        }

        #endregion

        #region API Downloading

       public static HttpResponseMessage DownloadFile(byte[] fileBytes, string filename)
       {
           if (fileBytes != null &&
               fileBytes.Length > 0)
           {
              
                   var stream = new System.IO.MemoryStream(fileBytes, 0, fileBytes.Length, true, true);

                   if (stream != null)
                   {
                       var result = new HttpResponseMessage(HttpStatusCode.OK)
                       {
                           Content = new ByteArrayContent(stream.GetBuffer())
                       };
                       result.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
                       {
                           FileName = filename
                       };
                       result.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");

                       return result;
                   }
               
           }

           return null;
       }

        #endregion

       #region Date Time Operations

       public static string CalculateTotalMinutesFromNow(DateTime futureDate)
       {
           if(futureDate != null)
           {
               return Convert.ToInt32(futureDate.Subtract(DateTime.Now).TotalMinutes).ToString();
           }
           else
           {
               return "";
           }

       }

       #endregion

       #region Misc

       public static string Base64Encode(string plainText)
       {
           var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
           return System.Convert.ToBase64String(plainTextBytes);
       }

       //public static string filterOutHTML(string input)
       //{
       //    Regex regex = new Regex(@"(.*<\s*body[^>]*>)|(<\s*/\s*body\s*\>.+)");
       //    Match match = regex.Match(input);
       //    if (match.Success)
       //    {
       //        return Regex.Replace(match.Value, "<.*?>", String.Empty);
       //    }
       //    else
       //    {
       //        return Regex.Replace(input, "<.*?>", String.Empty);
       //    }
       //}

        // Methods to filter out excluded words listed in Excluded words text file in app data folder.
        // This will generate a list of words from article contents text without excluded words.
        // Then this list will fed into elastic search JSON's suggestion feild.
        public static string[] filterKeywordsFromText(String text)
        {
            try
            {
                string[] keywords = new string[] { };

                if (text != null && text != "")
                {
                    // listr of article content's words list
                    string[] arrTextWords = text.Split(' ');

                    if(arrTextWords != null && arrTextWords.Length > 0)
                    {
                        // excluded words file path
                        var excludedFilePath = "";//HttpContext.Current.Server.MapPath(CAppSettings.GetConfigurationValue("ExcludedWordsFile", true));

                        if (excludedFilePath != null && excludedFilePath != "")
                        {
                            String excludedWords = System.IO.File.ReadAllText(excludedFilePath);

                            if (excludedWords != null && excludedWords != "")
                            {
                                // List of all excluded words 
                                string[] arrExcludedWords = excludedWords.Split(',');

                                if(arrExcludedWords != null &&
                                    arrExcludedWords.Length > 0)
                                {
                                    // list of all filtered keywords
                                    var keywordTemp = arrTextWords.Where(word => arrTextWords.Select(arrayElement => arrayElement.Trim()).Any(value => !(arrExcludedWords.Contains(value))));

                                    keywords = keywordTemp.ToArray();
                                }
                            }
                        }
                    }
                }

                return keywords;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }

        #endregion

        #region Error Handling

        public static ErrorProp GetError(string Code, string Message)
        {
            ErrorProp error = GetError(Code);

            if(Message != null &&
                Message != "")
            {
                error.ErrorDetail = Message;
            }

            return error;
        }
        public static  ErrorProp GetError(string Code)
        {
            ErrorProp error = new ErrorProp();

            ResourceManager rm = new ResourceManager("KMS.Authoring.Core.ErrorMsg", 
                Assembly.GetExecutingAssembly());
            string errMsg = rm.GetString(Code);

            if(errMsg != null &&
                errMsg != "")
            {
                error.ErrorCode = Code;
                error.ErrorDetail = errMsg;
            }

            return error;
        }

        #endregion

        #region Password Handling

        public static string GeneratePasswordString()
        {
            var length = 8;

            const string lower = "abcdefghijklmnopqrstuvwxyz";
            const string upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            const string number = "1234567890";
            const string special = "!@#$%^&*?_~()";

            var middle = length / 2;
            StringBuilder res = new StringBuilder();
            Random rnd = new Random(Guid.NewGuid().GetHashCode());
            while (0 < length--)
            {
                if (middle == length)
                {
                    res.Append(number[rnd.Next(number.Length)]);
                }
                else if (middle - 1 == length)
                {
                    res.Append(special[rnd.Next(special.Length)]);
                }
                else
                {
                    if (length % 2 == 0)
                    {
                        res.Append(lower[rnd.Next(lower.Length)]);
                    }
                    else
                    {
                        res.Append(upper[rnd.Next(upper.Length)]);
                    }
                }
            }
            return res.ToString();
        }

        #endregion




        public static string HTMLToText(string HTMLCode)
        {
            string retVal = string.Empty;
            try
            {
                // Remove new lines since they are not visible in HTML
                HTMLCode = HTMLCode.Replace("\n", " ");

                // Remove tab spaces
                HTMLCode = HTMLCode.Replace("\t", " ");

                // Remove multiple white spaces from HTML
                HTMLCode = Regex.Replace(HTMLCode, "\\s+", " ");

                // Remove HEAD tag
                HTMLCode = Regex.Replace(HTMLCode, "<head.*?</head>", ""
                                    , RegexOptions.IgnoreCase | RegexOptions.Singleline);

                // Remove any JavaScript
                HTMLCode = Regex.Replace(HTMLCode, "<script.*?</script>", ""
                  , RegexOptions.IgnoreCase | RegexOptions.Singleline);

                // Replace special characters like &, <, >, " etc.
                StringBuilder sbHTML = new StringBuilder(HTMLCode);
                // Note: There are many more special characters, these are just
                // most common. You can add new characters in this arrays if needed
                string[] OldWords = { "&nbsp;", "&amp;", "&quot;", "&lt;", "&gt;", "&reg;", "&copy;", "&bull;", "&trade;" };
                string[] NewWords = { " ", "&", "\"", "<", ">", "Â®", "Â©", "â€¢", "â„¢" };
                for (int i = 0; i < OldWords.Length; i++)
                {
                    sbHTML.Replace(OldWords[i], NewWords[i]);
                }

                // Check if there are line breaks (<br>) or paragraph (<p>)
                sbHTML.Replace("<br>", "\n<br>");
                sbHTML.Replace("<br ", "\n<br ");
                sbHTML.Replace("<p ", "\n<p ");

                // Finally, remove all HTML tags and return plain text
                return System.Text.RegularExpressions.Regex.Replace(sbHTML.ToString(), "<[^>]*>", "");
            }
            catch (Exception)
            {
                return HTMLCode;
                //throw;
            }

           
        }




      



    }



}
