﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OneClick.KM.Authoring.Core.Utility
{
    public class CustomLogs
    {
        //public static void LoginLogEnabledForClient(string Message)
        //{
        //    if (!String.IsNullOrEmpty(AppSettings.GetConfigurationValue("LoginLog")))
        //    {
        //        if (AppSettings.GetConfigurationValue("LoginLog") == "Y")
        //        {
        //            try
        //            {
        //                if (!String.IsNullOrEmpty(AppSettings.GetConfigurationValue("LoginLogFilePath")))
        //                {
        //                    var Path = AppSettings.GetConfigurationValue("LoginLogFilePath");
        //                    if (!System.IO.Directory.Exists(Path))
        //                        System.IO.Directory.CreateDirectory(Path);
        //                    //var SW = new System.IO.StreamWriter(Path + @"\UserLoginLog.txt", true);
        //                    //SW.WriteLine(Message);
        //                    //SW.Close();
        //                    StreamWriter sw = null;
        //                    string logFile = Path + "\\" + DateTime.Now.ToString("ddMMyyyy") + ".txt";
        //                    if (!System.IO.File.Exists(logFile))
        //                    {
        //                        System.IO.File.Create(logFile).Close();
        //                    }
        //                    sw = new StreamWriter(logFile, true);
        //                    sw.WriteLine(DateTime.Now.ToString() + ": " + Message);
        //                    sw.Flush();
        //                    sw.Close();
        //                }
        //            }
        //            catch (Exception exception)
        //            {
        //                throw exception;
        //            }
        //        }

        //    }
        //}
    }
}