﻿
using System;
using System.Configuration;
using System.Text;
using System.Web;
using OneClick.KM.Authoring.Core.Security;

namespace OneClick.KM.Authoring.Core.Utility
{
    public class KMSAppSettings
    {

        private static readonly string _clientmgmtApi = "ClientMgmtApi";
        private static readonly string _authoringApi = "AuthoringApi";
        private static readonly string _oneClickKmAuthoringApi = "OneClickKmAuthoringApi";
        private static readonly string _listCountConfig = "ListCountConfig";
        private static readonly string _hostFullUrl = "HostFullUrl";

        private static readonly string _hostName = "HostName";
        private static readonly string _hostType = "HostType";
        private static readonly string _PassCsc = "PassCsc";
        private static readonly string _imageMaxSizeUpload = "ImageMaxSizeUpload";
        private static readonly string _logoMaxSizeUpload = "LogoMaxSizeUpload";
        private static readonly string _attachmentMaxSizeUpload = "AttachmentMaxSizeUpload";
        private static readonly string _LogoWidthHeightUpload = "LogoWidthHeightUpload";


        private static readonly string _GhWorkflow = "GhWorkflow";
        private static readonly string _IsCoverPage = "IsCoverPage"; 

        private static readonly string _imageBankThumbDimension = "ImgThumbDim";


        private static readonly string _SimulatorAPI= "SimulatorAPI";
        private static readonly string _SimApiUserName = "SimApiUserName";
        private static readonly string _SimApiPassword = "SimApiPassword";

        /// <summary>
        /// Get the ShortCode of the Client
        /// </summary>
        /// <returns>Get the ShortCode of the Client</returns>
        public static string GetClientShortCode()
        {
            string preHost = CAppSettings.GetConfigurationValue(_hostName);
            Uri currHost = HttpContext.Current.Request.Url;
            //Uri currHost =  new Uri("http://voda.oneclick.info/", UriKind.Absolute); //HttpContext.Current.Request.Url;
            // Match the pre-define host name with the current host name
            // Thats means, multiple clients useing same login
            if (string.Equals(preHost, currHost.Host, StringComparison.OrdinalIgnoreCase))
            {
                return string.Empty;
            }
            else
            {
                // Check the application running for PAAS or SAAS 
                if (HostType() == "PAAS")
                {
                    // get the shortcode of the client 
                    return PassCsc();
                }
                else
                {
                    // get shortcode from the host url (abc.example.com) of the client 
                    // abc is a shortcode of the client                    
                    return GetSubDomain(currHost);

                }
            }
        }

        /// <summary>
        /// Get the subdomain by filtering in the host url
        /// </summary>
        /// <param name="url">mandatory parameter</param>
        /// <param name="defaultValue"> It is an optional parameter</param>
        /// <returns>String</returns>
        public static string GetSubDomain(Uri url, string defaultValue = "")
        {
            string subdomain = defaultValue;

            if (url.HostNameType == UriHostNameType.Dns)
            {
                string host = url.Host;
                if (host.Split('.').Length > 2)
                {
                    int index = host.IndexOf(".");
                    int lastIndex = host.LastIndexOf(".");
                    subdomain = index.Equals(lastIndex) ? defaultValue : host.Substring(0, index);
                }
            }

            return subdomain;
        }


        public static string GhWorkflow()
        {
            return CAppSettings.GetConfigurationValue(_GhWorkflow);
        }

        public static string IsCoverPage()
        {
            return CAppSettings.GetConfigurationValue(_IsCoverPage);
        }

        /// <summary>
        /// Host Type means client using our application as PAAS or SAAS Based
        /// </summary>
        /// <returns></returns>
        public static string HostType()
        {
            return CAppSettings.GetConfigurationValue(_hostType);
        }

        public static string PassCsc()
        {
            return CAppSettings.GetConfigurationValue(_PassCsc);
        }


        /// <summary>
        /// This method is provide the api url for client management
        /// </summary>
        /// <returns></returns>
        public static string ClientMgmtApi()
        {
            return CAppSettings.GetConfigurationValue(_clientmgmtApi);
        }

        public static string AuthoringApi()
        {
            return CAppSettings.GetConfigurationValue(_authoringApi);
        }

        public static string OneClickKmAuthoringApi()
        {
            return CAppSettings.GetConfigurationValue(_oneClickKmAuthoringApi);
        }

        public static string ListCountConfig()
        {
            return CAppSettings.GetConfigurationValue(_listCountConfig);
        }
        public static string HostFullUrl()
        {
            return CAppSettings.GetConfigurationValue(_hostFullUrl);
        }

        public static string GetHost()
        {
            string urlHost = CAppSettings.GetConfigurationValue("HostUrl");
            if (!string.IsNullOrWhiteSpace(urlHost))
            {
                return urlHost;
            }
            else
            {
                return HttpContext.Current.Request.Url.Host;
            }
        }
        public static string GetPortalHost()
        {
            string urlHost = CAppSettings.GetConfigurationValue("PortalHostUrl");
            if (!string.IsNullOrWhiteSpace(urlHost))
            {
                return urlHost;
            }
            else
            {
                return HttpContext.Current.Request.Url.Host;
            }
        }

        public static string GetPoweredBy()
        {
            return CAppSettings.GetConfigurationValue("PoweredBy");
        }

        public static string GetModuleCode()
        {
            return CAppSettings.GetConfigurationValue("ModuleCode");
        }
        //public static string GetClientCode()
        //{
        //    return CAppSettings.GetConfigurationValue("ClientCode");
        //}

        public static string GetToolTipMaxLength()
        {
            return CAppSettings.GetConfigurationValue("ToolTipMaxCharLength");
        }

        public static string ImageMaxSizeUpload()
        {
            return CAppSettings.GetConfigurationValue(_imageMaxSizeUpload);
        }

        public static string LogoMaxSizeUpload()
        {
            return CAppSettings.GetConfigurationValue(_logoMaxSizeUpload);
        }

        public static string AttachmentMaxSizeUpload()
        {
            return CAppSettings.GetConfigurationValue(_attachmentMaxSizeUpload);
        }

        public static string LogoWidthHeightUpload()
        {
            return CAppSettings.GetConfigurationValue(_LogoWidthHeightUpload);
        }
        public static string SimulatorAPI()
        {
            return CAppSettings.GetConfigurationValue(_SimulatorAPI);
        }

        public static string SimulatorAPIUserName()
        {
            return CAppSettings.GetConfigurationValue(_SimApiUserName);
        }
        public static string SimulatorAPIPassword()
        {
            return CAppSettings.GetConfigurationValue(_SimApiPassword);
        }

        public static string LogFormatter(string UserId, string UserName, DateTime RequestTime, long ResponseMillis, string Method, string RequestBody, string ResponseBody)
        {
            StringBuilder msg = new StringBuilder();
            msg.Append("\r\n\n================================ Start ======================================  \n");
            msg.Append("\r\nUserId         : " + UserId);
            msg.Append("\r\nUserName       : " + UserName);
            msg.Append("\r\nRequestTime    : " + RequestTime);
            msg.Append("\r\nResponseMillis : " + ResponseMillis);
            msg.Append("\r\nURL            : " + Method);
            msg.Append("\r\nRequestBody    : " + RequestBody);
            msg.Append("\r\nResponseBody   : " + ResponseBody);
            msg.Append("\r\n\n================================ End ======================================  \n");
            return msg.ToString();
        }


        public static Tuple<int, int> ImageThumbDimWidthHeight()
        {
            string imgdimWidthHeight = CAppSettings.GetConfigurationValue(_imageBankThumbDimension);
            var arr = imgdimWidthHeight.Split(',');
            int width = Convert.ToInt32(arr[0]);
            int height = Convert.ToInt32(arr[0]);
            return new Tuple<int, int>(width, height);
        }

    }
}